/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expthis.responsesed written
 * permission of Wyplay.
 */

// Load module
var Controller = Container.parentControllerWithDefaultApi;
var util = require('util');

// Create intermediate class that receive sub APIs on its prototype
var ControllerWithSubscriberSubDocApis = function (params) {
  ControllerWithSubscriberSubDocApis.super_.call(this, params);
};
util.inherits(ControllerWithSubscriberSubDocApis, Controller);
ControllerWithSubscriberSubDocApis.prototype.subDocApisParams = [
  {
    methodName: 'devices',
    valueName: 'devices',
    fieldName: 'devices'
  },
  {
    methodName: 'profiles',
    valueName: 'profiles',
    fieldName: 'profiles'
  },
  {
    methodName: 'deviceInstances',
    valueName: 'deviceInstances',
    fieldName: 'deviceInstances'
  }
];

// Create Subscriber controller
var Subscriber = function (params) {
  'use strict';
  Subscriber.super_.call(this, params);
};

util.inherits(Subscriber, ControllerWithSubscriberSubDocApis);

// Default model
Subscriber.prototype.getDefaultModel = function (values) {
  'use strict';
  return Container.subscriber.model.subscriber;
}

// Default subscriberId
Subscriber.prototype.getDefaultFilter = function (values) {
  'use strict';
  return {_id: values.id};
}

/**
 * @typedef {Object} profiles
 * @property {string} [label] - Label
 * @property {string} [birthdate] - Birth date
 * @property {string} [position] - Position
 * @property {string} [password] - Password
 */

/**
 * @typedef {Object} deviceInstances
 * @property {string} [deviceId] - Device id
 * @property {string} [applicationId] - Application id
 */

/**
 * @typedef {Object} devices
 * @property {string} uuid - uuid
 * @property {string} label - Label
 * @property {number} status - Status
 *
 */

/**
 * @typedef {Object} subscriberValues
 * @property {string} _id - Record id
 * @property {profiles[]} profiles - Profiles
 * @property {deviceInstances[]} deviceInstances - Device Instances
 * @property {devices[]} devices - Devices
 */


/**
 * @bma subscriber
 * @method subscriber - readAll
 * @desc /{wyclubToken}/subscriber/subscribers
 * @httpmethod GET
 * @summary subscriber.readAll — Read all subscribers
 *
 * @param {Number} response.body.code - Operation result code, 0 indicates a success, any other value a failure
 * @param {String} response.body.content - Operation result human readable message (if any)
 * @param {subscriberValues[]} response.body.data - Operation result data
 * @param {string} response.body.data.id - Id of the subscriber
 *
 * @param {string} request.params.wyclubToken - A session ID
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 503 Service Unavailable
 *
 * @errorcode {200} 0 Success
 * @errorcode {503} 105 Error during reading
 *
 *
 */

/**
 * @bma subscriber
 * @method subscriber - read
 * @desc /{wyclubToken}/subscriber/subscriber/{id}
 * @httpmethod GET
 * @summary subscriber.read — Read a subscriber
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {string} request.params.id - The ID of the subscriber
 *
 * @param {Number} response.body.code - Operation result code, 0 indicates a success, any other value a failure
 * @param {String} response.body.content - Operation result human readable message (if any)
 * @param {subscriberValues} response.body.data - Operation result data
 * @param {string} response.body.data.id - Id of the subscriber
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Not found
 * @httpcode 503 Service Unavailable
 *
 * @errorcode {200} 0 Success
 * @errorcode {404} 104 Non-existent subscriber
 * @errorcode {503} 105 Error during reading
 *
 *
 */

/**
 * @bma subscriber
 * @method subscriber - create
 * @desc /{wyclubToken}/subscriber/subscriber
 * @httpmethod POST
 * @summary subscriber.create — Create new subscriber
 *
 * @param {string} request.params.wyclubToken - A WyClub token
 * @param {subscriberValues} request.body - subscriber details
 *
 * @param {Number} response.body.code - Operation result code, 0 indicates a success, any other value a failure
 * @param {String} response.body.content - Operation result human readable message (if any)
 * @param {subscriberValues} response.body.data - Operation result data
 * @param {string} response.body.data.id - Id of the subscriber
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 503 Service Unavailable
 *
 * @errorcode {200} 0 Success
 * @errorcode {503} 100 Error during creation
 */


/**
 * @bma subscriber
 * @method subscriber - update
 * @desc /{wyclubToken}/subscriber/subscriber/{id}
 * @httpmethod PATCH
 * @summary subscriber.update — Update a subscriber
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.id - The ID of the new subscriber
 * @param {subscriberValues} request.body - subscriber details
 *
 * @param {Number} response.body.code - Operation result code, 0 indicates a success, any other value a failure
 * @param {String} response.body.content - Operation result human readable message (if any)
 * @param {subscriberValues} response.body.data - Operation result data
 * @param {string} response.body.data.id - Id of the subscriber
 *
 * @httpcode 200 Success
 * @httpcode 503 Service Unavailable
 *
 */

/**
 * @bma subscriber
 * @method subscriber - delete
 * @desc /{wyclubToken}/subscriber/subscriber/{id}
 * @httpmethod DELETE
 * @summary subscriber.delete — Delete a subscriber
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.id - The ID of the new subscriber
 *
 * @param {Number} response.body.code - Operation result code, 0 indicates a success, any other value a failure
 * @param {String} response.body.content - Operation result human readable message (if any)
 * @param {integer} response.body.data - Operation result data, 1 when success
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Not found
 * @httpcode 503 Service Unavailable
 */


/**
 * @bma subscriber
 * @method subscriber - deleteDevices
 * @desc /{wyclubToken}/subscriber/subscriber/{id}/device
 * @httpmethod DELETE
 * @summary subscriber.deleteDevices — Remove device from subscriber
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.id - The catalog ID
 * @param {array} [request.body.devices] - Array of devices
 * @param {string} request.body.devices.stbId - STB Id
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Not Found
 *
 * @errorcode {200} 0 Success
 * @errorcode {403} 5 Resource don't have required parameter.
 * @errorcode {404} 104 Resource don't exist in database
 */

/**
 * @bma subscriber
 * @method subscriber - updateDevices
 * @desc /{wyclubToken}/subscriber/subscriber/{id}/device
 * @httpmethod PATCH
 * @summary subscriber.updateDevices — Update device for subscriber
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.id - The catalog ID
 * @param {array} [request.body.devices] - Array of devices
 * @param {string} request.body.devices.stbId - STB Id
 *
 * @param {string} [request.body.devices.label] - Label
 * @param {number} [request.body.devices.status] - Status
 * @param {string} [request.body.devices.stbSN] - Setupbox serial number
 * @param {string} [request.body.devices.stbMACAddress] - STB MAC address
 * @param {string} [request.body.devices.stbCertificateSN] - STB certificate serial number
 * @param {number} [request.body.devices.stbCertificateExpiry] - STB certificate expiry
 * @param {boolean} [request.body.devices.stbCertificateRevokedFlag] -STB certificate revoked flag
 * @param {string} [request.body.devices.stbSoftwareVersion] - STB software version
 * @param {string} [request.body.devices.stbBootloader2Version] -STB bootloader version
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Not Found
 *
 * @errorcode {200} 0 Success
 * @errorcode {403} 5 Resource don't have required parameter.
 * @errorcode {404} 104 Resource don't exist in database
 */


/**
 * @bma subscriber
 * @method subscriber - addDevices
 * @desc /{wyclubToken}/subscriber/subscriber/{id}/device
 * @httpmethod POST
 * @summary subscriber.addDevices— Create a device for subscriber
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.id - The catalog ID
 * @param {array} [request.body.devices] - Array of devices
 * @param {string} request.body.devices.stbId - STB Id
 *
 * @param {string} request.body.devices.label - Label
 * @param {number} request.body.devices.status - Status
 * @param {string} request.body.devices.stbSN - Setupbox serial number
 * @param {string} request.body.devices.stbMACAddress - STB MAC address
 * @param {string} request.body.devices.stbCertificateSN - STB certificate serial number
 * @param {number} request.body.devices.stbCertificateExpiry - STB certificate expiry
 * @param {boolean} [request.body.devices.stbCertificateRevokedFlag] -STB certificate revoked flag
 * @param {string} [request.body.devices.stbSoftwareVersion] - STB software version
 * @param {string} [request.body.devices.stbBootloader2Version] -STB bootloader version
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Not Found
 *
 * @errorcode {200} 0 Success
 * @errorcode {403} 5 Resource don't have required parameter.
 * @errorcode {404} 104 Resource don't exist in database
 */

/**
 * @bma subscriber
 * @method subscriber - deleteDeviceInstances
 * @desc /{wyclubToken}/subscriber/subscriber/{id}/deviceInstance
 * @httpmethod DELETE
 * @summary subscriber.deleteDeviceInstances — Remove device instance from subscriber
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.id - The catalog ID
 * @param {array} [request.body.deviceInstances] - Array of devices
 * @param {string} request.body.deviceInstances.deviceId - deviceId Id
 * @param {string} request.body.deviceInstances.applicationId - application Id
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Not Found
 *
 * @errorcode {200} 0 Success
 * @errorcode {403} 5 Resource don't have required parameter.
 * @errorcode {404} 104 Resource don't exist in database
 */

/**
 * @bma subscriber
 * @method subscriber - addDeviceInstances
 * @desc /{wyclubToken}/subscriber/subscriber/{id}/deviceInstance
 * @httpmethod POST
 * @summary subscriber.addDeviceInstances— Create a device instance for subscriber
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.id - The catalog ID
 * @param {array} [request.body.deviceInstances] - Array of devices
 * @param {string} request.body.deviceInstances.deviceId - device id
 * @param {string} request.body.deviceInstances.applicationId - device id
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Not Found
 *
 * @errorcode {200} 0 Success
 * @errorcode {403} 5 Resource don't have required parameter.
 * @errorcode {404} 104 Resource don't exist in database
 */

/**
 * @bma subscriber
 * @method subscriber - deleteProfiles
 * @desc /{wyclubToken}/subscriber/subscriber/{id}/profile
 * @httpmethod DELETE
 * @summary subscriber.deleteProfiles — Remove profile from subscriber
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.id - The catalog ID
 * @param {array} [request.body.profiles] - Array of profiles
 * @param {string} request.body.profiles.label - Label
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Not Found
 *
 * @errorcode {200} 0 Success
 * @errorcode {403} 5 Resource don't have required parameter.
 * @errorcode {404} 104 Resource don't exist in database
 */

/**
 * @bma subscriber
 * @method subscriber - updateProfiles
 * @desc /{wyclubToken}/subscriber/subscriber/{id}/profile
 * @httpmethod PATCH
 * @summary subscriber.updateProfiles — Update device for subscriber
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.id - The catalog ID
 * @param {array} [request.body.profiles] - Array of devices
 * @param {string} request.body.profiles.label - Label
 *
 * @param {string} [request.body.profiles.birthdate] - Birth date
 * @param {string} [request.body.profiles.position] - Position
 * @param {string} [request.body.profiles.password] - Password
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Not Found
 *
 * @errorcode {200} 0 Success
 * @errorcode {403} 5 Resource don't have required parameter.
 * @errorcode {404} 104 Resource don't exist in database
 */

/**
 * @bma subscriber
 * @method subscriber - addProfiles
 * @desc /{wyclubToken}/subscriber/subscriber/{id}/profile
 * @httpmethod POST
 * @summary subscriber.addProfiles— Create a profile for subscriber
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.id - The catalog ID
 * @param {array} [request.body.profiles] - Array of devices
 * @param {string} request.body.profiles.label - Label
 *
 * @param {string} [request.body.profiles.birthdate] - Birth date
 * @param {string} [request.body.profiles.position] - Position
 * @param {string} [request.body.profiles.password] - Password
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Not Found
 *
 * @errorcode {200} 0 Success
 * @errorcode {403} 5 Resource don't have required parameter.
 * @errorcode {404} 104 Resource don't exist in database
 */

module.exports = Subscriber;
