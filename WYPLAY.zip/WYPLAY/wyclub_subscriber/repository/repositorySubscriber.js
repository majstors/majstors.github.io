/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/* jshint -W079, -W098 */

var Repository = Container.parentRepository;
var Subscriber = function (request) {
  Repository.call(this, request);
  this.mongoCollection = Container.subscriber.model.subscriber;
  this.redisCollection = '';
  this.cacheCollection = 'subscriber';
};

Subscriber.prototype = Object.create(Repository.prototype);

/*
 * @method Subscriber - deviceExists
 * @summary Subscriber.deviceExists — Indicate if at least one device exists in the returned subscribers
 * @param {Object} query - The query to execute
 * @param {Function} callback - Callback called with one param which value is true if at least on device exist, false
 * otherwise.
 */
Subscriber.prototype.deviceExists = function (query, callback) {
  this.read(query, function (err, value) {
    var valid = !!(!err && !!value);
    if (valid && !!value.devices) {
      callback(true);
    } else {
      callback(false);
    }
  });
};

module.exports = Subscriber;
