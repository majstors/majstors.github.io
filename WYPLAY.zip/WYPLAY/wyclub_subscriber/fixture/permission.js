// List of default permissions
// type: right to save
// group: list of tag(s) from the core that are attached to the permission
var permission = [
  {
    "group": [
      "core_tag"
    ],
    "type": "read"
  },
  {
    "group": [
      "core_tag"
    ],
    "type": "write"
  }
];

module.exports = permission;