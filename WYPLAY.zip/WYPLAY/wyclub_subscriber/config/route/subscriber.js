var Route = Container.parentRoute;

module.exports = function () {
  'use strict';

  Container.express.get('/:wyclubToken/subscriber/subscribers', function (request, response) {
    Route.process(request, response, 'subscriber', 'subscriber', 'readAll');
  });

  Container.express.get('/:wyclubToken/subscriber/subscriber/:id', function (request, response) {
    Route.process(request, response, 'subscriber', 'subscriber', 'read');
  });

  Container.express.post('/:wyclubToken/subscriber/subscriber', function (request, response) {
    Route.process(request, response, 'subscriber', 'subscriber', 'create');
  });

  Container.express.patch('/:wyclubToken/subscriber/subscriber/:id', function (request, response) {
    Route.process(request, response, 'subscriber', 'subscriber', 'update');
  });

  Container.express.delete('/:wyclubToken/subscriber/subscriber/:id', function (request, response) {
    Route.process(request, response, 'subscriber', 'subscriber', 'delete');
  });

  Container.express.get('/:wyclubToken/subscriber/subscriber/:id', function (request, response) {
    Route.process(request, response, 'subscriber', 'subscriber', 'read');
  });

  Container.express.delete('/:wyclubToken/subscriber/subscriber/:id/device', function (request, response) {
    Route.process(request, response, 'subscriber', 'subscriber', 'deleteDevices');
  });

  Container.express.patch('/:wyclubToken/subscriber/subscriber/:id/device', function (request, response) {
    Route.process(request, response, 'subscriber', 'subscriber', 'updateDevices');
  });

  Container.express.post('/:wyclubToken/subscriber/subscriber/:id/device', function (request, response) {
    Route.process(request, response, 'subscriber', 'subscriber', 'addDevices');
  });

  Container.express.delete('/:wyclubToken/subscriber/subscriber/:id/deviceInstance', function (request, response) {
    Route.process(request, response, 'subscriber', 'subscriber', 'deleteDeviceInstances');
  });

  Container.express.post('/:wyclubToken/subscriber/subscriber/:id/deviceInstance', function (request, response) {
    Route.process(request, response, 'subscriber', 'subscriber', 'addDeviceInstances');
  });

  Container.express.delete('/:wyclubToken/subscriber/subscriber/:id/profile', function (request, response) {
    Route.process(request, response, 'subscriber', 'subscriber', 'deleteProfiles');
  });

  Container.express.patch('/:wyclubToken/subscriber/subscriber/:id/profile', function (request, response) {
    Route.process(request, response, 'subscriber', 'subscriber', 'updateProfiles');
  });

  Container.express.post('/:wyclubToken/subscriber/subscriber/:id/profile', function (request, response) {
    Route.process(request, response, 'subscriber', 'subscriber', 'addProfiles');
  });
};