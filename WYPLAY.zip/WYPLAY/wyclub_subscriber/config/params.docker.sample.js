var params = {};

params.databaseUrl = process.env.MONGODB_PORT_27017_TCP_ADDR;
params.databaseName = 'static';
params.databaseUser = 'core';
params.databasePassword= 'core';
params.databaseAuthdb = 'core';

module.exports = params;
