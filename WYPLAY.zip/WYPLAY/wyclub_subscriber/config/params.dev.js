var params = {};

params.databaseUrl = "localhost";
params.databaseName = "static";

module.exports = params;
