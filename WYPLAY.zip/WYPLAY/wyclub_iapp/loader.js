'use strict';

var loader = {};
module.exports = loader;
