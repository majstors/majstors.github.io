iApp Module


Introduction
============
Iapp is a module used to manage catalog (create, update, delete, read) on
the WyClub.


API Documentation
=================
.. toctree::
   :maxdepth: 1
   :glob:

   api/*
   api/statuscodes/*
