//
// Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//

var validate = require('mongoose-validator');
var async = require('async');

var modelExist = function (self, modelName, value, findObj, valid) {
  if (!value || !value.length) {
    return valid(true);
  }

  var model = Container[modelName].model[modelName];
  var errNullIapp = [];

  var queueFile = async.priorityQueue(function (item, callback) {
    var findItem = {};
    findItem[findObj.src] = item[findObj.dest];
    model.findOne(findItem, function (err, result) {
      if (!result) {
        errNullIapp.push(item);
      }
      callback(err, result);
    });
  }, 1);

  queueFile.drain = function () {
    if (errNullIapp.length) {
      var err = {
        path: 'iapps',
        message: modelName + ' doesn\'t exist in ' + modelName + ' database',
        type: 'NO_' + modelName.toUpperCase(),
        value: JSON.stringify(errNullIapp)
      };
      self.invalidate('iapps', err, errNullIapp);
      valid(true);
    } else {
      valid(true);
    }
  };

  value.forEach(function (item) {
    queueFile.push(item);
  });
};
var checkBouquetKey = function(value,valid) {
  if(value == null) {
    return valid(false);
  }

  var self = this;
  var errors = [];
  var lineupModel = Container.lineup.model.lineup;

  var queue = async.priorityQueue(function(item,callback) {
    lineupModel.findOne({bouquetKey: item}, function(err,found) {
      if(!found) {
        errors.push(item);
      }
      return callback(err,found);
    });
  },1);
  queue.drain = function() {
    if(errors.length) {
      self.invalidate('catalog', 'bouquetKey '+errors+' does not exist in lineups collection');
      return valid(false);
    } else {
      return valid(true);
    }
  };
  queue.push(value);
};

var inImm = function (self, value) {
  if (typeof value !== 'boolean') {
    return false;
  }
  if (self.inImm && !self.immOrder) {
    self.invalidate('iapps', 'immOrder is mandatory if inImm is true', self);
  }
  return true;
};

var valueHasGreenButton = function (value) {
  var self = this;
  if (self.greenButton === null || self.greenButton === undefined) {
    self.invalidate('iapps channel', 'GreenButton doesn\'t activate', null)
    return false;
  } else {
    return true;
  }
};

var inLineup = function (self, value, bouquetKey, valid) {
  if (value.length) {
    var lineupModel = Container.lineup.model.lineup;
    lineupModel.findOne({'bouquetKey': bouquetKey}, function (err, result) {

      if (!result) {

        var errR =  new Container.mongoose.Error.ValidatorError({
          path: 'iapps',
          message: 'Lineup associated with this catalog with bouquetKey: ' + bouquetKey + ' does not exist',
          type: 'NO_LINEUP',
          value: value
        });
        self.invalidate('iapps', errR, value);
        valid(false)

      } else {
        value.forEach(function (iappValue) {

          var exists = false;

          if (iappValue.channels.length) {
            iappValue.channels.forEach(function (service) {
              result.lineupList.forEach(function (value) {
                if (service.serviceKey == value.serviceKey) {
                  exists = true;
                }
              });
            });
          } else {
            exists = true;
          }

          if (!exists) {
            var errR =  new Container.mongoose.Error.ValidatorError({
              path: 'iapps',
              message: 'iApp doesn\'t exist in selected lineup with bouquetKey: ' + bouquetKey,
              type: 'NOT_IN_LINEUP',
              value: iappValue
            });
            self.invalidate('iapps', errR, iappValue);
            valid(false)
          } else {
            valid(true)
          }

        });
      }
    })
  } else {
    valid(true);
  }
};

var serviceChannelSchema = Container.parentMongooseSchemaWithId({
  serviceKey: {
    type: String,
    required: true
  },
  status: {
    type: String,
    required: true
  },
  greenButton: {
    type: {
      url: {
        type: String,
        required: true
      },
      x: {
        type: Number,
        required: true
      },
      y: {
        type: Number,
        required: true
      }
    }
  },
  inviteButton: {
    type: {
      url: {
        type: String,
        required: true
      },
      x: {
        type: Number,
        required: true
      },
      y: {
        type: Number,
        required: true
      }
    },
    validate: valueHasGreenButton
  },
  autolaunchDelay: {
    type: Number
  },
  autolaunch: {
    type: Boolean
  }
});

var serviceiAppSchema = Container.parentMongooseSchemaWithId({
  appId: {
    type: String,
    required: true
  },
  inImm: {
    type: Boolean,
    required: true,
    validate: function (value) {
      return inImm(this, value);
    }
  },
  immOrder: {
    type: String
  },
  channels: {
    type: [serviceChannelSchema],
    validate: function (value, valid) {
      modelExist(this, 'channel', value, {src: 'serviceKey', dest: 'serviceKey'}, valid);
    },
    uniqueKey: [
      ['serviceKey']
    ]
  }
});

var catalogSchema = Container.parentMongooseSchemaWithId({
  catalogId: {
    type: Number,
    required: true,
    unique: true
  },
  bouquetKey: {
    type: Number,
    validate: checkBouquetKey,
    required: true,
    isInteger: true
  },
  name: {
    type: String,
    required: true
  },
  iapps: {
    type: [serviceiAppSchema],
    validate: function (value, valid) {
      var self = this
      inLineup(self, value, this.bouquetKey, function (isValid) {
        if (isValid) {
          modelExist(self, 'iApp', value, {src: '_id', dest: 'appId'}, valid);
        } else {
          valid(true);
        }
      });
    },
    uniqueKey: [
      ['appId']
    ]
  }
});

var catalog = Container.iApp.db.model('catalog', catalogSchema);

module.exports = catalog;
