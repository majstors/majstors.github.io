var notificationSchema = Container.parentMongooseSchemaWithId({
  bouquetId:{
    type: Number,
    isInteger: true
  },
  timestamp: {
    type: Number,
    required: true
  },
  iAppId: {
    type: String,
    required: true
  },
  channels: {
    type: String,
    required: true
  },
  state: {
    type: Boolean,
    required: true
  },
  data: {
    type : String,
    required : true
  }
});

var notification = Container.iApp.db.model('notification', notificationSchema);

module.exports = notification;
