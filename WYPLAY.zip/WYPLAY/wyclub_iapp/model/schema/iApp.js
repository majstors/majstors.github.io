/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expthis.responsesed written
 * permission of Wyplay.
 */

var util = require('util');
var iappTools = require('../../lib/iappTools.js');

function iAppSchema() {
  /* jshint validthis:true */
  'use strict';

  Container.parentMongooseSchemaWithId.apply(this, arguments);

  this.add({
    label: {
      type: String,
      required: true
    },
    description: {
      type: String,
      required: true
    },
    launchingMessage: {
      type: String
    },
    url: {
      type: 'string',
      required: true
    }
  });

  // Hook to remove iApp from Catalog when iApp is deleted
  if (!Container.fixturesMode) {
    this.hook = function(doc, callback) {
      if (typeof doc !== 'object') {
        doc = {
          _id: doc
        };
      }

      iappTools.deleteIAppsFromCatalogs({}, [{
        "serviceKeyIdApp": doc._id
      }], function(err, results) {
        if (callback) {
          callback(err, results);
        }
      })
    };

    this.post('remove', this.hook);
  }

}
util.inherits(iAppSchema, Container.parentMongooseSchemaWithId);
module.exports = iAppSchema;
