var util = require('util');

function lastBouquetSchema() {
  /* jshint validthis:true */
  'use strict';

  Container.parentMongooseSchemaWithId.apply(this, arguments);

  this.add({
    key: {
      type: Number,
      isInteger: true,
      required: true
    },
    data: {
      type: String,
      required: true
    }
  });
}

util.inherits(lastBouquetSchema, Container.parentMongooseSchemaWithId);
module.exports = lastBouquetSchema;
