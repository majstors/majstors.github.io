var lastBouquetSchema = require('./schema/lastBouquet');

var lastBouquet = Container.iApp.db.model('lastBouquet', new lastBouquetSchema());
module.exports = lastBouquet;