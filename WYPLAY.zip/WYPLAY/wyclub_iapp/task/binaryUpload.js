/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */


var async = require('async');

module.exports = function (task, callback) {
  var lastBouquetModel = Container.iApp.model.lastBouquet;
  var originLinkTool = Container.originLink.lib.originLinkTool;
  async.waterfall(
    [
      function (callback) {
        originLinkTool.uploadResource(task.data, true, function (err, uploadedResource) {
          if (!!err) {
            Container.logger.log({ color: 'red', message: err});
            callback('DB_ERROR');
          } else {
            callback(null, uploadedResource);
          }
        });
      },
      function (uploadedResource, callback) {
        task.data.resourceUrl = uploadedResource.url;
        Container.resourceDelivery.lib.resourceDeliveryTool.declareResource(task.data, callback);
      },
      function (dummy, callback) {
        callback(null, 'resource ' + task.data.resourceUrl + ' sent to CDN');
        var payload = JSON.parse(task.data.data);
        lastBouquetModel.findOneAndSave(
          { key: payload.bouquetKey },
          {
            key: payload.bouquetKey,
            data: JSON.stringify(payload)
          },
          { upsert: true },
          function(err, data){
            if(err){
              Container.logger.error('Last catalog saving error:'+JSON.stringify(err))
            }
            //saving is performed async, check if needed to sync it
          });
      }
    ],
    function (err, result) {
      callback(err, result);
    });
};
