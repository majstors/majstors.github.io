/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expthis.responsesed written
 * permission of Wyplay.
 */

// Load module
var Controller = Container.parentControllerWithDefaultApi;
var catalogTools = require('./../lib/iappTools');
var util = require('util');

// Create intermediate class that receive sub APIs on its prototype
var ControllerWithCatalogSubDocApis = function(params){
  ControllerWithCatalogSubDocApis.super_.call(this, params);
};
util.inherits(ControllerWithCatalogSubDocApis, Controller);
ControllerWithCatalogSubDocApis.prototype.subDocApisParams = [
  {
    methodName: 'iapps',
    valueName: 'iapps',
    fieldName: 'iapps',
    filter: function (values) {
      return {appId: values.appId}
    },
    subDocApisParams: [
      {
        methodName: 'channels',
        valueName: 'channels',
        fieldName: 'channels'
      }
    ]
  }
];

// Create iApp catalog controller from intermediate class
var Catalog = function (params) {
  'use strict';
  Catalog.super_.call(this, params);

  // Add appId to default jsonSchema
  if (params.methodName === 'addChannels' || params.methodName === 'updateChannels' || params.methodName === 'deleteChannels') {
    this.addEntryToJsonSchema('appId', this.request.body.appId, {
      type: 'string',
      required: true
    });
  }
};
util.inherits(Catalog, ControllerWithCatalogSubDocApis);

// Default model
Catalog.prototype.getDefaultModel = function (values) {
  return Container.iApp.model.catalog;
};

// Default filter
Catalog.prototype.getDefaultFilter = function (values) {
  return {catalogId: values.catalogId};
};

/**
 * @bma iApp
 * @method catalog - update
 * @desc /{wyclubToken}/iApp/catalog/{catalogId}
 * @httpmethod PATCH
 * @summary catalog.update — Update catalog
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.catalogId - ID of a catalog
 * @param {integer} [request.body.bouquetKey] - Id of a lineup
 * @param {string} [request.body.name] - name of a catalog
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Not Found
 *
 * @errorcode {200} 0 Success
 * @errorcode {200} 5 Resource don't have required parameter.
 * @errorcode {404} 104 Resource don't exist in database
 *
 * @example {request} - Request example
 * .. sourcecode:: http
 *
 *   POST /12345678901234567890123456789012/iApp/catalog/<catalogId:integer> HTTP/1.1
 *   Accept: application/json, text/javascript
 *   Content-Type: application/json
 *
 *     {
 *       "name": "name updated"
 *     }
 *
 * @example {response} - Response example
 * .. sourcecode:: http
 *
 *   HTTP/1.1 200 OK
 *   Vary: Accept
 *   Content-Type: application/json
 *
 *     {
 *       "code": 0,
 *       "content": "success",
 *       "data": {
 *         "catalogId": 1
 *         "bouquetKey": 1
 *         "name": "name updated"
 *         "_id": "543638edd355c1de1d52103d"
 *         "iapps": [
 *           {
 *             "appId": "id"
 *             "inImm": false
 *             "immOrder": "Alphabetic"
 *             "_id": "543648d40b9f5af82774e20d"
 *             "channels": [
 *               {
 *                 "serviceKey": "id"
 *                 "status": "enable"
 *                 "greenButtonType": "toto"
 *                 "autolaunchType": 10
 *                 "haveAutolaunch": true
 *                 "haveGreenButton": false
 *                 "_id": "543648d40b9f5af82774e20e"
 *               }
 *             ]
 *           }
 *         ]
 *       }
 *     }
 */

/**
 * @bma iApp
 * @method catalog - addIapps
 * @desc /{wyclubToken}/iApp/catalog/{catalogId}/iapp
 * @httpmethod POST
 * @summary catalog.addIapps — Add new iApp in catalog
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.catalogId - ID of a catalog
 * @param {array} [request.body.iapps] - Array of iApp
 * @param {string} [request.body.iapps.appId] - ID of an iApp
 * @param {boolean} [request.body.iapps.inImm] - if display in imm
 * @param {string} [request.body.iapps.immOrder] - position of iApp in imm
 * @param {array} request.body.iapps.channels - a list of channel
 * @param {string} [request.body.iapps.channels.serviceKey] - ID of a channel
 * @param {string} [request.body.iapps.channels.status] - status of an iApp : {"enable","disable"}
 * @param {string} request.body.iapps.channels.greenButtonType - type of green button
 * @param {integer} request.body.iapps.channels.autolaunchType - type of autolaunch
 * @param {boolean} request.body.iapps.channels.haveAutolaunch - if iApp type is autolaunch
 * @param {boolean} request.body.iapps.channels.haveGreenButton - if iApp have green button
 *
 * @httpcode 200 Success
 * @httpcode 404 Not Found
 *
 * @errorcode {200} 0 Success
 * @errorcode {404} 104 Resource don't exist in database
 *
 * @example {request} - Request example
 * .. sourcecode:: http
 *
 *   POST /12345678901234567890123456789012/iApp/catalog/<catalogId:integer>/iapp HTTP/1.1
 *   Accept: application/json, text/javascript
 *   Content-Type: application/json
 *
 *     {
 *       "iapps": [
 *         {
 *           "appId": "newservice",
 *           "inImm": false,
 *           "immOrder": "immOrder",
 *           "channels": [
 *            {
 *               "serviceKey": "id",
 *               "status": "enable",
 *               "greenButtonType": "",
 *               "autolaunchType": 10,
 *               "haveAutolaunch": true,
 *               "haveGreenButton": false
 *            }
 *          ]
 *         }
 *       ]
 *     }
 *
 * @example {response} - Response example
 * .. sourcecode:: http
 *
 *   HTTP/1.1 200 OK
 *   Vary: Accept
 *   Content-Type: application/json
 *
 *     {
 *         "code": 0,
 *         "content": "success",
 *         "data": {
 *             "catalogId": 1,
 *             "bouquetKey": 1,
 *             "iapps": [
 *                 {
 *                     "appId": "service123456789",
 *                     "inImm": false,
 *                     "immOrder": "toto",
 *                     "channels": [
 *                         {
 *                             "serviceKey": "id",
 *                             "status": "enable",
 *                             "greenButtonType": "",
 *                             "autolaunchType": 10,
 *                             "haveAutolaunch": true,
 *                             "haveGreenButton": false
 *                         }
 *                     ]
 *                 },
 *                 {
 *                     "appId": "newservice",
 *                     "inImm": false,
 *                     "immOrder": "immOrder",
 *                     "channels": [
 *                         {
 *                             "serviceKey": "id",
 *                             "status": "enable",
 *                             "greenButtonType": "",
 *                             "autolaunchType": 10,
 *                             "haveAutolaunch": true,
 *                             "haveGreenButton": false
 *                         }
 *                     ]
 *                 }
 *             ]
 *         }
 *     }
 */

/**
 * @bma iApp
 * @method catalog - updateIapps
 * @desc /{wyclubToken}/iApp/catalog/{catalogId}/iapp
 * @httpmethod PATCH
 * @summary catalog.updateIapps — Update an iApp of a catalog
 *
 * @param {string} request.params.wyclubToken - A wyclubToken
 * @param {integer} request.params.catalogId - ID of a catalog
 * @param {integer} request.body.iapps - Array of iApp
 * @param {string} request.body.iapps.appId - The iApp ID
 * @param {boolean} request.body.iapps.inImm - if display in imm
 * @param {string} request.body.iapps.immOrder - position of iApp in imm
 *
 * @httpcode 200 Success
 * @httpcode 404 Not Found
 *
 * @errorcode {200} 0 Success
 * @errorcode {404} 104 Resource don't exist in database
 *
 * @example {request} - Request example
 * .. sourcecode:: http
 *
 *   PATCH /12345678901234567890123456789012/iApp/catalog/<catalogId:integer>/iapp HTTP/1.1
 *   Accept: application/json, text/javascript
 *   Content-Type: application/json
 *
 *     {
 *      "iapps": [
 *        {
 *          "appId": "service123456789",
 *          "inImm": false,
 *          "immOrder": "UpdateImmOrder"
 *        }
 *      ]
 *    }
 *
 * @example {response} - Response example
 * .. sourcecode:: http
 *
 *   HTTP/1.1 200 OK
 *   Vary: Accept
 *   Content-Type: application/json
 *
 *     {
 *      "code": 0,
 *      "content": "Success",
 *      "data": {
 *        "_id": "5448dd9cf3b31ad81e499253",
 *        "catalogId": 1,
 *        "bouquetKey": 1,
 *        "name": "Kids",
 *        "iapps": [
 *          {
 *            "appId": "service123456789",
 *            "inImm": false,
 *            "immOrder": "UpdateImmOrder",
 *            "_id" : "5448f8f4f3b31ad81e499259",
 *            "channels": [
 *   	           {
 *   	             "_id" : "543648d40b9f5af82774e20e",
 *   	             "serviceKey" : "id",
 *   	             "status" : "enable",
 *   	             "greenButtonType" : "",
 *   	             "autolaunchType" : 10,
 *   	             "haveAutolaunch" : true,
 *   	             "haveGreenButton" : false
 *   	           }
 *   	        ]
 *          }
 *        ]
 *      }
 *    }
 */

/**
 * @bma iApp
 * @method catalog - deleteIapps
 * @desc /{wyclubToken}/iApp/catalog/{catalogId}/iapp
 * @httpmethod DELETE
 * @summary catalog.deleteIapps — Remove an iapp of a catalog
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.catalogId - The Catalog ID
 * @param {array} request.body.iapps - List of Iapp ID
 * @param {string} request.body.iapps.appId - The iApp ID
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Not Found
 *
 * @errorcode {200} 0 Success
 * @errorcode {403} 5 Resource don't have required parameter.
 * @errorcode {404} 104 Resource don't exist in database
 *
 * @example {request} - Request example
 * .. sourcecode:: http
 *
 *   DELETE /12345678901234567890123456789012/iApp/catalog/<catalogId:integer>/iapp HTTP/1.1
 *   Accept: application/json, text/javascript
 *   Content-Type: application/json
 *
 *     {
 *       "iapps": [
 *         {
 *           "appId": "service123456789"
 *         }
 *       ]
 *     }
 *
 * @example {response} - Response example
 * .. sourcecode:: http
 *
 *   HTTP/1.1 200 OK
 *   Vary: Accept
 *   Content-Type: application/json
 *
 *     {
 *       "code": 0,
 *       "content": "Success",
 *       "data": {
 *         "_id": "5448dd9cf3b31ad81e499253",
 *         "catalogId": 1,
 *         "bouquetKey": 1,
 *         "name": "Kids",
 *         "iapps": []
 *       }
 *     }
 */

/**
 * @bma iApp
 * @method catalog - addChannels
 * @desc /{wyclubToken}/iApp/catalog/{catalogId}/channel
 * @httpmethod POST
 * @summary catalog.addChannels — Add channels in iapp's catalog
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.catalogId - The catalog ID
 * @param {string} request.body.appId - The iApp ID
 * @param {array} request.body.channels - The new channel
 * @param {string} request.body.channels.serviceKey - The new channel ID
 * @param {string} request.body.channels.status - status of an iApp : {"enable","disable"}
 * @param {string} request.body.channels.greenButtonType - type of green button
 * @param {integer} request.body.channels.autolaunchType - type of autolaunch
 * @param {boolean} request.body.channels.haveAutolaunch - if iApp type is autolaunch
 * @param {boolean} request.body.channels.haveGreenButton - if iApp have green button
 *
 * @httpcode 200 Success
 * @httpcode 404 Not Found
 *
 * @errorcode {200} 0 Success
 * @errorcode 104
 *
 * @example {request} - Request example
 * .. sourcecode:: http
 *
 *   POST /12345678901234567890123456789012/iApp/catalog/<catalogId:integer>/channel HTTP/1.1
 *   Accept: application/json, text/javascript
 *   Content-Type: application/json
 *
 *     {
 *       "appId": "service123456789",
 *       "channels": [
 *	       {
 *           "serviceKey" : "newchannelid",
 *           "status" : "disable",
 *           "greenButtonType" : "",
 *           "autolaunchType" : 10,
 *           "haveAutolaunch" : true,
 *           "haveGreenButton" : false
 *         }
 *       ]
 *      }
 *
 * @example {request} - Response example
 * .. sourcecode:: http
 *
 *   HTTP/1.1 200 OK
 *   Vary: Accept
 *   Content-Type: application/json
 *
 *   {
 *     "code": 0,
 *     "content": "Success",
 *     "data" : {
 *       "_id": "543638edd355c1de1d52103d",
 *       "catalogId": 1,
 *       "bouquetKey": 1,
 *       "iapps": [
 *         {
 *           "appId": "service123456789",
 *           "inImm": false,
 *           "immOrder": "UpdateImmOrder",
 *           "channels": [
 *		         {
 *			         "serviceKey" : "id",
 *			         "status" : "enable",
 *			         "greenButtonType" : "",
 *			         "autolaunchType" : 10,
 *			         "haveAutolaunch" : true,
 *			         "haveGreenButton" : false
 *		         },
 *		         {
 *			         "serviceKey" : "newchannelid",
 *			         "status" : "disable",
 *			         "greenButtonType" : "",
 *			         "autolaunchType" : 10,
 *			         "haveAutolaunch" : true,
 *			         "haveGreenButton" : false
 *		         }
 *	         ]
 *         }
 *       ]
 *     }
 *   }
 */

/**
 * @bma iApp
 * @method catalog - updateChannels
 * @desc /{wyclubToken}/iApp/catalog/{catalogId}/channel
 * @httpmethod PATCH
 * @summary catalog.updateChannels — Update channels from an iApp of a catalog
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.catalogId - The catalog ID
 * @param {string} request.body.appId - The iApp ID
 * @param {array} request.body.channels - Array of channel to update
 * @param {string} request.body.channels.serviceKey - ID of a channel
 * @param {string} [request.body.channels.status] - status of an iApp : {"enable","disable"}
 * @param {string} [request.body.channels.greenButtonType] - type of green button
 * @param {integer} [request.body.channels.autolaunchType] - type of autolaunch
 * @param {boolean} [request.body.channels.haveAutolaunch] - if iApp type is autolaunch
 * @param {boolean} [request.body.channels.haveGreenButton] - if iApp have green button
 *
 * @httpcode 200 Success
 * @httpcode 404 Not Found
 *
 * @errorcode {200} 0 Success
 * @errorcode {404} 104 Resource don't exist in database
 *
 * @example {request} - Request example
 * .. sourcecode:: http
 *
 *   PATCH /12345678901234567890123456789012/iApp/catalog/<catalogId:integer>/channel HTTP/1.1
 *   Accept: application/json, text/javascript
 *   Content-Type: application/json
 *
 *     {
 *       "appId": "service123456789",
 *       "channels": [
 *         {
 *           "serviceKey" : "id",
 *           "greenButtonType" : "updated-green-button"
 *         }
 *       ]
 *     }
 *
 * @example {response} - Response example
 * .. sourcecode:: http
 *
 *   HTTP/1.1 200 OK
 *   Vary: Accept
 *   Content-Type: application/json
 *
 *     {
 *       "code": 0,
 *       "content": "Success",
 *       "data": {
 *         "_id": "543638edd355c1de1d52103d",
 *         "catalogId": 1,
 *         "lineupId": 1,
 *         "name": "Test",
 *         "iapps": [
 *           {
 *             "_id": "543648d40b9f5af82774e20d",
 *             "appId": "service123456789",
 *             "inImm": false,
 *             "immOrder": "order",
 *             "channels": [
 *               {
 *                 "_id": "543648d40b9f5af82774e20e",
 *                 "serviceKey": "id",
 *                 "status": "enable",
 *                 "greenButtonType": "updated-green-button",
 *                 "autolaunchType": 10,
 *                 "haveAutolaunch": true,
 *                 "haveGreenButton": false
 *               }
 *             ]
 *           }
 *         ]
 *       }
 *     }
 */

/**
 * @bma iApp
 * @method catalog - deleteChannels
 * @desc /{wyclubToken}/iApp/catalog/{catalogId}/channel
 * @httpmethod DELETE
 * @summary catalog.deleteChannels — Remove channels from an iApp of a catalog
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.catalogId - The catalog ID
 * @param {string} request.body.appId - The iApp ID
 * @param {array} request.body.channels - Array of channel ID
 * @param {string} request.body.channels.serviceKey - ID of channel
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Not Found
 *
 * @errorcode {200} 0 Success
 * @errorcode {403} 5 Resource don't have required parameter.
 * @errorcode {404} 104 Resource don't exist in database
 *
 * @example {request} - Request example
 * .. sourcecode:: http
 *
 *   DELETE /12345678901234567890123456789012/iApp/catalog/<catalogId:integer>/channel HTTP/1.1
 *   Accept: application/json, text/javascript
 *   Content-Type: application/json
 *
 *     {
 *       "appId": "service123456789",
 *       "channels": [
 *		     {
 *		       "serviceKey" : "idtodelete"
 *		     }
 *	     ]
 *     }
 *
 * @example {response} - Response example
 * .. sourcecode:: http
 *
 *   HTTP/1.1 200 OK
 *   Vary: Accept
 *   Content-Type: application/json
 *
 *     {
 *       "code": 0,
 *       "content": "Success",
 *       "data": {
 *         "_id": "543638edd355c1de1d52103d",
 *         "catalogId": 1,
 *         "lineupId": 1,
 *         "name": "Test",
 *         "iapps": [
 *           {
 *             "_id": "543648d40b9f5af82774e20d",
 *             "appId": "service123456789",
 *             "inImm": false,
 *             "immOrder": "order",
 *             "channels": [
 *               {
 *                 "_id": "543648d40b9f5af82774e20e",
 *                 "serviceKey": "id",
 *                 "status": "enable",
 *                 "greenButtonType": "test",
 *                 "autolaunchType": 10,
 *                 "haveAutolaunch": true,
 *                 "haveGreenButton": false
 *               }
 *             ]
 *           }
 *         ]
 *       }
 *     }
 */

/**
 * @bma iApp
 * @method catalog - read
 * @desc /{wyclubToken}/iApp/catalog/{catalogId}
 * @httpmethod GET
 * @summary catalog.read — Read a catalog
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.catalogId - The catalog ID
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Not not found
 *
 * @errorcode {200} 0 Success
 * @errorcode {403} 5 Invalid request parameter
 * @errorcode {404} 104 Resource don't exist in database
 *
 * @example {request} - Request example
 * .. sourcecode:: http
 *
 *   GET /12345678901234567890123456789012/iApp/catalog/<catalogId:integer> HTTP/1.1
 *   Accept: application/json, text/javascript
 *   Content-Type: application/json
 *
 *
 * @example {response} - Response example
 * .. sourcecode:: http
 *
 *   HTTP/1.1 200 OK
 *   Vary: Accept
 *   Content-Type: application/json
 *
 *     {
 *       "code": 0,
 *       "content": "Success",
 *       "data": {
 *         "catalogId": 1,
 *         "lineupId": 1,
 *         "name": "Test",
 *         "iapps": [
 *           {
 *             "appId": "service123456789",
 *             "inImm": false,
 *             "immOrder": "order",
 *             "channels": [
 *               {
 *                 "serviceKey": "id",
 *                 "status": "enable",
 *                 "greenButtonType": "test",
 *                 "autolaunchType": 10,
 *                 "haveAutolaunch": true,
 *                 "haveGreenButton": false
 *               }
 *             ]
 *           }
 *         ]
 *       }
 *     }
 */

/**
 * @bma iApp
 * @method catalog - create
 * @desc /{wyclubToken}/iApp/catalog
 * @httpmethod POST
 * @summary catalog.create — Create a catalog
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.body.catalogId - ID of a catalog
 * @param {integer} request.body.bouquetKey - ID of a lineup
 * @param {string} request.body.name - Bouquet's name
 * @param {array} request.body.iapps - iApp list
 * @param {string} request.body.iapps.appId - iApp ID
 * @param {boolean} request.body.iapps.inImm - if display in imm
 * @param {string} request.body.iapps.immOrder - position of iApp in imm
 * @param {array} [request.body.iapps.channels] - array of channel
 * @param {string} request.body.iapps.channels.serviceKey - ID channel
 * @param {string} request.body.iapps.channels.status - status of an iApp : {"enable","disable"}
 * @param {string} [request.body.iapps.channels.greenButtonType] - type of green button
 * @param {integer} [request.body.iapps.channels.autolaunchType] - type of autolaunch
 * @param {boolean} [request.body.iapps.channels.haveAutolaunch] - if iApp type is autolaunch
 * @param {boolean} [request.body.iapps.channels.haveGreenButton] - if iApp have green button
 *
 * @httpcode 200 Success
 * @httpcode 503 Service Unavailable
 *
 * @errorcode {200} 0 Success
 * @errorcode {503} 103 This resource already exist in database.
 * @errorcode {503} 100 This resource don't content data required for save.
 *
 * @example {request} - Request example
 * .. sourcecode:: http
 *
 *   POST /12345678901234567890123456789012/iApp/catalog HTTP/1.1
 *   Accept: application/json, text/javascript
 *   Content-Type: application/json
 *
 *     {
 *       "catalogId": 1,
 *       "lineupId": 1,
 *       "name": "Test",
 *       "iapps": [
 *         {
 *           "appId": "service123456789",
 *           "inImm": false,
 *           "immOrder": "order",
 *           "channels": [
 *             {
 *               "serviceKey": "id",
 *               "status": "enable",
 *               "greenButtonType": "test",
 *               "autolaunchType": 10,
 *               "haveAutolaunch": true,
 *               "haveGreenButton": false
 *             }
 *           ]
 *         }
 *       ]
 *     }
 *
 * @example {response} - Response example
 * .. sourcecode:: http
 *
 *   HTTP/1.1 200 OK
 *   Vary: Accept
 *   Content-Type: application/json
 *
 *     {
 *       "code": 0,
 *       "content": "Success",
 *       "data": {
 *         "_id": "543638edd355c1de1d52103d",
 *         "catalogId": 1,
 *         "lineupId": 1,
 *         "name": "Test",
 *         "iapps": [
 *           {
 *             "_id": "543648d40b9f5af82774e20d",
 *             "appId": "service123456789",
 *             "inImm": false,
 *             "immOrder": "order",
 *             "channels": [
 *               {
 *                 "_id": "543648d40b9f5af82774e20e",
 *                 "serviceKey": "id",
 *                 "status": "enable",
 *                 "greenButtonType": "test",
 *                 "autolaunchType": 10,
 *                 "haveAutolaunch": true,
 *                 "haveGreenButton": false
 *               }
 *             ]
 *           }
 *         ]
 *       }
 *     }
 */

/**
 * @bma iApp
 * @method catalog - delete
 * @desc /{wyclubToken}/iApp/catalog/{catalogId}
 * @httpmethod DELETE
 * @summary catalog.delete — Delete a catalog
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {integer} request.params.catalogId - The ID of the to be deleted catalogue
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbiden
 * @httpcode 404 Not Found
 *
 * @errorcode {200} 0 Success
 * @errorcode {403} 5 Resource don't have required parameter.
 * @errorcode {404} 104 Resource don't exist in database
 *
 * @example {request} - Request example
 * .. sourcecode:: http
 *
 *   DELETE /12345678901234567890123456789012/iApp/catalog.json HTTP/1.1
 *   Accept: application/json, text/javascript
 *   Content-Type: application/json
 *
 * @example {response} - Response example
 * .. sourcecode:: http
 *
 *   HTTP/1.1 200 OK
 *   Vary: Accept
 *   Content-Type: application/json
 *
 *     {
 *       "code": 0,
 *       "content": "success",
 *       "data": 1
 *     }
 */

module.exports = Catalog;
