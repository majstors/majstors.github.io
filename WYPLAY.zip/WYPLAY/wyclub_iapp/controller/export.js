/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expthis.responsesed written
 * permission of Wyplay.
 */

// Load module
var Controller = Container.parentController;
var async = require('async');
var iappTools = require('./../lib/iappTools');
// Init controller prototype

// Create catalog controller
var Export = function (params) {
  'use strict';

  // Call parent constructor with container
  Controller.call(this, params);
};

// Inherited all functions of the parent controller
Export.prototype = Object.create(Controller.prototype);

// All right for this controller
Export.prototype.createPermission = "write";
Export.prototype.readPermission = "write";


/**
 * @bma iApp
 * @method export - export
 * @desc /{wyclubToken}/iApp/export/{bouquetKey}
 * @httpmethod POST
 * @summary export.export — Create export task by bouquetKey
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {string} request.params.bouquetKey - The bouquet ID
 * @param {integer} [request.body.uploadDate] - Timestamp
 */
Export.prototype.export = function () {
  'use strict';

  // Allows to access this variable outside th main scope of the function (here getAll())
  var self = this;

  this.addEntryToJsonSchema('uploadDate', this.request.body.uploadDate, {
    type: 'Number',
    required: false
  });

  // Mandatory, this function allow to validate the request (jsonSchema if set and request type (json, xml...etc))
  // "values" in the callback is null if you doesn't set this.jsonSchema, otherwise, values contains all params verified by jsonSchema !
  this.process(function (values) {
      var lastBouquetModel = Container.iApp.model.lastBouquet;
      var bouquetKey = parseInt(values.bouquetKey);
      var uploadDate = values.uploadDate;
      var response;
      iappTools.realCatalogData(bouquetKey, function (err, catalog) {
        if (err) {
          self.postProcessError('POST_ERROR', err);
        } else {
          async.waterfall([
            function (cb) {
              var params = {
                resourceType: 'iapps',
                resourceName: String(values.bouquetKey),
                resourceVersion: new Date().getTimestamp(),
                data: JSON.stringify(catalog),
                metadata: {
                  bouquetId: String(values.bouquetKey)
                }
              };
              if(uploadDate){
                params.uploadDate = uploadDate;
                params.scheduler = Container.iApp.scheduler;
              }
              Container.originLink.lib.originLinkTool.declareResource(params, function (err, res) {
                response = res;
                if(!uploadDate){
                  lastBouquetModel.findOneAndSave(
                    { key: bouquetKey },
                    {
                      key: bouquetKey,
                      data: response.data
                    },
                    { upsert: true },
                    function(err, data){
                      if(err){
                        Container.logger.error('Last catalog saving error:'+JSON.stringify(err))
                      }
                      //saving is performed async, check if needed to sync it
                    });
                }
                if (err) {
                  cb(err);
                } else {
                  cb(null);
                }
              });
            }
          ], function (err) {
            if (!!err) {
              self.postProcessError(err);
            } else {
              var tmpResponse = {
                "export": JSON.parse(response.data),
                "taskId": response.taskId
              };
              self.postProcessSuccess(tmpResponse);
            }
          });
        }
      });
    }
  );
};

/**
 * @bma iApp
 * @method export - lastBouquet
 * @desc /{wyclubToken}/iApp/export/{bouquetKey}/last
 * @httpmethod GET
 * @summary export.lastBouquet — Read a last exported bouquet from DB
 *
 * @param {string} request.params.wyclubToken - A session ID
 * @param {string} request.params.bouquetKey - The bouquet ID
 */
Export.prototype.lastBouquet = function () {
  'use strict';

  var self = this;

  this.process(function (values) {

    var lastBouquetModel = Container.iApp.model.lastBouquet;
    lastBouquetModel.findOne({key: values.bouquetKey}).exec(function (err, bouquet) {
      if (err) {
        self.postProcessError('GET_ERROR');
      } else if (!bouquet) {
        self.postProcessError('NOTHING_ERROR');
      } else {
        if (err === null && bouquet !== null) {
          self.postProcessSuccess(JSON.parse(bouquet.data));
        }
      }
    });
  });
};

module.exports = Export;
