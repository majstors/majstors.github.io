/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expthis.responsesed written
 * permission of Wyplay.
 */

var Controller = Container.parentControllerWithDefaultApi;
var _ = require('lodash');

var iApp = function (params) {
  'use strict';
  Controller.call(this, params);
};

iApp.prototype = Object.create(Controller.prototype);

// Default model
iApp.prototype.getDefaultModel = function (values) {
  return Container.iApp.model.iApp;
}

// Default filter
iApp.prototype.getDefaultFilter = function (values) {
  return {_id: values.iAppId};
}

/**
 * @typedef {Object} iAppValues
 * @property {string} label - The label of the iApp
 * @property {string} description - The description of the iApp
 * @property {string} [launchingMessage] - The launching message of the iApp
 * @property {string} url - The url of the iApp
 */

/**
 * @bma iApp
 * @method iApp - readAll
 * @desc /{wyclubToken}/iApp/iApps
 * @httpmethod GET
 * @summary iApp.readAll — Read all iApps
 *
 * @param {string} request.params.wyclubToken - A WyClub token
 *
 * @param {Number} response.body.code - Operation result code, 0 indicates a success, any other value a failure
 * @param {String} response.body.content - Operation result human readable message (if any)
 * @param {iAppValues[]} response.body.data - Operation result data
 * @param {string} response.body.data.iAppId - Id of the iApp
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 503 Service Unavailable
 *
 * @errorcode {200} 0 Success
 * @errorcode {503} 105 Error during reading
 */

/**
 * @bma iApp
 * @method iApp - read
 * @desc /{wyclubToken}/iApp/iApp/{iAppId}
 * @httpmethod GET
 * @summary iApp.read — Read a iApp
 *
 * @param {string} request.params.wyclubToken - A WyClub token
 * @param {string} request.params.iAppId - The ID of the iApp
 *
 * @param {Number} response.body.code - Operation result code, 0 indicates a success, any other value a failure
 * @param {String} response.body.content - Operation result human readable message (if any)
 * @param {iAppValues} response.body.data - Operation result data
 * @param {string} response.body.data.iAppId - Id of the iApp
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Not found
 * @httpcode 503 Service Unavailable
 *
 * @errorcode {200} 0 Success
 * @errorcode {404} 104 Non-existent iApp
 * @errorcode {503} 105 Error during reading
 */

/**
 * @bma iApp
 * @method iApp - create
 * @desc /{wyclubToken}/iApp/iApp
 * @httpmethod POST
 * @summary iApp.create — Write an iApp
 *
 * @param {string} request.params.wyclubToken - A WyClub token
 * @param {iAppValues} request.body - iApp details
 *
 * @param {Number} response.body.code - Operation result code, 0 indicates a success, any other value a failure
 * @param {String} response.body.content - Operation result human readable message (if any)
 * @param {iAppValues} response.body.data - Operation result data
 * @param {string} response.body.data.iAppId - Id of the iApp
 *
 * @example {request} Request example
 * .. sourcecode:: http
 *
 *   POST /12345678901234567890123456789012/iApp/iApp.json HTTP/1.1
 *   Accept: application/json, text/javascript
 *   Content-Type: application/json
 *
 *     {
 *       "label": "test",
 *       "description": "test\ntest",
 *       "launchingMessage": "",
 *       "url": "http://www"
 *     }
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 503 Service Unavailable
 *
 * @errorcode {200} 0 Success
 * @errorcode {503} 100 Error during creation
 * @errorcode {503} 103 Try to create an iApp that already exists
 */

/**
 * @bma iApp
 * @method iApp - update
 * @desc /{wyclubToken}/iApp/iApp/{iAppId}
 * @httpmethod PATCH
 * @summary iApp.update — Update an iApp
 *
 * @param {string} request.params.wyclubToken - A WyClub token
 * @param {string} request.params.iAppId - The ID of the iApp
 * @param {optIAppValues} request.body - iApp details
 *
 * @param {Number} response.body.code - Operation result code, 0 indicates a success, any other value a failure
 * @param {String} response.body.content - Operation result human readable message (if any)
 * @param {iAppValues} response.body.data - Operation result data
 * @param {string} response.body.data.iAppId - Id of the iApp
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Not found
 * @httpcode 503 Service Unavailable
 *
 * @errorcode {200} 0 Success
 * @errorcode {404} 104 Non-existent iApp
 * @errorcode {503} 102 Error during update
 */

/**
 * @bma iApp
 * @method iApp - delete
 * @desc /{wyclubToken}/iApp/iApp/{iAppId}
 * @httpmethod DELETE
 * @summary iApp.delete — Delete an iApp
 *
 * @param {string} request.params.wyclubToken - A WyClub token
 * @param {string} request.params.iAppId - The ID of the iApp
 *
 * @param {Number} response.body.code - Operation result code, 0 indicates a success, any other value a failure
 * @param {String} response.body.content - Operation result human readable message (if any)
 * @param {integer} response.body.data - Operation result data, 1 when success
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Not found
 * @httpcode 503 Service Unavailable
 *
 * @errorcode {200} 0 Success
 * @errorcode {404} 104 Non-existent iApp
 * @errorcode {503} 101 Error during update
 */


/**
 * @bma iApp
 * @method iApp - activate
 * @desc /{wyclubToken}/iApp/activate
 * @httpmethod POST
 * @summary iApp.activate — Activate an iApp on one or more channels
 *
 * @param {string} request.params.wyclubToken - A WyClub token

 * @param {string} request.body.iAppId - ServiceKey of the iApp
 * @param {boolean} request.body.activate - Enable or disable the iApp
 * @param {array} [request.body.channels] - The list of the channel where we want to enable or disable the iApp. Enables all the iApp on all channels if not given
 *
 * @example {request} Request example if we want to active the iApp 100 on the channel 308
 * .. sourcecode:: http
 *
 *   POST /123abc/iApp/activate HTTP/1.1
 *   Accept: application/json, text/javascript
 *   Content-Type: application/json
 *
 *     {
 *       "activate": true,
 *       "iAppId": "100",
 *       "channels": [
 *         "308"
 *       ]
 *     }
 *
 * @example {request} Request example if we want to active the iApp 100 on all channels
 * .. sourcecode:: http
 *
 *   POST /123abc/iApp/activate HTTP/1.1
 *   Accept: application/json, text/javascript
 *   Content-Type: application/json
 *
 *     {
 *       "activate": true,
 *       "iAppId": "100"
 *     }
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 * @httpcode 404 Resource doen't exists
 * @httpcode 503 Service Unavailable
 *
 * @errorcode {200} 0 Success
 * @errorcode {503} 100 Error during activation
 * @errorcode {404} 1200 No iApp assciated to given channels found
 *
 * @param {Number} response.body.code - Operation result code, 0 indicates a success, any other value a failure
 * @param {String} response.body.content - Operation result human readable message (if any)
 *
 * @example {response} Response example when we have a success
 * .. sourcecode:: http
 *
 *   HTTP/1.1 200 OK
 *   Vary: Accept
 *   Content-Type: application/json
 *
 *     {
 *       "code": 0,
 *       "content": "Success"
 *     }
 *
 */
iApp.prototype.activate = function() {
  var self = this;

  this.addEntryToJsonSchema('iAppId', this.request.body.iAppId, {
    type: 'string',
    required: true
  });

  this.addEntryToJsonSchema('activate', this.request.body.activate, {
    type: 'boolean',
    required: true
  });

  this.addEntryToJsonSchema('channels', this.request.body.channels, {
    type: 'array',
    required: false
  });

  this.process(function (values) {
    var now = Date.now()/1000|0;
    var catalogModel = Container.iApp.model.catalog;
    var event = {
      id: now,
      type: 'iApp',
      iAppId: values.iAppId,
      state: values.activate
    };
    var channelList;

    var processResult = function(err, docs) {
      if (!!err) {
        self.postProcessError('DB_ERROR');
      } else if (docs.length === 0) {
        self.postProcessError('CANNOT_FIND_IAPP_OR_CHANNEL');
      } else {
        var failure = false;
        _.each(docs, function(item) {
          var topic = String(item.bouquetKey);
          _.each(channelList, function(elem) {
            event.channels = elem;
            Container.lineup.messaging.publisher.publish(topic, event, 'utf-8', function (err) {
              if (!!err) {
                failure = err;
              }
            });
          });
        });
        if (!!failure) {
          self.postProcessError(failure);
        } else {
          self.postProcessSuccess();
        }
      }
    };

    if (!!values.channels && values.channels.length > 0) {
      channelList = values.channels;
      catalogModel.find({
        'iapps.appId': values.iAppId,
        'iapps.channels' : {
          $elemMatch: {
            serviceKey: {$in: values.channels}
          }
        }
      }, processResult);
    } else {
      // Activate on all channels
      channelList = ['*'];
      catalogModel.find({'iapps.appId': values.iAppId}, processResult);
    }
  });
};

module.exports = iApp;
