var params = {};

params.databaseUrl = process.env.MONGODB_PORT_27017_TCP_ADDR;
params.databaseName = 'iApp';
params.databaseUser = 'iApp';
params.databasePassword = 'iApp';
params.databaseAuthdb = 'iApp';

module.exports = params;
