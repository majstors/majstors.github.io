//
// Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//

'use strict';

/**
 * Config file
 */

var fs = require('fs');

module.exports = function () {

  var params = {};
  if(fs.existsSync(__dirname + '/params.js')) {
    params = require(__dirname + '/params.js');
  } else if (fs.existsSync(__dirname + '/params.dev.js')) {
    params = require(__dirname + '/params.dev.js');
  }

  if (!params.databasePort) {
    params.databasePort = '27017';
  }

  var mongoAuth = '';
  var option = {};
  if(params.databaseUser !== undefined &&
      params.databasePassword !== undefined &&
      params.databaseAuthdb !== undefined) {
    mongoAuth = params.databaseUser + ':' + params.databasePassword + '@';
    option = {
      auth: {
        authdb: params.databaseAuthdb
      }
    };
  }

  Container.iApp.db = Container.mongoose.createConnection(
    'mongodb://'+
    mongoAuth +
    params.databaseUrl +
    ':' +
    params.databasePort +
    '/' +
    params.databaseName,
    option
  );

};