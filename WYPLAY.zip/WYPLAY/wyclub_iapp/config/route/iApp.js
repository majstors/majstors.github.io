//
// Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//

var Route = Container.parentRoute;

module.exports = function (){
  'use strict';

  Container.express.post('/:wyclubToken/iApp/iApp', function (request, response) {
    Route.process(request, response, 'iApp', 'iApp', 'create');
  });


  Container.express.patch('/:wyclubToken/iApp/iApp/:iAppId', function (request, response) {
    Route.process(request, response, 'iApp', 'iApp', 'update');
  });

  Container.express.delete('/:wyclubToken/iApp/iApp/:iAppId', function (request, response) {
    Route.process(request, response, 'iApp', 'iApp', 'delete');
  });

  Container.express.get('/:wyclubToken/iApp/iApp/:iAppId', function (request, response) {
    Route.process(request, response, 'iApp', 'iApp', 'read');
  });

  Container.express.get('/:wyclubToken/iApp/iApps', function (request, response) {
    Route.process(request, response, 'iApp', 'iApp', 'readAll');
  });

  Container.express.post('/:wyclubToken/iApp/activate', function (request, response) {
    Route.process(request, response, 'iApp', 'iApp', 'activate');
  });
};
