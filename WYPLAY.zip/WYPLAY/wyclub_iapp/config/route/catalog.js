//
// Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//

var Route = Container.parentRoute;

module.exports = function (){
  'use strict';

  Container.express.post('/:wyclubToken/iApp/catalog', function (request, response) {
    Route.process(request, response, 'iApp', 'catalog', 'create');
  });

  Container.express.post('/:wyclubToken/iApp/catalog/:catalogId/iapp', function (request, response) {
    Route.process(request, response, 'iApp', 'catalog', 'addIapps');
  });

  Container.express.post('/:wyclubToken/iApp/catalog/:catalogId/channel', function (request, response) {
    Route.process(request, response, 'iApp', 'catalog', 'addChannels');
  });


  Container.express.patch('/:wyclubToken/iApp/catalog/:catalogId', function (request, response) {
    Route.process(request, response, 'iApp', 'catalog', 'update');
  });

  Container.express.patch('/:wyclubToken/iApp/catalog/:catalogId/iapp', function (request, response) {
    Route.process(request, response, 'iApp', 'catalog', 'updateIapps');
  });

  Container.express.patch('/:wyclubToken/iApp/catalog/:catalogId/channel', function (request, response) {
    Route.process(request, response, 'iApp', 'catalog', 'updateChannels');
  });

  Container.express.delete('/:wyclubToken/iApp/catalog/:catalogId', function (request, response) {
    Route.process(request, response, 'iApp', 'catalog', 'delete');
  });

  Container.express.delete('/:wyclubToken/iApp/catalog/:catalogId/iapp', function (request, response) {
    Route.process(request, response, 'iApp', 'catalog', 'deleteIapps');
  });

  Container.express.delete('/:wyclubToken/iApp/catalog/:catalogId/channel', function (request, response) {
    Route.process(request, response, 'iApp', 'catalog', 'deleteChannels');
  });

  Container.express.get('/:wyclubToken/iApp/catalog/:catalogId', function (request, response) {
    Route.process(request, response, 'iApp', 'catalog', 'read');
  });
};
