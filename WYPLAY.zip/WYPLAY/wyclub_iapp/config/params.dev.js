var params = {};

params.databaseUrl = 'localhost';
params.databaseName = 'iApp';

module.exports = params;
