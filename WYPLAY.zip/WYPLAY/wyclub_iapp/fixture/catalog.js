var catalog = [{
  'catalogId': 1,
  'bouquetKey': '00',
  'name': 'Bouquet 00',
  'iapps': [{
    'appId': '5482ab24507e99440da9af38',
    'inImm': true,
    'immOrder':'20',
    'channels': [{
      'serviceKey': '237',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }, {
      'serviceKey': '122',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }, {
      'serviceKey': '235',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }]
  }, {
    'appId': '5466ab24507e99440da9af38',
    'inImm': true,
    'immOrder': 2,
    'channels': [{
      'serviceKey': '238',
      'status': 'enable',
      'autolaunch': true,
      'autolaunchDelay': 5000
    }]
  }, {
    'appId': '5468ab24507e99440da9af38',
    'inImm': true,
    'immOrder': 3,
    'channels': [{
      'serviceKey': '235',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }

    }, {
      'serviceKey': '105',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }]
  }, {
    'appId': '5471ab24507e99440da9af38',
    'inImm': true,
    'immOrder': 4,
    'channels': [{
      'serviceKey': '235',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }]
  }, {
    'appId': '5473ab24507e99440da9af38',
    'inImm': true,
    'immOrder': 5,
    'channels': [{
      'serviceKey': '308',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }]
  }, {
    'appId': '5475ab24507e99440da9af38',
    'inImm': true,
    'immOrder': 6,
    'channels': [{
      'serviceKey': '344',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }, {
      'serviceKey': '367',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }]
  }, {
    'appId': '5478ab24507e99440da9af38',
    'inImm': true,
    'immOrder': 7,
    'channels': [{
      'serviceKey': '341',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }]
  }, {
    'appId': '5480ab24507e99440da9af38',
    'inImm': true,
    'immOrder': 8,
    'channels': [{
      'serviceKey': '240',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }]
  }]
},
{
  'catalogId': 2,
  'bouquetKey': '04',
  'name': 'Bouquet 04',
  'iapps': [{
    'appId': '5482ab24507e99440da9af38',
    'inImm': true,
    'immOrder':'20',
    'channels': [{
      'serviceKey': '237',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }, {
      'serviceKey': '122',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }, {
      'serviceKey': '235',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }]
  }, {
    'appId': '5466ab24507e99440da9af38',
    'inImm': true,
    'immOrder': 2,
    'channels': [{
      'serviceKey': '238',
      'status': 'enable',
      'autolaunch': true,
      'autolaunchDelay': 5000
    }]
  }, {
    'appId': '5468ab24507e99440da9af38',
    'inImm': true,
    'immOrder': 3,
    'channels': [{
      'serviceKey': '235',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }

    }, {
      'serviceKey': '105',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }]
  }, {
    'appId': '5471ab24507e99440da9af38',
    'inImm': true,
    'immOrder': 4,
    'channels': [{
      'serviceKey': '235',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }]
  }, {
    'appId': '5473ab24507e99440da9af38',
    'inImm': true,
    'immOrder': 5,
    'channels': [{
      'serviceKey': '308',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }]
  }, {
    'appId': '5475ab24507e99440da9af38',
    'inImm': true,
    'immOrder': 6,
    'channels': [{
      'serviceKey': '344',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }, {
      'serviceKey': '367',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }]
  }, {
    'appId': '5478ab24507e99440da9af38',
    'inImm': true,
    'immOrder': 7,
    'channels': [{
      'serviceKey': '341',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }]
  }, {
    'appId': '5480ab24507e99440da9af38',
    'inImm': true,
    'immOrder': 8,
    'channels': [{
      'serviceKey': '240',
      'status': 'enable',
      'autolaunch': false,
      'greenButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/green.png',
        'x': 1179,
        'y': 663
      },
      'inviteButton': {
        'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/trigger/test/waiting.png',
        'x': 1122,
        'y': 663
      }
    }]
  }]
}
];

module.exports = catalog;
