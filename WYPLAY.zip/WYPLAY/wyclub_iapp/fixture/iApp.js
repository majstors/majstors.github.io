var iApp = [
{
  'label' : 'Test',
  'description' : 'Test insert',
  'launchingMessage' : 'Message',
  'url' : 'http://www/test'
},
{
  'label' : 'Test bis',
  'description' : 'Test insert bis',
  'launchingMessage' : 'Message bis',
  'url' : 'http://www/test/bis'
},
{
  '_id': "5458ab24507e99440da9af38",
  'label' : 'Test',
  'description' : 'Test insert',
  'launchingMessage' : 'Message',
  'url' : 'http://www/test'
},
{
  '_id': "5458ab24507e99440da9af39",
  'label' : 'Test bis',
  'description' : 'Test insert bis',
  'launchingMessage' : 'Message bis',
  'url' : 'http://www/test/bis'
},
{
  '_id': '5482ab24507e99440da9af38',
  'label': 'SkyTG24 Active',
  'description': 'Il mosaico interattivo con 6 canali per scegliere le notizie di Sky TG24 che vuoi, quandi vuoi',
  'launchingMessage': 'Il mosaico interattivo con 6 canali per scegliere le notizie di Sky TG24 che vuoi, quandi vuoi',
  'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/SkyTG24/index.html',
},
{
  '_id': '5466ab24507e99440da9af38',
  'label': 'Sky Meteo 24 Active',
  'description': 'Il canale interattivo con le previsioni sempre aggiornate sulle citta\' d\'italia e del mondo',
  'launchingMessage': 'Il canale interattivo con le previsioni sempre aggiornate sulle citta\' d\'italia e del mondo',
  'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/SkyTG24/index.html',
},
{
  '_id': '5468ab24507e99440da9af38',
  'label': 'Sky Cinema Active',
  'description': 'Le vetrina dei film di prima serata, con le schede dei film, i cast e le trame',
  'launchingMessage': 'Le vetrina dei film di prima serata, con le schede dei film, i cast e le trame',
  'url': 'http://somewhere.com/theURL/content',
},
{
  '_id': '5471ab24507e99440da9af38',
  'label': 'Sky Primafila Active',
  'description': 'Il grande spettacolo prima di tutto! Acquistare e\' semplice e veloce.',
  'launchingMessage': 'Il grande spettacolo prima di tutto! Acquistare e\' semplice e veloce.',
  'url': 'http://somewhere.com/theURL/content',
},
{
  '_id': '5473ab24507e99440da9af38',
  'label': 'Mosaico Bambini',
  'description': 'Il canale interattivo per vedere in un colpo d\'occhio tutti i canali dedicati ai piu\' piccoli',
  'launchingMessage': 'Il canale interattivo per vedere in un colpo d\'occhio tutti i canali dedicati ai piu\' piccoli',
  'url': 'http://data.oscdn.any.sky.it/iapp/test/polka/MosaicoKids/index.html',
},
{
  '_id': '5475ab24507e99440da9af38',
  'label': 'Sky Music',
  'description': 'Tutta la musica che vuoi in 25 canali tematici in colloborazione con Radio Deejay, Capital e m2o',
  'launchingMessage': 'Tutta la musica che vuoi in 25 canali tematici in colloborazione con Radio Deejay, Capital e m2o',
  'url': 'http://somewhere.com/theURL/content',
},
{
  '_id': '5478ab24507e99440da9af38',
  'label': 'Sky Radio',
  'description': 'Il canale interattivo che ti da\' l\'accesso ad oltre 50 tra le piu\' importanto stazioni FM',
  'launchingMessage': 'Il canale interattivo che ti da\' l\'accesso ad oltre 50 tra le piu\' importanto stazioni FM',
  'url': 'http://somewhere.com/theURL/content',
},
{
  '_id': '5480ab24507e99440da9af38',
  'label': 'Demo iApp',
  'description': 'Il canale interattivo che ti da\' l\'accesso ad oltre 50 tra le piu\' importanto stazioni FM',
  'launchingMessage': 'Il canale interattivo che ti da\' l\'accesso ad oltre 50 tra le piu\' importanto stazioni FM',
  'url': 'http://iapps.local/apps/polka-ui/extra/iapp-demo/iapp-demo.html?origin=fullscreen&test=yes',
}
];

module.exports = iApp;
