var permission =
  [
    {
      "group": [
        "read"
      ],
      "type": "read"
    },
    {
      "group": [
        "write"
      ],
      "type": "write"
    }
  ];

module.exports = permission;