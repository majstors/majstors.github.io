#!/usr/bin/env node

'use strict';

/**
 * Module dependencies.
 */

global.Container = {
  consoleMode: true,
  root: __dirname + '/'
};
var program = require('commander');
var exec = require('child_process').exec;
var chalk = require('chalk');
var async = require('async');
var fs = require('fs-extra');
var path = require('path');
var async = require('async');
var params = require('./config/paramsloader');
var lodash = require('lodash');

program
  .version('0.0.1')
  .option('-s, --swagger', 'Generate swagger file [name] [version]')
  .option('-r, --rst', 'Generate RST file')
  .option('-f, --fixtures', 'Generate fixtures')
  .option('-t, --test [value]', 'Launch unitary tests')
  .option('--report', 'Write report of unitary tests (only use with option -t)');

program.run = function (args) {
  program.parse(args);

  var root = __dirname;
  var nameOfBma = require(root + '/package.json').name;

  switch (false) {
  case !program.rst:
    fs.removeSync(root + '/generated/doc');
    try {
      fs.mkdirSync(root + '/generated');
    } catch (e) {
    }
    fs.mkdirSync(root + '/generated/doc');

    var arrayDirRst = '';
    var modulesRst = {};

    Object.keys(params.module).forEach(function (moduleKey) {
      // If routes are disabled on the module, don't generate rst for it
      if (params.module[moduleKey].routesDisabled === true) {
        console.log(chalk.yellow(moduleKey + ': Will be ignored because routes are disabled'));
        return;
      }

      var moduleDir = params.module[moduleKey].dir;
      var assemblyDir = Container.modules["assembly"].dir + "/" + moduleKey;
      var dirs = [assemblyDir, moduleDir];
      var module = require(moduleDir);
      module.root = moduleDir;
      module.controller = moduleDir + '/controller';
      module.assemblyController = assemblyDir + '/controller';
      module.config = moduleDir + '/config';
      module.assemblyConfig = assemblyDir + '/config';
      modulesRst[moduleKey] = module;

      async.eachSeries(dirs, function (dir, clb) {
        if (fs.existsSync(dir + '/controller')) {
          arrayDirRst += dir + '/controller' + ' ';
          if (fs.existsSync(dir + '/jsdoc')) {
            arrayDirRst += dir + '/jsdoc' + ' ';
          }
        }
        if (fs.existsSync(dir + '/doc')) {
          try{
            fs.mkdirSync(root + '/generated/doc/' + moduleKey);
          }catch(e){
          }
          fs.copySync(dir + '/doc', root + '/generated/doc/' + moduleKey);
        }
        clb();
      });
    });

    exec(root + '/node_modules/jsdoc/jsdoc.js ' + arrayDirRst + ' -c ' + __dirname + '/jsdoc/rst-config.json -d "' + __dirname + '/generated/jsdoc" --query controller=true',
      function (error) {
        if (error === null) {
          async.eachSeries(Object.keys(modulesRst), function (moduleKey, callback) {
            var module = modulesRst[moduleKey];
            // If no controller, not need to generate status codes
            if (!fs.existsSync(module.controller) && !fs.existsSync(module.assemblyController)) {
              return callback();
            }
            // Global status codes
            var statusCodeDir = __dirname + '/config/statuscodes.js ';
            // Specific status codes
            if (fs.existsSync(module.config + '/statuscodes.js')) {
              statusCodeDir += module.config + '/statuscodes.js ';
            }
            // Specific status codes
            if (fs.existsSync(module.assemblyConfig + '/statuscodes.js')) {
              statusCodeDir += module.assemblyConfig + '/statuscodes.js ';
            }

            // Generate
            exec(root + '/node_modules/jsdoc/jsdoc.js ' + statusCodeDir + ' -c ' +
                __dirname + '/jsdoc/rst-config.json -d "' + __dirname + '/generated/jsdoc" --query "statuscode=true&bma=' + moduleKey + '"',
              function (error) {
                if (error === null) {
                  console.log(chalk.green(moduleKey + ': Done'));
                } else {
                  console.log(chalk.red(moduleKey + ': ' + error));
                }

                callback();
              }
            );
          })
        } else {
          console.log(chalk.red(error));
        }
      }
    );

    break;
  case !program.swagger:

    var name = program.args[0];
    if (!name) {
      name = 'Server';
    }
    var version = program.args[1];
    if (!version) {
      version = '';
    }

    fs.removeSync(root + '/generated/swagger');
    try {
      fs.mkdirSync('generated');
    } catch (e) {
    }
    try {
      fs.mkdirSync('generated/swagger');
    } catch (e) {
    }
    fs.copySync(__dirname + '/node_modules/wyclub_swaggerui', __dirname + '/generated/swagger');

    var apis = [];

    var bmaPort = params.serverPort;

    var arrayDirSwagger = '';
    var modulesSwagger = {};
    Object.keys(params.module).forEach(function (moduleKey) {
      // If routes are disabled on the module, don't generate rst for it
      if (params.module[moduleKey].routesDisabled === true) {
        console.log(chalk.yellow(moduleKey + ': Will be ignored because routes are disabled'));
        return;
      }

      //routes are loaded from module directory and from assembly/module directory
      var moduleDir = params.module[moduleKey].dir;
      var assemblyDir = Container.modules["assembly"].dir + "/" + moduleKey;
      var dirs = [assemblyDir, moduleDir];
      async.eachSeries(dirs, function (dir, clb) {
        if (fs.existsSync(dir)) {
          var moduleController = dir + '/controller';
          if (fs.existsSync(moduleController)) {
            modulesSwagger[moduleKey] = module;
            arrayDirSwagger += moduleController + ' ';
            if (fs.existsSync(dir + '/jsdoc')) {
              arrayDirSwagger += dir + '/jsdoc' + ' ';
            }

            var controllerFolder = fs.readdirSync(moduleController);
            Object.keys(controllerFolder).forEach(function (controllerFolderKey) {
              var controllerName = path.basename(controllerFolder[controllerFolderKey], '.js');
              var pathApi = {
                path: '/docs/' + moduleKey + '/' + controllerName + '.{format}'
              };
              apis.push(pathApi);
              clb();
            });

          }
        }
        clb();
      });
    });

    var apiDocs = {
      'apiVersion': version,
      'swaggerVersion': '1.0',
      'basePath': ':' + bmaPort,
      'info': {
        'title': name,
        'description': 'API documentation for the ' + name
      },
      'apis': apis
    };

    fs.writeFileSync(__dirname + '/generated/swagger/api-docs.json', JSON.stringify(apiDocs));

    var sampleIndex = fs.readFileSync(__dirname + '/node_modules/wyclub_swaggerui/index.sample.html', 'utf8');
    sampleIndex = sampleIndex.replace(/\{\{name\}\}/g, name);

    fs.writeFileSync(__dirname + '/generated/swagger/index.html', sampleIndex);

    if (fs.existsSync(__dirname + '/generated/swagger/index.sample.html')) {
      fs.unlinkSync(__dirname + '/generated/swagger/index.sample.html');
    }
    if (fs.existsSync(__dirname + '/generated/swagger/api-docs.sample.json')) {
      fs.unlinkSync(__dirname + '/generated/swagger/api-docs.sample.json');
    }

    if (!fs.existsSync(__dirname + '/generated/swagger/docs')) {
      fs.mkdirSync(__dirname + '/generated/swagger/docs');
    }

    console.log(chalk.green('Generate swagger files with controllers'));

    exec(root + '/node_modules/jsdoc/jsdoc.js ' + arrayDirSwagger + '-c ' + __dirname + '/jsdoc/swagger-config.json -d "' + __dirname + '/generated/jsdoc"', function (error, stdout) {
      if (error === null) {
        console.log(chalk.green(stdout));

        if (!fs.existsSync(__dirname + '/generated/swagger/output/')) {
          fs.mkdirSync(__dirname + '/generated/swagger/output');
        }

        Object.keys(modulesSwagger).forEach(function (moduleKey) {

          if (!fs.existsSync(__dirname + '/generated/swagger/output/' + moduleKey)) {
            fs.mkdirSync(__dirname + '/generated/swagger/output/' + moduleKey);
            fs.mkdirSync(__dirname + '/generated/swagger/output/' + moduleKey + '/nodejs');
            fs.mkdirSync(__dirname + '/generated/swagger/output/' + moduleKey + '/nodejsTestapp');
            fs.mkdirSync(__dirname + '/generated/swagger/output/' + moduleKey + '/angularjs');
          }
          console.log(chalk.green('Generate nodejs libraries with swagger files for module ' + moduleKey));

          exec('php ' + __dirname + '/node_modules/wyclub_swagger-client-generator/generator ' +
            __dirname + '/generated/swagger/docs/' + moduleKey + ' ' + __dirname + '/generated/swagger/output/' + moduleKey +
            '/nodejs nodejs', function (error) {
            if (error === null) {
              console.log(chalk.green('Write files in generated/swagger/output/' + moduleKey + '/nodejs'));
              exec('php ' + __dirname + '/node_modules/wyclub_swagger-client-generator/generator ' +
                  __dirname + '/generated/swagger/docs/' + moduleKey + ' ' + __dirname + '/generated/swagger/output/' + moduleKey +
                  '/nodejsTestapp nodejsTestapp',
                function (error) {
                  if (error === null) {
                    console.log(chalk.green('Write files in generated/swagger/output/' + moduleKey + '/nodejsTestapp'));
                    exec('php ' + __dirname + '/node_modules/wyclub_swagger-client-generator/generator ' +
                        __dirname + '/generated/swagger/docs/' + moduleKey + ' ' + __dirname + '/generated/swagger/output/' +
                        moduleKey + '/angularjs angularjs',
                      function (error) {
                        if (error === null) {
                          console.log(chalk.green('Write files in generated/swagger/output/' + moduleKey + '/angularjs'));
                        } else {
                          console.log(chalk.red(error));
                        }
                      });
                  } else {
                    console.log(chalk.red(error));
                  }
                });
            } else {
              console.log(chalk.red(error));
            }
          });
        });

      } else {
        console.log(chalk.red(error));
      }
    });
    break;
  case !program.fixtures:
    Container.fixturesMode = true;
    var error = false;
    var fixturesQueue = async.queue(function (object, callback) {
      if (object.clear) {
        console.log(chalk.blue.bold.underline('\nClear model ' + object.fixtureName + ' for ' + object.module));
      } else {
        console.log(chalk.blue.bold.underline('\nClear model ' + object.fixtureName + ' for ' + object.module));
      }
      var FixtureModel = object.fixtureModel;
      var fixtureData = object.fixtureData;

      // Clean database
      if (FixtureModel.collection.drop !== undefined) {
        // Mongoose
        FixtureModel.collection.drop();
        FixtureModel.ensureIndexes(function () {
          async.eachSeries(Object.keys(fixtureData), function (fixtureKey, callbackEach) {
            var fixture = fixtureData[fixtureKey];
            var model = new FixtureModel(fixture);
            console.log(chalk.green('Insert new ' + object.fixtureName + '[' + fixtureKey + '] :\n'), chalk.green(model));
            model.save(function (err) {
              if (err === null) {
                console.log(chalk.green('SAVED\n'));
                callbackEach(null);
              } else {
                console.log(chalk.red('ERROR'));
                console.log(err);
                error = true;
                callbackEach(err);
              }
            });
          }, function (err) {
            callback(err);
          });
        });
      } else {
        // MongoQuery, RedisQuery
        FixtureModel.drop(function (err) {
          async.eachSeries(Object.keys(fixtureData), function (fixtureKey, callbackEach) {
            var fixture = fixtureData[fixtureKey];
            console.log(chalk.green('Insert new ' + object.fixtureName + '[' + fixtureKey + '] :\n'), chalk.green(fixture));
            FixtureModel.create(fixture, function (err, document) {
              if (err === null) {
                console.log(chalk.green('SAVED\n'));
                callbackEach(null);
              } else {
                console.log(chalk.red('ERROR'));
                console.log(err);
                error = true;
                callbackEach(err);
              }
            });
          }, function (err) {
            callback(err);
          });
        });
      }
    }, 1);

    require(__dirname + '/app.js')(function () {
      var modules = Container.modules;
      var hasFx = false;
      Object.keys(modules).forEach(function (moduleKey) {
        // @TODO this condition is temporally because these models are generated/cleaned in the core
        // When core will be removed, this condition can be removed
        if (moduleKey === 'sessionManager' || moduleKey === 'tag' || moduleKey === 'application') {
          return;
        }
        if (Container[moduleKey].model) {
          Object.keys(Container[moduleKey].model).forEach(function (modelName) {
            var object = {
              fixtureModel: Container[moduleKey].model[modelName],
              fixtureName: modelName,
              module: moduleKey,
              fixtureData: {},
              clear: true
            };
            hasFx = true;
            fixturesQueue.push(object);
          });
        }
      });

      // Load fixture in a specific order
      var fixtureOrderArray = require(params.module.assembly.dir + '/fixtureOrder.js');
      var fixtureAlreadyImportArray = {};
      fixtureOrderArray.forEach(function (fixtureOrder) {
        if (Container.modules[fixtureOrder.moduleName] !== undefined) {
          var moduleFixtureDir = Container.modules[fixtureOrder.moduleName].dir + '/fixture';
          if (fixtureAlreadyImportArray[fixtureOrder.moduleName] === undefined) {
            fixtureAlreadyImportArray[fixtureOrder.moduleName] = [];
          }
          fixtureOrder.fixtureOrder.forEach(function (fixtureName) {
            fixtureAlreadyImportArray[fixtureOrder.moduleName].push(fixtureName);
            var fixture = require(moduleFixtureDir + '/' + fixtureName);
            console.log(fixtureOrder.moduleName);
            console.log(fixtureName);
            var object = {
              fixtureData: fixture,
              fixtureModel: Container[fixtureOrder.moduleName].model[fixtureName],
              module: fixtureOrder.moduleName,
              fixtureName: fixtureName
            };
            hasFx = true;
            fixturesQueue.push(object);
          });
        }
      });

      Object.keys(modules).forEach(function (moduleKey) {
        if (lodash.indexOf(fixtureAlreadyImportArray, moduleKey) === -1) {
          var module = modules[moduleKey];
          var fixtureFolder = module.dir + '/fixture';
          var speFixtureFolder = params.module.assembly.dir + '/' + moduleKey + '/fixture';
          var toImport = [fixtureFolder, speFixtureFolder];
          toImport.forEach(function (dir) {
            if (fs.existsSync(dir)) {
              var arrayFixture = fs.readdirSync(dir);
              for (var arrayFixtureKey in arrayFixture) {
                var fixture = require(dir + '/' + arrayFixture[arrayFixtureKey]);
                var fixtureName = path.basename(arrayFixture[arrayFixtureKey], '.js');

                if (fixtureAlreadyImportArray[moduleKey] === undefined || (fixtureAlreadyImportArray[moduleKey] !== undefined && !fixtureAlreadyImportArray[moduleKey][fixtureName])) {
                  var object = {
                    fixtureData: fixture,
                    fixtureModel: Container[moduleKey].model[fixtureName],
                    module: moduleKey,
                    fixtureName: fixtureName
                  };
                  hasFx = true;
                  fixturesQueue.push(object);
                }
              }
            }
          });
        }
      });

      fixturesQueue.drain = function () {
        if (error) {
          console.log(chalk.red('Import done with errors, check log above'));
          process.exit(8);
        } else {
          console.log(chalk.green('Import done successfully'));
          process.exit();
        }
      };

      if (!hasFx) {
        fixturesQueue.drain();
      }
    });

    break;
  case !program.test:
    require(__dirname + '/app.js')(function () {
      var test = require('./bin/test.js');
      test.run(program.test, program.report);
    });
    break;
  default:
    program.outputHelp();
  }
};


if (require.main === module) {
  program.run(process.argv);
} else {
  module.exports = program;
}
