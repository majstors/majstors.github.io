var root = __dirname + '/../';
var child_process = require('child_process');
var async = require('async');
var params = require(root + 'config/paramsloader');
async.eachSeries(Object.keys(params.module), function (moduleName, callback) {
  if (params.module[moduleName].repo) {
    console.log('== Start initialisation of ' + moduleName + ' module ==');
    console.log('npm install ' + params.module[moduleName].repo);
    var npm = child_process.spawn('npm', ['install', params.module[moduleName].repo]);
    npm.stdout.on('data', function (data) {
      console.log(data.toString());
    });
    npm.stderr.on('data', function (data) {
      console.log(data.toString());
    });
    npm.on('exit', function (code) {
      console.log('== End initialisation of ' + moduleName + ' module ==');
      callback();
    });
  } else {
    child_process.exec('rm -rf ' + root + 'node_modules/' + moduleName);
    child_process.exec('rm -rf ' + root + 'node_modules/wyclub_' + moduleName);
    callback();
  }
});
