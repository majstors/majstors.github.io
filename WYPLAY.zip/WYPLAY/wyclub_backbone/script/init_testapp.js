#!/usr/bin/env node

//
// Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//

var root = __dirname + '/../';
var child_process = require('child_process');
var async = require('async');
var fs = require('fs');
var params = require(root + 'config/paramsloader');
var env = {'Container_root_dir': root};
for (var moduleName in params.module) {
  env['Container_' + moduleName + '_dir'] = params.module[moduleName].dir;
}

var fx = child_process.spawn(root + 'console.js', ['-f'], {stdio: 'inherit'});
fx.on('close', function (code) {
  if (code) {
    console.log('Fixtures error (' + code + ')');
  } else {
    async.eachSeries(Object.keys(params.module), function (moduleName, callback) {
      if (params.module[moduleName].dir) {
        if (fs.existsSync(params.module[moduleName].dir + '/script/init_testapp.js')) {
          var file = params.module[moduleName].dir + '/script/init_testapp.js';
        } else if (fs.existsSync(params.module[moduleName].dir + '/script/init_testapp.sh')) {
          var file = params.module[moduleName].dir + '/script/init_testapp.sh';
        }
        if (file) {
          var init = child_process.spawn(file, [], {stdio: 'inherit', env: env});
          init.on('close', function (code) {
            if (code) {
              console.log('Error during execution of file (' + code + ')');
              callback(code);
            } else {
              callback();
            }
          });
        } else {
          callback();
        }
      } else {
        callback();
      }
    }, function (err) {
      if (!err) {
        var app = child_process.spawn(root + 'app.js', [], {stdio: 'inherit'});
        app.on('close', function (code) {
          console.log('App closed (' + code + ')');
        });
      }
    });
  }
});