module.exports = {
  wyclubToken: {
    type: 'string',
    required: true,
    minLength: 32,
    maxLength: 32
  },
  applicationId: {
    type: 'string',
    required: true,
    minLength: 32,
    maxLength: 32
  },
  module: {
    type: 'string',
    required: true,
    pattern: "^\\w+$"
  },
  id: {
    type: 'string',
    required: true,
    pattern: "^\\w+$"
  }
};
