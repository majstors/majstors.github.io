var params = {};

params.wyclubCoreUrl = 'localhost';
params.wyclubCoreProtocol = 'http';
params.wyclubCorePort = '3000';

params.serverPort = 3010;

module.exports = params;
