var params = {};

params.wyclubCoreUrl = process.env.CORE_PORT_3000_TCP_ADDR;
params.wyclubCoreProtocol = 'http';
params.wyclubCorePort = process.env.CORE_PORT_3000_TCP_PORT;

params.serverPort = 3010;

module.exports = params;
