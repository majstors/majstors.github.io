/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */
/**
 * Status Codes
 *
 * Range : 0 - 999
 */
module.exports = {
  'DEFAULT': {
    code: 999,
    httpCode: 403,
    content: 'An unexpected error occured.'
  },
  'BAD_REQUEST': {
    code: 1,
    httpCode: 403,
    content: 'Invalid %reqType% request, check your header.'
  },
  'DB_NO_CONNECTION': {
    code: 2,
    httpCode: 403,
    content: 'Could not connect to database.'
  },
  'DB_ERROR': {
    code: 3,
    httpCode: 403,
    content: 'Unexpected database error.'
  },
  'NO_SESSION': {
    code: 4,
    httpCode: 403,
    content: 'Your session isn\'t valid.'
  },
  'INVALID_REQ_PARAM': {
    code: 5,
    httpCode: 403,
    content: 'Invalid request parameter: %param%'
  },
  'MISSING_REQ_PARAM': {
    code: 6,
    httpCode: 403,
    content: 'Missing request parameter(s): %param%'
  },
  'NO_MODEL_TO_USE': {
    code: 7,
    httpCode: 404,
    content: 'No model defined'
  },
  'NON_EXISTING_MODULE': {
    code: 8,
    httpCode: 404,
    content: 'Non-existent module: %param%'
  },
  'BAD_SESSION_APPLICATION': {
    code: 9,
    httpCode: 403,
    content: 'Your session doesn\'t use correct application.'
  },
  'MISSING_MODULE': {
    code: 10,
    httpCode: 404,
    content: 'A module is needed to perform that and it\'s missing.'
  },
  'POST_ERROR': {
    code: 100,
    httpCode: 503,
    content: 'Could not create entry: %param%'
  },
  'DELETE_ERROR': {
    code: 101,
    httpCode: 503,
    content: 'Could not delete entry: %param%'
  },
  'PUT_ERROR': {
    code: 102,
    httpCode: 503,
    content: 'Could not update entry: %param%'
  },
  'DUPLICATE_ENTRY': {
    code: 103,
    httpCode: 503,
    content: 'Duplicate entry: %param%'
  },
  'NOTHING_ERROR': {
    code: 104,
    httpCode: 404,
    content: 'No entry: %param%'
  },
  'GET_ERROR': {
    code: 105,
    httpCode: 503,
    content: 'Could not get entry: %param%'
  },
  'PATCH_ERROR': {
    code: 106,
    httpCode: 503,
    content: 'Could not update entry: %param%'
  },
  'JSON_SCHEMA_ERROR': {
    code: 400,
    httpCode: 403,
    content: 'Json schema error'
  },
  'FORBIDDEN': {
    code: 403,
    httpCode: 403,
    content: 'Forbidden'
  },

  /* used both in wyclub_rendez-vous and wyclub_resource-delivery */
  'RESOURCE_PROFILE_FOUND_BUT_NO_RESOURCE_LINKED_IN_DB': {
    code: 700,
    httpCode: 404,
    content: 'A resource profile was found but nothing seems to be linked to that profile in database.'
  },
  'NO_RESOURCE_PROFILE_FOUND': {
    code: 701,
    httpCode: 404,
    content: 'Your session have no tag concerning this resource.'
  },
  'BAD_RESOURCE_TYPE': {
    code: 702,
    httpCode: 404,
    content: 'This type of resource does not exist.'
  },
  'RESOURCE_ALREADY_EXISTS': {
    code: 703,
    httpCode: 404,
    content: 'This resource already exists.'
  },
  'BOUQUET_NEEDED': {
    code: 704,
    httpCode: 404,
    content: 'A bouquetId is needed to get your lineup.'
  },
  /* -------------- */

  /* used both in wyclub_rendez-vous and wyclub_software-update */
  'NO_RESOURCE': {
    code: 800,
    httpCode: 404,
    content: 'The specified resource does not exist.'
  },
  /* --------------  */

  'NO_NOTIFICATION_DATABASE': {
    code: 108,
    httpCode: 404,
    content: 'No notification database.'
  }
};
