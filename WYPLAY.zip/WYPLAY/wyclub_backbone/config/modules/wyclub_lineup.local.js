module.exports = {
  name: 'lineup',
  dir: Container.root + '../wyclub_lineup', // jshint ignore:line
  permission: true,
  schema: true,
  routesDisabled: false,
  publisher: true,
  scheduler: true,
  dependencies: [
    'channel'
  ]
};
