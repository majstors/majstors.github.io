module.exports = {
  name: 'resourceDelivery',
  dir: Container.root + '../wyclub_resource-delivery', // jshint ignore:line
  permission: true,
  schema: true,
  routesDisabled: false,
  dependencies: [
    'subscriber'
  ]
};
