module.exports = {
  name: 'rendezVous',
  dir: Container.root + '../wyclub_rendez-vous', // jshint ignore:line
  permission: true,
  schema: true,
  routesDisabled: false,
  dependencies: [
    'resourceDelivery'
  ]
};
