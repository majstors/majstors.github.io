module.exports = {
  name: 'epg',
  dir: Container.root + '../wyclub_epg', // jshint ignore:line
  permission: true,
  scheduler:true,
  schema: true,
  routesDisabled: false,
  publisher: true,
  dependencies: [
    'epgParser'
  ]
};
