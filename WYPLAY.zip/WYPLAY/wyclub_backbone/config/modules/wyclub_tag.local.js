module.exports = {
  name: 'tag',
  dir: Container.root + '../wyclub_tag', // jshint ignore:line
  permission: true,
  schema: true,
  routesDisabled: false,
  dependencies: [
  ]
};
