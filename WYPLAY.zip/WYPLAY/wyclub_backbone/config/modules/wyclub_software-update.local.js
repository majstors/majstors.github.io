module.exports = {
  name: 'softwareUpdate',
  dir: Container.root + '../wyclub_software-update', // jshint ignore:line
  permission: true,
  schema: true,
  routesDisabled: false,
  scheduler: true,
  dependencies: [
    'resourceDelivery',
    'originLink'
  ]
};