module.exports = {
  name: 'subscriber',
  dir: Container.root + '../wyclub_subscriber', // jshint ignore:line
  permission: true,
  schema: true,
  routesDisabled: false,
  dependencies: [
    'sessionManager'
  ]
};