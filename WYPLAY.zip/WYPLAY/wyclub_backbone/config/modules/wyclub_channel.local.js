module.exports = {
  name: 'channel',
  dir: Container.root + '../wyclub_channel', // jshint ignore:line
  permission: true,
  schema: true,
  scheduler:true,
  routesDisabled: false,
  dependencies: [
    'iApp',
    'lineup'
  ]
};