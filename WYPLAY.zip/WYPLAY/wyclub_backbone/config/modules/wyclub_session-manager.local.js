module.exports = {
  name: 'sessionManager',
  dir: Container.root + '../wyclub_session-manager', // jshint ignore:line
  permission: false,
  schema: true,
  routesDisabled: false,
  scheduler: true,
  dependencies: [
    'application',
    'tag',
    'subscriber'
  ]
};
