module.exports = {
  name: 'globalSettings',
  dir: Container.root + '../wyclub_global-settings', // jshint ignore:line
  permission: false,
  schema: true,
  routesDisabled: false,
  dependencies: [
  ]
};
