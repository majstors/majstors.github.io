module.exports = {
  name: 'push',
  dir: Container.root + '../wyclub_push', // jshint ignore:line
  permission: false,
  schema: false,
  routesDisabled: false,
  register: true,
  dependencies: [
    "lineup",
    "epg",
    "iApp"
  ]
};
