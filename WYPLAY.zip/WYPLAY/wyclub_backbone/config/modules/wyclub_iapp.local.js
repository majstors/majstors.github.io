module.exports = {
  name: 'iApp',
  dir: Container.root + '../wyclub_iapp', // jshint ignore:line
  permission: true,
  scheduler:true,
  schema: true,
  routesDisabled: false,
  dependencies:[
    'channel'
  ]
};