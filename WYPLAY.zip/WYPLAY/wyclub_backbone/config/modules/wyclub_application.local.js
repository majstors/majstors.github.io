module.exports = {
  name: 'application',
  dir: Container.root + '../wyclub_application', // jshint ignore:line
  permission: false,
  schema: true,
  routesDisabled: false,
  dependencies: [
  ]
};
