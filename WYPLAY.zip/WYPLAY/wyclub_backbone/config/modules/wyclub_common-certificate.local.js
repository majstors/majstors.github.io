module.exports = {
  name: 'commonCertificate',
  dir: Container.root + '../wyclub_common-certificate', // jshint ignore:line
  permission: true,
  schema: true,
  routesDisabled: false,
  dependencies: [
  ]
};