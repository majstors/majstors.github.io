module.exports = {
  name: 'epgParser',
  dir: Container.root + '../wyclub_epg-parser', // jshint ignore:line
  permission: false,
  schema: false,
  routesDisabled: false,
  dependencies: [
    'epg',
    'originLink'
  ]
};
