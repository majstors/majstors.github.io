module.exports = {
  name: 'auth',
  dir: Container.root + '../wyclub_auth', // jshint ignore:line
  permission: false,
  schema: false,
  routesDisabled: false,
  dependencies: [
    'resourceDelivery',
    'commonCertificate',
    'globalSettings',
    'sessionManager',
    'subscriber'
  ]
};
