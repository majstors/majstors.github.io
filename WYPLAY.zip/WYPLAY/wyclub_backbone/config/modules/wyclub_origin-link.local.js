module.exports = {
  name: 'originLink',
  dir: Container.root + '../wyclub_origin-link', // jshint ignore:line
  permission: false,
  schema: true,
  routesDisabled: false,
  dependencies: [
    'resourceDelivery'
  ]
};