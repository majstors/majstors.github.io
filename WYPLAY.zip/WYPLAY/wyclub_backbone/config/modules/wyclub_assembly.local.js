module.exports = {
  name: 'assembly',
  dir: (typeof(Container) !== 'undefined' ? Container.root + '../wyclub_assembly' : Core.root + '../wyclub_assembly'), // jshint ignore:line
  permission: false,
  schema: false,
  routesDisabled: false,
  dependencies: [
    'sessionManager'
  ]
};