//
// Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//

'use strict';

/**
 * Config file
 */
var mongoose = require('mongoose');
var wyclubtools = Container.wyclubtools;
var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');
var methodOverride = require('method-override');
var httpTools = require(__dirname + '/../lib/httpTools');
var lodash = require('lodash');
var fs = require('fs');
var chalk = require('chalk');
var async = require('async');
var dir = __dirname + '/../';
var helmet = require("helmet");

module.exports = function (callback) {
  var params = require('./paramsloader');
  var statusCodes = {};
  var globalStatusCodes = statusCodes.global = require(__dirname + '/statuscodes');
  for (var moduleName in params.module) {
    var pathOfAssemblyStatusCode = params.module.assembly.dir + '/' + moduleName + '/config/statuscodes.js';
    var pathOfLocalStatusCode = params.module[moduleName].dir + '/config/statuscodes.js';
    var dirs = [pathOfAssemblyStatusCode, pathOfLocalStatusCode];
    statusCodes[moduleName] = globalStatusCodes;
    async.eachSeries(dirs, function (dir, clb) {
      try {
        var moduleStatus = require(dir);

        //check if code is already defined and throw an error if it is
        var existingIds = lodash.intersection(lodash.pluck(statusCodes[moduleName], "code"), lodash.pluck(moduleStatus, "code"));
        if (existingIds.length > 0) {
          console.log(chalk.red("There is double error code 'code' defined in module: "+ moduleName, existingIds));
          process.exit();
        }
        //check if key is already defined and throw an error if it is
        var existingKeys = lodash.intersection(lodash.keys(statusCodes[moduleName]), lodash.keys(moduleStatus));
        if (existingKeys.length > 0) {
          console.log(chalk.red("There is double error code 'key' defined in module: "+ moduleName, existingKeys));
          process.exit();
        } else {
          lodash.extend(statusCodes[moduleName], moduleStatus);
          clb();
        }
      } catch (e) {
        clb();
      }
    });
  }

  httpTools.statusCodes = statusCodes;
  wyclubtools.wyclubCoreUrl = params.wyclubCoreUrl;
  wyclubtools.wyclubCoreProtocol = params.wyclubCoreProtocol;
  wyclubtools.wyclubCorePort = params.wyclubCorePort;
  if (!Container.consoleMode) {
    // AngularJS requirement for CORS OPTIONS
    var allowCrossDomain = function (req, res, next) {
      res.header('Access-Control-Allow-Origin', '*');
      res.header('Access-Control-Allow-Methods', 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS');
      res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Content-Length, X-Requested-With');
      res.header('Access-Control-Allow-Credentials', 'true');

      // intercept OPTIONS method
      if ('OPTIONS' === req.method) {
        res.send(200);
      } else {
        next();
      }
    };

    Container.express.use(allowCrossDomain);
    Container.express.use(express.static(path.join(dir, '/generated/swagger')));
    Container.express.use(bodyParser.urlencoded({extended: true}));
    Container.express.use(bodyParser.json());
    Container.express.use(bodyParser.raw({type: 'application/octet-stream'}));
    Container.express.use(function (error, req, res, next) {
      //Catch json error
      if (error) {
        var err = Container.httpTools.getError({code: 'BAD_REQUEST', params: {reqType: req.headers['content-type'], error: error}});
        res.statusCode = 403;
        Container.httpTools.setResponse(req, err, res);
      } else {
        next();
      }
    });
    Container.express.use(methodOverride());

    // Remove default x-powered-by response header
    Container.express.disable('x-powered-by');

    // Prevent opening page in frame or iframe to protect from clickjacking
    Container.express.use(helmet.xframe());

    // Prevents browser from caching and storing page
    Container.express.use(helmet.nocache());

    // Allow loading resources only from white-listed domains
    Container.express.use(helmet.csp());

    // Forces browser to only use the Content-Type set in the response header instead of sniffing or guessing it
    Container.express.use(helmet.nosniff());

    Container.express.use(function (req, res, next) {
      // Start date used in each request logging
      req.startAt = new Date().getTime();
      next();
    });

    // Add decorator
    Container.decorators = [];
    for (var moduleName in params.module) {
      if (fs.existsSync(params.module[moduleName].dir + '/config/decorator.js')) {
        Container.logger.success('Load decorator for ' + moduleName);
        var moduleDecorator = require(params.module[moduleName].dir + '/config/decorator');
        moduleDecorator.forEach(function (decorator) {
          Container.decorators.push(decorator);
        });
      } else {
        Container.logger.error('No decorator for ' + moduleName);
      }
    }
  }

  var listener = function () {
    if (!Container.consoleMode) {
      Container.express.listen(params.serverPort, function (err) {

        // launch specific callbacks
        if (typeof Container.afterLaunchCallbacks !== 'undefined') {

          lodash.forEach(Container.afterLaunchCallbacks, function (item, idx) {
            var callbackToProcess = null;

            if (typeof item === 'function') {
              callbackToProcess = item;
            } else if (typeof item === 'string' && fs.existsSync(item)) {
              callbackToProcess = require(item);
            }

            if (null !== callbackToProcess) {
              Container.logger.log({ color: 'blue', message: 'Launch server started callback for "' + idx + '"' });
              callbackToProcess(err);
            }
          });
        }
        if (callback !== undefined) {
          callback();
        }
        Container.logger.log({ color: 'green', message: 'Launch server on port ' + params.serverPort});
      });
    } else {
      if (callback !== undefined) {
        callback();
      }
    }
  };

  Container.backboneParams = params;

  Container.autoloader.process(listener);
};
