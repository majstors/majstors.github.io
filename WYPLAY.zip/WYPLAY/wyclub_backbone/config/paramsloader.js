var fs = require('fs-extra');

if (typeof(Container) === 'undefined') {
  global.Container = { root: __dirname + '/../' };
}

var params = {};
if (fs.existsSync(__dirname + '/params.js')) {
  params = require(__dirname + '/params.js');
} else if (fs.existsSync(__dirname + '/params.dev.js')) {
  params = require(__dirname + '/params.dev.js');
}


params.module = {};


// Read wyclub modules
var modules = fs.readdirSync(__dirname + '/modules');
modules.forEach(function (module) {
  'use strict';

  // Keep js files only
  if (module.indexOf('.js') > 0) {
    var moduleParams = require(__dirname + '/modules/' + module);
    // If module is used as a node module, try to read branch to use on the file name
    if (moduleParams.repo) {
      var branch = module.split('#');
      if (branch.length === 2) {
        branch = branch[1].replace('.js', '');
        moduleParams.repo = moduleParams.repo.replace(/#[a-z0-9]+/i, '#' + branch);
      }
    }
    params.module[moduleParams.name] = moduleParams;
  }
});

// Add default modules
if (!params.module['backboneTools']) {
  params.module['backboneTools'] = {
    'name': 'backboneTools',
    'dir': __dirname + '/../lib/backboneTools',
    'permission': true,
    'schema': false
  };
}
if (!params.module['permission']) {
  params.module['permission'] = {
    'name': 'permission',
    'dir': __dirname + '/../lib/permission',
    'permission': false,
    'schema': false
  };
}
if (!params.module['scheduler']) {
  params.module['scheduler'] = {
    'name': 'scheduler',
    'dir': __dirname + '/../lib/scheduler',
    'permission': false,
    'scheduler': true,
    'schema': false
  };
}
if (!params.module['messaging']) {
  params.module['messaging'] = {
    'name': 'messaging',
    'dir': __dirname + '/../lib/messaging',
    'permission': false,
    'schema': false
  };
}
for (var i in params.module) {
  if (params.module[i].dependencies) {
    params.module[i].dependencies.forEach(function (dependency) {
      if (!params.module[dependency]) {
        var msg = 'Modules loading error : ' + i + ' module need ' + dependency + ' module and it is missing';
        if (Container.logger) {
          Container.logger.error(msg);
        }
        throw(new Error(msg));
      }
    });
  }
}

Container.modules = params.module;

module.exports = params;
