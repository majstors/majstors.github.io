'use strict';

var tool = require('../lib/tools.js');

exports.testCloneFunction = function(test){
  var testObj = {customVal: 1};
  var testObj2 = testObj;
  testObj2.customVal = 2;
  test.equals(testObj.customVal, testObj2.customVal, 'Values are not the same with no clone...');

  var testObj3 = tool.clone(testObj);
  testObj3.customVal = 3;
  test.notEqual(testObj.customVal, testObj3.customVal, 'Values are the sames, clone does not work.');

  test.done();
};


exports.testSetResponseFunction = function(test){
  var response = {
    header: {},
    setHeader: function(headerCell, headerValue){
      response.header[headerCell] = headerValue;
    },
    send: function(data){
      test.equals(response.header['Content-Type'], 'application/json');
      test.equals(response.header['Access-Control-Allow-Origin'], '*');
      test.equals(response.header['Access-Control-Allow-Credentials'], 'true');
      test.equals(response.statusCode, 10);
      test.equals(data.test, true);
      test.done();
    }
  };
  tool.setResponse({test: true}, response, 10);
};
