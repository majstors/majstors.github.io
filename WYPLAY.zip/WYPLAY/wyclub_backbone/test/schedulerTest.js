'use strict';

var scheduler = require('../lib/scheduler/lib/scheduler.js');
var schedulerTimer = 1*1000;
var s = new scheduler('scheduler', 1000);

exports.addTask = function (test) {
  var time = new Date().getTimestamp();
  var task = {};

  s.addTask(time, 'testTask', task, function (err, resp) {
    test.equals(resp.type, 'testTask');
    test.equals(resp.status, 'scheduled');

    setTimeout(function () {
      var schedulerModel = Container.scheduler.model.scheduledTask;
      schedulerModel.find({type: 'testTask'}, function (err, result) {
        test.equals(result[0].status, 'running');
        setTimeout(function () {
          schedulerModel.find({type: 'testTask'}, function (err, result) {
            test.equals(result[0].status, 'success');
            test.done();
          });
        }, 2000);
      });
    }, 1500);
  });
};

exports.wrongType = function (test) {
  var time = new Date().getTimestamp();
  var task = {};

  s.addTask(time, 'testTaskFail', task, function (err, resp) {
  });

  setTimeout(function () {
    var schedulerModel = Container.scheduler.model.scheduledTask;
    schedulerModel.find({type: 'testTaskFail'}, function (err, result) {
      test.equals(result[0].status, 'error');
      test.done();
    });
  }, 1500);
};

exports.rescheduleTask = function (test) {
  var task = Container.scheduler.model.scheduledTask();

  task.time = new Date().getTimestamp();
  task.type = 'testRescheduleTask';

  task.save(function (err, t) {
    s.rescheduleTask(t, 1000, function (err, newTask) {
      test.equals(err, null);
      test.equals(newTask.time,task.time+1000);
      test.done();
    });
  });
};

//simply remove test tasks after all tests
exports.removeTasks = function (test) {
  var schedulerModel = Container.scheduler.model.scheduledTask;
  var tasksToRemove = ['testTask', 'testTaskFail', 'testRescheduleTask'];
  schedulerModel.remove({type: {$in: tasksToRemove}}, function (err, res) {
    test.equals(err, null);
    test.done()
  });
};