/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* jshint -W106 */

var _ = require('lodash');
var rest = require('restler');
var querystring = require('querystring');

/**
 * Initialize component
 * @param {string} basePath Api base path
 **/
var backboneToolsModule = function (basePath) {
  'use strict';

  this.basePath = basePath || '';
  this.lastError = undefined;
  this.lastResponse = undefined;
};

/**
 * @method backboneTools - read
 * @summary backboneTools.read — Read all schemas of a module
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.module]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
backboneToolsModule.prototype.read = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var defaultOptions = {
    followRedirects: false
  };
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.get(
    this.basePath + '/' + pathParams.wyclubToken + '/' + pathParams.module + '/schema' + (params ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method backboneTools - readPermission
 * @summary backboneTools.readPermission — Read permissions needed for all APIs of all modules
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
backboneToolsModule.prototype.readPermission = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var defaultOptions = {
    followRedirects: false
  };
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.get(
    this.basePath + '/' + pathParams.wyclubToken + '/permission' + (params ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

module.exports = backboneToolsModule;