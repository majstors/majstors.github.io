/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */
 
/* jshint -W106 */

var rest = require('restler');
var querystring = require('querystring');

/**
 * Initialize component
 * @param {string} basePath Api base path
 **/
var channelModule = function (basePath) {
  'use strict';
  this.basePath = basePath || '';
};

/**
 * @method channel - readAll
 * @summary channel.readAll — Read all channel
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
channelModule.prototype.readAll = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/channel/channelList' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method channel - read
 * @summary channel.read — Read a channel
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.serviceKey]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
channelModule.prototype.read = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.serviceKey === 'undefined') {
    err += 'pathParams.serviceKey is required. ';
  }
  if (typeof pathParams.serviceKey !== 'undefined' && typeof pathParams.serviceKey !== 'string'){
    err += 'pathParams.serviceKey must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/channel/channel/' + pathParams.serviceKey + '' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method channel - create
 * @summary channel.create — Write an IP channel
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {number} [params.serviceKey]
 * @param {string} [params.channelName]
 * @param {string} [params.type]
 * @param {string} params.contentDescription
 * @param {string} params.note
 * @param {string} [params.contentType]
 * @param {string} params.logoUrl
 * @param {string} params.contentVideoUrl
 * @param {string} [params.genre]
 * @param {string} params.genre1
 * @param {string} params.unSubscribedMessage
 * @param {number} [params.epgSourceId]
 * @param {boolean} params.recordable
 * @param {boolean} params.safe
 * @param {boolean} params.searchAZ
 * @param {boolean} params.surfFlag
 * @param {boolean} params.searchScanFlag
 * @param {boolean} params.listingFlag
 * @param {number} params.channelCode
 * @param {string} [params.sourceChannelID]
 * @param {function(err, result)} callback 
 * @public
 */
channelModule.prototype.create = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.serviceKey === 'undefined') {
    err += 'params.serviceKey is required. ';
  }
  if (typeof params.serviceKey !== 'undefined' && typeof params.serviceKey !== 'number'){
    err += 'params.serviceKey must be number. ';
  }
  if (typeof params.channelName === 'undefined') {
    err += 'params.channelName is required. ';
  }
  if (typeof params.channelName !== 'undefined' && typeof params.channelName !== 'string'){
    err += 'params.channelName must be string. ';
  }
  if (typeof params.type === 'undefined') {
    err += 'params.type is required. ';
  }
  if (typeof params.type !== 'undefined' && typeof params.type !== 'string'){
    err += 'params.type must be string. ';
  }
  if (typeof params.contentDescription !== 'undefined' && typeof params.contentDescription !== 'string'){
    err += 'params.contentDescription must be string. ';
  }
  if (typeof params.note !== 'undefined' && typeof params.note !== 'string'){
    err += 'params.note must be string. ';
  }
  if (typeof params.contentType === 'undefined') {
    err += 'params.contentType is required. ';
  }
  if (typeof params.contentType !== 'undefined' && typeof params.contentType !== 'string'){
    err += 'params.contentType must be string. ';
  }
  if (typeof params.logoUrl !== 'undefined' && typeof params.logoUrl !== 'string'){
    err += 'params.logoUrl must be string. ';
  }
  if (typeof params.contentVideoUrl !== 'undefined' && typeof params.contentVideoUrl !== 'string'){
    err += 'params.contentVideoUrl must be string. ';
  }
  if (typeof params.genre === 'undefined') {
    err += 'params.genre is required. ';
  }
  if (typeof params.genre !== 'undefined' && typeof params.genre !== 'string'){
    err += 'params.genre must be string. ';
  }
  if (typeof params.genre1 !== 'undefined' && typeof params.genre1 !== 'string'){
    err += 'params.genre1 must be string. ';
  }
  if (typeof params.unSubscribedMessage !== 'undefined' && typeof params.unSubscribedMessage !== 'string'){
    err += 'params.unSubscribedMessage must be string. ';
  }
  if (typeof params.epgSourceId === 'undefined') {
    err += 'params.epgSourceId is required. ';
  }
  if (typeof params.epgSourceId !== 'undefined' && typeof params.epgSourceId !== 'number'){
    err += 'params.epgSourceId must be number. ';
  }
  if (typeof params.recordable !== 'undefined' && typeof params.recordable !== 'boolean'){
    err += 'params.recordable must be boolean. ';
  }
  if (typeof params.safe !== 'undefined' && typeof params.safe !== 'boolean'){
    err += 'params.safe must be boolean. ';
  }
  if (typeof params.searchAZ !== 'undefined' && typeof params.searchAZ !== 'boolean'){
    err += 'params.searchAZ must be boolean. ';
  }
  if (typeof params.surfFlag !== 'undefined' && typeof params.surfFlag !== 'boolean'){
    err += 'params.surfFlag must be boolean. ';
  }
  if (typeof params.searchScanFlag !== 'undefined' && typeof params.searchScanFlag !== 'boolean'){
    err += 'params.searchScanFlag must be boolean. ';
  }
  if (typeof params.listingFlag !== 'undefined' && typeof params.listingFlag !== 'boolean'){
    err += 'params.listingFlag must be boolean. ';
  }
  if (typeof params.channelCode !== 'undefined' && typeof params.channelCode !== 'number'){
    err += 'params.channelCode must be number. ';
  }
  if (typeof params.sourceChannelID === 'undefined') {
    err += 'params.sourceChannelID is required. ';
  }
  if (typeof params.sourceChannelID !== 'undefined' && typeof params.sourceChannelID !== 'string'){
    err += 'params.sourceChannelID must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.post(
      this.basePath + '/' + pathParams.wyclubToken + '/channel/channel' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method channel - create
 * @summary channel.create — Write a DTT channel
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {number} [params.serviceKey]
 * @param {string} [params.channelName]
 * @param {string} [params.type]
 * @param {string} params.contentDescription
 * @param {string} params.note
 * @param {string} [params.contentType]
 * @param {string} params.logoUrl
 * @param {string} [params.genre]
 * @param {string} params.genre1
 * @param {string} params.unSubscribedMessage
 * @param {number} params.epgSourceId
 * @param {boolean} params.recordable
 * @param {boolean} params.safe
 * @param {boolean} params.searchAZ
 * @param {boolean} params.surfFlag
 * @param {boolean} params.searchScanFlag
 * @param {boolean} params.listingFlag
 * @param {number} params.channelCode
 * @param {string} [params.sourceChannelID]
 * @param {string} [params.networkID]
 * @param {string} [params.transportID]
 * @param {string} [params.serviceID]
 * @param {function(err, result)} callback 
 * @public
 */
channelModule.prototype.create = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.serviceKey === 'undefined') {
    err += 'params.serviceKey is required. ';
  }
  if (typeof params.serviceKey !== 'undefined' && typeof params.serviceKey !== 'number'){
    err += 'params.serviceKey must be number. ';
  }
  if (typeof params.channelName === 'undefined') {
    err += 'params.channelName is required. ';
  }
  if (typeof params.channelName !== 'undefined' && typeof params.channelName !== 'string'){
    err += 'params.channelName must be string. ';
  }
  if (typeof params.type === 'undefined') {
    err += 'params.type is required. ';
  }
  if (typeof params.type !== 'undefined' && typeof params.type !== 'string'){
    err += 'params.type must be string. ';
  }
  if (typeof params.contentDescription !== 'undefined' && typeof params.contentDescription !== 'string'){
    err += 'params.contentDescription must be string. ';
  }
  if (typeof params.note !== 'undefined' && typeof params.note !== 'string'){
    err += 'params.note must be string. ';
  }
  if (typeof params.contentType === 'undefined') {
    err += 'params.contentType is required. ';
  }
  if (typeof params.contentType !== 'undefined' && typeof params.contentType !== 'string'){
    err += 'params.contentType must be string. ';
  }
  if (typeof params.logoUrl !== 'undefined' && typeof params.logoUrl !== 'string'){
    err += 'params.logoUrl must be string. ';
  }
  if (typeof params.genre === 'undefined') {
    err += 'params.genre is required. ';
  }
  if (typeof params.genre !== 'undefined' && typeof params.genre !== 'string'){
    err += 'params.genre must be string. ';
  }
  if (typeof params.genre1 !== 'undefined' && typeof params.genre1 !== 'string'){
    err += 'params.genre1 must be string. ';
  }
  if (typeof params.unSubscribedMessage !== 'undefined' && typeof params.unSubscribedMessage !== 'string'){
    err += 'params.unSubscribedMessage must be string. ';
  }
  if (typeof params.epgSourceId !== 'undefined' && typeof params.epgSourceId !== 'number'){
    err += 'params.epgSourceId must be number. ';
  }
  if (typeof params.recordable !== 'undefined' && typeof params.recordable !== 'boolean'){
    err += 'params.recordable must be boolean. ';
  }
  if (typeof params.safe !== 'undefined' && typeof params.safe !== 'boolean'){
    err += 'params.safe must be boolean. ';
  }
  if (typeof params.searchAZ !== 'undefined' && typeof params.searchAZ !== 'boolean'){
    err += 'params.searchAZ must be boolean. ';
  }
  if (typeof params.surfFlag !== 'undefined' && typeof params.surfFlag !== 'boolean'){
    err += 'params.surfFlag must be boolean. ';
  }
  if (typeof params.searchScanFlag !== 'undefined' && typeof params.searchScanFlag !== 'boolean'){
    err += 'params.searchScanFlag must be boolean. ';
  }
  if (typeof params.listingFlag !== 'undefined' && typeof params.listingFlag !== 'boolean'){
    err += 'params.listingFlag must be boolean. ';
  }
  if (typeof params.channelCode !== 'undefined' && typeof params.channelCode !== 'number'){
    err += 'params.channelCode must be number. ';
  }
  if (typeof params.sourceChannelID === 'undefined') {
    err += 'params.sourceChannelID is required. ';
  }
  if (typeof params.sourceChannelID !== 'undefined' && typeof params.sourceChannelID !== 'string'){
    err += 'params.sourceChannelID must be string. ';
  }
  if (typeof params.networkID === 'undefined') {
    err += 'params.networkID is required. ';
  }
  if (typeof params.networkID !== 'undefined' && typeof params.networkID !== 'string'){
    err += 'params.networkID must be string. ';
  }
  if (typeof params.transportID === 'undefined') {
    err += 'params.transportID is required. ';
  }
  if (typeof params.transportID !== 'undefined' && typeof params.transportID !== 'string'){
    err += 'params.transportID must be string. ';
  }
  if (typeof params.serviceID === 'undefined') {
    err += 'params.serviceID is required. ';
  }
  if (typeof params.serviceID !== 'undefined' && typeof params.serviceID !== 'string'){
    err += 'params.serviceID must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.post(
      this.basePath + '/' + pathParams.wyclubToken + '/channel/channel' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method channel - create
 * @summary channel.create — Write a DTT channel with IP inheritance
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {number} [params.serviceKey]
 * @param {string} [params.channelName]
 * @param {string} [params.type]
 * @param {string} params.contentDescription
 * @param {string} params.note
 * @param {string} [params.contentType]
 * @param {string} [params.networkID]
 * @param {string} [params.transportID]
 * @param {string} [params.serviceID]
 * @param {string} [params.serviceKeySource]
 * @param {function(err, result)} callback 
 * @public
 */
channelModule.prototype.create = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.serviceKey === 'undefined') {
    err += 'params.serviceKey is required. ';
  }
  if (typeof params.serviceKey !== 'undefined' && typeof params.serviceKey !== 'number'){
    err += 'params.serviceKey must be number. ';
  }
  if (typeof params.channelName === 'undefined') {
    err += 'params.channelName is required. ';
  }
  if (typeof params.channelName !== 'undefined' && typeof params.channelName !== 'string'){
    err += 'params.channelName must be string. ';
  }
  if (typeof params.type === 'undefined') {
    err += 'params.type is required. ';
  }
  if (typeof params.type !== 'undefined' && typeof params.type !== 'string'){
    err += 'params.type must be string. ';
  }
  if (typeof params.contentDescription !== 'undefined' && typeof params.contentDescription !== 'string'){
    err += 'params.contentDescription must be string. ';
  }
  if (typeof params.note !== 'undefined' && typeof params.note !== 'string'){
    err += 'params.note must be string. ';
  }
  if (typeof params.contentType === 'undefined') {
    err += 'params.contentType is required. ';
  }
  if (typeof params.contentType !== 'undefined' && typeof params.contentType !== 'string'){
    err += 'params.contentType must be string. ';
  }
  if (typeof params.networkID === 'undefined') {
    err += 'params.networkID is required. ';
  }
  if (typeof params.networkID !== 'undefined' && typeof params.networkID !== 'string'){
    err += 'params.networkID must be string. ';
  }
  if (typeof params.transportID === 'undefined') {
    err += 'params.transportID is required. ';
  }
  if (typeof params.transportID !== 'undefined' && typeof params.transportID !== 'string'){
    err += 'params.transportID must be string. ';
  }
  if (typeof params.serviceID === 'undefined') {
    err += 'params.serviceID is required. ';
  }
  if (typeof params.serviceID !== 'undefined' && typeof params.serviceID !== 'string'){
    err += 'params.serviceID must be string. ';
  }
  if (typeof params.serviceKeySource === 'undefined') {
    err += 'params.serviceKeySource is required. ';
  }
  if (typeof params.serviceKeySource !== 'undefined' && typeof params.serviceKeySource !== 'string'){
    err += 'params.serviceKeySource must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.post(
      this.basePath + '/' + pathParams.wyclubToken + '/channel/channel' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method channel - create
 * @summary channel.create — Write a radio channel
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {number} [params.serviceKey]
 * @param {string} [params.channelName]
 * @param {string} [params.type]
 * @param {string} params.contentDescription
 * @param {string} params.note
 * @param {string} params.logoUrl
 * @param {string} params.contentVideoUrl
 * @param {string} [params.genre]
 * @param {string} params.genre1
 * @param {string} params.unSubscribedMessage
 * @param {number} [params.epgSourceId]
 * @param {boolean} params.recordable
 * @param {boolean} params.safe
 * @param {boolean} params.searchAZ
 * @param {boolean} params.surfFlag
 * @param {boolean} params.searchScanFlag
 * @param {boolean} params.listingFlag
 * @param {number} params.channelCode
 * @param {string} [params.sourceChannelID]
 * @param {function(err, result)} callback 
 * @public
 */
channelModule.prototype.create = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.serviceKey === 'undefined') {
    err += 'params.serviceKey is required. ';
  }
  if (typeof params.serviceKey !== 'undefined' && typeof params.serviceKey !== 'number'){
    err += 'params.serviceKey must be number. ';
  }
  if (typeof params.channelName === 'undefined') {
    err += 'params.channelName is required. ';
  }
  if (typeof params.channelName !== 'undefined' && typeof params.channelName !== 'string'){
    err += 'params.channelName must be string. ';
  }
  if (typeof params.type === 'undefined') {
    err += 'params.type is required. ';
  }
  if (typeof params.type !== 'undefined' && typeof params.type !== 'string'){
    err += 'params.type must be string. ';
  }
  if (typeof params.contentDescription !== 'undefined' && typeof params.contentDescription !== 'string'){
    err += 'params.contentDescription must be string. ';
  }
  if (typeof params.note !== 'undefined' && typeof params.note !== 'string'){
    err += 'params.note must be string. ';
  }
  if (typeof params.logoUrl !== 'undefined' && typeof params.logoUrl !== 'string'){
    err += 'params.logoUrl must be string. ';
  }
  if (typeof params.contentVideoUrl !== 'undefined' && typeof params.contentVideoUrl !== 'string'){
    err += 'params.contentVideoUrl must be string. ';
  }
  if (typeof params.genre === 'undefined') {
    err += 'params.genre is required. ';
  }
  if (typeof params.genre !== 'undefined' && typeof params.genre !== 'string'){
    err += 'params.genre must be string. ';
  }
  if (typeof params.genre1 !== 'undefined' && typeof params.genre1 !== 'string'){
    err += 'params.genre1 must be string. ';
  }
  if (typeof params.unSubscribedMessage !== 'undefined' && typeof params.unSubscribedMessage !== 'string'){
    err += 'params.unSubscribedMessage must be string. ';
  }
  if (typeof params.epgSourceId === 'undefined') {
    err += 'params.epgSourceId is required. ';
  }
  if (typeof params.epgSourceId !== 'undefined' && typeof params.epgSourceId !== 'number'){
    err += 'params.epgSourceId must be number. ';
  }
  if (typeof params.recordable !== 'undefined' && typeof params.recordable !== 'boolean'){
    err += 'params.recordable must be boolean. ';
  }
  if (typeof params.safe !== 'undefined' && typeof params.safe !== 'boolean'){
    err += 'params.safe must be boolean. ';
  }
  if (typeof params.searchAZ !== 'undefined' && typeof params.searchAZ !== 'boolean'){
    err += 'params.searchAZ must be boolean. ';
  }
  if (typeof params.surfFlag !== 'undefined' && typeof params.surfFlag !== 'boolean'){
    err += 'params.surfFlag must be boolean. ';
  }
  if (typeof params.searchScanFlag !== 'undefined' && typeof params.searchScanFlag !== 'boolean'){
    err += 'params.searchScanFlag must be boolean. ';
  }
  if (typeof params.listingFlag !== 'undefined' && typeof params.listingFlag !== 'boolean'){
    err += 'params.listingFlag must be boolean. ';
  }
  if (typeof params.channelCode !== 'undefined' && typeof params.channelCode !== 'number'){
    err += 'params.channelCode must be number. ';
  }
  if (typeof params.sourceChannelID === 'undefined') {
    err += 'params.sourceChannelID is required. ';
  }
  if (typeof params.sourceChannelID !== 'undefined' && typeof params.sourceChannelID !== 'string'){
    err += 'params.sourceChannelID must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.post(
      this.basePath + '/' + pathParams.wyclubToken + '/channel/channel' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method channel - update
 * @summary channel.update — Update a channel
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.serviceKey]
 * @param {Object} params - Parameters send by the request
 * @param {string} params.label
 * @param {string} params.contentType
 * @param {string} params.genre
 * @param {string} params.genre1
 * @param {string} params.channelDescription
 * @param {string} params.minMaturityRating
 * @param {string} params.unSubscribedMessage
 * @param {number} params.epgSourceId
 * @param {boolean} params.recordable
 * @param {boolean} params.searchAZ
 * @param {boolean} params.surfFlag
 * @param {boolean} params.searchScanFlag
 * @param {boolean} params.listingFlag
 * @param {function(err, result)} callback 
 * @public
 */
channelModule.prototype.update = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.serviceKey === 'undefined') {
    err += 'pathParams.serviceKey is required. ';
  }
  if (typeof pathParams.serviceKey !== 'undefined' && typeof pathParams.serviceKey !== 'string'){
    err += 'pathParams.serviceKey must be string. ';
  }
  if (typeof params.label !== 'undefined' && typeof params.label !== 'string'){
    err += 'params.label must be string. ';
  }
  if (typeof params.contentType !== 'undefined' && typeof params.contentType !== 'string'){
    err += 'params.contentType must be string. ';
  }
  if (typeof params.genre !== 'undefined' && typeof params.genre !== 'string'){
    err += 'params.genre must be string. ';
  }
  if (typeof params.genre1 !== 'undefined' && typeof params.genre1 !== 'string'){
    err += 'params.genre1 must be string. ';
  }
  if (typeof params.channelDescription !== 'undefined' && typeof params.channelDescription !== 'string'){
    err += 'params.channelDescription must be string. ';
  }
  if (typeof params.minMaturityRating !== 'undefined' && typeof params.minMaturityRating !== 'string'){
    err += 'params.minMaturityRating must be string. ';
  }
  if (typeof params.unSubscribedMessage !== 'undefined' && typeof params.unSubscribedMessage !== 'string'){
    err += 'params.unSubscribedMessage must be string. ';
  }
  if (typeof params.epgSourceId !== 'undefined' && typeof params.epgSourceId !== 'number'){
    err += 'params.epgSourceId must be number. ';
  }
  if (typeof params.recordable !== 'undefined' && typeof params.recordable !== 'boolean'){
    err += 'params.recordable must be boolean. ';
  }
  if (typeof params.searchAZ !== 'undefined' && typeof params.searchAZ !== 'boolean'){
    err += 'params.searchAZ must be boolean. ';
  }
  if (typeof params.surfFlag !== 'undefined' && typeof params.surfFlag !== 'boolean'){
    err += 'params.surfFlag must be boolean. ';
  }
  if (typeof params.searchScanFlag !== 'undefined' && typeof params.searchScanFlag !== 'boolean'){
    err += 'params.searchScanFlag must be boolean. ';
  }
  if (typeof params.listingFlag !== 'undefined' && typeof params.listingFlag !== 'boolean'){
    err += 'params.listingFlag must be boolean. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.patch(
      this.basePath + '/' + pathParams.wyclubToken + '/channel/channel/' + pathParams.serviceKey + '' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method channel - delete
 * @summary channel.delete — Delete a channel
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.serviceKey]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
channelModule.prototype.delete = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.serviceKey === 'undefined') {
    err += 'pathParams.serviceKey is required. ';
  }
  if (typeof pathParams.serviceKey !== 'undefined' && typeof pathParams.serviceKey !== 'string'){
    err += 'pathParams.serviceKey must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.del(
      this.basePath + '/' + pathParams.wyclubToken + '/channel/channel/' + pathParams.serviceKey + '' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

module.exports = channelModule;