/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* jshint -W106 */

var _ = require('lodash');
var rest = require('restler');
var querystring = require('querystring');

/**
 * Initialize component
 * @param {string} basePath Api base path
 **/
var channelModule = function (basePath) {
  'use strict';

  this.basePath = basePath || '';
  this.lastError = undefined;
  this.lastResponse = undefined;
};

/**
 * @method channel - readAll
 * @summary channel.readAll — Read all channel
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
channelModule.prototype.readAll = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var defaultOptions = {
    followRedirects: false
  };
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.get(
    this.basePath + '/' + pathParams.wyclubToken + '/channel/channelList' + (params ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method channel - read
 * @summary channel.read — Read a channel
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.serviceKey]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
channelModule.prototype.read = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var defaultOptions = {
    followRedirects: false
  };
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.get(
    this.basePath + '/' + pathParams.wyclubToken + '/channel/channel/' + pathParams.serviceKey + '' + (params ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method channel - create
 * @summary channel.create — Write an IP channel
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {number} [params.serviceKey]
 * @param {string} [params.channelName]
 * @param {string} [params.type]
 * @param {string} params.contentDescription
 * @param {string} params.note
 * @param {string} [params.contentType]
 * @param {string} params.logoUrl
 * @param {string} params.contentVideoUrl
 * @param {string} [params.genre]
 * @param {string} params.genre1
 * @param {string} params.unSubscribedMessage
 * @param {number} [params.epgSourceId]
 * @param {boolean} params.recordable
 * @param {boolean} params.safe
 * @param {boolean} params.searchAZ
 * @param {boolean} params.surfFlag
 * @param {boolean} params.searchScanFlag
 * @param {boolean} params.listingFlag
 * @param {number} params.channelCode
 * @param {string} [params.sourceChannelID]
 * @param {function(err, result)} callback 
 * @public
 */
channelModule.prototype.create = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.post(
    this.basePath + '/' + pathParams.wyclubToken + '/channel/channel' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method channel - create
 * @summary channel.create — Write a DTT channel
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {number} [params.serviceKey]
 * @param {string} [params.channelName]
 * @param {string} [params.type]
 * @param {string} params.contentDescription
 * @param {string} params.note
 * @param {string} [params.contentType]
 * @param {string} params.logoUrl
 * @param {string} [params.genre]
 * @param {string} params.genre1
 * @param {string} params.unSubscribedMessage
 * @param {number} params.epgSourceId
 * @param {boolean} params.recordable
 * @param {boolean} params.safe
 * @param {boolean} params.searchAZ
 * @param {boolean} params.surfFlag
 * @param {boolean} params.searchScanFlag
 * @param {boolean} params.listingFlag
 * @param {number} params.channelCode
 * @param {string} [params.sourceChannelID]
 * @param {string} [params.networkID]
 * @param {string} [params.transportID]
 * @param {string} [params.serviceID]
 * @param {function(err, result)} callback 
 * @public
 */
channelModule.prototype.create = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.post(
    this.basePath + '/' + pathParams.wyclubToken + '/channel/channel' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method channel - create
 * @summary channel.create — Write a DTT channel with IP inheritance
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {number} [params.serviceKey]
 * @param {string} [params.channelName]
 * @param {string} [params.type]
 * @param {string} params.contentDescription
 * @param {string} params.note
 * @param {string} [params.contentType]
 * @param {string} [params.networkID]
 * @param {string} [params.transportID]
 * @param {string} [params.serviceID]
 * @param {string} [params.serviceKeySource]
 * @param {function(err, result)} callback 
 * @public
 */
channelModule.prototype.create = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.post(
    this.basePath + '/' + pathParams.wyclubToken + '/channel/channel' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method channel - create
 * @summary channel.create — Write a radio channel
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {number} [params.serviceKey]
 * @param {string} [params.channelName]
 * @param {string} [params.type]
 * @param {string} params.contentDescription
 * @param {string} params.note
 * @param {string} params.logoUrl
 * @param {string} params.contentVideoUrl
 * @param {string} [params.genre]
 * @param {string} params.genre1
 * @param {string} params.unSubscribedMessage
 * @param {number} [params.epgSourceId]
 * @param {boolean} params.recordable
 * @param {boolean} params.safe
 * @param {boolean} params.searchAZ
 * @param {boolean} params.surfFlag
 * @param {boolean} params.searchScanFlag
 * @param {boolean} params.listingFlag
 * @param {number} params.channelCode
 * @param {string} [params.sourceChannelID]
 * @param {function(err, result)} callback 
 * @public
 */
channelModule.prototype.create = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.post(
    this.basePath + '/' + pathParams.wyclubToken + '/channel/channel' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method channel - update
 * @summary channel.update — Update a channel
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.serviceKey]
 * @param {Object} params - Parameters send by the request
 * @param {string} params.label
 * @param {string} params.contentType
 * @param {string} params.genre
 * @param {string} params.genre1
 * @param {string} params.channelDescription
 * @param {string} params.minMaturityRating
 * @param {string} params.unSubscribedMessage
 * @param {number} params.epgSourceId
 * @param {boolean} params.recordable
 * @param {boolean} params.searchAZ
 * @param {boolean} params.surfFlag
 * @param {boolean} params.searchScanFlag
 * @param {boolean} params.listingFlag
 * @param {function(err, result)} callback 
 * @public
 */
channelModule.prototype.update = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.patch(
    this.basePath + '/' + pathParams.wyclubToken + '/channel/channel/' + pathParams.serviceKey + '' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method channel - delete
 * @summary channel.delete — Delete a channel
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.serviceKey]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
channelModule.prototype.delete = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.del(
    this.basePath + '/' + pathParams.wyclubToken + '/channel/channel/' + pathParams.serviceKey + '' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

module.exports = channelModule;