/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * @ngdoc service
 * @name wyclubBackofficeApp.wyclubsession
 * @description
 * # wyclubsession
 * Service in th wyclubBackofficeApp
 */
angular.module('wyclubBackofficeApp')
  .service('wyclubsession', function wyclubsession($q, $rootScope, $http) {

    /**
     * @method session - readSubscriber
     * @summary session.readSubscriber — Read the requested subscriber's info.
     * @param {Object} params - Parameters send by the request
     * @param {string} params.accessToken
     * @param {function(result)} promise
     * @public
     */
    this.readSubscriber = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.accessToken !== 'undefined' && typeof params.accessToken !== 'string') {
        err += 'params.accessToken must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.sessionBasePath + '/' + $rootScope.wyclubToken + '/sessionManager/sub',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method session - read
     * @summary session.read — Read information about my session
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.read = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.sessionBasePath + '/' + $rootScope.wyclubToken + '/sessionManager',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method session - createToken
     * @summary session.createToken — Create a new token with a specific application.
     * @param {Object} params - Parameters send by the request
     * @param {string} params.deviceId
     * @param {string} params.subscriberId
     * @param {function(result)} promise
     * @public
     */
    this.createToken = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.applicationId === 'undefined') {
        err += '$rootScope.applicationId is required. ';
      }
      if (typeof $rootScope.applicationId !== 'undefined' && typeof $rootScope.applicationId !== 'string') {
        err += '$rootScope.applicationId must be string. ';
      }
      if (typeof params.deviceId !== 'undefined' && typeof params.deviceId !== 'string') {
        err += 'params.deviceId must be string. ';
      }
      if (typeof params.subscriberId !== 'undefined' && typeof params.subscriberId !== 'string') {
        err += 'params.subscriberId must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.sessionBasePath + '/' + $rootScope.applicationId + '/sessionManager/token',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method session - deleteToken
     * @summary session.deleteToken — Delete a token
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.deleteToken = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'DELETE',
            url: $rootScope.sessionBasePath + '/' + $rootScope.wyclubToken + '/sessionManager/token',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

  });