/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */
 
/* jshint -W106 */

var rest = require('restler');
var querystring = require('querystring');

/**
 * Initialize component
 * @param {string} basePath Api base path
 **/
var sessionModule = function (basePath) {
  'use strict';
  this.basePath = basePath || '';
};

/**
 * @method session - readSubscriber
 * @summary session.readSubscriber — Read the requested subscriber's info.
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} params.accessToken
 * @param {function(err, result)} callback 
 * @public
 */
sessionModule.prototype.readSubscriber = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.accessToken !== 'undefined' && typeof params.accessToken !== 'string'){
    err += 'params.accessToken must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/sessionManager/sub' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method session - read
 * @summary session.read — Read information about my session
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
sessionModule.prototype.read = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/sessionManager' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method session - createToken
 * @summary session.createToken — Create a new token with a specific application.
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.applicationId]
 * @param {Object} params - Parameters send by the request
 * @param {string} params.deviceId
 * @param {string} params.subscriberId
 * @param {function(err, result)} callback 
 * @public
 */
sessionModule.prototype.createToken = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.applicationId === 'undefined') {
    err += 'pathParams.applicationId is required. ';
  }
  if (typeof pathParams.applicationId !== 'undefined' && typeof pathParams.applicationId !== 'string'){
    err += 'pathParams.applicationId must be string. ';
  }
  if (typeof params.deviceId !== 'undefined' && typeof params.deviceId !== 'string'){
    err += 'params.deviceId must be string. ';
  }
  if (typeof params.subscriberId !== 'undefined' && typeof params.subscriberId !== 'string'){
    err += 'params.subscriberId must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.post(
      this.basePath + '/' + pathParams.applicationId + '/sessionManager/token' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method session - deleteToken
 * @summary session.deleteToken — Delete a token
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
sessionModule.prototype.deleteToken = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.del(
      this.basePath + '/' + pathParams.wyclubToken + '/sessionManager/token' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

module.exports = sessionModule;