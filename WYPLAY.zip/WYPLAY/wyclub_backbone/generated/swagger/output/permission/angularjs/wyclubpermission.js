/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * @ngdoc service
 * @name wyclubBackofficeApp.wyclubpermission
 * @description
 * # wyclubpermission
 * Service in th wyclubBackofficeApp
 */
angular.module('wyclubBackofficeApp')
  .service('wyclubpermission', function wyclubpermission($q, $rootScope, $http) {

    /**
     * @method permission - readAll
     * @summary permission.readAll — Read all permissions
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.readAll = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.module === 'undefined') {
        err += '$rootScope.module is required. ';
      }
      if (typeof $rootScope.module !== 'undefined' && typeof $rootScope.module !== 'string') {
        err += '$rootScope.module must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.permissionBasePath + '/' + $rootScope.wyclubToken + '/' + $rootScope.module + '/permission',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method permission - update
     * @summary permission.update — Update a permission
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.group]
     * @param {function(result)} promise
     * @public
     */
    this.update = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.module === 'undefined') {
        err += '$rootScope.module is required. ';
      }
      if (typeof $rootScope.module !== 'undefined' && typeof $rootScope.module !== 'string') {
        err += '$rootScope.module must be string. ';
      }
      if (typeof $rootScope.type === 'undefined') {
        err += '$rootScope.type is required. ';
      }
      if (typeof $rootScope.type !== 'undefined' && typeof $rootScope.type !== 'string') {
        err += '$rootScope.type must be string. ';
      }
      if (typeof params.group === 'undefined') {
        err += 'params.group is required. ';
      }
      if (typeof params.group !== 'undefined' && typeof params.group !== 'string') {
        err += 'params.group must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'PATCH',
            url: $rootScope.permissionBasePath + '/' + $rootScope.wyclubToken + '/' + $rootScope.module + '/permission',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

  });