/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * @ngdoc service
 * @name wyclubBackofficeApp.wyclubscheduledTask
 * @description
 * # wyclubscheduledTask
 * Service in th wyclubBackofficeApp
 */
angular.module('wyclubBackofficeApp')
  .service('wyclubscheduledTask', function wyclubscheduledTask($q, $rootScope, $http) {

    /**
     * @method scheduledTask - readAll
     * @summary scheduledTask.readAll — Read all scheduled tasks
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.readAll = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.module === 'undefined') {
        err += '$rootScope.module is required. ';
      }
      if (typeof $rootScope.module !== 'undefined' && typeof $rootScope.module !== 'string') {
        err += '$rootScope.module must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.scheduledtaskBasePath + '/' + $rootScope.wyclubToken + '/' + $rootScope.module + '/scheduledTask',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method scheduledTask - delete
     * @summary scheduledTask.delete — Delete a task
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.delete = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.module === 'undefined') {
        err += '$rootScope.module is required. ';
      }
      if (typeof $rootScope.module !== 'undefined' && typeof $rootScope.module !== 'string') {
        err += '$rootScope.module must be string. ';
      }
      if (typeof $rootScope.id === 'undefined') {
        err += '$rootScope.id is required. ';
      }
      if (typeof $rootScope.id !== 'undefined' && typeof $rootScope.id !== 'string') {
        err += '$rootScope.id must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'DELETE',
            url: $rootScope.scheduledtaskBasePath + '/' + $rootScope.wyclubToken + '/' + $rootScope.module + '/scheduledTask/' + $rootScope.id + '',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

  });