/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * @ngdoc service
 * @name wyclubBackofficeApp.wyclubiApp
 * @description
 * # wyclubiApp
 * Service in th wyclubBackofficeApp
 */
angular.module('wyclubBackofficeApp')
  .service('wyclubiApp', function wyclubiApp($q, $rootScope, $http) {

    /**
     * @method iApp - readAll
     * @summary iApp.readAll — Read all iApps
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.readAll = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.iappBasePath + '/' + $rootScope.wyclubToken + '/iApp/iApps',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method iApp - read
     * @summary iApp.read — Read a iApp
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.read = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.iAppId === 'undefined') {
        err += '$rootScope.iAppId is required. ';
      }
      if (typeof $rootScope.iAppId !== 'undefined' && typeof $rootScope.iAppId !== 'string') {
        err += '$rootScope.iAppId must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.iappBasePath + '/' + $rootScope.wyclubToken + '/iApp/iApp/' + $rootScope.iAppId + '',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method iApp - create
     * @summary iApp.create — Write an iApp
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.label]
     * @param {string} [params.description]
     * @param {string} params.launchingMessage
     * @param {string} [params.url]
     * @param {function(result)} promise
     * @public
     */
    this.create = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.label === 'undefined') {
        err += 'params.label is required. ';
      }
      if (typeof params.label !== 'undefined' && typeof params.label !== 'string') {
        err += 'params.label must be string. ';
      }
      if (typeof params.description === 'undefined') {
        err += 'params.description is required. ';
      }
      if (typeof params.description !== 'undefined' && typeof params.description !== 'string') {
        err += 'params.description must be string. ';
      }
      if (typeof params.launchingMessage !== 'undefined' && typeof params.launchingMessage !== 'string') {
        err += 'params.launchingMessage must be string. ';
      }
      if (typeof params.url === 'undefined') {
        err += 'params.url is required. ';
      }
      if (typeof params.url !== 'undefined' && typeof params.url !== 'string') {
        err += 'params.url must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.iappBasePath + '/' + $rootScope.wyclubToken + '/iApp/iApp',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method iApp - update
     * @summary iApp.update — Update an iApp
     * @param {Object} params - Parameters send by the request
     * @param {string} params.label
     * @param {string} params.description
     * @param {string} params.launchingMessage
     * @param {string} params.url
     * @param {function(result)} promise
     * @public
     */
    this.update = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.iAppId === 'undefined') {
        err += '$rootScope.iAppId is required. ';
      }
      if (typeof $rootScope.iAppId !== 'undefined' && typeof $rootScope.iAppId !== 'string') {
        err += '$rootScope.iAppId must be string. ';
      }
      if (typeof params.label !== 'undefined' && typeof params.label !== 'string') {
        err += 'params.label must be string. ';
      }
      if (typeof params.description !== 'undefined' && typeof params.description !== 'string') {
        err += 'params.description must be string. ';
      }
      if (typeof params.launchingMessage !== 'undefined' && typeof params.launchingMessage !== 'string') {
        err += 'params.launchingMessage must be string. ';
      }
      if (typeof params.url !== 'undefined' && typeof params.url !== 'string') {
        err += 'params.url must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'PATCH',
            url: $rootScope.iappBasePath + '/' + $rootScope.wyclubToken + '/iApp/iApp/' + $rootScope.iAppId + '',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method iApp - delete
     * @summary iApp.delete — Delete an iApp
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.delete = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.iAppId === 'undefined') {
        err += '$rootScope.iAppId is required. ';
      }
      if (typeof $rootScope.iAppId !== 'undefined' && typeof $rootScope.iAppId !== 'string') {
        err += '$rootScope.iAppId must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'DELETE',
            url: $rootScope.iappBasePath + '/' + $rootScope.wyclubToken + '/iApp/iApp/' + $rootScope.iAppId + '',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method iApp - activate
     * @summary iApp.activate — Activate an iApp on one or more channels
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.iAppId]
     * @param {boolean} [params.activate]
     * @param {string} params.channels
     * @param {function(result)} promise
     * @public
     */
    this.activate = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.iAppId === 'undefined') {
        err += 'params.iAppId is required. ';
      }
      if (typeof params.iAppId !== 'undefined' && typeof params.iAppId !== 'string') {
        err += 'params.iAppId must be string. ';
      }
      if (typeof params.activate === 'undefined') {
        err += 'params.activate is required. ';
      }
      if (typeof params.activate !== 'undefined' && typeof params.activate !== 'boolean') {
        err += 'params.activate must be boolean. ';
      }
      if (typeof params.channels !== 'undefined' && typeof params.channels !== 'string') {
        err += 'params.channels must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.iappBasePath + '/' + $rootScope.wyclubToken + '/iApp/activate',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

  });