/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * @ngdoc service
 * @name wyclubBackofficeApp.wyclubcatalog
 * @description
 * # wyclubcatalog
 * Service in th wyclubBackofficeApp
 */
angular.module('wyclubBackofficeApp')
  .service('wyclubcatalog', function wyclubcatalog($q, $rootScope, $http) {

    /**
     * @method catalog - update
     * @summary catalog.update — Update catalog
     * @param {Object} params - Parameters send by the request
     * @param {number} params.bouquetKey
     * @param {string} params.name
     * @param {function(result)} promise
     * @public
     */
    this.update = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.catalogId === 'undefined') {
        err += '$rootScope.catalogId is required. ';
      }
      if (typeof $rootScope.catalogId !== 'undefined' && typeof $rootScope.catalogId !== 'string') {
        err += '$rootScope.catalogId must be string. ';
      }
      if (typeof params.bouquetKey !== 'undefined' && typeof params.bouquetKey !== 'number') {
        err += 'params.bouquetKey must be number. ';
      }
      if (typeof params.name !== 'undefined' && typeof params.name !== 'string') {
        err += 'params.name must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'PATCH',
            url: $rootScope.catalogBasePath + '/' + $rootScope.wyclubToken + '/iApp/catalog/' + $rootScope.catalogId + '',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method catalog - addIapps
     * @summary catalog.addIapps — Add new iApp in catalog
     * @param {Object} params - Parameters send by the request
     * @param {string} params.iapps
     * @param {function(result)} promise
     * @public
     */
    this.addIapps = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.catalogId === 'undefined') {
        err += '$rootScope.catalogId is required. ';
      }
      if (typeof $rootScope.catalogId !== 'undefined' && typeof $rootScope.catalogId !== 'string') {
        err += '$rootScope.catalogId must be string. ';
      }
      if (typeof params.iapps !== 'undefined' && typeof params.iapps !== 'string') {
        err += 'params.iapps must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.catalogBasePath + '/' + $rootScope.wyclubToken + '/iApp/catalog/' + $rootScope.catalogId + '/iapp',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method catalog - updateIapps
     * @summary catalog.updateIapps — Update an iApp of a catalog
     * @param {Object} params - Parameters send by the request
     * @param {number} [params.iapps]
     * @param {function(result)} promise
     * @public
     */
    this.updateIapps = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.catalogId === 'undefined') {
        err += '$rootScope.catalogId is required. ';
      }
      if (typeof $rootScope.catalogId !== 'undefined' && typeof $rootScope.catalogId !== 'string') {
        err += '$rootScope.catalogId must be string. ';
      }
      if (typeof params.iapps === 'undefined') {
        err += 'params.iapps is required. ';
      }
      if (typeof params.iapps !== 'undefined' && typeof params.iapps !== 'number') {
        err += 'params.iapps must be number. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'PATCH',
            url: $rootScope.catalogBasePath + '/' + $rootScope.wyclubToken + '/iApp/catalog/' + $rootScope.catalogId + '/iapp',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method catalog - deleteIapps
     * @summary catalog.deleteIapps — Remove an iapp of a catalog
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.iapps]
     * @param {function(result)} promise
     * @public
     */
    this.deleteIapps = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.catalogId === 'undefined') {
        err += '$rootScope.catalogId is required. ';
      }
      if (typeof $rootScope.catalogId !== 'undefined' && typeof $rootScope.catalogId !== 'string') {
        err += '$rootScope.catalogId must be string. ';
      }
      if (typeof params.iapps === 'undefined') {
        err += 'params.iapps is required. ';
      }
      if (typeof params.iapps !== 'undefined' && typeof params.iapps !== 'string') {
        err += 'params.iapps must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'DELETE',
            url: $rootScope.catalogBasePath + '/' + $rootScope.wyclubToken + '/iApp/catalog/' + $rootScope.catalogId + '/iapp',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method catalog - addChannels
     * @summary catalog.addChannels — Add channels in iapp's catalog
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.appId]
     * @param {string} [params.channels]
     * @param {function(result)} promise
     * @public
     */
    this.addChannels = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.catalogId === 'undefined') {
        err += '$rootScope.catalogId is required. ';
      }
      if (typeof $rootScope.catalogId !== 'undefined' && typeof $rootScope.catalogId !== 'string') {
        err += '$rootScope.catalogId must be string. ';
      }
      if (typeof params.appId === 'undefined') {
        err += 'params.appId is required. ';
      }
      if (typeof params.appId !== 'undefined' && typeof params.appId !== 'string') {
        err += 'params.appId must be string. ';
      }
      if (typeof params.channels === 'undefined') {
        err += 'params.channels is required. ';
      }
      if (typeof params.channels !== 'undefined' && typeof params.channels !== 'string') {
        err += 'params.channels must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.catalogBasePath + '/' + $rootScope.wyclubToken + '/iApp/catalog/' + $rootScope.catalogId + '/channel',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method catalog - updateChannels
     * @summary catalog.updateChannels — Update channels from an iApp of a catalog
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.appId]
     * @param {string} [params.channels]
     * @param {function(result)} promise
     * @public
     */
    this.updateChannels = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.catalogId === 'undefined') {
        err += '$rootScope.catalogId is required. ';
      }
      if (typeof $rootScope.catalogId !== 'undefined' && typeof $rootScope.catalogId !== 'string') {
        err += '$rootScope.catalogId must be string. ';
      }
      if (typeof params.appId === 'undefined') {
        err += 'params.appId is required. ';
      }
      if (typeof params.appId !== 'undefined' && typeof params.appId !== 'string') {
        err += 'params.appId must be string. ';
      }
      if (typeof params.channels === 'undefined') {
        err += 'params.channels is required. ';
      }
      if (typeof params.channels !== 'undefined' && typeof params.channels !== 'string') {
        err += 'params.channels must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'PATCH',
            url: $rootScope.catalogBasePath + '/' + $rootScope.wyclubToken + '/iApp/catalog/' + $rootScope.catalogId + '/channel',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method catalog - deleteChannels
     * @summary catalog.deleteChannels — Remove channels from an iApp of a catalog
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.appId]
     * @param {string} [params.channels]
     * @param {function(result)} promise
     * @public
     */
    this.deleteChannels = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.catalogId === 'undefined') {
        err += '$rootScope.catalogId is required. ';
      }
      if (typeof $rootScope.catalogId !== 'undefined' && typeof $rootScope.catalogId !== 'string') {
        err += '$rootScope.catalogId must be string. ';
      }
      if (typeof params.appId === 'undefined') {
        err += 'params.appId is required. ';
      }
      if (typeof params.appId !== 'undefined' && typeof params.appId !== 'string') {
        err += 'params.appId must be string. ';
      }
      if (typeof params.channels === 'undefined') {
        err += 'params.channels is required. ';
      }
      if (typeof params.channels !== 'undefined' && typeof params.channels !== 'string') {
        err += 'params.channels must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'DELETE',
            url: $rootScope.catalogBasePath + '/' + $rootScope.wyclubToken + '/iApp/catalog/' + $rootScope.catalogId + '/channel',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method catalog - read
     * @summary catalog.read — Read a catalog
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.read = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.catalogId === 'undefined') {
        err += '$rootScope.catalogId is required. ';
      }
      if (typeof $rootScope.catalogId !== 'undefined' && typeof $rootScope.catalogId !== 'string') {
        err += '$rootScope.catalogId must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.catalogBasePath + '/' + $rootScope.wyclubToken + '/iApp/catalog/' + $rootScope.catalogId + '',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method catalog - create
     * @summary catalog.create — Create a catalog
     * @param {Object} params - Parameters send by the request
     * @param {number} [params.catalogId]
     * @param {number} [params.bouquetKey]
     * @param {string} [params.name]
     * @param {string} [params.iapps]
     * @param {function(result)} promise
     * @public
     */
    this.create = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.catalogId === 'undefined') {
        err += 'params.catalogId is required. ';
      }
      if (typeof params.catalogId !== 'undefined' && typeof params.catalogId !== 'number') {
        err += 'params.catalogId must be number. ';
      }
      if (typeof params.bouquetKey === 'undefined') {
        err += 'params.bouquetKey is required. ';
      }
      if (typeof params.bouquetKey !== 'undefined' && typeof params.bouquetKey !== 'number') {
        err += 'params.bouquetKey must be number. ';
      }
      if (typeof params.name === 'undefined') {
        err += 'params.name is required. ';
      }
      if (typeof params.name !== 'undefined' && typeof params.name !== 'string') {
        err += 'params.name must be string. ';
      }
      if (typeof params.iapps === 'undefined') {
        err += 'params.iapps is required. ';
      }
      if (typeof params.iapps !== 'undefined' && typeof params.iapps !== 'string') {
        err += 'params.iapps must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.catalogBasePath + '/' + $rootScope.wyclubToken + '/iApp/catalog',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method catalog - delete
     * @summary catalog.delete — Delete a catalog
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.delete = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.catalogId === 'undefined') {
        err += '$rootScope.catalogId is required. ';
      }
      if (typeof $rootScope.catalogId !== 'undefined' && typeof $rootScope.catalogId !== 'string') {
        err += '$rootScope.catalogId must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'DELETE',
            url: $rootScope.catalogBasePath + '/' + $rootScope.wyclubToken + '/iApp/catalog/' + $rootScope.catalogId + '',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

  });