/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* jshint -W106 */

var _ = require('lodash');
var rest = require('restler');
var querystring = require('querystring');

/**
 * Initialize component
 * @param {string} basePath Api base path
 **/
var iAppModule = function (basePath) {
  'use strict';

  this.basePath = basePath || '';
  this.lastError = undefined;
  this.lastResponse = undefined;
};

/**
 * @method iApp - readAll
 * @summary iApp.readAll — Read all iApps
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
iAppModule.prototype.readAll = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var defaultOptions = {
    followRedirects: false
  };
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.get(
    this.basePath + '/' + pathParams.wyclubToken + '/iApp/iApps' + (params ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method iApp - read
 * @summary iApp.read — Read a iApp
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.iAppId]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
iAppModule.prototype.read = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var defaultOptions = {
    followRedirects: false
  };
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.get(
    this.basePath + '/' + pathParams.wyclubToken + '/iApp/iApp/' + pathParams.iAppId + '' + (params ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method iApp - create
 * @summary iApp.create — Write an iApp
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.label]
 * @param {string} [params.description]
 * @param {string} params.launchingMessage
 * @param {string} [params.url]
 * @param {function(err, result)} callback 
 * @public
 */
iAppModule.prototype.create = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.post(
    this.basePath + '/' + pathParams.wyclubToken + '/iApp/iApp' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method iApp - update
 * @summary iApp.update — Update an iApp
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.iAppId]
 * @param {Object} params - Parameters send by the request
 * @param {string} params.label
 * @param {string} params.description
 * @param {string} params.launchingMessage
 * @param {string} params.url
 * @param {function(err, result)} callback 
 * @public
 */
iAppModule.prototype.update = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.patch(
    this.basePath + '/' + pathParams.wyclubToken + '/iApp/iApp/' + pathParams.iAppId + '' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method iApp - delete
 * @summary iApp.delete — Delete an iApp
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.iAppId]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
iAppModule.prototype.delete = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.del(
    this.basePath + '/' + pathParams.wyclubToken + '/iApp/iApp/' + pathParams.iAppId + '' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method iApp - activate
 * @summary iApp.activate — Activate an iApp on one or more channels
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.iAppId]
 * @param {boolean} [params.activate]
 * @param {string} params.channels
 * @param {function(err, result)} callback 
 * @public
 */
iAppModule.prototype.activate = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.post(
    this.basePath + '/' + pathParams.wyclubToken + '/iApp/activate' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

module.exports = iAppModule;