/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* jshint -W106 */

var _ = require('lodash');
var rest = require('restler');
var querystring = require('querystring');

/**
 * Initialize component
 * @param {string} basePath Api base path
 **/
var catalogModule = function (basePath) {
  'use strict';

  this.basePath = basePath || '';
  this.lastError = undefined;
  this.lastResponse = undefined;
};

/**
 * @method catalog - update
 * @summary catalog.update — Update catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {number} params.bouquetKey
 * @param {string} params.name
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.update = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.patch(
    this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method catalog - addIapps
 * @summary catalog.addIapps — Add new iApp in catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {string} params.iapps
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.addIapps = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.post(
    this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '/iapp' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method catalog - updateIapps
 * @summary catalog.updateIapps — Update an iApp of a catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {number} [params.iapps]
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.updateIapps = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.patch(
    this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '/iapp' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method catalog - deleteIapps
 * @summary catalog.deleteIapps — Remove an iapp of a catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.iapps]
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.deleteIapps = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.del(
    this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '/iapp' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method catalog - addChannels
 * @summary catalog.addChannels — Add channels in iapp's catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.appId]
 * @param {string} [params.channels]
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.addChannels = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.post(
    this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '/channel' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method catalog - updateChannels
 * @summary catalog.updateChannels — Update channels from an iApp of a catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.appId]
 * @param {string} [params.channels]
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.updateChannels = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.patch(
    this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '/channel' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method catalog - deleteChannels
 * @summary catalog.deleteChannels — Remove channels from an iApp of a catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.appId]
 * @param {string} [params.channels]
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.deleteChannels = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.del(
    this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '/channel' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method catalog - read
 * @summary catalog.read — Read a catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.read = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var defaultOptions = {
    followRedirects: false
  };
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.get(
    this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '' + (params ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method catalog - create
 * @summary catalog.create — Create a catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {number} [params.catalogId]
 * @param {number} [params.bouquetKey]
 * @param {string} [params.name]
 * @param {string} [params.iapps]
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.create = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.post(
    this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method catalog - delete
 * @summary catalog.delete — Delete a catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.delete = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.del(
    this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

module.exports = catalogModule;