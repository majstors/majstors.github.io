/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */
 
/* jshint -W106 */

var rest = require('restler');
var querystring = require('querystring');

/**
 * Initialize component
 * @param {string} basePath Api base path
 **/
var catalogModule = function (basePath) {
  'use strict';
  this.basePath = basePath || '';
};

/**
 * @method catalog - update
 * @summary catalog.update — Update catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {number} params.bouquetKey
 * @param {string} params.name
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.update = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.catalogId === 'undefined') {
    err += 'pathParams.catalogId is required. ';
  }
  if (typeof pathParams.catalogId !== 'undefined' && typeof pathParams.catalogId !== 'string'){
    err += 'pathParams.catalogId must be string. ';
  }
  if (typeof params.bouquetKey !== 'undefined' && typeof params.bouquetKey !== 'number'){
    err += 'params.bouquetKey must be number. ';
  }
  if (typeof params.name !== 'undefined' && typeof params.name !== 'string'){
    err += 'params.name must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.patch(
      this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method catalog - addIapps
 * @summary catalog.addIapps — Add new iApp in catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {string} params.iapps
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.addIapps = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.catalogId === 'undefined') {
    err += 'pathParams.catalogId is required. ';
  }
  if (typeof pathParams.catalogId !== 'undefined' && typeof pathParams.catalogId !== 'string'){
    err += 'pathParams.catalogId must be string. ';
  }
  if (typeof params.iapps !== 'undefined' && typeof params.iapps !== 'string'){
    err += 'params.iapps must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.post(
      this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '/iapp' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method catalog - updateIapps
 * @summary catalog.updateIapps — Update an iApp of a catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {number} [params.iapps]
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.updateIapps = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.catalogId === 'undefined') {
    err += 'pathParams.catalogId is required. ';
  }
  if (typeof pathParams.catalogId !== 'undefined' && typeof pathParams.catalogId !== 'string'){
    err += 'pathParams.catalogId must be string. ';
  }
  if (typeof params.iapps === 'undefined') {
    err += 'params.iapps is required. ';
  }
  if (typeof params.iapps !== 'undefined' && typeof params.iapps !== 'number'){
    err += 'params.iapps must be number. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.patch(
      this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '/iapp' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method catalog - deleteIapps
 * @summary catalog.deleteIapps — Remove an iapp of a catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.iapps]
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.deleteIapps = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.catalogId === 'undefined') {
    err += 'pathParams.catalogId is required. ';
  }
  if (typeof pathParams.catalogId !== 'undefined' && typeof pathParams.catalogId !== 'string'){
    err += 'pathParams.catalogId must be string. ';
  }
  if (typeof params.iapps === 'undefined') {
    err += 'params.iapps is required. ';
  }
  if (typeof params.iapps !== 'undefined' && typeof params.iapps !== 'string'){
    err += 'params.iapps must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.del(
      this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '/iapp' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method catalog - addChannels
 * @summary catalog.addChannels — Add channels in iapp's catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.appId]
 * @param {string} [params.channels]
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.addChannels = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.catalogId === 'undefined') {
    err += 'pathParams.catalogId is required. ';
  }
  if (typeof pathParams.catalogId !== 'undefined' && typeof pathParams.catalogId !== 'string'){
    err += 'pathParams.catalogId must be string. ';
  }
  if (typeof params.appId === 'undefined') {
    err += 'params.appId is required. ';
  }
  if (typeof params.appId !== 'undefined' && typeof params.appId !== 'string'){
    err += 'params.appId must be string. ';
  }
  if (typeof params.channels === 'undefined') {
    err += 'params.channels is required. ';
  }
  if (typeof params.channels !== 'undefined' && typeof params.channels !== 'string'){
    err += 'params.channels must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.post(
      this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '/channel' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method catalog - updateChannels
 * @summary catalog.updateChannels — Update channels from an iApp of a catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.appId]
 * @param {string} [params.channels]
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.updateChannels = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.catalogId === 'undefined') {
    err += 'pathParams.catalogId is required. ';
  }
  if (typeof pathParams.catalogId !== 'undefined' && typeof pathParams.catalogId !== 'string'){
    err += 'pathParams.catalogId must be string. ';
  }
  if (typeof params.appId === 'undefined') {
    err += 'params.appId is required. ';
  }
  if (typeof params.appId !== 'undefined' && typeof params.appId !== 'string'){
    err += 'params.appId must be string. ';
  }
  if (typeof params.channels === 'undefined') {
    err += 'params.channels is required. ';
  }
  if (typeof params.channels !== 'undefined' && typeof params.channels !== 'string'){
    err += 'params.channels must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.patch(
      this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '/channel' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method catalog - deleteChannels
 * @summary catalog.deleteChannels — Remove channels from an iApp of a catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.appId]
 * @param {string} [params.channels]
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.deleteChannels = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.catalogId === 'undefined') {
    err += 'pathParams.catalogId is required. ';
  }
  if (typeof pathParams.catalogId !== 'undefined' && typeof pathParams.catalogId !== 'string'){
    err += 'pathParams.catalogId must be string. ';
  }
  if (typeof params.appId === 'undefined') {
    err += 'params.appId is required. ';
  }
  if (typeof params.appId !== 'undefined' && typeof params.appId !== 'string'){
    err += 'params.appId must be string. ';
  }
  if (typeof params.channels === 'undefined') {
    err += 'params.channels is required. ';
  }
  if (typeof params.channels !== 'undefined' && typeof params.channels !== 'string'){
    err += 'params.channels must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.del(
      this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '/channel' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method catalog - read
 * @summary catalog.read — Read a catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.read = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.catalogId === 'undefined') {
    err += 'pathParams.catalogId is required. ';
  }
  if (typeof pathParams.catalogId !== 'undefined' && typeof pathParams.catalogId !== 'string'){
    err += 'pathParams.catalogId must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method catalog - create
 * @summary catalog.create — Create a catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {number} [params.catalogId]
 * @param {number} [params.bouquetKey]
 * @param {string} [params.name]
 * @param {string} [params.iapps]
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.create = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.catalogId === 'undefined') {
    err += 'params.catalogId is required. ';
  }
  if (typeof params.catalogId !== 'undefined' && typeof params.catalogId !== 'number'){
    err += 'params.catalogId must be number. ';
  }
  if (typeof params.bouquetKey === 'undefined') {
    err += 'params.bouquetKey is required. ';
  }
  if (typeof params.bouquetKey !== 'undefined' && typeof params.bouquetKey !== 'number'){
    err += 'params.bouquetKey must be number. ';
  }
  if (typeof params.name === 'undefined') {
    err += 'params.name is required. ';
  }
  if (typeof params.name !== 'undefined' && typeof params.name !== 'string'){
    err += 'params.name must be string. ';
  }
  if (typeof params.iapps === 'undefined') {
    err += 'params.iapps is required. ';
  }
  if (typeof params.iapps !== 'undefined' && typeof params.iapps !== 'string'){
    err += 'params.iapps must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.post(
      this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method catalog - delete
 * @summary catalog.delete — Delete a catalog
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.catalogId]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
catalogModule.prototype.delete = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.catalogId === 'undefined') {
    err += 'pathParams.catalogId is required. ';
  }
  if (typeof pathParams.catalogId !== 'undefined' && typeof pathParams.catalogId !== 'string'){
    err += 'pathParams.catalogId must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.del(
      this.basePath + '/' + pathParams.wyclubToken + '/iApp/catalog/' + pathParams.catalogId + '' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

module.exports = catalogModule;