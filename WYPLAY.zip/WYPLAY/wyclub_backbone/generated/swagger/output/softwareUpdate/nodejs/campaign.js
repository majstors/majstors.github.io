/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */
 
/* jshint -W106 */

var rest = require('restler');
var querystring = require('querystring');

/**
 * Initialize component
 * @param {string} basePath Api base path
 **/
var campaignModule = function (basePath) {
  'use strict';
  this.basePath = basePath || '';
};

/**
 * @method campaign - create
 * @summary campaign.create - Create a software update campaign
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.resourceType]
 * @param {string} [params.values]
 * @param {function(err, result)} callback 
 * @public
 */
campaignModule.prototype.create = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.resourceType === 'undefined') {
    err += 'params.resourceType is required. ';
  }
  if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string'){
    err += 'params.resourceType must be string. ';
  }
  if (typeof params.values === 'undefined') {
    err += 'params.values is required. ';
  }
  if (typeof params.values !== 'undefined' && typeof params.values !== 'string'){
    err += 'params.values must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.post(
      this.basePath + '/' + pathParams.wyclubToken + '/softwareUpdate/campaign' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method campaign - update
 * @summary campaign.update - Update a software update campaign
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.campaignId]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.resourceType]
 * @param {string} [params.values]
 * @param {function(err, result)} callback 
 * @public
 */
campaignModule.prototype.update = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.campaignId === 'undefined') {
    err += 'pathParams.campaignId is required. ';
  }
  if (typeof pathParams.campaignId !== 'undefined' && typeof pathParams.campaignId !== 'string'){
    err += 'pathParams.campaignId must be string. ';
  }
  if (typeof params.resourceType === 'undefined') {
    err += 'params.resourceType is required. ';
  }
  if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string'){
    err += 'params.resourceType must be string. ';
  }
  if (typeof params.values === 'undefined') {
    err += 'params.values is required. ';
  }
  if (typeof params.values !== 'undefined' && typeof params.values !== 'string'){
    err += 'params.values must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.patch(
      this.basePath + '/' + pathParams.wyclubToken + '/softwareUpdate/campaign/' + pathParams.campaignId + '' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method campaign - read
 * @summary campaign.read - Read a software update campaign
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.campaignId]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.resourceType]
 * @param {function(err, result)} callback 
 * @public
 */
campaignModule.prototype.read = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.campaignId === 'undefined') {
    err += 'pathParams.campaignId is required. ';
  }
  if (typeof pathParams.campaignId !== 'undefined' && typeof pathParams.campaignId !== 'string'){
    err += 'pathParams.campaignId must be string. ';
  }
  if (typeof params.resourceType === 'undefined') {
    err += 'params.resourceType is required. ';
  }
  if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string'){
    err += 'params.resourceType must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/softwareUpdate/campaign/' + pathParams.campaignId + '' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method campaign - readAll
 * @summary campaign.readAll - Read all software update campaigns
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.resourceType]
 * @param {function(err, result)} callback 
 * @public
 */
campaignModule.prototype.readAll = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.resourceType === 'undefined') {
    err += 'params.resourceType is required. ';
  }
  if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string'){
    err += 'params.resourceType must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/softwareUpdate/campaigns' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method campaign - create
 * @summary campaign.create - Create a bootloader update campaign
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.resourceType]
 * @param {string} [params.values]
 * @param {function(err, result)} callback 
 * @public
 */
campaignModule.prototype.create = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.resourceType === 'undefined') {
    err += 'params.resourceType is required. ';
  }
  if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string'){
    err += 'params.resourceType must be string. ';
  }
  if (typeof params.values === 'undefined') {
    err += 'params.values is required. ';
  }
  if (typeof params.values !== 'undefined' && typeof params.values !== 'string'){
    err += 'params.values must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.post(
      this.basePath + '/' + pathParams.wyclubToken + '/softwareUpdate/campaign' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method campaign - update
 * @summary campaign.update - Update a bootloader update campaign
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.campaignId]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.resourceType=bootloader]
 * @param {string} [params.values]
 * @param {function(err, result)} callback 
 * @public
 */
campaignModule.prototype.update = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.campaignId === 'undefined') {
    err += 'pathParams.campaignId is required. ';
  }
  if (typeof pathParams.campaignId !== 'undefined' && typeof pathParams.campaignId !== 'string'){
    err += 'pathParams.campaignId must be string. ';
  }
  if (typeof params.resourceType=bootloader === 'undefined') {
    err += 'params.resourceType=bootloader is required. ';
  }
  if (typeof params.resourceType=bootloader !== 'undefined' && typeof params.resourceType=bootloader !== 'string'){
    err += 'params.resourceType=bootloader must be string. ';
  }
  if (typeof params.values === 'undefined') {
    err += 'params.values is required. ';
  }
  if (typeof params.values !== 'undefined' && typeof params.values !== 'string'){
    err += 'params.values must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.patch(
      this.basePath + '/' + pathParams.wyclubToken + '/softwareUpdate/campaign/' + pathParams.campaignId + '' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method campaign - delete
 * @summary campaign.delete — Delete a campaign
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.campaignId]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.resourceType]
 * @param {function(err, result)} callback 
 * @public
 */
campaignModule.prototype.delete = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.campaignId === 'undefined') {
    err += 'pathParams.campaignId is required. ';
  }
  if (typeof pathParams.campaignId !== 'undefined' && typeof pathParams.campaignId !== 'string'){
    err += 'pathParams.campaignId must be string. ';
  }
  if (typeof params.resourceType === 'undefined') {
    err += 'params.resourceType is required. ';
  }
  if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string'){
    err += 'params.resourceType must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.del(
      this.basePath + '/' + pathParams.wyclubToken + '/softwareUpdate/campaign/' + pathParams.campaignId + '' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method campaign - read
 * @summary campaign.read - Read a bootloader update campaign
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.campaignId]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.resourceType]
 * @param {function(err, result)} callback 
 * @public
 */
campaignModule.prototype.read = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.campaignId === 'undefined') {
    err += 'pathParams.campaignId is required. ';
  }
  if (typeof pathParams.campaignId !== 'undefined' && typeof pathParams.campaignId !== 'string'){
    err += 'pathParams.campaignId must be string. ';
  }
  if (typeof params.resourceType === 'undefined') {
    err += 'params.resourceType is required. ';
  }
  if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string'){
    err += 'params.resourceType must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/softwareUpdate/campaign/' + pathParams.campaignId + '' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method campaign - readAll
 * @summary campaign.readAll - Read all bootloader update campaigns
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.resourceType]
 * @param {function(err, result)} callback 
 * @public
 */
campaignModule.prototype.readAll = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.resourceType === 'undefined') {
    err += 'params.resourceType is required. ';
  }
  if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string'){
    err += 'params.resourceType must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/softwareUpdate/campaigns' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

module.exports = campaignModule;