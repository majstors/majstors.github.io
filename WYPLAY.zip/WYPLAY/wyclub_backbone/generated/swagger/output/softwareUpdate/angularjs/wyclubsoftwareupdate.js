/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * @ngdoc service
 * @name wyclubBackofficeApp.wyclubsoftwareUpdate
 * @description
 * # wyclubsoftwareUpdate
 * Service in th wyclubBackofficeApp
 */
angular.module('wyclubBackofficeApp')
  .service('wyclubsoftwareUpdate', function wyclubsoftwareUpdate($q, $rootScope, $http) {

    /**
     * @method softwareUpdate - upload
     * @summary softwareUpdate.upload - Schedule upload of a new binary file to Origin servers. If no date timestamp is given, the upload is on this request.
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.resourceName]
     * @param {string} [params.resourceVersion]
     * @param {string} params.content-type
     * @param {string} params.uploadDate
     * @param {function(result)} promise
     * @public
     */
    this.upload = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.resourceType === 'undefined') {
        err += '$rootScope.resourceType is required. ';
      }
      if (typeof $rootScope.resourceType !== 'undefined' && typeof $rootScope.resourceType !== 'string') {
        err += '$rootScope.resourceType must be string. ';
      }
      if (typeof params.resourceName === 'undefined') {
        err += 'params.resourceName is required. ';
      }
      if (typeof params.resourceName !== 'undefined' && typeof params.resourceName !== 'string') {
        err += 'params.resourceName must be string. ';
      }
      if (typeof params.resourceVersion === 'undefined') {
        err += 'params.resourceVersion is required. ';
      }
      if (typeof params.resourceVersion !== 'undefined' && typeof params.resourceVersion !== 'string') {
        err += 'params.resourceVersion must be string. ';
      }
      if (typeof params.content-type !== 'undefined' && typeof params.content-type !== 'string') {
        err += 'params.content-type must be string. ';
      }
      if (typeof params.uploadDate !== 'undefined' && typeof params.uploadDate !== 'string') {
        err += 'params.uploadDate must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.softwareupdateBasePath + '/' + $rootScope.wyclubToken + '/softwareUpdate/' + $rootScope.resourceType + '/upload',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

  });