/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * @ngdoc service
 * @name wyclubBackofficeApp.wyclubcampaign
 * @description
 * # wyclubcampaign
 * Service in th wyclubBackofficeApp
 */
angular.module('wyclubBackofficeApp')
  .service('wyclubcampaign', function wyclubcampaign($q, $rootScope, $http) {

    /**
     * @method campaign - create
     * @summary campaign.create - Create a software update campaign
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.resourceType]
     * @param {string} [params.values]
     * @param {function(result)} promise
     * @public
     */
    this.create = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.resourceType === 'undefined') {
        err += 'params.resourceType is required. ';
      }
      if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string') {
        err += 'params.resourceType must be string. ';
      }
      if (typeof params.values === 'undefined') {
        err += 'params.values is required. ';
      }
      if (typeof params.values !== 'undefined' && typeof params.values !== 'string') {
        err += 'params.values must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.campaignBasePath + '/' + $rootScope.wyclubToken + '/softwareUpdate/campaign',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method campaign - update
     * @summary campaign.update - Update a software update campaign
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.resourceType]
     * @param {string} [params.values]
     * @param {function(result)} promise
     * @public
     */
    this.update = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.campaignId === 'undefined') {
        err += '$rootScope.campaignId is required. ';
      }
      if (typeof $rootScope.campaignId !== 'undefined' && typeof $rootScope.campaignId !== 'string') {
        err += '$rootScope.campaignId must be string. ';
      }
      if (typeof params.resourceType === 'undefined') {
        err += 'params.resourceType is required. ';
      }
      if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string') {
        err += 'params.resourceType must be string. ';
      }
      if (typeof params.values === 'undefined') {
        err += 'params.values is required. ';
      }
      if (typeof params.values !== 'undefined' && typeof params.values !== 'string') {
        err += 'params.values must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'PATCH',
            url: $rootScope.campaignBasePath + '/' + $rootScope.wyclubToken + '/softwareUpdate/campaign/' + $rootScope.campaignId + '',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method campaign - read
     * @summary campaign.read - Read a software update campaign
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.resourceType]
     * @param {function(result)} promise
     * @public
     */
    this.read = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.campaignId === 'undefined') {
        err += '$rootScope.campaignId is required. ';
      }
      if (typeof $rootScope.campaignId !== 'undefined' && typeof $rootScope.campaignId !== 'string') {
        err += '$rootScope.campaignId must be string. ';
      }
      if (typeof params.resourceType === 'undefined') {
        err += 'params.resourceType is required. ';
      }
      if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string') {
        err += 'params.resourceType must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.campaignBasePath + '/' + $rootScope.wyclubToken + '/softwareUpdate/campaign/' + $rootScope.campaignId + '',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method campaign - readAll
     * @summary campaign.readAll - Read all software update campaigns
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.resourceType]
     * @param {function(result)} promise
     * @public
     */
    this.readAll = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.resourceType === 'undefined') {
        err += 'params.resourceType is required. ';
      }
      if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string') {
        err += 'params.resourceType must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.campaignBasePath + '/' + $rootScope.wyclubToken + '/softwareUpdate/campaigns',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method campaign - create
     * @summary campaign.create - Create a bootloader update campaign
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.resourceType]
     * @param {string} [params.values]
     * @param {function(result)} promise
     * @public
     */
    this.create = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.resourceType === 'undefined') {
        err += 'params.resourceType is required. ';
      }
      if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string') {
        err += 'params.resourceType must be string. ';
      }
      if (typeof params.values === 'undefined') {
        err += 'params.values is required. ';
      }
      if (typeof params.values !== 'undefined' && typeof params.values !== 'string') {
        err += 'params.values must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.campaignBasePath + '/' + $rootScope.wyclubToken + '/softwareUpdate/campaign',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method campaign - update
     * @summary campaign.update - Update a bootloader update campaign
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.resourceType=bootloader]
     * @param {string} [params.values]
     * @param {function(result)} promise
     * @public
     */
    this.update = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.campaignId === 'undefined') {
        err += '$rootScope.campaignId is required. ';
      }
      if (typeof $rootScope.campaignId !== 'undefined' && typeof $rootScope.campaignId !== 'string') {
        err += '$rootScope.campaignId must be string. ';
      }
      if (typeof params.resourceType=bootloader === 'undefined') {
        err += 'params.resourceType=bootloader is required. ';
      }
      if (typeof params.resourceType=bootloader !== 'undefined' && typeof params.resourceType=bootloader !== 'string') {
        err += 'params.resourceType=bootloader must be string. ';
      }
      if (typeof params.values === 'undefined') {
        err += 'params.values is required. ';
      }
      if (typeof params.values !== 'undefined' && typeof params.values !== 'string') {
        err += 'params.values must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'PATCH',
            url: $rootScope.campaignBasePath + '/' + $rootScope.wyclubToken + '/softwareUpdate/campaign/' + $rootScope.campaignId + '',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method campaign - delete
     * @summary campaign.delete — Delete a campaign
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.resourceType]
     * @param {function(result)} promise
     * @public
     */
    this.delete = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.campaignId === 'undefined') {
        err += '$rootScope.campaignId is required. ';
      }
      if (typeof $rootScope.campaignId !== 'undefined' && typeof $rootScope.campaignId !== 'string') {
        err += '$rootScope.campaignId must be string. ';
      }
      if (typeof params.resourceType === 'undefined') {
        err += 'params.resourceType is required. ';
      }
      if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string') {
        err += 'params.resourceType must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'DELETE',
            url: $rootScope.campaignBasePath + '/' + $rootScope.wyclubToken + '/softwareUpdate/campaign/' + $rootScope.campaignId + '',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method campaign - read
     * @summary campaign.read - Read a bootloader update campaign
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.resourceType]
     * @param {function(result)} promise
     * @public
     */
    this.read = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.campaignId === 'undefined') {
        err += '$rootScope.campaignId is required. ';
      }
      if (typeof $rootScope.campaignId !== 'undefined' && typeof $rootScope.campaignId !== 'string') {
        err += '$rootScope.campaignId must be string. ';
      }
      if (typeof params.resourceType === 'undefined') {
        err += 'params.resourceType is required. ';
      }
      if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string') {
        err += 'params.resourceType must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.campaignBasePath + '/' + $rootScope.wyclubToken + '/softwareUpdate/campaign/' + $rootScope.campaignId + '',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method campaign - readAll
     * @summary campaign.readAll - Read all bootloader update campaigns
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.resourceType]
     * @param {function(result)} promise
     * @public
     */
    this.readAll = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.resourceType === 'undefined') {
        err += 'params.resourceType is required. ';
      }
      if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string') {
        err += 'params.resourceType must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.campaignBasePath + '/' + $rootScope.wyclubToken + '/softwareUpdate/campaigns',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

  });