/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */
 
/* jshint -W106 */

var rest = require('restler');
var querystring = require('querystring');

/**
 * Initialize component
 * @param {string} basePath Api base path
 **/
var rendezVousModule = function (basePath) {
  'use strict';
  this.basePath = basePath || '';
};

/**
 * @method rendezVous - getResource
 * @summary rendezVous.getResource — Get a resource location and its associated next rendez-vous.
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.resourceType]
 * @param {Object} params - Parameters send by the request
 * @param {string} params.If-None-Match
 * @param {function(err, result)} callback 
 * @public
 */
rendezVousModule.prototype.getResource = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.resourceType === 'undefined') {
    err += 'pathParams.resourceType is required. ';
  }
  if (typeof pathParams.resourceType !== 'undefined' && typeof pathParams.resourceType !== 'string'){
    err += 'pathParams.resourceType must be string. ';
  }
  if (typeof params.If-None-Match !== 'undefined' && typeof params.If-None-Match !== 'string'){
    err += 'params.If-None-Match must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/resource/' + pathParams.resourceType + '' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method rendezVous - getResourceLineup
 * @summary rendezVous.getResource — Get a lineup location and its associated next rendez-vous.
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.bouquetId]
 * @param {string} [params.smartcardSN]
 * @param {string} params.If-None-Match
 * @param {function(err, result)} callback 
 * @public
 */
rendezVousModule.prototype.getResourceLineup = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.bouquetId === 'undefined') {
    err += 'params.bouquetId is required. ';
  }
  if (typeof params.bouquetId !== 'undefined' && typeof params.bouquetId !== 'string'){
    err += 'params.bouquetId must be string. ';
  }
  if (typeof params.smartcardSN === 'undefined') {
    err += 'params.smartcardSN is required. ';
  }
  if (typeof params.smartcardSN !== 'undefined' && typeof params.smartcardSN !== 'string'){
    err += 'params.smartcardSN must be string. ';
  }
  if (typeof params.If-None-Match !== 'undefined' && typeof params.If-None-Match !== 'string'){
    err += 'params.If-None-Match must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/resource/lineup' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method rendezVous - getResourceiApp
 * @summary rendezVous.getResource — Get an iApps catalog location and its associated next rendez-vous.
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.bouquetId]
 * @param {string} params.If-None-Match
 * @param {function(err, result)} callback 
 * @public
 */
rendezVousModule.prototype.getResourceiApp = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.bouquetId === 'undefined') {
    err += 'params.bouquetId is required. ';
  }
  if (typeof params.bouquetId !== 'undefined' && typeof params.bouquetId !== 'string'){
    err += 'params.bouquetId must be string. ';
  }
  if (typeof params.If-None-Match !== 'undefined' && typeof params.If-None-Match !== 'string'){
    err += 'params.If-None-Match must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/resource/iapps' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method rendezVous - getResourceEpg
 * @summary rendezVous.getResource — Get an EPG location and its associated next rendez-vous.
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} params.If-None-Match
 * @param {function(err, result)} callback 
 * @public
 */
rendezVousModule.prototype.getResourceEpg = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.If-None-Match !== 'undefined' && typeof params.If-None-Match !== 'string'){
    err += 'params.If-None-Match must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/resource/epg' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method rendezVous - getResourceSoftware
 * @summary rendezVous.getResource — Get a software update location and its associated next rendez-vous.
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} params.If-None-Match
 * @param {function(err, result)} callback 
 * @public
 */
rendezVousModule.prototype.getResourceSoftware = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.If-None-Match !== 'undefined' && typeof params.If-None-Match !== 'string'){
    err += 'params.If-None-Match must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/resource/software' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

module.exports = rendezVousModule;