/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * @ngdoc service
 * @name wyclubBackofficeApp.wyclubtimeWindow
 * @description
 * # wyclubtimeWindow
 * Service in th wyclubBackofficeApp
 */
angular.module('wyclubBackofficeApp')
  .service('wyclubtimeWindow', function wyclubtimeWindow($q, $rootScope, $http) {

    /**
     * @method timeWindow - create
     * @summary timeWindow.create — Add a time window to a resource type
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.hMin]
     * @param {string} [params.hMax]
     * @param {function(result)} promise
     * @public
     */
    this.create = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.resourceType === 'undefined') {
        err += '$rootScope.resourceType is required. ';
      }
      if (typeof $rootScope.resourceType !== 'undefined' && typeof $rootScope.resourceType !== 'string') {
        err += '$rootScope.resourceType must be string. ';
      }
      if (typeof params.hMin === 'undefined') {
        err += 'params.hMin is required. ';
      }
      if (typeof params.hMin !== 'undefined' && typeof params.hMin !== 'string') {
        err += 'params.hMin must be string. ';
      }
      if (typeof params.hMax === 'undefined') {
        err += 'params.hMax is required. ';
      }
      if (typeof params.hMax !== 'undefined' && typeof params.hMax !== 'string') {
        err += 'params.hMax must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.timewindowBasePath + '/' + $rootScope.wyclubToken + '/rendezVous/' + $rootScope.resourceType + '/timeWindow',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method timeWindow - delete
     * @summary timeWindow.delete — remove a time window from a resource type
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.delete = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.resourceType === 'undefined') {
        err += '$rootScope.resourceType is required. ';
      }
      if (typeof $rootScope.resourceType !== 'undefined' && typeof $rootScope.resourceType !== 'string') {
        err += '$rootScope.resourceType must be string. ';
      }
      if (typeof $rootScope.id === 'undefined') {
        err += '$rootScope.id is required. ';
      }
      if (typeof $rootScope.id !== 'undefined' && typeof $rootScope.id !== 'string') {
        err += '$rootScope.id must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'DELETE',
            url: $rootScope.timewindowBasePath + '/' + $rootScope.wyclubToken + '/rendezVous/' + $rootScope.resourceType + '/timeWindow/' + $rootScope.id + '',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

  });