/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * @ngdoc service
 * @name wyclubBackofficeApp.wyclubrendezVous
 * @description
 * # wyclubrendezVous
 * Service in th wyclubBackofficeApp
 */
angular.module('wyclubBackofficeApp')
  .service('wyclubrendezVous', function wyclubrendezVous($q, $rootScope, $http) {

    /**
     * @method rendezVous - getResource
     * @summary rendezVous.getResource — Get a resource location and its associated next rendez-vous.
     * @param {Object} params - Parameters send by the request
     * @param {string} params.If-None-Match
     * @param {function(result)} promise
     * @public
     */
    this.getResource = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.resourceType === 'undefined') {
        err += '$rootScope.resourceType is required. ';
      }
      if (typeof $rootScope.resourceType !== 'undefined' && typeof $rootScope.resourceType !== 'string') {
        err += '$rootScope.resourceType must be string. ';
      }
      if (typeof params.If-None-Match !== 'undefined' && typeof params.If-None-Match !== 'string') {
        err += 'params.If-None-Match must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.rendezvousBasePath + '/' + $rootScope.wyclubToken + '/resource/' + $rootScope.resourceType + '',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method rendezVous - getResourceLineup
     * @summary rendezVous.getResource — Get a lineup location and its associated next rendez-vous.
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.bouquetId]
     * @param {string} [params.smartcardSN]
     * @param {string} params.If-None-Match
     * @param {function(result)} promise
     * @public
     */
    this.getResourceLineup = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.bouquetId === 'undefined') {
        err += 'params.bouquetId is required. ';
      }
      if (typeof params.bouquetId !== 'undefined' && typeof params.bouquetId !== 'string') {
        err += 'params.bouquetId must be string. ';
      }
      if (typeof params.smartcardSN === 'undefined') {
        err += 'params.smartcardSN is required. ';
      }
      if (typeof params.smartcardSN !== 'undefined' && typeof params.smartcardSN !== 'string') {
        err += 'params.smartcardSN must be string. ';
      }
      if (typeof params.If-None-Match !== 'undefined' && typeof params.If-None-Match !== 'string') {
        err += 'params.If-None-Match must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.rendezvousBasePath + '/' + $rootScope.wyclubToken + '/resource/lineup',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method rendezVous - getResourceiApp
     * @summary rendezVous.getResource — Get an iApps catalog location and its associated next rendez-vous.
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.bouquetId]
     * @param {string} params.If-None-Match
     * @param {function(result)} promise
     * @public
     */
    this.getResourceiApp = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.bouquetId === 'undefined') {
        err += 'params.bouquetId is required. ';
      }
      if (typeof params.bouquetId !== 'undefined' && typeof params.bouquetId !== 'string') {
        err += 'params.bouquetId must be string. ';
      }
      if (typeof params.If-None-Match !== 'undefined' && typeof params.If-None-Match !== 'string') {
        err += 'params.If-None-Match must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.rendezvousBasePath + '/' + $rootScope.wyclubToken + '/resource/iapps',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method rendezVous - getResourceEpg
     * @summary rendezVous.getResource — Get an EPG location and its associated next rendez-vous.
     * @param {Object} params - Parameters send by the request
     * @param {string} params.If-None-Match
     * @param {function(result)} promise
     * @public
     */
    this.getResourceEpg = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.If-None-Match !== 'undefined' && typeof params.If-None-Match !== 'string') {
        err += 'params.If-None-Match must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.rendezvousBasePath + '/' + $rootScope.wyclubToken + '/resource/epg',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method rendezVous - getResourceSoftware
     * @summary rendezVous.getResource — Get a software update location and its associated next rendez-vous.
     * @param {Object} params - Parameters send by the request
     * @param {string} params.If-None-Match
     * @param {function(result)} promise
     * @public
     */
    this.getResourceSoftware = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.If-None-Match !== 'undefined' && typeof params.If-None-Match !== 'string') {
        err += 'params.If-None-Match must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.rendezvousBasePath + '/' + $rootScope.wyclubToken + '/resource/software',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

  });