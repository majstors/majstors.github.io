/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * @ngdoc service
 * @name wyclubBackofficeApp.wyclubmaxValidity
 * @description
 * # wyclubmaxValidity
 * Service in th wyclubBackofficeApp
 */
angular.module('wyclubBackofficeApp')
  .service('wyclubmaxValidity', function wyclubmaxValidity($q, $rootScope, $http) {

    /**
     * @method maxValidity - create
     * @summary maxValidity.create — Set the max validity of a resource in hours
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.maxValidity]
     * @param {function(result)} promise
     * @public
     */
    this.create = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.resourceType === 'undefined') {
        err += '$rootScope.resourceType is required. ';
      }
      if (typeof $rootScope.resourceType !== 'undefined' && typeof $rootScope.resourceType !== 'string') {
        err += '$rootScope.resourceType must be string. ';
      }
      if (typeof params.maxValidity === 'undefined') {
        err += 'params.maxValidity is required. ';
      }
      if (typeof params.maxValidity !== 'undefined' && typeof params.maxValidity !== 'string') {
        err += 'params.maxValidity must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.maxvalidityBasePath + '/' + $rootScope.wyclubToken + '/rendezVous/' + $rootScope.resourceType + '/maxValidity',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method maxValidity - delete
     * @summary maxValidity.delete — delete the max validity of a wyplay middleware with its resourceType
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.delete = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.resourceType === 'undefined') {
        err += '$rootScope.resourceType is required. ';
      }
      if (typeof $rootScope.resourceType !== 'undefined' && typeof $rootScope.resourceType !== 'string') {
        err += '$rootScope.resourceType must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'DELETE',
            url: $rootScope.maxvalidityBasePath + '/' + $rootScope.wyclubToken + '/rendezVous/' + $rootScope.resourceType + '/maxValidity',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

  });