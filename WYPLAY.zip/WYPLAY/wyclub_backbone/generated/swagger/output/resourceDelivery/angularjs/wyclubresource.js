/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * @ngdoc service
 * @name wyclubBackofficeApp.wyclubresource
 * @description
 * # wyclubresource
 * Service in th wyclubBackofficeApp
 */
angular.module('wyclubBackofficeApp')
  .service('wyclubresource', function wyclubresource($q, $rootScope, $http) {

    /**
     * @method resource - getResource
     * @summary resource.getResource — Get a resource for the session according to variable parameters
     * @param {Object} params - Parameters send by the request
     * @param {string} params.resource
     * @param {string} params.isBootloader
     * @param {function(result)} promise
     * @public
     */
    this.getResource = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.resource !== 'undefined' && typeof params.resource !== 'string') {
        err += 'params.resource must be string. ';
      }
      if (typeof params.isBootloader !== 'undefined' && typeof params.isBootloader !== 'string') {
        err += 'params.isBootloader must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.resourceBasePath + '/' + $rootScope.wyclubToken + '/delivery/resource',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method resource - declareResource
     * @summary resource.declareResource — Declare a resource for the session according to variable parameters
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.resourceType]
     * @param {string} [params.resourceName]
     * @param {string} [params.resourceVersion]
     * @param {string} [params.resourceUrl]
     * @param {function(result)} promise
     * @public
     */
    this.declareResource = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.resourceType === 'undefined') {
        err += 'params.resourceType is required. ';
      }
      if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string') {
        err += 'params.resourceType must be string. ';
      }
      if (typeof params.resourceName === 'undefined') {
        err += 'params.resourceName is required. ';
      }
      if (typeof params.resourceName !== 'undefined' && typeof params.resourceName !== 'string') {
        err += 'params.resourceName must be string. ';
      }
      if (typeof params.resourceVersion === 'undefined') {
        err += 'params.resourceVersion is required. ';
      }
      if (typeof params.resourceVersion !== 'undefined' && typeof params.resourceVersion !== 'string') {
        err += 'params.resourceVersion must be string. ';
      }
      if (typeof params.resourceUrl === 'undefined') {
        err += 'params.resourceUrl is required. ';
      }
      if (typeof params.resourceUrl !== 'undefined' && typeof params.resourceUrl !== 'string') {
        err += 'params.resourceUrl must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.resourceBasePath + '/' + $rootScope.wyclubToken + '/delivery/resource',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method resource - getResources
     * @summary resource.getResources — Get resources using some filters
     * @param {Object} params - Parameters send by the request
     * @param {string} params.resourceType
     * @param {string} params.resourceName
     * @param {string} params.resourceVersion
     * @param {function(result)} promise
     * @public
     */
    this.getResources = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string') {
        err += 'params.resourceType must be string. ';
      }
      if (typeof params.resourceName !== 'undefined' && typeof params.resourceName !== 'string') {
        err += 'params.resourceName must be string. ';
      }
      if (typeof params.resourceVersion !== 'undefined' && typeof params.resourceVersion !== 'string') {
        err += 'params.resourceVersion must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.resourceBasePath + '/' + $rootScope.wyclubToken + '/delivery/resources',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method resource - deleteResource
     * @summary resource.deleteResource — Delete a resource according to its name / type / version
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.resourceType]
     * @param {string} [params.resourceName]
     * @param {string} [params.resourceVersion]
     * @param {function(result)} promise
     * @public
     */
    this.deleteResource = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.resourceType === 'undefined') {
        err += 'params.resourceType is required. ';
      }
      if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string') {
        err += 'params.resourceType must be string. ';
      }
      if (typeof params.resourceName === 'undefined') {
        err += 'params.resourceName is required. ';
      }
      if (typeof params.resourceName !== 'undefined' && typeof params.resourceName !== 'string') {
        err += 'params.resourceName must be string. ';
      }
      if (typeof params.resourceVersion === 'undefined') {
        err += 'params.resourceVersion is required. ';
      }
      if (typeof params.resourceVersion !== 'undefined' && typeof params.resourceVersion !== 'string') {
        err += 'params.resourceVersion must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'DELETE',
            url: $rootScope.resourceBasePath + '/' + $rootScope.wyclubToken + '/delivery/resource',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

  });