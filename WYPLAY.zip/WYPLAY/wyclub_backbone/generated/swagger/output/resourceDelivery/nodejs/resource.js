/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */
 
/* jshint -W106 */

var rest = require('restler');
var querystring = require('querystring');

/**
 * Initialize component
 * @param {string} basePath Api base path
 **/
var resourceModule = function (basePath) {
  'use strict';
  this.basePath = basePath || '';
};

/**
 * @method resource - getResource
 * @summary resource.getResource — Get a resource for the session according to variable parameters
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} params.resource
 * @param {string} params.isBootloader
 * @param {function(err, result)} callback 
 * @public
 */
resourceModule.prototype.getResource = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.resource !== 'undefined' && typeof params.resource !== 'string'){
    err += 'params.resource must be string. ';
  }
  if (typeof params.isBootloader !== 'undefined' && typeof params.isBootloader !== 'string'){
    err += 'params.isBootloader must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/delivery/resource' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method resource - declareResource
 * @summary resource.declareResource — Declare a resource for the session according to variable parameters
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.resourceType]
 * @param {string} [params.resourceName]
 * @param {string} [params.resourceVersion]
 * @param {string} [params.resourceUrl]
 * @param {function(err, result)} callback 
 * @public
 */
resourceModule.prototype.declareResource = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.resourceType === 'undefined') {
    err += 'params.resourceType is required. ';
  }
  if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string'){
    err += 'params.resourceType must be string. ';
  }
  if (typeof params.resourceName === 'undefined') {
    err += 'params.resourceName is required. ';
  }
  if (typeof params.resourceName !== 'undefined' && typeof params.resourceName !== 'string'){
    err += 'params.resourceName must be string. ';
  }
  if (typeof params.resourceVersion === 'undefined') {
    err += 'params.resourceVersion is required. ';
  }
  if (typeof params.resourceVersion !== 'undefined' && typeof params.resourceVersion !== 'string'){
    err += 'params.resourceVersion must be string. ';
  }
  if (typeof params.resourceUrl === 'undefined') {
    err += 'params.resourceUrl is required. ';
  }
  if (typeof params.resourceUrl !== 'undefined' && typeof params.resourceUrl !== 'string'){
    err += 'params.resourceUrl must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.post(
      this.basePath + '/' + pathParams.wyclubToken + '/delivery/resource' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method resource - getResources
 * @summary resource.getResources — Get resources using some filters
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} params.resourceType
 * @param {string} params.resourceName
 * @param {string} params.resourceVersion
 * @param {function(err, result)} callback 
 * @public
 */
resourceModule.prototype.getResources = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string'){
    err += 'params.resourceType must be string. ';
  }
  if (typeof params.resourceName !== 'undefined' && typeof params.resourceName !== 'string'){
    err += 'params.resourceName must be string. ';
  }
  if (typeof params.resourceVersion !== 'undefined' && typeof params.resourceVersion !== 'string'){
    err += 'params.resourceVersion must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/delivery/resources' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method resource - deleteResource
 * @summary resource.deleteResource — Delete a resource according to its name / type / version
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.resourceType]
 * @param {string} [params.resourceName]
 * @param {string} [params.resourceVersion]
 * @param {function(err, result)} callback 
 * @public
 */
resourceModule.prototype.deleteResource = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.resourceType === 'undefined') {
    err += 'params.resourceType is required. ';
  }
  if (typeof params.resourceType !== 'undefined' && typeof params.resourceType !== 'string'){
    err += 'params.resourceType must be string. ';
  }
  if (typeof params.resourceName === 'undefined') {
    err += 'params.resourceName is required. ';
  }
  if (typeof params.resourceName !== 'undefined' && typeof params.resourceName !== 'string'){
    err += 'params.resourceName must be string. ';
  }
  if (typeof params.resourceVersion === 'undefined') {
    err += 'params.resourceVersion is required. ';
  }
  if (typeof params.resourceVersion !== 'undefined' && typeof params.resourceVersion !== 'string'){
    err += 'params.resourceVersion must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.del(
      this.basePath + '/' + pathParams.wyclubToken + '/delivery/resource' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

module.exports = resourceModule;