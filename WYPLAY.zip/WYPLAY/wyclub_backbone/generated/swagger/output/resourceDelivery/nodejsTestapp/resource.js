/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* jshint -W106 */

var _ = require('lodash');
var rest = require('restler');
var querystring = require('querystring');

/**
 * Initialize component
 * @param {string} basePath Api base path
 **/
var resourceModule = function (basePath) {
  'use strict';

  this.basePath = basePath || '';
  this.lastError = undefined;
  this.lastResponse = undefined;
};

/**
 * @method resource - getResource
 * @summary resource.getResource — Get a resource for the session according to variable parameters
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} params.resource
 * @param {string} params.isBootloader
 * @param {function(err, result)} callback 
 * @public
 */
resourceModule.prototype.getResource = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var defaultOptions = {
    followRedirects: false
  };
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.get(
    this.basePath + '/' + pathParams.wyclubToken + '/delivery/resource' + (params ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method resource - declareResource
 * @summary resource.declareResource — Declare a resource for the session according to variable parameters
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.resourceType]
 * @param {string} [params.resourceName]
 * @param {string} [params.resourceVersion]
 * @param {string} [params.resourceUrl]
 * @param {function(err, result)} callback 
 * @public
 */
resourceModule.prototype.declareResource = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.post(
    this.basePath + '/' + pathParams.wyclubToken + '/delivery/resource' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method resource - getResources
 * @summary resource.getResources — Get resources using some filters
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} params.resourceType
 * @param {string} params.resourceName
 * @param {string} params.resourceVersion
 * @param {function(err, result)} callback 
 * @public
 */
resourceModule.prototype.getResources = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var defaultOptions = {
    followRedirects: false
  };
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.get(
    this.basePath + '/' + pathParams.wyclubToken + '/delivery/resources' + (params ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

/**
 * @method resource - deleteResource
 * @summary resource.deleteResource — Delete a resource according to its name / type / version
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.resourceType]
 * @param {string} [params.resourceName]
 * @param {string} [params.resourceVersion]
 * @param {function(err, result)} callback 
 * @public
 */
resourceModule.prototype.deleteResource = function(pathParams, params, options, callback){
  'use strict';

  var self = this;
  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }

  var binary_body = !!params ? params['_binary_body_'] : undefined;
  var defaultOptions = {
    data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
    headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
    parser: rest.parsers.auto,
    followRedirects: false
  };
  if (!!binary_body) {
    delete params['_binary_body_'];
    defaultOptions.data = String(binary_body);
  }
  if (options) {
    options = _.merge({}, defaultOptions, options);
  } else {
    options = defaultOptions;
  }
  rest.del(
    this.basePath + '/' + pathParams.wyclubToken + '/delivery/resource' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
    if(result instanceof Error) {
      self.lastError = result.message;
      self.lastResponse = (!!response && response.statusCode !== 200) ? {httpStatusCode: response.statusCode} : {};
      self.lastResponse.headers = (!!response) ? response.headers : {};
    } else if(typeof(result) === 'object' && result.code !== 0) {
      self.lastError = 'An error occurred. Code = ' + result.code + ', Message = ' + result.content;
      self.lastResponse = result;
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    } else {
      self.lastError = null;
      self.lastResponse = typeof(result) === 'object' ? result : {data: result};
      self.lastResponse.httpStatusCode = response.statusCode;
      self.lastResponse.headers = response.headers;
    }
    callback(self.lastError, self.lastResponse);
  });
};

module.exports = resourceModule;