/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */
 
/* jshint -W106 */

var rest = require('restler');
var querystring = require('querystring');

/**
 * Initialize component
 * @param {string} basePath Api base path
 **/
var exportModule = function (basePath) {
  'use strict';
  this.basePath = basePath || '';
};

/**
 * @method export - export
 * @summary export.export — Export a bouquet to CDN. Send a notification to push module on
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.bouquetKey]
 * @param {Object} params - Parameters send by the request
 * @param {boolean} [params.critical]
 * @param {number} params.uploadDate
 * @param {function(err, result)} callback 
 * @public
 */
exportModule.prototype.export = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.bouquetKey === 'undefined') {
    err += 'pathParams.bouquetKey is required. ';
  }
  if (typeof pathParams.bouquetKey !== 'undefined' && typeof pathParams.bouquetKey !== 'string'){
    err += 'pathParams.bouquetKey must be string. ';
  }
  if (typeof params.critical === 'undefined') {
    err += 'params.critical is required. ';
  }
  if (typeof params.critical !== 'undefined' && typeof params.critical !== 'boolean'){
    err += 'params.critical must be boolean. ';
  }
  if (typeof params.uploadDate !== 'undefined' && typeof params.uploadDate !== 'number'){
    err += 'params.uploadDate must be number. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.post(
      this.basePath + '/' + pathParams.wyclubToken + '/lineup/export/' + pathParams.bouquetKey + '' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method lastBouquet - lastBouquet
 * @summary export.lastBouquet — Read a last exported bouquet from DB
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.bouquetKey]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
exportModule.prototype.lastBouquet = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.bouquetKey === 'undefined') {
    err += 'pathParams.bouquetKey is required. ';
  }
  if (typeof pathParams.bouquetKey !== 'undefined' && typeof pathParams.bouquetKey !== 'string'){
    err += 'pathParams.bouquetKey must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/lineup/export/' + pathParams.bouquetKey + '/last' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

module.exports = exportModule;