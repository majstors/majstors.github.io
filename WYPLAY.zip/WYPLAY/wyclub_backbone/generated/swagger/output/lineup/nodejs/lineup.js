/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */
 
/* jshint -W106 */

var rest = require('restler');
var querystring = require('querystring');

/**
 * Initialize component
 * @param {string} basePath Api base path
 **/
var lineupModule = function (basePath) {
  'use strict';
  this.basePath = basePath || '';
};

/**
 * @method lineup - readAll
 * @summary lineup.readAll — Read all lineup
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
lineupModule.prototype.readAll = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/lineup/lineupList' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method lineup - read
 * @summary lineup.read — Read a lineup
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.bouquetKey]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
lineupModule.prototype.read = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.bouquetKey === 'undefined') {
    err += 'pathParams.bouquetKey is required. ';
  }
  if (typeof pathParams.bouquetKey !== 'undefined' && typeof pathParams.bouquetKey !== 'string'){
    err += 'pathParams.bouquetKey must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/lineup/lineup/' + pathParams.bouquetKey + '' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method lineup - write
 * @summary lineup.write — Write a lineup
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {Object} params - Parameters send by the request
 * @param {number} [params.bouquetKey]
 * @param {string} [params.labelOfBouquet]
 * @param {string} params.homelineup
 * @param {string} params.lineupList
 * @param {function(err, result)} callback 
 * @public
 */
lineupModule.prototype.write = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof params.bouquetKey === 'undefined') {
    err += 'params.bouquetKey is required. ';
  }
  if (typeof params.bouquetKey !== 'undefined' && typeof params.bouquetKey !== 'number'){
    err += 'params.bouquetKey must be number. ';
  }
  if (typeof params.labelOfBouquet === 'undefined') {
    err += 'params.labelOfBouquet is required. ';
  }
  if (typeof params.labelOfBouquet !== 'undefined' && typeof params.labelOfBouquet !== 'string'){
    err += 'params.labelOfBouquet must be string. ';
  }
  if (typeof params.homelineup !== 'undefined' && typeof params.homelineup !== 'string'){
    err += 'params.homelineup must be string. ';
  }
  if (typeof params.lineupList !== 'undefined' && typeof params.lineupList !== 'string'){
    err += 'params.lineupList must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.post(
      this.basePath + '/' + pathParams.wyclubToken + '/lineup/lineup' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method lineup - delete
 * @summary lineup.delete — Delete a lineup
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.bouquetKey]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
lineupModule.prototype.delete = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.bouquetKey === 'undefined') {
    err += 'pathParams.bouquetKey is required. ';
  }
  if (typeof pathParams.bouquetKey !== 'undefined' && typeof pathParams.bouquetKey !== 'string'){
    err += 'pathParams.bouquetKey must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.del(
      this.basePath + '/' + pathParams.wyclubToken + '/lineup/lineup/' + pathParams.bouquetKey + '' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method lineup - update
 * @summary lineup.update — Update a lineup
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.bouquetKey]
 * @param {Object} params - Parameters send by the request
 * @param {string} params.labelOfBouquet
 * @param {string} params.homelineup
 * @param {string} params.lineupList
 * @param {function(err, result)} callback 
 * @public
 */
lineupModule.prototype.update = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.bouquetKey === 'undefined') {
    err += 'pathParams.bouquetKey is required. ';
  }
  if (typeof pathParams.bouquetKey !== 'undefined' && typeof pathParams.bouquetKey !== 'string'){
    err += 'pathParams.bouquetKey must be string. ';
  }
  if (typeof params.labelOfBouquet !== 'undefined' && typeof params.labelOfBouquet !== 'string'){
    err += 'params.labelOfBouquet must be string. ';
  }
  if (typeof params.homelineup !== 'undefined' && typeof params.homelineup !== 'string'){
    err += 'params.homelineup must be string. ';
  }
  if (typeof params.lineupList !== 'undefined' && typeof params.lineupList !== 'string'){
    err += 'params.lineupList must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.patch(
      this.basePath + '/' + pathParams.wyclubToken + '/lineup/lineup/' + pathParams.bouquetKey + '' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method lineup - addChannels
 * @summary lineup.addChannels — Add channels to a bouquet
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.bouquetKey]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.channels]
 * @param {function(err, result)} callback 
 * @public
 */
lineupModule.prototype.addChannels = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.bouquetKey === 'undefined') {
    err += 'pathParams.bouquetKey is required. ';
  }
  if (typeof pathParams.bouquetKey !== 'undefined' && typeof pathParams.bouquetKey !== 'string'){
    err += 'pathParams.bouquetKey must be string. ';
  }
  if (typeof params.channels === 'undefined') {
    err += 'params.channels is required. ';
  }
  if (typeof params.channels !== 'undefined' && typeof params.channels !== 'string'){
    err += 'params.channels must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.post(
      this.basePath + '/' + pathParams.wyclubToken + '/lineup/' + pathParams.bouquetKey + '/channel' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method lineup - updateChannels
 * @summary lineup.updateChannels — Update channels in a bouquet
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.bouquetKey]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.channels]
 * @param {function(err, result)} callback 
 * @public
 */
lineupModule.prototype.updateChannels = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.bouquetKey === 'undefined') {
    err += 'pathParams.bouquetKey is required. ';
  }
  if (typeof pathParams.bouquetKey !== 'undefined' && typeof pathParams.bouquetKey !== 'string'){
    err += 'pathParams.bouquetKey must be string. ';
  }
  if (typeof params.channels === 'undefined') {
    err += 'params.channels is required. ';
  }
  if (typeof params.channels !== 'undefined' && typeof params.channels !== 'string'){
    err += 'params.channels must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.patch(
      this.basePath + '/' + pathParams.wyclubToken + '/lineup/' + pathParams.bouquetKey + '/channel' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method lineup - readInProgress
 * @summary lineup.readInProgress — Read a lineup with full channel data
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.bouquetKey]
 * @param {Object} params - Parameters send by the request
 * @param {function(err, result)} callback 
 * @public
 */
lineupModule.prototype.readInProgress = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.bouquetKey === 'undefined') {
    err += 'pathParams.bouquetKey is required. ';
  }
  if (typeof pathParams.bouquetKey !== 'undefined' && typeof pathParams.bouquetKey !== 'string'){
    err += 'pathParams.bouquetKey must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var defaultOptions = {
      followRedirects: false
    };
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.get(
      this.basePath + '/' + pathParams.wyclubToken + '/lineup/' + pathParams.bouquetKey + '/readInProgress' + (params ? '?' +
      querystring.stringify(params) : ''), options).on('complete', function(result){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

/**
 * @method lineup - deleteChannels
 * @summary lineup.deleteChannels — Delete channels from a bouquet
 * @param {Object} pathParams - Parameters used to build the request url
 * @param {string} [pathParams.wyclubToken]
 * @param {string} [pathParams.bouquetKey]
 * @param {Object} params - Parameters send by the request
 * @param {string} [params.channels]
 * @param {function(err, result)} callback 
 * @public
 */
lineupModule.prototype.deleteChannels = function(pathParams, params, options, callback){
  'use strict';

  if(!callback && typeof(options) === 'function') {
    callback = options;
    options = null;
  }
  var err = '';
  if (typeof pathParams.wyclubToken === 'undefined') {
    err += 'pathParams.wyclubToken is required. ';
  }
  if (typeof pathParams.wyclubToken !== 'undefined' && typeof pathParams.wyclubToken !== 'string'){
    err += 'pathParams.wyclubToken must be string. ';
  }
  if (typeof pathParams.bouquetKey === 'undefined') {
    err += 'pathParams.bouquetKey is required. ';
  }
  if (typeof pathParams.bouquetKey !== 'undefined' && typeof pathParams.bouquetKey !== 'string'){
    err += 'pathParams.bouquetKey must be string. ';
  }
  if (typeof params.channels === 'undefined') {
    err += 'params.channels is required. ';
  }
  if (typeof params.channels !== 'undefined' && typeof params.channels !== 'string'){
    err += 'params.channels must be string. ';
  }

  if (err !== ''){
    callback(err, null);
  } else {
    var binary_body = !!params ? params['_binary_body_'] : undefined;
    var defaultOptions = {
      data: typeof(params) === 'object' ? JSON.stringify(params) : String(params),
      headers: typeof(params) === 'object' ? {'Content-type': 'application/json'} : {'Content-type': 'application/octet-stream'},
      parser: typeof(params) === 'object' ? rest.parsers.json : null,
      followRedirects: false
    };
    if (!!binary_body) {
      delete params['_binary_body_'];
      defaultOptions.data = String(binary_body);
    }
    if (options) {
      options = _.extend({}, defaultOptions, options);
    } else {
      options = defaultOptions;
    }
    rest.del(
      this.basePath + '/' + pathParams.wyclubToken + '/lineup/' + pathParams.bouquetKey + '/channel' + (!!binary_body ? '?' +
    querystring.stringify(params) : ''), options).on('complete', function(result, response){
      if(result instanceof Error) {
        callback(result.message, null);
      } else if(typeof(result) === 'object' && result.code !== 0) {
        callback('An error occurred. Code = ' + result.code + ', Message = ' + result.content, result);
      } else {
        callback(null, result);
      }
    });
  }
};

module.exports = lineupModule;