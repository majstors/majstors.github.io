/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * @ngdoc service
 * @name wyclubBackofficeApp.wyclubexport
 * @description
 * # wyclubexport
 * Service in th wyclubBackofficeApp
 */
angular.module('wyclubBackofficeApp')
  .service('wyclubexport', function wyclubexport($q, $rootScope, $http) {

    /**
     * @method export - export
     * @summary export.export — Export a bouquet to CDN. Send a notification to push module on
     * @param {Object} params - Parameters send by the request
     * @param {boolean} [params.critical]
     * @param {number} params.uploadDate
     * @param {function(result)} promise
     * @public
     */
    this.export = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.bouquetKey === 'undefined') {
        err += '$rootScope.bouquetKey is required. ';
      }
      if (typeof $rootScope.bouquetKey !== 'undefined' && typeof $rootScope.bouquetKey !== 'string') {
        err += '$rootScope.bouquetKey must be string. ';
      }
      if (typeof params.critical === 'undefined') {
        err += 'params.critical is required. ';
      }
      if (typeof params.critical !== 'undefined' && typeof params.critical !== 'boolean') {
        err += 'params.critical must be boolean. ';
      }
      if (typeof params.uploadDate !== 'undefined' && typeof params.uploadDate !== 'number') {
        err += 'params.uploadDate must be number. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.exportBasePath + '/' + $rootScope.wyclubToken + '/lineup/export/' + $rootScope.bouquetKey + '',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method lastBouquet - lastBouquet
     * @summary export.lastBouquet — Read a last exported bouquet from DB
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.lastBouquet = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.bouquetKey === 'undefined') {
        err += '$rootScope.bouquetKey is required. ';
      }
      if (typeof $rootScope.bouquetKey !== 'undefined' && typeof $rootScope.bouquetKey !== 'string') {
        err += '$rootScope.bouquetKey must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.exportBasePath + '/' + $rootScope.wyclubToken + '/lineup/export/' + $rootScope.bouquetKey + '/last',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

  });