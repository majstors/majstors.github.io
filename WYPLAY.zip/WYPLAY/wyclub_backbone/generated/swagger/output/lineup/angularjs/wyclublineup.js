/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * @ngdoc service
 * @name wyclubBackofficeApp.wyclublineup
 * @description
 * # wyclublineup
 * Service in th wyclubBackofficeApp
 */
angular.module('wyclubBackofficeApp')
  .service('wyclublineup', function wyclublineup($q, $rootScope, $http) {

    /**
     * @method lineup - readAll
     * @summary lineup.readAll — Read all lineup
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.readAll = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.lineupBasePath + '/' + $rootScope.wyclubToken + '/lineup/lineupList',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method lineup - read
     * @summary lineup.read — Read a lineup
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.read = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.bouquetKey === 'undefined') {
        err += '$rootScope.bouquetKey is required. ';
      }
      if (typeof $rootScope.bouquetKey !== 'undefined' && typeof $rootScope.bouquetKey !== 'string') {
        err += '$rootScope.bouquetKey must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.lineupBasePath + '/' + $rootScope.wyclubToken + '/lineup/lineup/' + $rootScope.bouquetKey + '',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method lineup - write
     * @summary lineup.write — Write a lineup
     * @param {Object} params - Parameters send by the request
     * @param {number} [params.bouquetKey]
     * @param {string} [params.labelOfBouquet]
     * @param {string} params.homelineup
     * @param {string} params.lineupList
     * @param {function(result)} promise
     * @public
     */
    this.write = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.bouquetKey === 'undefined') {
        err += 'params.bouquetKey is required. ';
      }
      if (typeof params.bouquetKey !== 'undefined' && typeof params.bouquetKey !== 'number') {
        err += 'params.bouquetKey must be number. ';
      }
      if (typeof params.labelOfBouquet === 'undefined') {
        err += 'params.labelOfBouquet is required. ';
      }
      if (typeof params.labelOfBouquet !== 'undefined' && typeof params.labelOfBouquet !== 'string') {
        err += 'params.labelOfBouquet must be string. ';
      }
      if (typeof params.homelineup !== 'undefined' && typeof params.homelineup !== 'string') {
        err += 'params.homelineup must be string. ';
      }
      if (typeof params.lineupList !== 'undefined' && typeof params.lineupList !== 'string') {
        err += 'params.lineupList must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.lineupBasePath + '/' + $rootScope.wyclubToken + '/lineup/lineup',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method lineup - delete
     * @summary lineup.delete — Delete a lineup
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.delete = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.bouquetKey === 'undefined') {
        err += '$rootScope.bouquetKey is required. ';
      }
      if (typeof $rootScope.bouquetKey !== 'undefined' && typeof $rootScope.bouquetKey !== 'string') {
        err += '$rootScope.bouquetKey must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'DELETE',
            url: $rootScope.lineupBasePath + '/' + $rootScope.wyclubToken + '/lineup/lineup/' + $rootScope.bouquetKey + '',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method lineup - update
     * @summary lineup.update — Update a lineup
     * @param {Object} params - Parameters send by the request
     * @param {string} params.labelOfBouquet
     * @param {string} params.homelineup
     * @param {string} params.lineupList
     * @param {function(result)} promise
     * @public
     */
    this.update = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.bouquetKey === 'undefined') {
        err += '$rootScope.bouquetKey is required. ';
      }
      if (typeof $rootScope.bouquetKey !== 'undefined' && typeof $rootScope.bouquetKey !== 'string') {
        err += '$rootScope.bouquetKey must be string. ';
      }
      if (typeof params.labelOfBouquet !== 'undefined' && typeof params.labelOfBouquet !== 'string') {
        err += 'params.labelOfBouquet must be string. ';
      }
      if (typeof params.homelineup !== 'undefined' && typeof params.homelineup !== 'string') {
        err += 'params.homelineup must be string. ';
      }
      if (typeof params.lineupList !== 'undefined' && typeof params.lineupList !== 'string') {
        err += 'params.lineupList must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'PATCH',
            url: $rootScope.lineupBasePath + '/' + $rootScope.wyclubToken + '/lineup/lineup/' + $rootScope.bouquetKey + '',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method lineup - addChannels
     * @summary lineup.addChannels — Add channels to a bouquet
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.channels]
     * @param {function(result)} promise
     * @public
     */
    this.addChannels = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.bouquetKey === 'undefined') {
        err += '$rootScope.bouquetKey is required. ';
      }
      if (typeof $rootScope.bouquetKey !== 'undefined' && typeof $rootScope.bouquetKey !== 'string') {
        err += '$rootScope.bouquetKey must be string. ';
      }
      if (typeof params.channels === 'undefined') {
        err += 'params.channels is required. ';
      }
      if (typeof params.channels !== 'undefined' && typeof params.channels !== 'string') {
        err += 'params.channels must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.lineupBasePath + '/' + $rootScope.wyclubToken + '/lineup/' + $rootScope.bouquetKey + '/channel',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method lineup - updateChannels
     * @summary lineup.updateChannels — Update channels in a bouquet
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.channels]
     * @param {function(result)} promise
     * @public
     */
    this.updateChannels = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.bouquetKey === 'undefined') {
        err += '$rootScope.bouquetKey is required. ';
      }
      if (typeof $rootScope.bouquetKey !== 'undefined' && typeof $rootScope.bouquetKey !== 'string') {
        err += '$rootScope.bouquetKey must be string. ';
      }
      if (typeof params.channels === 'undefined') {
        err += 'params.channels is required. ';
      }
      if (typeof params.channels !== 'undefined' && typeof params.channels !== 'string') {
        err += 'params.channels must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'PATCH',
            url: $rootScope.lineupBasePath + '/' + $rootScope.wyclubToken + '/lineup/' + $rootScope.bouquetKey + '/channel',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method lineup - readInProgress
     * @summary lineup.readInProgress — Read a lineup with full channel data
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.readInProgress = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.bouquetKey === 'undefined') {
        err += '$rootScope.bouquetKey is required. ';
      }
      if (typeof $rootScope.bouquetKey !== 'undefined' && typeof $rootScope.bouquetKey !== 'string') {
        err += '$rootScope.bouquetKey must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.lineupBasePath + '/' + $rootScope.wyclubToken + '/lineup/' + $rootScope.bouquetKey + '/readInProgress',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method lineup - deleteChannels
     * @summary lineup.deleteChannels — Delete channels from a bouquet
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.channels]
     * @param {function(result)} promise
     * @public
     */
    this.deleteChannels = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.bouquetKey === 'undefined') {
        err += '$rootScope.bouquetKey is required. ';
      }
      if (typeof $rootScope.bouquetKey !== 'undefined' && typeof $rootScope.bouquetKey !== 'string') {
        err += '$rootScope.bouquetKey must be string. ';
      }
      if (typeof params.channels === 'undefined') {
        err += 'params.channels is required. ';
      }
      if (typeof params.channels !== 'undefined' && typeof params.channels !== 'string') {
        err += 'params.channels must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'DELETE',
            url: $rootScope.lineupBasePath + '/' + $rootScope.wyclubToken + '/lineup/' + $rootScope.bouquetKey + '/channel',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

  });