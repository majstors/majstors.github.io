/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * @ngdoc service
 * @name wyclubBackofficeApp.wyclubauthStb
 * @description
 * # wyclubauthStb
 * Service in th wyclubBackofficeApp
 */
angular.module('wyclubBackofficeApp')
  .service('wyclubauthStb', function wyclubauthStb($q, $rootScope, $http) {

    /**
     * @method authStb - serial
     * @summary authStb.serial — Query to check if middleware or bootloader
can be updated. Also redirect to the binary location according to query
type.
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.ID]
     * @param {string} [params.Type]
     * @param {function(result)} promise
     * @public
     */
    this.serial = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof params.ID === 'undefined') {
        err += 'params.ID is required. ';
      }
      if (typeof params.ID !== 'undefined' && typeof params.ID !== 'string') {
        err += 'params.ID must be string. ';
      }
      if (typeof params.Type === 'undefined') {
        err += 'params.Type is required. ';
      }
      if (typeof params.Type !== 'undefined' && typeof params.Type !== 'string') {
        err += 'params.Type must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.authstbBasePath + '/auth/bootloader',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method authStb - renewToken
     * @summary authStb.renewToken —  Authenticates and creates a fresh WyClub token for the given (`applicationId`) and STB information.
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.stbSN]
     * @param {string} [params.stbId]
     * @param {string} [params.stbMACAddress]
     * @param {string} [params.stbSoftwareVersion]
     * @param {string} [params.stbBootloader2Version]
     * @param {string} [params.smartcardSN]
     * @param {function(result)} promise
     * @public
     */
    this.renewToken = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.applicationId === 'undefined') {
        err += '$rootScope.applicationId is required. ';
      }
      if (typeof $rootScope.applicationId !== 'undefined' && typeof $rootScope.applicationId !== 'string') {
        err += '$rootScope.applicationId must be string. ';
      }
      if (typeof params.stbSN === 'undefined') {
        err += 'params.stbSN is required. ';
      }
      if (typeof params.stbSN !== 'undefined' && typeof params.stbSN !== 'string') {
        err += 'params.stbSN must be string. ';
      }
      if (typeof params.stbId === 'undefined') {
        err += 'params.stbId is required. ';
      }
      if (typeof params.stbId !== 'undefined' && typeof params.stbId !== 'string') {
        err += 'params.stbId must be string. ';
      }
      if (typeof params.stbMACAddress === 'undefined') {
        err += 'params.stbMACAddress is required. ';
      }
      if (typeof params.stbMACAddress !== 'undefined' && typeof params.stbMACAddress !== 'string') {
        err += 'params.stbMACAddress must be string. ';
      }
      if (typeof params.stbSoftwareVersion === 'undefined') {
        err += 'params.stbSoftwareVersion is required. ';
      }
      if (typeof params.stbSoftwareVersion !== 'undefined' && typeof params.stbSoftwareVersion !== 'string') {
        err += 'params.stbSoftwareVersion must be string. ';
      }
      if (typeof params.stbBootloader2Version === 'undefined') {
        err += 'params.stbBootloader2Version is required. ';
      }
      if (typeof params.stbBootloader2Version !== 'undefined' && typeof params.stbBootloader2Version !== 'string') {
        err += 'params.stbBootloader2Version must be string. ';
      }
      if (typeof params.smartcardSN === 'undefined') {
        err += 'params.smartcardSN is required. ';
      }
      if (typeof params.smartcardSN !== 'undefined' && typeof params.smartcardSN !== 'string') {
        err += 'params.smartcardSN must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.authstbBasePath + '/' + $rootScope.applicationId + '/auth/token',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method authStb - registration
     * @summary authStb.registration —  Authenticates, registers and creates a WyClub token for the given (`applicationId`) and STB information.
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.stbSN]
     * @param {string} [params.stbId]
     * @param {string} [params.stbMACAddress]
     * @param {string} [params.stbSoftwareVersion]
     * @param {string} [params.stbBootloader2Version]
     * @param {function(result)} promise
     * @public
     */
    this.registration = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.applicationId === 'undefined') {
        err += '$rootScope.applicationId is required. ';
      }
      if (typeof $rootScope.applicationId !== 'undefined' && typeof $rootScope.applicationId !== 'string') {
        err += '$rootScope.applicationId must be string. ';
      }
      if (typeof params.stbSN === 'undefined') {
        err += 'params.stbSN is required. ';
      }
      if (typeof params.stbSN !== 'undefined' && typeof params.stbSN !== 'string') {
        err += 'params.stbSN must be string. ';
      }
      if (typeof params.stbId === 'undefined') {
        err += 'params.stbId is required. ';
      }
      if (typeof params.stbId !== 'undefined' && typeof params.stbId !== 'string') {
        err += 'params.stbId must be string. ';
      }
      if (typeof params.stbMACAddress === 'undefined') {
        err += 'params.stbMACAddress is required. ';
      }
      if (typeof params.stbMACAddress !== 'undefined' && typeof params.stbMACAddress !== 'string') {
        err += 'params.stbMACAddress must be string. ';
      }
      if (typeof params.stbSoftwareVersion === 'undefined') {
        err += 'params.stbSoftwareVersion is required. ';
      }
      if (typeof params.stbSoftwareVersion !== 'undefined' && typeof params.stbSoftwareVersion !== 'string') {
        err += 'params.stbSoftwareVersion must be string. ';
      }
      if (typeof params.stbBootloader2Version === 'undefined') {
        err += 'params.stbBootloader2Version is required. ';
      }
      if (typeof params.stbBootloader2Version !== 'undefined' && typeof params.stbBootloader2Version !== 'string') {
        err += 'params.stbBootloader2Version must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.authstbBasePath + '/' + $rootScope.applicationId + '/auth/registration',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method authStb - signCertificate
     * @summary authStb.signCertificate — Provides a signed unique certificate for the given CSR.
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.signCertificate = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.authstbBasePath + '/' + $rootScope.wyclubToken + '/auth/csr',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

  });