/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * @ngdoc service
 * @name wyclubBackofficeApp.wyclubepg
 * @description
 * # wyclubepg
 * Service in th wyclubBackofficeApp
 */
angular.module('wyclubBackofficeApp')
  .service('wyclubepg', function wyclubepg($q, $rootScope, $http) {

    /**
     * @method epg - read
     * @summary epg.read — Read epg with param
     * @param {Object} params - Parameters send by the request
     * @param {string} params.trafficKey
     * @param {string} params.serviceId
     * @param {string} params.start
     * @param {string} params.stop
     * @param {string} params.paginationSkip
     * @param {string} params.paginationLimit
     * @param {function(result)} promise
     * @public
     */
    this.read = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.trafficKey !== 'undefined' && typeof params.trafficKey !== 'string') {
        err += 'params.trafficKey must be string. ';
      }
      if (typeof params.serviceId !== 'undefined' && typeof params.serviceId !== 'string') {
        err += 'params.serviceId must be string. ';
      }
      if (typeof params.start !== 'undefined' && typeof params.start !== 'string') {
        err += 'params.start must be string. ';
      }
      if (typeof params.stop !== 'undefined' && typeof params.stop !== 'string') {
        err += 'params.stop must be string. ';
      }
      if (typeof params.paginationSkip !== 'undefined' && typeof params.paginationSkip !== 'string') {
        err += 'params.paginationSkip must be string. ';
      }
      if (typeof params.paginationLimit !== 'undefined' && typeof params.paginationLimit !== 'string') {
        err += 'params.paginationLimit must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.epgBasePath + '/' + $rootScope.wyclubToken + '/epg/epg',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

  });