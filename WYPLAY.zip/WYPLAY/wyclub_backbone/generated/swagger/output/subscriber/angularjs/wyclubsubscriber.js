/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * @ngdoc service
 * @name wyclubBackofficeApp.wyclubsubscriber
 * @description
 * # wyclubsubscriber
 * Service in th wyclubBackofficeApp
 */
angular.module('wyclubBackofficeApp')
  .service('wyclubsubscriber', function wyclubsubscriber($q, $rootScope, $http) {

    /**
     * @method subscriber - readAll
     * @summary subscriber.readAll — Read all subscribers
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.readAll = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.subscriberBasePath + '/' + $rootScope.wyclubToken + '/subscriber/subscribers',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method subscriber - read
     * @summary subscriber.read — Read a subscriber
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.read = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.id === 'undefined') {
        err += '$rootScope.id is required. ';
      }
      if (typeof $rootScope.id !== 'undefined' && typeof $rootScope.id !== 'string') {
        err += '$rootScope.id must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'GET',
            url: $rootScope.subscriberBasePath + '/' + $rootScope.wyclubToken + '/subscriber/subscriber/' + $rootScope.id + '',
            params: params || params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method subscriber - create
     * @summary subscriber.create — Create new subscriber
     * @param {Object} params - Parameters send by the request
     * @param {string} [params._id]
     * @param {string} [params.profiles]
     * @param {string} [params.deviceInstances]
     * @param {string} [params.devices]
     * @param {function(result)} promise
     * @public
     */
    this.create = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params._id === 'undefined') {
        err += 'params._id is required. ';
      }
      if (typeof params._id !== 'undefined' && typeof params._id !== 'string') {
        err += 'params._id must be string. ';
      }
      if (typeof params.profiles === 'undefined') {
        err += 'params.profiles is required. ';
      }
      if (typeof params.profiles !== 'undefined' && typeof params.profiles !== 'string') {
        err += 'params.profiles must be string. ';
      }
      if (typeof params.deviceInstances === 'undefined') {
        err += 'params.deviceInstances is required. ';
      }
      if (typeof params.deviceInstances !== 'undefined' && typeof params.deviceInstances !== 'string') {
        err += 'params.deviceInstances must be string. ';
      }
      if (typeof params.devices === 'undefined') {
        err += 'params.devices is required. ';
      }
      if (typeof params.devices !== 'undefined' && typeof params.devices !== 'string') {
        err += 'params.devices must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.subscriberBasePath + '/' + $rootScope.wyclubToken + '/subscriber/subscriber',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method subscriber - update
     * @summary subscriber.update — Update a subscriber
     * @param {Object} params - Parameters send by the request
     * @param {string} [params._id]
     * @param {string} [params.profiles]
     * @param {string} [params.deviceInstances]
     * @param {string} [params.devices]
     * @param {function(result)} promise
     * @public
     */
    this.update = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.id === 'undefined') {
        err += '$rootScope.id is required. ';
      }
      if (typeof $rootScope.id !== 'undefined' && typeof $rootScope.id !== 'string') {
        err += '$rootScope.id must be string. ';
      }
      if (typeof params._id === 'undefined') {
        err += 'params._id is required. ';
      }
      if (typeof params._id !== 'undefined' && typeof params._id !== 'string') {
        err += 'params._id must be string. ';
      }
      if (typeof params.profiles === 'undefined') {
        err += 'params.profiles is required. ';
      }
      if (typeof params.profiles !== 'undefined' && typeof params.profiles !== 'string') {
        err += 'params.profiles must be string. ';
      }
      if (typeof params.deviceInstances === 'undefined') {
        err += 'params.deviceInstances is required. ';
      }
      if (typeof params.deviceInstances !== 'undefined' && typeof params.deviceInstances !== 'string') {
        err += 'params.deviceInstances must be string. ';
      }
      if (typeof params.devices === 'undefined') {
        err += 'params.devices is required. ';
      }
      if (typeof params.devices !== 'undefined' && typeof params.devices !== 'string') {
        err += 'params.devices must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'PATCH',
            url: $rootScope.subscriberBasePath + '/' + $rootScope.wyclubToken + '/subscriber/subscriber/' + $rootScope.id + '',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method subscriber - delete
     * @summary subscriber.delete — Delete a subscriber
     * @param {Object} params - Parameters send by the request
     * @param {function(result)} promise
     * @public
     */
    this.delete = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.id === 'undefined') {
        err += '$rootScope.id is required. ';
      }
      if (typeof $rootScope.id !== 'undefined' && typeof $rootScope.id !== 'string') {
        err += '$rootScope.id must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'DELETE',
            url: $rootScope.subscriberBasePath + '/' + $rootScope.wyclubToken + '/subscriber/subscriber/' + $rootScope.id + '',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method subscriber - deleteDevices
     * @summary subscriber.deleteDevices — Remove device from subscriber
     * @param {Object} params - Parameters send by the request
     * @param {string} params.devices
     * @param {function(result)} promise
     * @public
     */
    this.deleteDevices = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.id === 'undefined') {
        err += '$rootScope.id is required. ';
      }
      if (typeof $rootScope.id !== 'undefined' && typeof $rootScope.id !== 'string') {
        err += '$rootScope.id must be string. ';
      }
      if (typeof params.devices !== 'undefined' && typeof params.devices !== 'string') {
        err += 'params.devices must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'DELETE',
            url: $rootScope.subscriberBasePath + '/' + $rootScope.wyclubToken + '/subscriber/subscriber/' + $rootScope.id + '/device',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method subscriber - updateDevices
     * @summary subscriber.updateDevices — Update device for subscriber
     * @param {Object} params - Parameters send by the request
     * @param {string} params.devices
     * @param {function(result)} promise
     * @public
     */
    this.updateDevices = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.id === 'undefined') {
        err += '$rootScope.id is required. ';
      }
      if (typeof $rootScope.id !== 'undefined' && typeof $rootScope.id !== 'string') {
        err += '$rootScope.id must be string. ';
      }
      if (typeof params.devices !== 'undefined' && typeof params.devices !== 'string') {
        err += 'params.devices must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'PATCH',
            url: $rootScope.subscriberBasePath + '/' + $rootScope.wyclubToken + '/subscriber/subscriber/' + $rootScope.id + '/device',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method subscriber - addDevices
     * @summary subscriber.addDevices— Create a device for subscriber
     * @param {Object} params - Parameters send by the request
     * @param {string} params.devices
     * @param {function(result)} promise
     * @public
     */
    this.addDevices = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.id === 'undefined') {
        err += '$rootScope.id is required. ';
      }
      if (typeof $rootScope.id !== 'undefined' && typeof $rootScope.id !== 'string') {
        err += '$rootScope.id must be string. ';
      }
      if (typeof params.devices !== 'undefined' && typeof params.devices !== 'string') {
        err += 'params.devices must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.subscriberBasePath + '/' + $rootScope.wyclubToken + '/subscriber/subscriber/' + $rootScope.id + '/device',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method subscriber - deleteDeviceInstances
     * @summary subscriber.deleteDeviceInstances — Remove device instance from subscriber
     * @param {Object} params - Parameters send by the request
     * @param {string} params.deviceInstances
     * @param {function(result)} promise
     * @public
     */
    this.deleteDeviceInstances = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.id === 'undefined') {
        err += '$rootScope.id is required. ';
      }
      if (typeof $rootScope.id !== 'undefined' && typeof $rootScope.id !== 'string') {
        err += '$rootScope.id must be string. ';
      }
      if (typeof params.deviceInstances !== 'undefined' && typeof params.deviceInstances !== 'string') {
        err += 'params.deviceInstances must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'DELETE',
            url: $rootScope.subscriberBasePath + '/' + $rootScope.wyclubToken + '/subscriber/subscriber/' + $rootScope.id + '/deviceInstance',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method subscriber - addDeviceInstances
     * @summary subscriber.addDeviceInstances— Create a device instance for subscriber
     * @param {Object} params - Parameters send by the request
     * @param {string} params.deviceInstances
     * @param {function(result)} promise
     * @public
     */
    this.addDeviceInstances = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.id === 'undefined') {
        err += '$rootScope.id is required. ';
      }
      if (typeof $rootScope.id !== 'undefined' && typeof $rootScope.id !== 'string') {
        err += '$rootScope.id must be string. ';
      }
      if (typeof params.deviceInstances !== 'undefined' && typeof params.deviceInstances !== 'string') {
        err += 'params.deviceInstances must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.subscriberBasePath + '/' + $rootScope.wyclubToken + '/subscriber/subscriber/' + $rootScope.id + '/deviceInstance',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method subscriber - deleteProfiles
     * @summary subscriber.deleteProfiles — Remove profile from subscriber
     * @param {Object} params - Parameters send by the request
     * @param {string} params.profiles
     * @param {function(result)} promise
     * @public
     */
    this.deleteProfiles = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.id === 'undefined') {
        err += '$rootScope.id is required. ';
      }
      if (typeof $rootScope.id !== 'undefined' && typeof $rootScope.id !== 'string') {
        err += '$rootScope.id must be string. ';
      }
      if (typeof params.profiles !== 'undefined' && typeof params.profiles !== 'string') {
        err += 'params.profiles must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'DELETE',
            url: $rootScope.subscriberBasePath + '/' + $rootScope.wyclubToken + '/subscriber/subscriber/' + $rootScope.id + '/profile',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method subscriber - updateProfiles
     * @summary subscriber.updateProfiles — Update device for subscriber
     * @param {Object} params - Parameters send by the request
     * @param {string} params.profiles
     * @param {function(result)} promise
     * @public
     */
    this.updateProfiles = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.id === 'undefined') {
        err += '$rootScope.id is required. ';
      }
      if (typeof $rootScope.id !== 'undefined' && typeof $rootScope.id !== 'string') {
        err += '$rootScope.id must be string. ';
      }
      if (typeof params.profiles !== 'undefined' && typeof params.profiles !== 'string') {
        err += 'params.profiles must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'PATCH',
            url: $rootScope.subscriberBasePath + '/' + $rootScope.wyclubToken + '/subscriber/subscriber/' + $rootScope.id + '/profile',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method subscriber - addProfiles
     * @summary subscriber.addProfiles— Create a profile for subscriber
     * @param {Object} params - Parameters send by the request
     * @param {string} params.profiles
     * @param {function(result)} promise
     * @public
     */
    this.addProfiles = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof $rootScope.id === 'undefined') {
        err += '$rootScope.id is required. ';
      }
      if (typeof $rootScope.id !== 'undefined' && typeof $rootScope.id !== 'string') {
        err += '$rootScope.id must be string. ';
      }
      if (typeof params.profiles !== 'undefined' && typeof params.profiles !== 'string') {
        err += 'params.profiles must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.subscriberBasePath + '/' + $rootScope.wyclubToken + '/subscriber/subscriber/' + $rootScope.id + '/profile',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

  });