/*
 * Copyright (C) 2013 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * @ngdoc service
 * @name wyclubBackofficeApp.wyclubscms
 * @description
 * # wyclubscms
 * Service in th wyclubBackofficeApp
 */
angular.module('wyclubBackofficeApp')
  .service('wyclubscms', function wyclubscms($q, $rootScope, $http) {

    /**
     * @method scms - create
     * @summary scms.create — Create subscriber throw SCMS API.
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.subscribers]
     * @param {function(result)} promise
     * @public
     */
    this.create = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.subscribers === 'undefined') {
        err += 'params.subscribers is required. ';
      }
      if (typeof params.subscribers !== 'undefined' && typeof params.subscribers !== 'string') {
        err += 'params.subscribers must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'POST',
            url: $rootScope.scmsBasePath + '/' + $rootScope.wyclubToken + '/subscriber/scms',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method scms - update
     * @summary scms.update — Update subscriber throw SCMS API.
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.subscribers]
     * @param {function(result)} promise
     * @public
     */
    this.update = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.subscribers === 'undefined') {
        err += 'params.subscribers is required. ';
      }
      if (typeof params.subscribers !== 'undefined' && typeof params.subscribers !== 'string') {
        err += 'params.subscribers must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'PATCH',
            url: $rootScope.scmsBasePath + '/' + $rootScope.wyclubToken + '/subscriber/scms',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

    /**
     * @method scms - delete
     * @summary scms.delete — Delete subscriber throw SCMS API.
     * @param {Object} params - Parameters send by the request
     * @param {string} [params.subscribers]
     * @param {function(result)} promise
     * @public
     */
    this.delete = function (params) {

      var deferred = $q.defer();

      var err = '';
      if (typeof $rootScope.wyclubToken === 'undefined') {
        err += '$rootScope.wyclubToken is required. ';
      }
      if (typeof $rootScope.wyclubToken !== 'undefined' && typeof $rootScope.wyclubToken !== 'string') {
        err += '$rootScope.wyclubToken must be string. ';
      }
      if (typeof params.subscribers === 'undefined') {
        err += 'params.subscribers is required. ';
      }
      if (typeof params.subscribers !== 'undefined' && typeof params.subscribers !== 'string') {
        err += 'params.subscribers must be string. ';
      }

      if (err !== '') {
        deferred.reject(err);
      } else {
        $http(
          {
            method: 'DELETE',
            url: $rootScope.scmsBasePath + '/' + $rootScope.wyclubToken + '/subscriber/scms',
            data: params
          }).
          success(function (result) {
            if (result.code !== 0) {
              deferred.reject('An error occurred. Code = ' + result.code + ', Message = ' + result.content);
            } else {
              deferred.resolve(result);
            }
          }).
          error(function (result) {
            deferred.reject(null);
          });
      }
      return deferred.promise;
    };

  });