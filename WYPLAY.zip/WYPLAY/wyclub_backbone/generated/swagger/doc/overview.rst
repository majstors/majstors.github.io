*****************
Wyclub Swagger UI
*****************

Introduction
============
Swagger UI is the module used to generate the user interface of swagger for each Wyclub server.
