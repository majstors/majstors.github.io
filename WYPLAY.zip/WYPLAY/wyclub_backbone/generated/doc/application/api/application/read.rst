.. http:get:: /(string:wyclubToken)/application
  :noindex:

  :synopsis:
    Read the requested application info.

  :parameter string wyclubToken: *(mandatory)* – A session ID

  :query string accessToken: A session access token.

