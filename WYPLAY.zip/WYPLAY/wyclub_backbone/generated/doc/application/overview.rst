***********
Application
***********

Introduction
============
Application allow to manage wyclub application.
It provide a repository via the Container which allow to crud application.

Call
====
You can call the repository with Container.application.repository.repositorySession
