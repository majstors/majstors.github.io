.. http:post:: /(string:wyclubToken)/softwareUpdate/(string:resourceType)/upload
  :noindex:

  :synopsis:
    Schedule upload of a new binary file to Origin servers. If no date timestamp is given, the upload is on this request.

  :reqheader content-type: *(default: application/octet-stream)* – 

  :parameter string wyclubToken: *(mandatory)* – -
  :parameter string resourceType: *(mandatory)* – The resource type, can be software or bootloader

  :query string resourceName: *(mandatory)* – The name of the uploaded resource
  :query string resourceVersion: *(mandatory)* – The version of the uploaded resource
  :query number uploadDate: Upload date (UTC timestamp)

  :Request content: (file) – The binary to be uploaded

  **- Upload binary**:

    path: /bowrite0000088n0EhD5O721gD3lFE3X/softwareUpdate/software/upload?resourceName=update1.bin&resourceVersion=1.0&uploadDate=1414079776
    
    Body: Binary file

  :statuscode 200: Success

  :statuscode 403: Forbidden

  :statuscode 404: Resource already exists or scheduled

  :statuscode 409: Upload already scheduled

  :statuscode 412: Given upload timestamp is in the past

  **- valid response with uploadDate param given**:

    {
    "code":0,
    "content":"Success",
    "data":
    {
      "resourcePath": "software/1.0/update1.bin"
    }
    }

  **- error response**:

    {
    "code": 703,
    "httpcode": 404
    "content":"This resource already exists."
    }

