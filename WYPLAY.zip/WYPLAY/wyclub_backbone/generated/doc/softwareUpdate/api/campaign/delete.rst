.. http:delete:: /(string:wyclubToken)/softwareUpdate/campaign/(string:campaignId)
  :noindex:

  :synopsis:
    Delete a campaign

  :Version follow-up:

    * .. versionadded:: 0.1.0

    * .. versionchanged:: 0.2.0
         Update response format

  :parameter string wyclubToken: *(mandatory)* – WyClub Token
  :parameter string campaignId: *(mandatory)* – Campaign ID to delete

  :reqjson string resourceType: *(mandatory)* – The campaign type. Allowed values: "software" or "bootloader"

  :resjson integer code: Operation result code, 0 indicates a success, any other value a failure
  :resjson string content: Operation result human readable message (if any)
  :resjson object data: Number of campaign deleted

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

  :statuscode 404: Not found

    + *code*:  104: Campaign not found

  :statuscode 503: Service Unavailable

    + *code*:  101: Error during deletion

