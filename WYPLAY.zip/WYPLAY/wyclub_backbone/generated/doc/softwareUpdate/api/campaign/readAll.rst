.. http:get:: /(string:wyclubToken)/softwareUpdate/campaigns
  :noindex:

  :synopsis:
    Read all software update campaigns

  :Version follow-up:

    * .. versionadded:: 0.1.0

    * .. versionchanged:: 0.2.0
         Update response format

  :parameter string wyclubToken: *(mandatory)* – WyClub Token

  :query string resourceType: *(mandatory)* – The campaign type. Must be: "software"

  :resjson integer code: Operation result code, 0 indicates a success, any other value a failure
  :resjson string content: Operation result human readable message (if any)
  :resjson array.<object> data: Operation result data
  :resjson string data.campaignId: Identifier of the campaign
  :resjson object data.values: Campaign in database
  :resjson string data.values.resourceName: Name of the resource
  :resjson string data.values.resourceVersion: Version of the resource
  :resjson boolean data.values.mandatory: To know if the update is mandatory or optional.
  :resjson boolean data.values.forced: To know if the update is forced or not.
  :resjson string data.values.installationType: When the installation shall be performed. Allowed values: “immediate”, “poweron”, “standby”
  :resjson integer data.values.priority: Priority of the campaign. Higher value means higher priority
  :resjson boolean data.values.activated: To know if the campaign is active or not
  :resjson object data.values.hardwareModel: Hardware model condition
  :resjson string data.values.hardwareModel.value: Hardware model
  :resjson string data.values.hardwareModel.operator: Operator to apply on value. Allowed values: "=", "!=", "<", ">", "<=", ">="
  :resjson object data.values.stbSN: STB Serial number conditions
  :resjson string data.values.stbSN.value: STB Serial number
  :resjson string data.values.stbSN.operator: Operator to apply on value. Allowed values: "=", "!=", "<", ">", "<=", ">="
  :resjson array data.values.stbSN.range: Array of STB Serial number range
  :resjson string data.values.stbSN.range.min: Minimum limit for a STB serial number range
  :resjson string data.values.stbSN.range.max: Maximum limit for a STB serial number range
  :resjson object data.values.smartcardSN: Smartcard Serial number conditions
  :resjson string data.values.smartcardSN.value: Smartcard Serial number
  :resjson string data.values.smartcardSN.operator: Operator to apply on value. Allowed values: "=", "!=", "<", ">", "<=", ">="
  :resjson array data.values.smartcardSN.range: Array of smartcard Serial number range
  :resjson string data.values.smartcardSN.range.min: Minimum limit for a smartcard serial number range
  :resjson string data.values.smartcardSN.range.max: Maximum limit for a smartcard serial number range
  :resjson object data.values.currentSoftwareVersion: Software version condition
  :resjson string data.values.currentSoftwareVersion.value: Software version
  :resjson string data.values.currentSoftwareVersion.operator: Operator to apply on value. Allowed values: "=", "!=", "<", ">", "<=", ">="
  :resjson object data.values.campaignDates: Date conditions
  :resjson integer data.values.campaignDates.value: Date (UTC timestamp)
  :resjson string data.values.campaignDates.operator: Operator to apply on value. Allowed values: "=", "!=", "<", ">", "<=", ">="
  :resjson array data.values.campaignDates.range: Array of date range
  :resjson integer data.values.campaignDates.range.min: Minimum limit for a date range (UTC timestamp)
  :resjson integer data.values.campaignDates.range.max: Maximum limit for a date range (UTC timestamp)

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

  :statuscode 503: Service Unavailable

    + *code*:  101: Error during reading

.. http:get:: /(string:wyclubToken)/softwareUpdate/campaigns
  :noindex:

  :synopsis:
    Read all bootloader update campaigns

  :Version follow-up:

    * .. versionadded:: 0.1.0

    * .. versionchanged:: 0.2.0
         Update response format

  :parameter string wyclubToken: *(mandatory)* – WyClub Token

  :query string resourceType: *(mandatory)* – The campaign type. Must be: "bootloader"

  :resjson integer code: Operation result code, 0 indicates a success, any other value a failure
  :resjson string content: Operation result human readable message (if any)
  :resjson array.<object> data: Operation result data
  :resjson string data.campaignId: Identifier of the campaign
  :resjson object data.values: Campaign in database
  :resjson string data.values.resourceName: Name of the resource
  :resjson string data.values.resourceVersion: Version of the resource
  :resjson boolean data.values.mandatory: To know if the update is mandatory or optional.
  :resjson boolean data.values.forced: To know if the update is forced or not.
  :resjson string data.values.installationType: When the installation shall be performed. Allowed values: “immediate”, “poweron”, “standby”
  :resjson integer data.values.priority: Priority of the campaign. Higher value means higher priority
  :resjson boolean data.values.activated: To know if the campaign is active or not
  :resjson object data.values.hardwareModel: Hardware model condition
  :resjson string data.values.hardwareModel.value: Hardware model
  :resjson string data.values.hardwareModel.operator: Operator to apply on value. Allowed values: "=", "!=", "<", ">", "<=", ">="
  :resjson object data.values.currentSoftwareVersion: Software version condition
  :resjson string data.values.currentSoftwareVersion.value: Software version
  :resjson string data.values.currentSoftwareVersion.operator: Operator to apply on value. Allowed values: "=", "!=", "<", ">", "<=", ">="

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

  :statuscode 503: Service Unavailable

    + *code*:  101: Error during reading

