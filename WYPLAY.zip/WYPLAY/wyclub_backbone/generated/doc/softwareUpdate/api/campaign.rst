********
campaign
********

create
======
.. include:: campaign/create.rst
update
======
.. include:: campaign/update.rst
read
====
.. include:: campaign/read.rst
readAll
=======
.. include:: campaign/readAll.rst
delete
======
.. include:: campaign/delete.rst
