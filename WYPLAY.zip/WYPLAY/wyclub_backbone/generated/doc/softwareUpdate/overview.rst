**********************
Software Update Module
**********************

Introduction
============
WyClub SoftwareUpdate module is a CRUD API for managing software update campaigns
by using protorules.

This module uses the Wyclub Tools module for managing campaigns.


Install dependencies
====================
Assuming current directory is module's root::

  npm install


Launch unit tests
=================
Assuming current directory is module's root::

  nodeunit test/toolsTest.js


API Documentation
=================
.. toctree::
   :maxdepth: 1
   :glob:

   api/*
   api/statuscodes/*