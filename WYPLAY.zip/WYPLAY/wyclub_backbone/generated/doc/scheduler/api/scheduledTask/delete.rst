.. http:delete:: /(string:wyclubToken)/(string:module)/scheduledTask/(string:id)
  :noindex:

  :synopsis:
    Delete a task

  :parameter string wyclubToken: *(mandatory)* – A Wyclub Token
  :parameter string module: *(mandatory)* – A module name e.g. epg
  :parameter string id: *(mandatory)* – A task ID

