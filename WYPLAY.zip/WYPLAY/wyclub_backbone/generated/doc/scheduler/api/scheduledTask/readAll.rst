.. http:get:: /(string:wyclubToken)/(string:module)/scheduledTask
  :noindex:

  :synopsis:
    Read all scheduled tasks

  :parameter string wyclubToken: *(mandatory)* – A Wyclub Token
  :parameter string module: *(mandatory)* – A module name e.g. epg

