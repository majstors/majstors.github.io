********
resource
********

getResource
===========
.. include:: resource/getResource.rst
declareResource
===============
.. include:: resource/declareResource.rst
getResources
============
.. include:: resource/getResources.rst
deleteResource
==============
.. include:: resource/deleteResource.rst
