.. http:get:: /(string:wyclubToken)/delivery/resource
  :noindex:

  :synopsis:
    Get a resource for the session according to variable parameters

  :parameter string wyclubToken: *(mandatory)* – A session ID

  :query string resource: A resource type, all if not specified (e.g. lineup)
  :query string isBootloader: true if request come from bootloader

