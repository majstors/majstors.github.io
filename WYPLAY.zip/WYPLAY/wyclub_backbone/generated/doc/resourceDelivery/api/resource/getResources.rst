.. http:get:: /(string:wyclubToken)/delivery/resources
  :noindex:

  :synopsis:
    Get resources using some filters

  :parameter string wyclubToken: *(mandatory)* – A session ID

  :query string resourceType: A resource type (e.g. lineup)
  :query string resourceName: A resource name (e.g. softwareupdate)
  :query string resourceVersion: A resource version (e.g. 1.2.3)

