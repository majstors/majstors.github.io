.. http:post:: /(string:wyclubToken)/delivery/resource
  :noindex:

  :synopsis:
    Declare a resource for the session according to variable parameters

  :parameter string wyclubToken: *(mandatory)* – A session ID

  :reqjson string resourceType: *(mandatory)* – A resource type (e.g. software)
  :reqjson string resourceName: *(mandatory)* – A resource anem (e.g. softwareupdate_wyplay)
  :reqjson string resourceVersion: *(mandatory)* – a version number (e.g. 1.4.1)
  :reqjson string resourceUrl: *(mandatory)* – A resource URL on the sky CDN

