.. http:delete:: /(string:wyclubToken)/delivery/resource
  :noindex:

  :synopsis:
    Delete a resource according to its name / type / version

  :parameter string wyclubToken: *(mandatory)* – A session ID

  :reqjson string resourceType: *(mandatory)* – A resource type (e.g. lineup)
  :reqjson string resourceName: *(mandatory)* – A resource name (e.g. softwareupdate)
  :reqjson string resourceVersion: *(mandatory)* – A resource version (e.g. 1.2.3)

