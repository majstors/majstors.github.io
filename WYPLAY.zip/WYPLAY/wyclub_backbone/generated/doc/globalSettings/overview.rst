***************
Global Settings
***************

Introduction
============
Global Settings is a module used to manage settings in mode key/value 
