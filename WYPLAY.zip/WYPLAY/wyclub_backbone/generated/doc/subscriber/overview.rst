*****************
Subscriber Module
*****************

Introduction
============
Subscriber is a module used to manage subscribers (create, update, delete) on
the WyClub.


API Documentation
=================
.. toctree::
   :maxdepth: 1
   :glob:

   api/*
   api/statuscodes/*