**********
subscriber
**********

readAll
=======
.. include:: subscriber/readAll.rst
read
====
.. include:: subscriber/read.rst
create
======
.. include:: subscriber/create.rst
update
======
.. include:: subscriber/update.rst
delete
======
.. include:: subscriber/delete.rst
deleteDevices
=============
.. include:: subscriber/deleteDevices.rst
updateDevices
=============
.. include:: subscriber/updateDevices.rst
addDevices— Create a device for subscriber
==========================================
.. include:: subscriber/addDevices— Create a device for subscriber.rst
deleteDeviceInstances
=====================
.. include:: subscriber/deleteDeviceInstances.rst
addDeviceInstances— Create a device instance for subscriber
===========================================================
.. include:: subscriber/addDeviceInstances— Create a device instance for subscriber.rst
deleteProfiles
==============
.. include:: subscriber/deleteProfiles.rst
updateProfiles
==============
.. include:: subscriber/updateProfiles.rst
addProfiles— Create a profile for subscriber
============================================
.. include:: subscriber/addProfiles— Create a profile for subscriber.rst
