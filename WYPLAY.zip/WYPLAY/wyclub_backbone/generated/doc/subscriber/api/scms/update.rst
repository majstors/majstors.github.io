.. http:patch:: /(string:wyclubToken)/subscriber/scms
  :noindex:

  :synopsis:
    Update subscriber throw SCMS API.

  :parameter string wyclubToken: *(mandatory)* – Wyclub Token

  :reqjson array subscribers: *(mandatory)* – Array of subscribers
  :reqjson string subscribers.polkaId: *(mandatory)* – Subscriber ID (10 digits)
  :reqjson string subscribers.accountId: Account ID (20 chars)
  :reqjson string subscribers.pdaId: PDA ID (30 chars)
  :reqjson string subscribers.smartcardSN: Serial number of the smartcard (11 chars)
  :reqjson string subscribers.stbSN: Serial number of the STB (16 chars)
  :reqjson string subscribers.stbId: ID of the STB (10 chars)
  :reqjson string subscribers.stbMACAddress: MAC address of the STB (AA:AA:AA:AA:AA:AA)
  :reqjson boolean subscribers.stbCertificateRevokedFlag: Subscriber certificate is revoked?
  :reqjson string subscribers.telcoId: Telco ID (16 chars)
  :reqjson string subscribers.bouquetId: Bouquet ID (16 chars)
  :reqjson boolean subscribers.bouquetIdFlag: 
  :reqjson string subscribers.telcoFlag: (can be true, false or 'passed')
  :reqjson string subscribers.skyStatus: (can be 'provisioned' or 'installed')
  :reqjson string subscribers.telcoStatus: (can be 'provisioned', 'installed' or 'inactive')

  **- Subscriber update request example (update telcoStatus provisioned to installed)**:

    .. sourcecode:: http
    
     POST /9BvMMXWSOoqzgKbHbC86E1KwAuSxTeN3/subscriber/scms HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
       {
         "subscribers": [
           {
             "polkaId": "1284567892",
             "accountId": "12345678901234567892",
             "telcoStatus": "installed"
           }
         ]
       }

  :resjson integer code: code of response
  :resjson integer content: Status of response
  :resjson array data: array of module result
  :resjson string data.polkaId: Subscriber ID
  :resjson object data.subscriber: Subscriber object
  :resjson string data.subscriber.polkaId: Subscriber ID
  :resjson string data.subscriber.accountId: Account ID
  :resjson string data.subscriber.pdaId: PDA ID
  :resjson string data.subscriber.smartcardSN: Serial number of the STB
  :resjson string data.subscriber.bouquetId: Bouquet ID
  :resjson string data.subscriber.telcoId: Telco ID
  :resjson string data.subscriber.skyStatus: 
  :resjson string data.subscriber.telcoStatus: 
  :resjson string data.subscriber.telcoFlag: 
  :resjson boolean data.subscriber.bouquetIdFlag: 
  :resjson array data.subscriber.deviceInstances: 
  :resjson array data.subscriber.profiles: 
  :resjson array data.subscriber.devices: 
  :resjson string data.subscriber.devices.uuid: 
  :resjson string data.subscriber.devices.stbId: Serial number of the STB
  :resjson string data.subscriber.devices.stbSN: ID of the STB
  :resjson string data.subscriber.devices.stbMACAddress: MAC address of the STB
  :resjson string data.subscriber.devices.stbBootloader2Version: 
  :resjson boolean data.subscriber.devices.stbSoftwareVersion: 
  :resjson string data.subscriber.devices.stbCertificateRevokedFlag: 
  :resjson integer data.subscriber.devices.stbCertificateExpiry: 
  :resjson string data.subscriber.devices.stbCertificateSN: 
  :resjson integer data.subscriber.devices.status: 
  :resjson string data.subscriber.devices.label: 
  :resjson string data.subscriber.devices._id: 
  :resjson string data.subscriber._id: 
  :resjson integer data.errorCode: 
  :resjson string data.errorMessage: 
  :resjson object data.errorData: 

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbiden

    + *code*:  5: Invalid request parameter
    + *code*:  999: An unexpected error occured (read body.data.errorMessage in response body for more details)

  :statuscode 503: Service Unavailable

    + *code*:  2000: stbId, stbSN and stbMACAddress must be updated together. At least one of these fields is missing

  **- Subscriber update response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Vary : Accept
     Content-Type: application/json
    
       {
         "code": 0,
         "content": "Success",
         "data": [
           {
             "polkaId": "1284567892",
               "subscriber": {
               "_id": "XHPiMFOgAD0KzimPeitfH6WgJVJP6r1b",
               "polkaId": "1284567892",
               "accountId": "12345678901234567892",
               "pdaId": "789456123078945678901234567890",
               "smartcardSN": "12345678902",
               "telcoId": "7894561594256842",
               "skyStatus": "provisioned",
                "telcoStatus": "installed",
               "telcoFlag": "passed",
               "bouquetIdFlag": false,
               "deviceInstances": [
                 {
                   "_id": "bvQDB3RKpGxCgxU18r7vI20sDAJPVBTV",
                   "deviceId": "gtk7Ca2HAXp5R15ZjcXOHOAZYlJQkL6U",
                   "applicationId": "XHPiMdpchfugjthdjitfH6WgJVJP6r62"
                 }
               ],
               "profiles": [],
               "devices": [
                 {
                   "_id": "GW8i3fdu7v1c1oyExSYmnBL009sLnQkn",
                   "uuid": "4561327886",
                   "stbSN": "2234567891234534",
                   "stbId": "2619259546",
                   "stbBootloader2Version": "",
                   "stbSoftwareVersion": "",
                   "stbCertificateRevokedFlag": false,
                   "stbCertificateExpiry": 0,
                   "stbCertificateSN": "",
                   "status": 1,
                   "label": "device_forUpdate"
                 }
               ]
             },
           "errorCode": 0,
           "errorMessage": "",
           "errorData": null
         }
       ]
     }

