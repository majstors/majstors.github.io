.. http:post:: /(string:wyclubToken)/subscriber/scms
  :noindex:

  :synopsis:
    Create subscriber throw SCMS API.

  :parameter string wyclubToken: *(mandatory)* – Wyclub Token

  :reqjson array subscribers: *(mandatory)* – Array of subscribers
  :reqjson string subscribers.polkaId: *(mandatory)* – Subscriber ID (10 digits)
  :reqjson string subscribers.accountId: *(mandatory)* – Account ID (20 chars)
  :reqjson string subscribers.pdaId: *(mandatory)* – PDA ID (30 chars)
  :reqjson string subscribers.smartcardSN: *(mandatory)* – Serial number of the smartcard (11 chars)
  :reqjson string subscribers.stbSN: *(mandatory)* – Serial number of the STB (16 chars)
  :reqjson string subscribers.stbId: *(mandatory)* – ID of the STB (10 chars)
  :reqjson string subscribers.stbMACAddress: MAC address of the STB (AA:AA:AA:AA:AA:AA)
  :reqjson boolean subscribers.stbCertificateRevokedFlag: *(default: false)* – Subscriber certificate is revoked?
  :reqjson string subscribers.telcoId: *(mandatory)* – Telco ID (16 chars)
  :reqjson string subscribers.bouquetId: Bouquet ID (16 chars)
  :reqjson boolean subscribers.bouquetIdFlag: *(default: false)* – 
  :reqjson string subscribers.telcoFlag: *(default: true)* – (can be true, false or 'passed')
  :reqjson string subscribers.skyStatus: *(mandatory)* – (can be 'provisioned' or 'installed')
  :reqjson string subscribers.telcoStatus: *(mandatory)* – (can be 'provisioned', 'installed' or 'inactive')

  **- Request create subscriber with Id 3686914412**:

    .. sourcecode:: http
    
     POST /9BvMMXWSOoqzgKbHbC86E1KwAuSxTeN3/subscriber/scms HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
       {
         "subscribers": [
           {
             "polkaId": "3686914412",
             "accountId": "12345678901234567892",
             "pdaId": "789456123078945678901234567890",
             "smartcardSN": "64613390956",
             "stbSN": "1RTOBERD396WOXWG",
             "stbId": "1689454642",
             "stbMACAddress": "12:12:12:12:12:12",
             "bouquetId": "0JUBYTDI5NXTEE2T",
             "telcoId": "BGG1NPBMV1NUD2VL",
             "skyStatus": "installed",
             "telcoStatus": "provisioned",
             "stbCertificateSN": "xxx",
             "stbCertificateExpiry": 1420000000,
             "stbSoftwareVersion": "1",
             "stbBootloader2Version": "2"
           }
         ]
       }

  :resjson integer code: code of response
  :resjson integer content: Status of response
  :resjson array data: array of module result
  :resjson string data.polkaId: Subscriber ID
  :resjson object data.subscriber: Subscriber object
  :resjson string data.subscriber.polkaId: Subscriber ID
  :resjson string data.subscriber.accountId: Account ID
  :resjson string data.subscriber.pdaId: PDA ID
  :resjson string data.subscriber.smartcardSN: Serial number of the STB
  :resjson string data.subscriber.bouquetId: Bouquet ID
  :resjson string data.subscriber.telcoId: Telco ID
  :resjson string data.subscriber.skyStatus: -
  :resjson string data.subscriber.telcoStatus: -
  :resjson string data.subscriber.telcoFlag: -
  :resjson boolean data.subscriber.bouquetIdFlag: -
  :resjson array data.subscriber.deviceInstances: -
  :resjson array data.subscriber.profiles: -
  :resjson array data.subscriber.devices: -
  :resjson string data.subscriber.devices.uuid: -
  :resjson string data.subscriber.devices.stbId: Serial number of the STB
  :resjson string data.subscriber.devices.stbSN: ID of the STB
  :resjson string data.subscriber.devices.stbMACAddress: MAC address of the STB
  :resjson string data.subscriber.devices.stbBootloader2Version: 
  :resjson boolean data.subscriber.devices.stbSoftwareVersion: 
  :resjson string data.subscriber.devices.stbCertificateRevokedFlag: 
  :resjson integer data.subscriber.devices.stbCertificateExpiry: 
  :resjson string data.subscriber.devices.stbCertificateSN: 
  :resjson integer data.subscriber.devices.status: 
  :resjson string data.subscriber.devices.label: 
  :resjson string data.subscriber.devices._id: 
  :resjson string data.subscriber._id: 
  :resjson integer data.errorCode: code of error
  :resjson string data.errorMessage: Error message
  :resjson object data.errorData: -

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

    + *code*:  5: invalid request parameter
    + *code*:  999: An unexpected error occured (read body.data.errorMessage in response body for more details)

  **- Subscriber create request example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Vary : Accept
     Content-Type: application/json
    
       {
         "code": 0,
         "content": "Success",
         "data": [
           {
             "polkaId": "3686914412",
             "subscriber": {
               "polkaId": "3686914412",
               "accountId": "12345678901234567892",
               "pdaId": "789456123078945678901234567890",
               "smartcardSN": "64613390956",
               "bouquetId": "0JUBYTDI5NXTEE2T",
               "telcoId": "BGG1NPBMV1NUD2VL",
               "skyStatus": "installed",
               "telcoStatus": "provisioned",
               "telcoFlag": "true",
               "bouquetIdFlag": false,
               "deviceInstances": [],
               "profiles": [],
               "devices": [
                 {
                   "uuid": "1689454642",
                   "stbId": "1689454642",
                   "stbSN": "1RTOBERD396WOXWG",
                   "stbMACAddress": "12:12:12:12:12:12",
                   "stbBootloader2Version": "",
                   "stbSoftwareVersion": "",
                   "stbCertificateRevokedFlag": false,
                   "stbCertificateExpiry": 0,
                   "stbCertificateSN": "",
                   "status": 1,
                   "label": "device",
                   "_id": "544f6d062940706d1fc48b31"
                 }
               ],
               "_id": "544f6d062940706d1fc48b30"
             },
           "errorCode": 0,
           "errorMessage": "",
           "errorData": null
           }
         ]
       }

