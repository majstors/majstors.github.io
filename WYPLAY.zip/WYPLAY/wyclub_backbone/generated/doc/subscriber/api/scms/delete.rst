.. http:delete:: /(string:wyclubToken)/subscriber/scms
  :noindex:

  :synopsis:
    Delete subscriber throw SCMS API.

  :parameter string wyclubToken: *(mandatory)* – Wyclub Token

  :reqjson array subscribers: *(mandatory)* – Array of subscribers
  :reqjson string subscribers.polkaId: *(mandatory)* – Subscriber ID (10 digits)

  **- Subscriber delete request example**:

    .. sourcecode:: http
    
     POST /9BvMMXWSOoqzgKbHbC86E1KwAuSxTeN3/subscriber/scms HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
       {
         "subscribers": [
           {
             "polkaId": "1284567892"
           }
         ]
       }

  :resjson integer code: code of a response
  :resjson integer content: Content of a response
  :resjson array data: data of a response
  :resjson string data.polkaId: Subscriber ID
  :resjson integer data.errorCode: Subscriber object
  :resjson string data.errorMessage: Subscriber ID
  :resjson object data.errorData: 

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbiden

    + *code*:  5: Invalid request parameter
    + *code*:  999: An unexpected error occured (read body.data.errorMessage in response body for more details)

  **- Subscriber delete response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Vary: Accept
     Content-Type: application/json
    
       {
         "code": 0,
         "content": "Success",
         "data": [
           {
             "polkaId": "1284567892",
             "errorCode": 0,
             "errorMessage": "",
             "errorData": null
           }
         ]
       }

