****
scms
****

create
======
.. include:: scms/create.rst
update
======
.. include:: scms/update.rst
delete
======
.. include:: scms/delete.rst
