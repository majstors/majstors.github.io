.. http:delete:: /(string:wyclubToken)/subscriber/subscriber/(integer:id)
  :noindex:

  :synopsis:
    Delete a subscriber

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter integer id: *(mandatory)* – The ID of the new subscriber

  :resjson number code: Operation result code, 0 indicates a success, any other value a failure
  :resjson string content: Operation result human readable message (if any)
  :resjson integer data: Operation result data, 1 when success

  :statuscode 200: Success

  :statuscode 403: Forbidden

  :statuscode 404: Not found

  :statuscode 503: Service Unavailable

