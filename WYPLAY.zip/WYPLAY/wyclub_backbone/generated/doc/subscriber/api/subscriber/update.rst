.. http:patch:: /(string:wyclubToken)/subscriber/subscriber/(integer:id)
  :noindex:

  :synopsis:
    Update a subscriber

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter integer id: *(mandatory)* – The ID of the new subscriber

  :reqjson string _id: *(mandatory)* – Record id
  :reqjson array profiles: *(mandatory)* – Profiles
  :reqjson string profiles.label: Label
  :reqjson string profiles.birthdate: Birth date
  :reqjson string profiles.position: Position
  :reqjson string profiles.password: Password
  :reqjson array deviceInstances: *(mandatory)* – Device Instances
  :reqjson string deviceInstances.deviceId: Device id
  :reqjson string deviceInstances.applicationId: Application id
  :reqjson array devices: *(mandatory)* – Devices
  :reqjson string devices.uuid: *(mandatory)* – uuid
  :reqjson string devices.label: *(mandatory)* – Label
  :reqjson number devices.status: *(mandatory)* – Status

  :resjson number code: Operation result code, 0 indicates a success, any other value a failure
  :resjson string content: Operation result human readable message (if any)
  :resjson object data: Operation result data
  :resjson string data._id: Record id
  :resjson array data.profiles: Profiles
  :resjson string data.profiles.label: Label
  :resjson string data.profiles.birthdate: Birth date
  :resjson string data.profiles.position: Position
  :resjson string data.profiles.password: Password
  :resjson array data.deviceInstances: Device Instances
  :resjson string data.deviceInstances.deviceId: Device id
  :resjson string data.deviceInstances.applicationId: Application id
  :resjson array data.devices: Devices
  :resjson string data.devices.uuid: uuid
  :resjson string data.devices.label: Label
  :resjson number data.devices.status: Status
  :resjson string data.id: Id of the subscriber

  :statuscode 200: Success

  :statuscode 503: Service Unavailable

