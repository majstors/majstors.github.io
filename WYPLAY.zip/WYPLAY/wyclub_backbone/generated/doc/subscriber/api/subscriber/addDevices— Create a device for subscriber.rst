.. http:post:: /(string:wyclubToken)/subscriber/subscriber/(integer:id)/device
  :noindex:

  :synopsis:
    

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter integer id: *(mandatory)* – The catalog ID

  :reqjson array devices: Array of devices
  :reqjson string devices.stbId: *(mandatory)* – STB Id
  :reqjson string devices.label: *(mandatory)* – Label
  :reqjson number devices.status: *(mandatory)* – Status
  :reqjson string devices.stbSN: *(mandatory)* – Setupbox serial number
  :reqjson string devices.stbMACAddress: *(mandatory)* – STB MAC address
  :reqjson string devices.stbCertificateSN: *(mandatory)* – STB certificate serial number
  :reqjson number devices.stbCertificateExpiry: *(mandatory)* – STB certificate expiry
  :reqjson boolean devices.stbCertificateRevokedFlag: STB certificate revoked flag
  :reqjson string devices.stbSoftwareVersion: STB software version
  :reqjson string devices.stbBootloader2Version: STB bootloader version

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

    + *code*:  5: Resource don't have required parameter.

  :statuscode 404: Not Found

    + *code*:  104: Resource don't exist in database

