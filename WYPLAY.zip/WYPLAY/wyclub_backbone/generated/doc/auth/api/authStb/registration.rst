.. http:post:: /(string:applicationId)/auth/registration
  :noindex:

  :synopsis:
     Authenticates, registers and creates a WyClub token for the given (`applicationId`) and STB information.

  :Version follow-up:

    * .. versionadded:: 0.1.0

  :parameter string applicationId: *(mandatory)* – The client applicationId.

  :reqjson string stbSN: *(mandatory)* – The STB serial number.
  :reqjson string stbId: *(mandatory)* – The STB Id.
  :reqjson string stbMACAddress: *(mandatory)* – The STB MAC address.
  :reqjson string stbSoftwareVersion: *(mandatory)* – The STB software (middleware) version. **NOT SUPPORTED YET**
  :reqjson string stbBootloader2Version: *(mandatory)* – The STB bootloader 2 version. **NOT SUPPORTED YET**

  **- Request example**:

    .. sourcecode:: http
    
     POST /xyz987/auth/registration HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
      {
        "stbSN": "0xAF13020492000214",
        "stbId": "0492000214",
        "stbMACAddress": "58:91:cf:46:67:66",
        "stbSoftwareVersion": "4.2.8",
        "stbBootloader2Version": "1.8.3"
      }

  :resjson string wyclubToken: The WyClub Token.

  :statuscode 200: Success

  :statuscode 403: Forbidden

    + *code*:  4: Your session isn\'t valid.
    + *code*:  1001: No subscriber in current session.
    + *code*:  1007: The specified device does not exists.
    + *code*:  1011: Common certificate has been revoked.
    + *code*:  1014: Error with SCMS.
    + *code*:  1015: Your stb is already register.

  :statuscode 404: No Found

    + *code*:  1010: Common certificate expiry.
    + *code*:  1012: Home check error.
    + *code*:  1013: No common certificate.

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Content-Type: application/json; charset=utf-8
    
       {
         "code": 0,
         "content": "success",
         "data": {
           "wyclubToken": "123abc"
         }
       }

