.. http:post:: /(string:wyclubToken)/auth/csr
  :noindex:

  :synopsis:
    Provides a signed unique certificate for the given CSR.

  :parameter string wyclubToken: *(mandatory)* – The WyClub Token.

  :Request content: (string) – The C(ertificate) S(igning) R(equest), PEM encoded.

  **- Request example**:

    .. sourcecode:: http
    
     POST /123abc/auth/csr HTTP/1.1
     Accept: application/octet-stream
     Content-Type: application/octet-stream
     
     
     -----BEGIN CERTIFICATE REQUEST-----
     MIICnDCCAYQCAQAwPzELMAkGA1UEBhMCSVQxEzARBgNVBAgTClNvbWUtU3RhdGUx
     DTALBgNVBAoTBFNreSAxDDAKBgNVBAMTA01BQzCCASIwDQYJKoZIhvcNAQEBBQAD
     ggEPADCCAQoCggEBAKYhWnNMJz8meTaE+1CWV2P/z/u6N9nGr8pNAxhSed1u70/c
     gNGeujhpU96SF8pzSRvZTfGsNhPRhrrXFma1rN7zrQ31Q+v3e00ulLmGSCXszMOH
     +Guk/Jcum96tIc1ntFBqNuopEZR4IPkOWoROzdcMDm02iGB7nvx4XW0OKESE8VQt
     lmQk2c+AeVx6CaHUX76gQhH8bwd++Rm1XPidNcpDKxxM/RGMclGlaj3S34lMIkH7
     xTbwSfD0+yCzihKaLXsO/x2b+itkxI4brVYd+hRscf06yDhdfAPMn+zrJWBhy8Se
     zeqYqddSpgE9D/AFZQnlrcmS1MLTJ57oaTn9qu8CAwEAAaAYMBYGCSqGSIb3DQEJ
     BzEJEwdnLWZvcmNlMA0GCSqGSIb3DQEBBQUAA4IBAQBtb3fFzgxwgZmvDHKw8TTG
     2pEu4h0cUvLK99Un16SRZt0RJmzEdoq5pO033sicnd2GGAXRbz4Pj4Kg/3nQpQsC
     f2AYjc5Olbnla8889jnRzSGl1PB1mELL2wCRkB3u1+wm6Egkkc2TVKTHslZ3EjoW
     FMP9VBsT5fXA0qo3h7Nu9atYv3ambhU8t4/3ftVUlQ+xKKTYIQnwnrdzXVw+Hn36
     RpX6MoTRVx1ehZTWAfq0sI8Hstn8uT/y/47VIzPH9AROH2IuvsCAhPhqV9jGKddu
     TkAmWqrR6n0kvwd7lsMoxlz8a8iA4NrH32eUZWkUK4Ij2w1Kvmg5FeZ9K4C1iXBI
     -----END CERTIFICATE REQUEST-----

  :Response content: (string) – The signed certificate PEM encoded.

  :statuscode 200: Success

  :statuscode 403: Forbidden

    + *code*:  4: Your session isn\'t valid.
    + *code*:  1007: The specified device does not exists.
    + *code*:  1008: Your CSR isn't valid.
    + *code*:  1011: Common certificate has been revoked.

  :statuscode 404: No Found

    + *code*:  1002: Unique certificate doesn't correspond to current session.
    + *code*:  1003: Unique certificate has been revoked.
    + *code*:  1004: Unique certificate expired.
    + *code*:  1005: Home check error on IP.
    + *code*:  1009: Certificate Authority not available.
    + *code*:  1010: Common certificate expiry.
    + *code*:  1013: No common certificate.

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Content-Type: application/octet-stream
     
     -----BEGIN CERTIFICATE-----
     MIIC7TCCAdWgAwIBAgIJAI2tW6hxzeyoMA0GCSqGSIb3DQEBCwUAMA0xCzAJBgNV
     BAYTAkZSMB4XDTE0MDgyNTA4Mjg0OVoXDTE3MDgyNDA4Mjg0OVowDTELMAkGA1UE
     BhMCRlIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC0nVm+0QLyYJ3B
     QjGOuPTIaThra5fY7qhaT2lPWHIrgRlzgWrtJUd/i5RkubVNdDk6wnKdKkGK9EtM
     ti7gxN9+GdCDUWW1awiq+eveq+SECSj2+MQoh1e/r0/hq1CK3ttVnyjaASLb3LDR
     RUVwgN/Z0az33ZN3NNIoeljJ+vFYtiV+++4ycBxvtybPUmdWcWUPNaHQo0QOy1FJ
     zaRw7Jbs0ZzntbJ8Yf7x4jw5rdB0Gie0PxVm8bIlE6emTeKYUPpADePXeD0oyfDe
     BosJywfH4m7YjVkZwaTId++9UMlmlDG1os1VezteD0OwohApB03q+K4aF0Hh/kFz
     5QxMTEZFAgMBAAGjUDBOMB0GA1UdDgQWBBSKmotylScGGZfGStTYm21I3EkCbDAf
     BgNVHSMEGDAWgBSKmotylScGGZfGStTYm21I3EkCbDAMBgNVHRMEBTADAQH/MA0G
     CSqGSIb3DQEBCwUAA4IBAQADO8EIk17MF9vIfoXozpWFbcH5fkO27YHb+HjOEYTZ
     hoSFygLF5AfcdSd9NYXIQUSsahZx8/drxAFO80spHbl+MOH24DG1VgNPHaR6e9wY
     x3Xc3P85gDtnfkCydx4h1Dw+VWkL//YL00AivW/YXuJ3KOigEGDmQcybj9thJWF/
     bR6dKekmf/BlX/+5wSt45ocGgs0GHtmCWCAAoJ3JID9DyrMvzzwIMdDkfg2sEV6i
     gzckTAC9NSOusxo5sKTvvOy6usm4oId4eobpW/ZFDBY7fBDPLhr69lSeU4y5Sgmr
     t0/dMEQ3oiy2K1hMRZc3CDQbCteJdLGWKSX48L0eTH1X
     -----END CERTIFICATE-----

