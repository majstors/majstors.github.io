.. http:get:: /auth/bootloader
  :noindex:

  :synopsis:
    Query to check if middleware or bootloader
    can be updated. Also redirect to the binary location according to query
    type.

  :query string ID: *(mandatory)* – Serial NB
  :query string Type: *(mandatory)* – Query type ("0" for middleware, "1" for bootloader, or "2" for stb)

  **- Request example with type 0**:

    .. sourcecode:: http
    
     GET /auth/bootloader?ID=123abc&Type=0
     Accept: application/json
     Content-Type: application/json
     If-None-Match: e6e8ea7465f12e4d3b5a067a4c4dc698436b3478

  **- Request example with type 1**:

    .. sourcecode:: http
    
     GET /auth/bootloader?ID=123abc&Type=1
     Accept: application/json
     Content-Type: application/json
     If-None-Match: e6e8ea7465f12e4d3b5a067a4c4dc698436b3478

  **- Request example with type 2**:

    .. sourcecode:: http
    
     GET /auth/bootloader?ID=123abc&Type=2
     Accept: application/json
     Content-Type: application/json
     If-None-Match: e6e8ea7465f12e4d3b5a067a4c4dc698436b3478

  :statuscode 200: Success

  :statuscode 307: Redirect

  :statuscode 403: Forbidden

    + *code*:  1006: IP installation is not possible

  **- Response example with type 0**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Content-Type: application/json; charset=utf-8
    
    {
    "code": 0,
    "content": "Success"
    }

  **- Response example with type 1**:

    .. sourcecode:: http
    
     HTTP/1.1 307 OK
     Content-Type: application/json; charset=utf-8
     Location: http://<server>/<location>/<resource>

  **- Response example with type 2**:

    .. sourcecode:: http
    
     HTTP/1.1 307 OK
     Content-Type: application/json; charset=utf-8
     Location: http://<server>/<location>/<resource>

