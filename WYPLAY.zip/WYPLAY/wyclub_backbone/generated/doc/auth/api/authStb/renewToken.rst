.. http:post:: /(string:applicationId)/auth/token
  :noindex:

  :synopsis:
     Authenticates and creates a fresh WyClub token for the given (`applicationId`) and STB information.

  :Version follow-up:

    * .. versionadded:: 0.1.0

  :parameter string applicationId: *(mandatory)* – The client applicationId.

  :reqjson string stbSN: *(mandatory)* – The STB serial number.
  :reqjson string stbId: *(mandatory)* – The STB Id.
  :reqjson string stbMACAddress: *(mandatory)* – The STB MAC address.
  :reqjson string stbSoftwareVersion: *(mandatory)* – The STB software (middleware) version.
  :reqjson string stbBootloader2Version: *(mandatory)* – The STB bootloader 2 version.
  :reqjson string smartcardSN: *(mandatory)* – The STB bootloader 2 version.

  **- Request example**:

    .. sourcecode:: http
    
     POST /xyz987/auth/token HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
      {
        "stbSN": "0xAF13020492000214",
        "stbId": "0492000214",
        "stbMACAddress": "58:91:cf:46:67:66",
        "stbSoftwareVersion": "4.2.8",
        "stbBootloader2Version": "1.8.3",
        "smartcardSN": "12345678912"
      }

  :resjson string wyclubToken: The WyClub Token.

  :statuscode 200: Success

  :statuscode 403: Forbidden

    + *code*:  4: Your session isn\'t valid.
    + *code*:  1007: The specified device does not exists.
    + *code*:  1011: Common certificate has been revoked.

  :statuscode 404: No Found

    + *code*:  1002: Unique certificate doesn't correspond to current session.
    + *code*:  1003: Unique certificate has been revoked.
    + *code*:  1004: Unique certificate expired.
    + *code*:  1005: Home check error on IP.
    + *code*:  1010: Common certificate expiry.
    + *code*:  1013: No common certificate.

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Content-Type: application/json; charset=utf-8
    
       {
         "code": 0,
         "content": "success",
         "data": {
           "wyclubToken": "123abc"
         }
       }

