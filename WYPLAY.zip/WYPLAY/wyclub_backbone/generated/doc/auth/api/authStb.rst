*******
authStb
*******

serial
======
.. include:: authStb/serial.rst
renewToken
==========
.. include:: authStb/renewToken.rst
registration
============
.. include:: authStb/registration.rst
signCertificate
===============
.. include:: authStb/signCertificate.rst
