*********************
Authentication Module
*********************

Introduction
============
The Auth module handles STB authentification for WyClub.
It is also used as a pass-through for the subscriber certificate signature.


API Documentation
=================
.. toctree::
   :maxdepth: 1
   :glob:

   api/*
   api/statuscodes/*