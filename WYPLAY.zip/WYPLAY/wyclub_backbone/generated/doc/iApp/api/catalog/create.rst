.. http:post:: /(string:wyclubToken)/iApp/catalog
  :noindex:

  :synopsis:
    Create a catalog

  :parameter string wyclubToken: *(mandatory)* – A session ID

  :reqjson integer catalogId: *(mandatory)* – ID of a catalog
  :reqjson integer bouquetKey: *(mandatory)* – ID of a lineup
  :reqjson string name: *(mandatory)* – Bouquet's name
  :reqjson array iapps: *(mandatory)* – iApp list
  :reqjson string iapps.appId: *(mandatory)* – iApp ID
  :reqjson boolean iapps.inImm: *(mandatory)* – if display in imm
  :reqjson string iapps.immOrder: *(mandatory)* – position of iApp in imm
  :reqjson array iapps.channels: array of channel
  :reqjson string iapps.channels.serviceKey: *(mandatory)* – ID channel
  :reqjson string iapps.channels.status: *(mandatory)* – status of an iApp : {"enable","disable"}
  :reqjson string iapps.channels.greenButtonType: type of green button
  :reqjson integer iapps.channels.autolaunchType: type of autolaunch
  :reqjson boolean iapps.channels.haveAutolaunch: if iApp type is autolaunch
  :reqjson boolean iapps.channels.haveGreenButton: if iApp have green button

  **- Request example**:

    .. sourcecode:: http
    
     POST /12345678901234567890123456789012/iApp/catalog HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
       {
         "catalogId": 1,
         "lineupId": 1,
         "name": "Test",
         "iapps": [
           {
             "appId": "service123456789",
             "inImm": false,
             "immOrder": "order",
             "channels": [
               {
                 "serviceKey": "id",
                 "status": "enable",
                 "greenButtonType": "test",
                 "autolaunchType": 10,
                 "haveAutolaunch": true,
                 "haveGreenButton": false
               }
             ]
           }
         ]
       }

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 503: Service Unavailable

    + *code*:  100: This resource don't content data required for save.
    + *code*:  103: This resource already exist in database.

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Vary: Accept
     Content-Type: application/json
    
       {
         "code": 0,
         "content": "Success",
         "data": {
           "_id": "543638edd355c1de1d52103d",
           "catalogId": 1,
           "lineupId": 1,
           "name": "Test",
           "iapps": [
             {
               "_id": "543648d40b9f5af82774e20d",
               "appId": "service123456789",
               "inImm": false,
               "immOrder": "order",
               "channels": [
                 {
                   "_id": "543648d40b9f5af82774e20e",
                   "serviceKey": "id",
                   "status": "enable",
                   "greenButtonType": "test",
                   "autolaunchType": 10,
                   "haveAutolaunch": true,
                   "haveGreenButton": false
                 }
               ]
             }
           ]
         }
       }

