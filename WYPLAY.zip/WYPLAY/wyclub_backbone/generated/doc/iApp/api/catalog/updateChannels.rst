.. http:patch:: /(string:wyclubToken)/iApp/catalog/(integer:catalogId)/channel
  :noindex:

  :synopsis:
    Update channels from an iApp of a catalog

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter integer catalogId: *(mandatory)* – The catalog ID

  :reqjson string appId: *(mandatory)* – The iApp ID
  :reqjson array channels: *(mandatory)* – Array of channel to update
  :reqjson string channels.serviceKey: *(mandatory)* – ID of a channel
  :reqjson string channels.status: status of an iApp : {"enable","disable"}
  :reqjson string channels.greenButtonType: type of green button
  :reqjson integer channels.autolaunchType: type of autolaunch
  :reqjson boolean channels.haveAutolaunch: if iApp type is autolaunch
  :reqjson boolean channels.haveGreenButton: if iApp have green button

  **- Request example**:

    .. sourcecode:: http
    
     PATCH /12345678901234567890123456789012/iApp/catalog/<catalogId:integer>/channel HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
       {
         "appId": "service123456789",
         "channels": [
           {
             "serviceKey" : "id",
             "greenButtonType" : "updated-green-button"
           }
         ]
       }

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 404: Not Found

    + *code*:  104: Resource don't exist in database

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Vary: Accept
     Content-Type: application/json
    
       {
         "code": 0,
         "content": "Success",
         "data": {
           "_id": "543638edd355c1de1d52103d",
           "catalogId": 1,
           "lineupId": 1,
           "name": "Test",
           "iapps": [
             {
               "_id": "543648d40b9f5af82774e20d",
               "appId": "service123456789",
               "inImm": false,
               "immOrder": "order",
               "channels": [
                 {
                   "_id": "543648d40b9f5af82774e20e",
                   "serviceKey": "id",
                   "status": "enable",
                   "greenButtonType": "updated-green-button",
                   "autolaunchType": 10,
                   "haveAutolaunch": true,
                   "haveGreenButton": false
                 }
               ]
             }
           ]
         }
       }

