.. http:delete:: /(string:wyclubToken)/iApp/catalog/(integer:catalogId)/channel
  :noindex:

  :synopsis:
    Remove channels from an iApp of a catalog

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter integer catalogId: *(mandatory)* – The catalog ID

  :reqjson string appId: *(mandatory)* – The iApp ID
  :reqjson array channels: *(mandatory)* – Array of channel ID
  :reqjson string channels.serviceKey: *(mandatory)* – ID of channel

  **- Request example**:

    .. sourcecode:: http
    
     DELETE /12345678901234567890123456789012/iApp/catalog/<catalogId:integer>/channel HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
       {
         "appId": "service123456789",
         "channels": [
    		     {
    		       "serviceKey" : "idtodelete"
    		     }
    	     ]
       }

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

    + *code*:  5: Resource don't have required parameter.

  :statuscode 404: Not Found

    + *code*:  104: Resource don't exist in database

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Vary: Accept
     Content-Type: application/json
    
       {
         "code": 0,
         "content": "Success",
         "data": {
           "_id": "543638edd355c1de1d52103d",
           "catalogId": 1,
           "lineupId": 1,
           "name": "Test",
           "iapps": [
             {
               "_id": "543648d40b9f5af82774e20d",
               "appId": "service123456789",
               "inImm": false,
               "immOrder": "order",
               "channels": [
                 {
                   "_id": "543648d40b9f5af82774e20e",
                   "serviceKey": "id",
                   "status": "enable",
                   "greenButtonType": "test",
                   "autolaunchType": 10,
                   "haveAutolaunch": true,
                   "haveGreenButton": false
                 }
               ]
             }
           ]
         }
       }

