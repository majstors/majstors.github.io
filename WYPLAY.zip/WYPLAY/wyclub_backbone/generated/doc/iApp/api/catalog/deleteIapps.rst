.. http:delete:: /(string:wyclubToken)/iApp/catalog/(integer:catalogId)/iapp
  :noindex:

  :synopsis:
    Remove an iapp of a catalog

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter integer catalogId: *(mandatory)* – The Catalog ID

  :reqjson array iapps: *(mandatory)* – List of Iapp ID
  :reqjson string iapps.appId: *(mandatory)* – The iApp ID

  **- Request example**:

    .. sourcecode:: http
    
     DELETE /12345678901234567890123456789012/iApp/catalog/<catalogId:integer>/iapp HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
       {
         "iapps": [
           {
             "appId": "service123456789"
           }
         ]
       }

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

    + *code*:  5: Resource don't have required parameter.

  :statuscode 404: Not Found

    + *code*:  104: Resource don't exist in database

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Vary: Accept
     Content-Type: application/json
    
       {
         "code": 0,
         "content": "Success",
         "data": {
           "_id": "5448dd9cf3b31ad81e499253",
           "catalogId": 1,
           "bouquetKey": 1,
           "name": "Kids",
           "iapps": []
         }
       }

