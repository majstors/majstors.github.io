.. http:patch:: /(string:wyclubToken)/iApp/catalog/(integer:catalogId)/iapp
  :noindex:

  :synopsis:
    Update an iApp of a catalog

  :parameter string wyclubToken: *(mandatory)* – A wyclubToken
  :parameter integer catalogId: *(mandatory)* – ID of a catalog

  :reqjson integer iapps: *(mandatory)* – Array of iApp
  :reqjson string iapps.appId: *(mandatory)* – The iApp ID
  :reqjson boolean iapps.inImm: *(mandatory)* – if display in imm
  :reqjson string iapps.immOrder: *(mandatory)* – position of iApp in imm

  **- Request example**:

    .. sourcecode:: http
    
     PATCH /12345678901234567890123456789012/iApp/catalog/<catalogId:integer>/iapp HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
       {
        "iapps": [
          {
            "appId": "service123456789",
            "inImm": false,
            "immOrder": "UpdateImmOrder"
          }
        ]
      }

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 404: Not Found

    + *code*:  104: Resource don't exist in database

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Vary: Accept
     Content-Type: application/json
    
       {
        "code": 0,
        "content": "Success",
        "data": {
          "_id": "5448dd9cf3b31ad81e499253",
          "catalogId": 1,
          "bouquetKey": 1,
          "name": "Kids",
          "iapps": [
            {
              "appId": "service123456789",
              "inImm": false,
              "immOrder": "UpdateImmOrder",
              "_id" : "5448f8f4f3b31ad81e499259",
              "channels": [
     	           {
     	             "_id" : "543648d40b9f5af82774e20e",
     	             "serviceKey" : "id",
     	             "status" : "enable",
     	             "greenButtonType" : "",
     	             "autolaunchType" : 10,
     	             "haveAutolaunch" : true,
     	             "haveGreenButton" : false
     	           }
     	        ]
            }
          ]
        }
      }

