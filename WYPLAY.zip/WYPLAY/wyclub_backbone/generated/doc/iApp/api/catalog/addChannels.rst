.. http:post:: /(string:wyclubToken)/iApp/catalog/(integer:catalogId)/channel
  :noindex:

  :synopsis:
    Add channels in iapp's catalog

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter integer catalogId: *(mandatory)* – The catalog ID

  :reqjson string appId: *(mandatory)* – The iApp ID
  :reqjson array channels: *(mandatory)* – The new channel
  :reqjson string channels.serviceKey: *(mandatory)* – The new channel ID
  :reqjson string channels.status: *(mandatory)* – status of an iApp : {"enable","disable"}
  :reqjson string channels.greenButtonType: *(mandatory)* – type of green button
  :reqjson integer channels.autolaunchType: *(mandatory)* – type of autolaunch
  :reqjson boolean channels.haveAutolaunch: *(mandatory)* – if iApp type is autolaunch
  :reqjson boolean channels.haveGreenButton: *(mandatory)* – if iApp have green button

  **- Request example**:

    .. sourcecode:: http
    
     POST /12345678901234567890123456789012/iApp/catalog/<catalogId:integer>/channel HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
       {
         "appId": "service123456789",
         "channels": [
    	       {
             "serviceKey" : "newchannelid",
             "status" : "disable",
             "greenButtonType" : "",
             "autolaunchType" : 10,
             "haveAutolaunch" : true,
             "haveGreenButton" : false
           }
         ]
        }

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Vary: Accept
     Content-Type: application/json
    
     {
       "code": 0,
       "content": "Success",
       "data" : {
         "_id": "543638edd355c1de1d52103d",
         "catalogId": 1,
         "bouquetKey": 1,
         "iapps": [
           {
             "appId": "service123456789",
             "inImm": false,
             "immOrder": "UpdateImmOrder",
             "channels": [
    		         {
    			         "serviceKey" : "id",
    			         "status" : "enable",
    			         "greenButtonType" : "",
    			         "autolaunchType" : 10,
    			         "haveAutolaunch" : true,
    			         "haveGreenButton" : false
    		         },
    		         {
    			         "serviceKey" : "newchannelid",
    			         "status" : "disable",
    			         "greenButtonType" : "",
    			         "autolaunchType" : 10,
    			         "haveAutolaunch" : true,
    			         "haveGreenButton" : false
    		         }
    	         ]
           }
         ]
       }
     }

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 404: Not Found

