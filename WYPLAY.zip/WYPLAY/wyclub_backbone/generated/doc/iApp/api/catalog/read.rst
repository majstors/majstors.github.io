.. http:get:: /(string:wyclubToken)/iApp/catalog/(integer:catalogId)
  :noindex:

  :synopsis:
    Read a catalog

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter integer catalogId: *(mandatory)* – The catalog ID

  **- Request example**:

    .. sourcecode:: http
    
     GET /12345678901234567890123456789012/iApp/catalog/<catalogId:integer> HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

    + *code*:  5: Invalid request parameter

  :statuscode 404: Not not found

    + *code*:  104: Resource don't exist in database

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Vary: Accept
     Content-Type: application/json
    
       {
         "code": 0,
         "content": "Success",
         "data": {
           "catalogId": 1,
           "lineupId": 1,
           "name": "Test",
           "iapps": [
             {
               "appId": "service123456789",
               "inImm": false,
               "immOrder": "order",
               "channels": [
                 {
                   "serviceKey": "id",
                   "status": "enable",
                   "greenButtonType": "test",
                   "autolaunchType": 10,
                   "haveAutolaunch": true,
                   "haveGreenButton": false
                 }
               ]
             }
           ]
         }
       }

