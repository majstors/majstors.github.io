.. http:post:: /(string:wyclubToken)/iApp/catalog/(integer:catalogId)/iapp
  :noindex:

  :synopsis:
    Add new iApp in catalog

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter integer catalogId: *(mandatory)* – ID of a catalog

  :reqjson array iapps: Array of iApp
  :reqjson string iapps.appId: ID of an iApp
  :reqjson boolean iapps.inImm: if display in imm
  :reqjson string iapps.immOrder: position of iApp in imm
  :reqjson array iapps.channels: *(mandatory)* – a list of channel
  :reqjson string iapps.channels.serviceKey: ID of a channel
  :reqjson string iapps.channels.status: status of an iApp : {"enable","disable"}
  :reqjson string iapps.channels.greenButtonType: *(mandatory)* – type of green button
  :reqjson integer iapps.channels.autolaunchType: *(mandatory)* – type of autolaunch
  :reqjson boolean iapps.channels.haveAutolaunch: *(mandatory)* – if iApp type is autolaunch
  :reqjson boolean iapps.channels.haveGreenButton: *(mandatory)* – if iApp have green button

  **- Request example**:

    .. sourcecode:: http
    
     POST /12345678901234567890123456789012/iApp/catalog/<catalogId:integer>/iapp HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
       {
         "iapps": [
           {
             "appId": "newservice",
             "inImm": false,
             "immOrder": "immOrder",
             "channels": [
              {
                 "serviceKey": "id",
                 "status": "enable",
                 "greenButtonType": "",
                 "autolaunchType": 10,
                 "haveAutolaunch": true,
                 "haveGreenButton": false
              }
            ]
           }
         ]
       }

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 404: Not Found

    + *code*:  104: Resource don't exist in database

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Vary: Accept
     Content-Type: application/json
    
       {
           "code": 0,
           "content": "success",
           "data": {
               "catalogId": 1,
               "bouquetKey": 1,
               "iapps": [
                   {
                       "appId": "service123456789",
                       "inImm": false,
                       "immOrder": "toto",
                       "channels": [
                           {
                               "serviceKey": "id",
                               "status": "enable",
                               "greenButtonType": "",
                               "autolaunchType": 10,
                               "haveAutolaunch": true,
                               "haveGreenButton": false
                           }
                       ]
                   },
                   {
                       "appId": "newservice",
                       "inImm": false,
                       "immOrder": "immOrder",
                       "channels": [
                           {
                               "serviceKey": "id",
                               "status": "enable",
                               "greenButtonType": "",
                               "autolaunchType": 10,
                               "haveAutolaunch": true,
                               "haveGreenButton": false
                           }
                       ]
                   }
               ]
           }
       }

