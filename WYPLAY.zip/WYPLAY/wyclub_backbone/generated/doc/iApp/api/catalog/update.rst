.. http:patch:: /(string:wyclubToken)/iApp/catalog/(integer:catalogId)
  :noindex:

  :synopsis:
    Update catalog

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter integer catalogId: *(mandatory)* – ID of a catalog

  :reqjson integer bouquetKey: Id of a lineup
  :reqjson string name: name of a catalog

  **- Request example**:

    .. sourcecode:: http
    
     POST /12345678901234567890123456789012/iApp/catalog/<catalogId:integer> HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
       {
         "name": "name updated"
       }

  :statuscode 200: Success

    + *code*:  0: Success
    + *code*:  5: Resource don't have required parameter.

  :statuscode 403: Forbidden

  :statuscode 404: Not Found

    + *code*:  104: Resource don't exist in database

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Vary: Accept
     Content-Type: application/json
    
       {
         "code": 0,
         "content": "success",
         "data": {
           "catalogId": 1
           "bouquetKey": 1
           "name": "name updated"
           "_id": "543638edd355c1de1d52103d"
           "iapps": [
             {
               "appId": "id"
               "inImm": false
               "immOrder": "Alphabetic"
               "_id": "543648d40b9f5af82774e20d"
               "channels": [
                 {
                   "serviceKey": "id"
                   "status": "enable"
                   "greenButtonType": "toto"
                   "autolaunchType": 10
                   "haveAutolaunch": true
                   "haveGreenButton": false
                   "_id": "543648d40b9f5af82774e20e"
                 }
               ]
             }
           ]
         }
       }

