****
iApp
****

readAll
=======
.. include:: iApp/readAll.rst
read
====
.. include:: iApp/read.rst
create
======
.. include:: iApp/create.rst
update
======
.. include:: iApp/update.rst
delete
======
.. include:: iApp/delete.rst
activate
========
.. include:: iApp/activate.rst
