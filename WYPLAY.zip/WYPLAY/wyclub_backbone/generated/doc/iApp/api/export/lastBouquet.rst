.. http:get:: /(string:wyclubToken)/iApp/export/(string:bouquetKey)/last
  :noindex:

  :synopsis:
    Read a last exported bouquet from DB

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter string bouquetKey: *(mandatory)* – The bouquet ID

.. http:get:: /(string:wyclubToken)/lineup/export/(string:bouquetKey)/last
  :noindex:

  :synopsis:
    Read a last exported bouquet from DB

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter string bouquetKey: *(mandatory)* – The bouquet ID

