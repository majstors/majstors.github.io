.. http:post:: /(string:wyclubToken)/iApp/export/(string:bouquetKey)
  :noindex:

  :synopsis:
    Create export task by bouquetKey

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter string bouquetKey: *(mandatory)* – The bouquet ID

  :reqjson integer uploadDate: Timestamp

.. http:post:: /(string:wyclubToken)/lineup/export/(string:bouquetKey)
  :noindex:

  :synopsis:
    Export a bouquet to CDN. Send a notification to push module on

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter string bouquetKey: *(mandatory)* – The bouquet ID

  :reqjson boolean critical: *(mandatory)* – Send a notification to push module if set to true. It also disables delayed upload (uploadDate params ignored).
  :reqjson integer uploadDate: Upload date (UTC timestamp).

  **- Valid request example**:

    .. sourcode:: http
    
     POST /123abc/lineup/1/export
     Host: example.com
     Accept: application/json

  :statuscode 200: Success

  :statuscode 403: Forbidden

    + *code*:  4: Your session is not valid

  **- Response on success**:

    .. sourcecode:: http
    
     HTTP1.1 200 OK
     Date: Wed, 08 Oct 2014 12:00:00 GMT
     Content-Type: application/json
    
     {
       "code": 0,
       "content": "Success"
     }

