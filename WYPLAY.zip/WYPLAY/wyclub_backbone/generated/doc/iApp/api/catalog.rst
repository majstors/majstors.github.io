*******
catalog
*******

update
======
.. include:: catalog/update.rst
addIapps
========
.. include:: catalog/addIapps.rst
updateIapps
===========
.. include:: catalog/updateIapps.rst
deleteIapps
===========
.. include:: catalog/deleteIapps.rst
addChannels
===========
.. include:: catalog/addChannels.rst
updateChannels
==============
.. include:: catalog/updateChannels.rst
deleteChannels
==============
.. include:: catalog/deleteChannels.rst
read
====
.. include:: catalog/read.rst
create
======
.. include:: catalog/create.rst
delete
======
.. include:: catalog/delete.rst
