.. http:post:: /(string:wyclubToken)/iApp/iApp
  :noindex:

  :synopsis:
    Write an iApp

  :parameter string wyclubToken: *(mandatory)* – A WyClub token

  :reqjson string label: *(mandatory)* – The label of the iApp
  :reqjson string description: *(mandatory)* – The description of the iApp
  :reqjson string launchingMessage: The launching message of the iApp
  :reqjson string url: *(mandatory)* – The url of the iApp

  **Request example**:

    .. sourcecode:: http
    
     POST /12345678901234567890123456789012/iApp/iApp.json HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
       {
         "label": "test",
         "description": "test\ntest",
         "launchingMessage": "",
         "url": "http://www"
       }

  :resjson number code: Operation result code, 0 indicates a success, any other value a failure
  :resjson string content: Operation result human readable message (if any)
  :resjson object data: Operation result data
  :resjson string data.label: The label of the iApp
  :resjson string data.description: The description of the iApp
  :resjson string data.launchingMessage: The launching message of the iApp
  :resjson string data.url: The url of the iApp
  :resjson string data.iAppId: Id of the iApp

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

  :statuscode 503: Service Unavailable

    + *code*:  100: Error during creation
    + *code*:  103: Try to create an iApp that already exists

