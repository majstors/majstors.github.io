.. http:patch:: /(string:wyclubToken)/iApp/iApp/(string:iAppId)
  :noindex:

  :synopsis:
    Update an iApp

  :parameter string wyclubToken: *(mandatory)* – A WyClub token
  :parameter string iAppId: *(mandatory)* – The ID of the iApp

  :reqjson string label: The label of the iApp
  :reqjson string description: The description of the iApp
  :reqjson string launchingMessage: The launching message of the iApp
  :reqjson string url: The url of the iApp

  :resjson number code: Operation result code, 0 indicates a success, any other value a failure
  :resjson string content: Operation result human readable message (if any)
  :resjson object data: Operation result data
  :resjson string data.label: The label of the iApp
  :resjson string data.description: The description of the iApp
  :resjson string data.launchingMessage: The launching message of the iApp
  :resjson string data.url: The url of the iApp
  :resjson string data.iAppId: Id of the iApp

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

  :statuscode 404: Not found

    + *code*:  104: Non-existent iApp

  :statuscode 503: Service Unavailable

    + *code*:  102: Error during update

