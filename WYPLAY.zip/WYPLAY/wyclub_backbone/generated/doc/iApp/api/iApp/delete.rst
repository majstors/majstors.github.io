.. http:delete:: /(string:wyclubToken)/iApp/iApp/(string:iAppId)
  :noindex:

  :synopsis:
    Delete an iApp

  :parameter string wyclubToken: *(mandatory)* – A WyClub token
  :parameter string iAppId: *(mandatory)* – The ID of the iApp

  :resjson number code: Operation result code, 0 indicates a success, any other value a failure
  :resjson string content: Operation result human readable message (if any)
  :resjson integer data: Operation result data, 1 when success

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

  :statuscode 404: Not found

    + *code*:  104: Non-existent iApp

  :statuscode 503: Service Unavailable

    + *code*:  101: Error during update

