.. http:post:: /(string:wyclubToken)/iApp/activate
  :noindex:

  :synopsis:
    Activate an iApp on one or more channels

  :parameter string wyclubToken: *(mandatory)* – A WyClub token

  :reqjson string iAppId: *(mandatory)* – ServiceKey of the iApp
  :reqjson boolean activate: *(mandatory)* – Enable or disable the iApp
  :reqjson array channels: The list of the channel where we want to enable or disable the iApp. Enables all the iApp on all channels if not given

  **Request example if we want to active the iApp 100 on the channel 308**:

    .. sourcecode:: http
    
     POST /123abc/iApp/activate HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
       {
         "activate": true,
         "iAppId": "100",
         "channels": [
           "308"
         ]
       }

  **Request example if we want to active the iApp 100 on all channels**:

    .. sourcecode:: http
    
     POST /123abc/iApp/activate HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
       {
         "activate": true,
         "iAppId": "100"
       }

  :resjson number code: Operation result code, 0 indicates a success, any other value a failure
  :resjson string content: Operation result human readable message (if any)

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

  :statuscode 404: Resource doen't exists

    + *code*:  1200: No iApp assciated to given channels found

  :statuscode 503: Service Unavailable

    + *code*:  100: Error during activation

  **Response example when we have a success**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Vary: Accept
     Content-Type: application/json
    
       {
         "code": 0,
         "content": "Success"
       }

