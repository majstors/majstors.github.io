.. http:get:: /(string:wyclubToken)/iApp/iApps
  :noindex:

  :synopsis:
    Read all iApps

  :parameter string wyclubToken: *(mandatory)* – A WyClub token

  :resjson number code: Operation result code, 0 indicates a success, any other value a failure
  :resjson string content: Operation result human readable message (if any)
  :resjson array data: Operation result data
  :resjson string data.label: The label of the iApp
  :resjson string data.description: The description of the iApp
  :resjson string data.launchingMessage: The launching message of the iApp
  :resjson string data.url: The url of the iApp
  :resjson string data.iAppId: Id of the iApp

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

  :statuscode 503: Service Unavailable

    + *code*:  105: Error during reading

