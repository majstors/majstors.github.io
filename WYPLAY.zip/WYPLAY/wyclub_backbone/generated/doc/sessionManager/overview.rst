***************
Session Manager
***************

Introduction
============
Session manager allow to manage wyclub session.
It provide a repository via the Container which allow to crud session.

Call
====
You can call the repository with Container.sessionManager.repository.repositorySession
