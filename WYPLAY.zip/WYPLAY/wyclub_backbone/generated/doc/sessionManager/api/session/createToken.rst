.. http:post:: /(string:applicationId)/sessionManager/token
  :noindex:

  :synopsis:
    Create a new token with a specific application.

  :parameter string applicationId: *(mandatory)* – An application ID

  :reqjson string deviceId: The device ID
  :reqjson string subscriberId: The subscriber ID

