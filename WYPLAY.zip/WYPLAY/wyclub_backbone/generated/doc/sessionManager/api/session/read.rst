.. http:get:: /(string:wyclubToken)/sessionManager
  :noindex:

  :synopsis:
    Read information about my session

  :parameter string wyclubToken: *(mandatory)* – A session ID

