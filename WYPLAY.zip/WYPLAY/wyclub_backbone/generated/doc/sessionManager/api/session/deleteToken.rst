.. http:delete:: /(string:wyclubToken)/sessionManager/token
  :noindex:

  :synopsis:
    Delete a token

  :parameter string wyclubToken: *(mandatory)* – An session ID

