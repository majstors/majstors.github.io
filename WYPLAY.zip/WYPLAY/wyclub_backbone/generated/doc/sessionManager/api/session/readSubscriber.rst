.. http:get:: /(string:wyclubToken)/sessionManager/sub
  :noindex:

  :synopsis:
    Read the requested subscriber's info.

  :parameter string wyclubToken: *(mandatory)* – A session ID

  :query string accessToken: A session access token.

