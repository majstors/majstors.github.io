.. http:get:: /(string:wyclubToken)/tag/tag
  :noindex:

  :synopsis:
    Read the requested tag's info.

  :parameter string wyclubToken: *(mandatory)* – A session ID

  :query string tagId: *(mandatory)* – Tag ID
  :query string accessToken: A session access token.

