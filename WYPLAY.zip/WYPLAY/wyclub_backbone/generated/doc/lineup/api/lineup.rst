******
lineup
******

readAll
=======
.. include:: lineup/readAll.rst
read
====
.. include:: lineup/read.rst
write
=====
.. include:: lineup/write.rst
delete
======
.. include:: lineup/delete.rst
update
======
.. include:: lineup/update.rst
addChannels
===========
.. include:: lineup/addChannels.rst
updateChannels
==============
.. include:: lineup/updateChannels.rst
readInProgress
==============
.. include:: lineup/readInProgress.rst
deleteChannels
==============
.. include:: lineup/deleteChannels.rst
