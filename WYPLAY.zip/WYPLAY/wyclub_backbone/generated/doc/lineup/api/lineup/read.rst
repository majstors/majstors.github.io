.. http:get:: /(string:wyclubToken)/lineup/lineup/(integer:bouquetKey)
  :noindex:

  :synopsis:
    Read a lineup

  :Version follow-up:

    * .. versionadded:: 0.1.0

  :parameter string wyclubToken: *(mandatory)* – A wyclub token
  :parameter integer bouquetKey: *(mandatory)* – The bouquet ID

  **- Get the lineup of the bouquetKey 1**:

    .. sourcecode:: http
    
     GET /123abc/lineup/lineup/1 HTTP/1.1
     Accept: application/json
     Content-Type: application/json

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

    + *code*:  4: Your session is not valid.

  **- A lineup**:

    .. sourcecode:: http
    
     Date: Wed, 08 Oct 2014 12:14:20 GMT
     Expires: Sun, 16 Nov 2014 04:36:20 GMT
     Content-Type: application/json; charset=utf-8
    
       {
         "code": 0,
         "content": "Success",
         "data": {
           "_id": "5444c6e58aadef7a1e627d11",
           "bouquetKey": 1,
           "labelOfBouquet": "example",
           "homelineup": 1,
           "lineupList": [
             {
               "position": 1,
               "positionOrderNum": 1,
               "serviceKey": 1,
               "_id": "5444c6e58aadef7a1e627d12"
             }
           ]
         }
       }

