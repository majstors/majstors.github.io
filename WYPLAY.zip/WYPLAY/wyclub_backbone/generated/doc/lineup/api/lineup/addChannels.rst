.. http:post:: /(string:wyclubToken)/lineup/(integer:bouquetKey)/channel
  :noindex:

  :synopsis:
    Add channels to a bouquet

  :Version follow-up:

    * .. versionadded:: 0.5.0

  :parameter string wyclubToken: *(mandatory)* – A wyclub token
  :parameter integer bouquetKey: *(mandatory)* – The bouquet ID

  :reqjson array channels: *(mandatory)* – Array of channels
  :reqjson integer channels.position: *(mandatory)* – The position of the channel in the lineup
  :reqjson integer channels.positionOrderNum: *(mandatory)* – The position of the channel in the epg
  :reqjson integer channels.serviceKey: *(mandatory)* – The ID of this channel

  **- Add channels to a bouquet**:

    .. sourcecode:: http
    
     POST /123abc/lineup/2/channel HTTP/1.1
     Accept: application/json
     Content-Type: application/json
       {
         "bouquetKey": 2,
         "channels": [
           {
             "position": 10,
             "positionOrderNum": 0,
             "serviceKey": 13
           }
         ]
       }

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

    + *code*:  4: Your session is not valid.

  :statuscode 404: Not Found

    + *code*:  104: No entry.

  :statuscode 503: Update Error

    + *code*:  102: Could not update entry
    + *code*:  105: Could not get entry

  **- Add channels to a bouquet**:

    .. sourcecode:: http
    
     Date: Wed, 08 Oct 2014 12:14:20 GMT
     Expires: Sun, 16 Nov 2014 04:36:20 GMT
     Content-Type: application/json; charset=utf-8
       {
         "code": 0,
         "content": "Success",
         "data": {
           "_id": "5444d0338aadef7a1e627d21",
           "bouquetKey": 2,
           "labelOfBouquet": "test",
           "homelineup": null,
           "lineupList": [
             {
               "position": 1,
               "positionOrderNum": 1,
               "serviceKey": 1,
               "_id": "5444d0338aadef7a1e627d22"
             },
             {
               "position": 10,
               "positionOrderNum": 0,
               "serviceKey": 13,
               "_id": "5444eae9f4e7188f310d9d61"
             }
           ]
         }
       }

