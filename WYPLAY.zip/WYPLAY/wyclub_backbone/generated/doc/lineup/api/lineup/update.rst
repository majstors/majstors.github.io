.. http:patch:: /(string:wyclubToken)/lineup/lineup/(integer:bouquetKey)
  :noindex:

  :synopsis:
    Update a lineup

  :Version follow-up:

    * .. versionadded:: 0.1.0

  :parameter string wyclubToken: *(mandatory)* – A wyclub token ID
  :parameter integer bouquetKey: *(mandatory)* – The bouquet ID

  :reqjson string labelOfBouquet: The updated bouquet name
  :reqjson string homelineup: The updated home channel of the lineup
  :reqjson array lineupList: The updated lineup channel list
  :reqjson integer lineupList.position: The position of the channel in the lineup
  :reqjson integer lineupList.positionOrderNum: The position of the channel in the lineup TODO: ask to JRousseau
  :reqjson integer lineupList.serviceKey: The ID of this channel

  **- Write the lineup of the bouquetKey 1**:

    .. sourcecode:: http
    
     PATCH /123abc/lineup/lineup/2 HTTP/1.1
     Accept: application/json
     Content-Type: application/json
       {
         "bouquetKey": 2,
         "labelOfBouquet": "example 2",
         "homelineup": 1,
         "lineupList": [
           {
             'position': 1,
             'positionOrderNum': 1,
             'serviceKey': 9999
           },
           {
             'position': 2,
             'positionOrderNum': 2,
             'serviceKey': 9998
           }
         ]
       }

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

    + *code*:  4: Your session is not valid.

  **- A lineup update**:

    .. sourcecode:: http
    
     Date: Wed, 08 Oct 2014 12:14:20 GMT
     Expires: Sun, 16 Nov 2014 04:36:20 GMT
     Content-Type: application/json; charset=utf-8
       {
         "code": 0,
         "content": "Success",
         "data": {
           "_id": "5444d0338aadef7a1e627d21",
           "bouquetKey": 2,
           "labelOfBouquet": "test",
           "homelineup": null,
           "lineupList": [
             {
               "position": 1,
               "positionOrderNum": 1,
               "serviceKey": 1,
               "_id": "5444d0338aadef7a1e627d22"
             }
           ]
         }
       }

