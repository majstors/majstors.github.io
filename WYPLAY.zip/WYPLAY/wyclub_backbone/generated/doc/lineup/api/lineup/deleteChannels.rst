.. http:delete:: /(string:wyclubToken)/lineup/(integer:bouquetKey)/channel
  :noindex:

  :synopsis:
    Delete channels from a bouquet

  :Version follow-up:

    * .. versionadded:: 0.5.0

  :parameter string wyclubToken: *(mandatory)* – A wyclub token
  :parameter integer bouquetKey: *(mandatory)* – The bouquet ID

  :reqjson array channels: *(mandatory)* – Array of channels
  :reqjson integer channels.position: *(mandatory)* – The position of the channel to delete from the lineup

  **- Delete channels from a bouquet**:

    .. sourcecode:: http
    
     DELETE /123abc/lineup/2/channel HTTP/1.1
     Accept: application/json
     Content-Type: application/json
     Date: Wed, 08 Oct 2014 12:14:20 GMT
     Expires: Sun, 16 Nov 2014 04:36:20 GMT
     Content-Type: application/json; charset=utf-8
       {
         "bouquetKey": 2,
         "channels": [
           {
             "position": 13
           }
         ]
       }

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

    + *code*:  4: Your session is not valid.

  :statuscode 404: Not Found

    + *code*:  104: No entry.

  :statuscode 503: Update Error

    + *code*:  101: Could not delete entry
    + *code*:  105: Could not get entry

  **- Delete channels from bouquet**:

    .. sourcecode:: http
    
     Date: Wed, 08 Oct 2014 12:14:20 GMT
     Expires: Sun, 16 Nov 2014 04:36:20 GMT
     Content-Type: application/json; charset=utf-8
       {
         "code": 0,
         "content": "Success",
         "data": {
           "_id": "5444fbbe651eaae2397bd28a",
           "bouquetKey": 2,
           "labelOfBouquet": "test",
           "homelineup": null,
           "lineupList": [
             {
               "position": 2,
               "positionOrderNum": 1,
               "serviceKey": 13,
               "_id": "5444fbea651eaae2397bd290"
             }
           ]
         }
       }

