.. http:delete:: /(string:wyclubToken)/lineup/lineup/(integer:bouquetKey)
  :noindex:

  :synopsis:
    Delete a lineup

  :Version follow-up:

    * .. versionadded:: 0.1.0

  :parameter string wyclubToken: *(mandatory)* – A wyclub token ID
  :parameter integer bouquetKey: *(mandatory)* – The ID of the to be deleted bouquet

  **- Delete a lineup**:

    .. sourcecode:: http
    
     DELETE /123abc/lineup/lineup/2 HTTP/1.1
     Accept: application/json
     Content-Type: application/json
       {
         "bouquetKey": 2
       }

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

    + *code*:  4: Your session is not valid.

  **- Delete a lineup**:

    .. sourcecode:: http
    
     Date: Wed, 08 Oct 2014 12:14:20 GMT
     Expires: Sun, 16 Nov 2014 04:36:20 GMT
     Content-Type: application/json; charset=utf-8
       {
         "code": 0,
         "content": "Success",
         "data": 1
       }

