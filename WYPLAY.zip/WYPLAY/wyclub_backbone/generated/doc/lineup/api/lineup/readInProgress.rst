.. http:get:: /(string:wyclubToken)/lineup/(integer:bouquetKey)/readInProgress
  :noindex:

  :synopsis:
    Read a lineup with full channel data

  :Version follow-up:

    * .. versionadded:: 0.1.0

  :parameter string wyclubToken: *(mandatory)* – A wyclub token
  :parameter integer bouquetKey: *(mandatory)* – The bouquet ID

  **- Get the lineup of the bouquetKey 1**:

    .. sourcecode:: http
    
     GET /123abc/lineup/1/readInProgress HTTP/1.1
     Accept: application/json
     Content-Type: application/json

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

    + *code*:  4: Your session is not valid.

  **- A lineup**:

    .. sourcecode:: http
    
     Date: Wed, 08 Oct 2014 12:14:20 GMT
     Expires: Sun, 16 Nov 2014 04:36:20 GMT
     Content-Type: application/json; charset=utf-8
    
       {
         "code": 0,
         "content": "Success",
         "data": {
           "_id": "5444c6e58aadef7a1e627d11",
           "bouquetKey": 1,
           "labelOfBouquet": "example",
           "homelineup": 1,
           "lineupList": [
             {
               "type": "IP",
               "channelName": "PF9 HD",
               "contentType": "Video SD",
               "contentVideoUrl": "applehttp://iptv.sicdn.it/ndstest/pf9/index.m3u8",
               "genre": "News",
               "contentDescription": "PF9 channel",
               "epgSourceId": "120",
               "unSubscribedMessage": "PF9 channel",
               "channelCode": 6,
               "sourceChannelID": 6,
               "__t": "channelIp",
               "listingFlag": true,
               "searchScanFlag": true,
               "surfFlag": true,
               "searchAZ": true,
               "safe": true,
               "recordable": true,
               "position": 105,
               "positionOrderNum": 105,
               "serviceKey": 235,
               "_id": "5465f2157417a2393b1c11c2"
             }
           ]
         }
       }

