.. http:post:: /(string:wyclubToken)/lineup/lineup
  :noindex:

  :synopsis:
    Write a lineup

  :Version follow-up:

    * .. versionadded:: 0.1.0

  :parameter string wyclubToken: *(mandatory)* – A wyclub token

  :reqjson integer bouquetKey: *(mandatory)* – The new bouquet ID
  :reqjson string labelOfBouquet: *(mandatory)* – The new bouquet name
  :reqjson string homelineup: The home channel of the lineup
  :reqjson array lineupList: The list of the channels
  :reqjson integer lineupList.position: The position of the channel in the lineup
  :reqjson integer lineupList.positionOrderNum: The position of the channel in the lineup
  :reqjson integer lineupList.serviceKey: The ID of this channel

  **- Write the lineup of the bouquetKey 2**:

    .. sourcecode:: http
    
     POST /123abc/lineup/lineup HTTP/1.1
     Accept: application/json
     Content-Type: application/json
    
       {
         "bouquetKey": 2,
         "labelOfBouquet": "example 2",
         "homelineup": "1",
         "lineupList": [
           {
             "position": 1,
             "positionOrderNum": 1,
             "serviceKey": 1
           }
         ]
       }

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

    + *code*:  4: Your session is not valid.

  **- Write the lineup of the bouquetKey 2**:

    .. sourcecode:: http
    
     Date: Wed, 08 Oct 2014 12:14:20 GMT
     Expires: Sun, 16 Nov 2014 04:36:20 GMT
     Content-Type: application/json; charset=utf-8
    
       {
         "code": 0,
         "content": "Success",
         "data": {
           "bouquetKey": 2,
           "labelOfBouquet": "example 2",
           "homelineup": 1,
           "_id": "5444ccde8aadef7a1e627d19",
           "lineupList": [
             {
               "position": 1,
               "positionOrderNum": 1,
               "serviceKey": 1,
               "_id": "5444ccde8aadef7a1e627d1a"
             }
           ]
         }
       }

