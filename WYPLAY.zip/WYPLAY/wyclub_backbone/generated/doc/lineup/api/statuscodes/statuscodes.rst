************
Status codes
************

999
---
:Reference:
 DEFAULT

:Description:
 An unexpected error occured.

1
-
:Reference:
 BAD_REQUEST

:Description:
 Invalid %reqType% request, check your header.

2
-
:Reference:
 DB_NO_CONNECTION

:Description:
 Could not connect to database.

3
-
:Reference:
 DB_ERROR

:Description:
 Unexpected database error.

4
-
:Reference:
 NO_SESSION

:Description:
 Your session isn't valid.

5
-
:Reference:
 INVALID_REQ_PARAM

:Description:
 Invalid request parameter: %param%

6
-
:Reference:
 MISSING_REQ_PARAM

:Description:
 Missing request parameter(s): %param%

7
-
:Reference:
 NO_MODEL_TO_USE

:Description:
 No model defined

8
-
:Reference:
 NON_EXISTING_MODULE

:Description:
 Non-existent module: %param%

9
-
:Reference:
 BAD_SESSION_APPLICATION

:Description:
 Your session doesn't use correct application.

10
--
:Reference:
 MISSING_MODULE

:Description:
 A module is needed to perform that and it's missing.

100
---
:Reference:
 POST_ERROR

:Description:
 Could not create entry: %param%

101
---
:Reference:
 DELETE_ERROR

:Description:
 Could not delete entry: %param%

102
---
:Reference:
 PUT_ERROR

:Description:
 Could not update entry: %param%

103
---
:Reference:
 DUPLICATE_ENTRY

:Description:
 Duplicate entry: %param%

104
---
:Reference:
 NOTHING_ERROR

:Description:
 No entry: %param%

105
---
:Reference:
 GET_ERROR

:Description:
 Could not get entry: %param%

106
---
:Reference:
 PATCH_ERROR

:Description:
 Could not update entry: %param%

400
---
:Reference:
 JSON_SCHEMA_ERROR

:Description:
 Json schema error

403
---
:Reference:
 FORBIDDEN

:Description:
 Forbidden

700
---
:Reference:
 RESOURCE_PROFILE_FOUND_BUT_NO_RESOURCE_LINKED_IN_DB

:Description:
 A resource profile was found but nothing seems to be linked to that profile in database.

701
---
:Reference:
 NO_RESOURCE_PROFILE_FOUND

:Description:
 Your session have no tag concerning this resource.

702
---
:Reference:
 BAD_RESOURCE_TYPE

:Description:
 This type of resource does not exist.

703
---
:Reference:
 RESOURCE_ALREADY_EXISTS

:Description:
 This resource already exists.

704
---
:Reference:
 BOUQUET_NEEDED

:Description:
 A bouquetId is needed to get your lineup.

800
---
:Reference:
 NO_RESOURCE

:Description:
 The specified resource does not exist.

108
---
:Reference:
 NO_NOTIFICATION_DATABASE

:Description:
 No notification database.

1400
----
:Reference:
 CHANNEL_ALREADY_EXIST_BOUQUET

:Description:
 The following channels already exist in this bouquet with these position

1401
----
:Reference:
 UNKNOWN_HOMELINEUP

:Description:
 Homelineup must be in lineup list

1402
----
:Reference:
 NO_LINEUP_LIST

:Description:
 No lineup list

1403
----
:Reference:
 CANNOT_POSTPONE_CRITICAL

:Description:
 It is not possible to postpone a critical lineup update

