**************
Line-Up Module
**************

Introduction
============
Line-Up is a module used to manage bouquets (create, update, delete, read) on
the WyClub.


API Documentation
=================
.. toctree::
   :maxdepth: 1
   :glob:

   api/*
   api/statuscodes/*