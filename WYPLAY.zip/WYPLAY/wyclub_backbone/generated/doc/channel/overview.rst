**************
Channel Module
**************

Introduction
============
Channel is a module used to manage channels (create, update, delete, read) on
the WyClub.


API Documentation
=================
.. toctree::
   :maxdepth: 1
   :glob:

   api/*
   api/statuscodes/*