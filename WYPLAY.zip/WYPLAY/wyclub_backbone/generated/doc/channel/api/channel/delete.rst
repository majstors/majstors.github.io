.. http:delete:: /(string:wyclubToken)/channel/channel/(integer:serviceKey)
  :noindex:

  :synopsis:
    Delete a channel

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter integer serviceKey: *(mandatory)* – The ID of the new channel

  **- Request example**:

    .. sourcecode:: http
    
     DELETE /xyz987/channel/channel/11111 HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json

  :statuscode 200: Success

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Content-Type: application/json; charset=utf-8
    
       {
         "code": 0,
         "content": "success",
         "data": 1
       }

