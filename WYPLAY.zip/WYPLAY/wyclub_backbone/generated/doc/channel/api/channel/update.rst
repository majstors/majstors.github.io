.. http:patch:: /(string:wyclubToken)/channel/channel/(integer:serviceKey)
  :noindex:

  :synopsis:
    Update a channel

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter integer serviceKey: *(mandatory)* – The ID of the new channel

  :reqjson string label: The name of the new channel
  :reqjson string contentType: The content type of the new channel
  :reqjson string genre: The genre of the new channel
  :reqjson string genre1: The sub-genre of the new channel
  :reqjson string channelDescription: The description of the new channel
  :reqjson string minMaturityRating: The minimal age required for this channel
  :reqjson string unSubscribedMessage: The message displayed if not subscribed to the channel
  :reqjson integer epgSourceId: The epg ID of the new channel
  :reqjson boolean recordable: A flag, true if the channel is recordable
  :reqjson boolean searchAZ: A flag, true if the channel is listed on search functionality
  :reqjson boolean surfFlag: A flag, true if the channel is listed through the surfing with P+/P-
  :reqjson boolean searchScanFlag: A flag, true if the channel is listed through scan arrows UP/DOWN
  :reqjson boolean listingFlag: A flag, true if the channel appears in listing

  **- Request example**:

    .. sourcecode:: http
    
     PATCH /xyz987/channel/channel/11111 HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
    {
     "channelName": "TEST Application",
    }

  :resjson string _id: Record id.
  :resjson integer serviceKey: The WyClub Token.
  :resjson string type: type.
  :resjson string channelName: Channel Name.
  :resjson string contentType: Content Type.
  :resjson string contentVideoUrl: Content Video URL.
  :resjson string genre: Channel Genre.
  :resjson string contentDescription: Content Description.
  :resjson integer epgSourceId: EPG Source ID.
  :resjson string unSubscribedMessage: Unsubscribed Message.
  :resjson string channelCode: Channel Code.
  :resjson string sourceChannelID: Source Channel ID.
  :resjson boolean listingFlag: Listing Flag.
  :resjson string __t: Type of the channel MongoDB Schema.
  :resjson boolean searchScanFlag: Search Scan Flag.
  :resjson boolean surfFlag: Surf Flag.
  :resjson boolean searchAZ: Search A-Z.
  :resjson boolean safe: Safe.
  :resjson boolean recordable: Recordable.

  :statuscode 200: Success

  :statuscode 503: Service Unavailable

    + *code*:  1100: Not possible to change the type of the Channel

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Content-Type: application/json; charset=utf-8
    
    {
     "code": 0,
     "content": "Success",
     "data": {
       "serviceKey": 11111,
       "channelName": "TEST Application",
       "type": "IP",
       "contentDescription": "TEST CH",
       "sourceChannelID": 1,
       "epgSourceId": "0001",
       "genre": "Bambini",
       "contentType": "Video SD",
       "__t": "channelIp",
       "listingFlag": true,
       "searchScanFlag": true,
       "surfFlag": true,
       "searchAZ": true,
       "safe": true,
       "recordable": true,
       "_id": "544e7461f20ad37c703f83c4"
     }

