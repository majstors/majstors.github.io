.. http:get:: /(string:wyclubToken)/channel/channel/(string:serviceKey)
  :noindex:

  :synopsis:
    Read a channel

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter string serviceKey: *(mandatory)* – The ID of the channel

  **- Request example**:

    .. sourcecode:: http
    
     GET /xyz987/channel/channel/308 HTTP/1.1
     Accept: application/json, text/javascript

  :resjson string _id: Record id.
  :resjson integer serviceKey: The WyClub Token.
  :resjson string type: type.
  :resjson string channelName: Channel Name.
  :resjson string contentType: Content Type.
  :resjson string contentVideoUrl: Content Video URL.
  :resjson string genre: Channel Genre.
  :resjson string contentDescription: Content Description.
  :resjson integer epgSourceId: EPG Source ID.
  :resjson string unSubscribedMessage: Unsubscribed Message.
  :resjson string channelCode: Channel Code.
  :resjson string sourceChannelID: Source Channel ID.
  :resjson boolean listingFlag: Listing Flag.
  :resjson string __t: Type of the channel MongoDB Schema.
  :resjson boolean searchScanFlag: Search Scan Flag.
  :resjson boolean surfFlag: Surf Flag.
  :resjson boolean searchAZ: Search A-Z.
  :resjson boolean safe: Safe.
  :resjson boolean recordable: Recordable.

  :statuscode 200: Success

  :statuscode 403: Forbidden

    + *code*:  1101: Channel type is wrong. Must be IP, DTT or Radio

  :statuscode 404: Resource not found

    + *code*:  104: No entry: see details in data property

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Content-Type: application/json; charset=utf-8
    
    {
     "code": 0,
     "content": "Success",
     "data": {
       "serviceKey": 110,
       "channelName": "TEST",
       "type": "IP",
       "contentDescription": "TEST CH",
       "sourceChannelID": 1,
       "epgSourceId": "0001",
       "genre": "Bambini",
       "contentType": "Video SD",
       "__t": "channelIp",
       "listingFlag": true,
       "searchScanFlag": true,
       "surfFlag": true,
       "searchAZ": true,
       "safe": true,
       "recordable": true,
       "_id": "544e7461f20ad37c703f83c4"
     }

