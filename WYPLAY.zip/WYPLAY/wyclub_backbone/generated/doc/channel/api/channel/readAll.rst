.. http:get:: /(string:wyclubToken)/channel/channelList
  :noindex:

  :synopsis:
    Read all channel

  :parameter string wyclubToken: *(mandatory)* – A session ID

  **- Request example**:

    .. sourcecode:: http
    
     GET /123abc/channel/channelList HTTP/1.1
     Accept: application/json
     Content-Type: application/json
     If-None-Match: e6e8ea7465f12e4d3b5a067a4c4dc698436b3478

  :resjson string _id: Record id.
  :resjson integer serviceKey: The WyClub Token.
  :resjson string type: type.
  :resjson string channelName: Channel Name.
  :resjson string contentType: Content Type.
  :resjson string contentVideoUrl: Content Video URL.
  :resjson string genre: Channel Genre.
  :resjson string contentDescription: Content Description.
  :resjson integer epgSourceId: EPG Source ID.
  :resjson string unSubscribedMessage: Unsubscribed Message.
  :resjson string channelCode: Channel Code.
  :resjson string sourceChannelID: Source Channel ID.
  :resjson boolean listingFlag: Listing Flag.
  :resjson string __t: Type of the channel MongoDB Schema.
  :resjson boolean searchScanFlag: Search Scan Flag.
  :resjson boolean surfFlag: Surf Flag.
  :resjson boolean searchAZ: Search A-Z.
  :resjson boolean safe: Safe.
  :resjson boolean recordable: Recordable.

  :statuscode 200: Success

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Vary: Accept
     Content-Type: application/json
    
    {
     "code": 0,
     "content": "Success",
     "data": [
       {
         "_id": "544e68c09606a1256b9cb449",
         "serviceKey": 308,
         "type": "IP",
         "channelName": "Cartoon HD",
         "contentType": "Video HD",
         "contentVideoUrl": "http://server/data/index.m3u8",
         "genre": "Bambini",
         "contentDescription": "Toto",
         "epgSourceId": "0308",
         "unSubscribedMessage": "Toto",
         "channelCode": 1,
         "sourceChannelID": 1,
         "__t": "channelIp",
         "listingFlag": true,
         "searchScanFlag": true,
         "surfFlag": true,
         "searchAZ": true,
         "safe": true,
         "recordable": true
       }
     ]
    }

