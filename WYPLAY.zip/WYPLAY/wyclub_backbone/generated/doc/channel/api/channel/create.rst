.. http:post:: /(string:wyclubToken)/channel/channel
  :noindex:

  :synopsis:
    Write an IP channel

  :parameter string wyclubToken: *(mandatory)* – A session ID

  :reqjson integer serviceKey: *(mandatory)* – The new channel ID
  :reqjson string channelName: *(mandatory)* – The new channel name
  :reqjson string type: *(mandatory)* – The new channel type
  :reqjson string contentDescription: The new channel description
  :reqjson string note: The new channel note
  :reqjson string contentType: *(mandatory)* – The new channel content type
  :reqjson string logoUrl: The new channel logo url
  :reqjson string contentVideoUrl: The new channel content video url
  :reqjson string genre: *(mandatory)* – The new channel genre
  :reqjson string genre1: The new channel sub-genre
  :reqjson string unSubscribedMessage: The new channel message for unsubscribed watchers
  :reqjson integer epgSourceId: *(mandatory)* – The new channel ID in the EPG
  :reqjson boolean recordable: *(default: true)* – A flag, true if the new channel is recordable
  :reqjson boolean safe: *(default: true)* – A flag, true if the new channel is safe
  :reqjson boolean searchAZ: *(default: true)* – A flag, true if the channel is listed on search functionality
  :reqjson boolean surfFlag: *(default: true)* – A flag, true if the channel is listed through the surfing with P+/P-
  :reqjson boolean searchScanFlag: *(default: true)* – A flag, true if the channel is listed through scan arrows UP/DOWN
  :reqjson boolean listingFlag: *(default: true)* – A flag, true if the new channel is listed
  :reqjson integer channelCode: The new channel code
  :reqjson string sourceChannelID: *(mandatory)* – The new channel source id

  **- Request example**:

    .. sourcecode:: http
    
     POST /xyz987/channel/channel HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
    {
     "serviceKey": "123AZ",
     "channelName": "TESTApp",
     "type": "IP",
     "contentDescription": "Description of the channel",
     "sourceChannelID": "1",
     "epgSourceId": 1,
     "genre": "Bambini",
     "contentType": "Video SD"
    }

  :resjson string _id: Record id.
  :resjson integer serviceKey: The WyClub Token.
  :resjson string type: type.
  :resjson string channelName: Channel Name.
  :resjson string contentType: Content Type.
  :resjson string contentVideoUrl: Content Video URL.
  :resjson string genre: Channel Genre.
  :resjson string contentDescription: Content Description.
  :resjson integer epgSourceId: EPG Source ID.
  :resjson string unSubscribedMessage: Unsubscribed Message.
  :resjson string channelCode: Channel Code.
  :resjson string sourceChannelID: Source Channel ID.
  :resjson boolean listingFlag: Listing Flag.
  :resjson string __t: Type of the channel MongoDB Schema.
  :resjson boolean searchScanFlag: Search Scan Flag.
  :resjson boolean surfFlag: Surf Flag.
  :resjson boolean searchAZ: Search A-Z.
  :resjson boolean safe: Safe.
  :resjson boolean recordable: Recordable.

  :statuscode 200: Success

  :statuscode 403: Forbidden

    + *code*:  1101: Channel type is wrong. Must be IP, DTT or Radio

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Content-Type: application/json; charset=utf-8
    
    {
     "code": 0,
     "content": "Success",
     "data": {
       "serviceKey": 110,
       "channelName": "TEST",
       "type": "IP",
       "contentDescription": "TEST CH",
       "sourceChannelID": 1,
       "epgSourceId": "0001",
       "genre": "Bambini",
       "contentType": "Video SD",
       "__t": "channelIp",
       "listingFlag": true,
       "searchScanFlag": true,
       "surfFlag": true,
       "searchAZ": true,
       "safe": true,
       "recordable": true,
       "_id": "544e7461f20ad37c703f83c4"
     }

.. http:post:: /(string:wyclubToken)/channel/channel
  :noindex:

  :synopsis:
    Write a DTT channel

  :parameter string wyclubToken: *(mandatory)* – A session ID

  :reqjson integer serviceKey: *(mandatory)* – The new channel ID
  :reqjson string channelName: *(mandatory)* – The new channel name
  :reqjson string type: *(mandatory)* – The new channel type
  :reqjson string contentDescription: The new channel description
  :reqjson string note: The new channel note
  :reqjson string contentType: *(mandatory)* – The new channel content type
  :reqjson string logoUrl: The new channel logo url
  :reqjson string genre: *(mandatory)* – The new channel genre
  :reqjson string genre1: The new channel sub-genre
  :reqjson string unSubscribedMessage: The new channel message for unsubscribed watchers
  :reqjson integer epgSourceId: The new channel ID in the EPG
  :reqjson boolean recordable: *(default: true)* – A flag, true if the new channel is recordable
  :reqjson boolean safe: *(default: true)* – A flag, true if the new channel is safe
  :reqjson boolean searchAZ: *(default: true)* – A flag, true if the channel is listed on search functionality
  :reqjson boolean surfFlag: *(default: true)* – A flag, true if the channel is listed through the surfing with P+/P-
  :reqjson boolean searchScanFlag: *(default: true)* – A flag, true if the channel is listed through scan arrows UP/DOWN
  :reqjson boolean listingFlag: *(default: true)* – A flag, true if the new channel is listed
  :reqjson integer channelCode: The new channel code
  :reqjson string sourceChannelID: *(mandatory)* – The new channel source id
  :reqjson string networkID: *(mandatory)* – The new channel network ID
  :reqjson string transportID: *(mandatory)* – The new channel transport ID
  :reqjson string serviceID: *(mandatory)* – The new channel service ID

  **- Request example**:

    .. sourcecode:: http
    
     POST /xyz987/channel/channel HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
    {
     "serviceKey": "123AZ",
     "channelName": "TESTApp",
     "type": "IP",
     "contentDescription": "Description of the channel",
     "sourceChannelID": "1",
     "epgSourceId": 1,
     "genre": "Bambini",
     "contentType": "Video SD"
    }

  :resjson string _id: Record id.
  :resjson integer serviceKey: The WyClub Token.
  :resjson string type: type.
  :resjson string channelName: Channel Name.
  :resjson string contentType: Content Type.
  :resjson string contentVideoUrl: Content Video URL.
  :resjson string genre: Channel Genre.
  :resjson string contentDescription: Content Description.
  :resjson integer epgSourceId: EPG Source ID.
  :resjson string unSubscribedMessage: Unsubscribed Message.
  :resjson string channelCode: Channel Code.
  :resjson string sourceChannelID: Source Channel ID.
  :resjson boolean listingFlag: Listing Flag.
  :resjson string __t: Type of the channel MongoDB Schema.
  :resjson boolean searchScanFlag: Search Scan Flag.
  :resjson boolean surfFlag: Surf Flag.
  :resjson boolean searchAZ: Search A-Z.
  :resjson boolean safe: Safe.
  :resjson boolean recordable: Recordable.

  :statuscode 200: Success

  :statuscode 403: Forbidden

    + *code*:  1101: Channel type is wrong. Must be IP, DTT or Radio

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Content-Type: application/json; charset=utf-8
    
    {
     "code": 0,
     "content": "Success",
     "data": {
       "serviceKey": 110,
       "channelName": "TEST",
       "type": "IP",
       "contentDescription": "TEST CH",
       "sourceChannelID": 1,
       "epgSourceId": "0001",
       "genre": "Bambini",
       "contentType": "Video SD",
       "__t": "channelIp",
       "listingFlag": true,
       "searchScanFlag": true,
       "surfFlag": true,
       "searchAZ": true,
       "safe": true,
       "recordable": true,
       "_id": "544e7461f20ad37c703f83c4"
     }

.. http:post:: /(string:wyclubToken)/channel/channel
  :noindex:

  :synopsis:
    Write a DTT channel with IP inheritance

  :parameter string wyclubToken: *(mandatory)* – A session ID

  :reqjson integer serviceKey: *(mandatory)* – The new channel ID
  :reqjson string channelName: *(mandatory)* – The new channel name
  :reqjson string type: *(mandatory)* – The new channel type
  :reqjson string contentDescription: The new channel description
  :reqjson string note: The new channel note
  :reqjson string contentType: *(mandatory)* – The new channel content type
  :reqjson string networkID: *(mandatory)* – The new channel network ID
  :reqjson string transportID: *(mandatory)* – The new channel transport ID
  :reqjson string serviceID: *(mandatory)* – The new channel service ID
  :reqjson string serviceKeySource: *(mandatory)* – The new channel service key source

  **- Request example**:

    .. sourcecode:: http
    
     POST /xyz987/channel/channel HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
    {
     "serviceKey": "123AZ",
     "channelName": "TESTApp",
     "type": "IP",
     "contentDescription": "Description of the channel",
     "sourceChannelID": "1",
     "epgSourceId": 1,
     "genre": "Bambini",
     "contentType": "Video SD"
    }

  :resjson string _id: Record id.
  :resjson integer serviceKey: The WyClub Token.
  :resjson string type: type.
  :resjson string channelName: Channel Name.
  :resjson string contentType: Content Type.
  :resjson string contentVideoUrl: Content Video URL.
  :resjson string genre: Channel Genre.
  :resjson string contentDescription: Content Description.
  :resjson integer epgSourceId: EPG Source ID.
  :resjson string unSubscribedMessage: Unsubscribed Message.
  :resjson string channelCode: Channel Code.
  :resjson string sourceChannelID: Source Channel ID.
  :resjson boolean listingFlag: Listing Flag.
  :resjson string __t: Type of the channel MongoDB Schema.
  :resjson boolean searchScanFlag: Search Scan Flag.
  :resjson boolean surfFlag: Surf Flag.
  :resjson boolean searchAZ: Search A-Z.
  :resjson boolean safe: Safe.
  :resjson boolean recordable: Recordable.

  :statuscode 200: Success

  :statuscode 403: Forbidden

    + *code*:  1101: Channel type is wrong. Must be IP, DTT or Radio

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Content-Type: application/json; charset=utf-8
    
    {
     "code": 0,
     "content": "Success",
     "data": {
       "serviceKey": 110,
       "channelName": "TEST",
       "type": "IP",
       "contentDescription": "TEST CH",
       "sourceChannelID": 1,
       "epgSourceId": "0001",
       "genre": "Bambini",
       "contentType": "Video SD",
       "__t": "channelIp",
       "listingFlag": true,
       "searchScanFlag": true,
       "surfFlag": true,
       "searchAZ": true,
       "safe": true,
       "recordable": true,
       "_id": "544e7461f20ad37c703f83c4"
     }

.. http:post:: /(string:wyclubToken)/channel/channel
  :noindex:

  :synopsis:
    Write a radio channel

  :parameter string wyclubToken: *(mandatory)* – A session ID

  :reqjson integer serviceKey: *(mandatory)* – The new channel ID
  :reqjson string channelName: *(mandatory)* – The new channel name
  :reqjson string type: *(mandatory)* – The new channel type
  :reqjson string contentDescription: The new channel description
  :reqjson string note: The new channel note
  :reqjson string logoUrl: The new channel logo url
  :reqjson string contentVideoUrl: The new channel content video url
  :reqjson string genre: *(mandatory)* – The new channel genre
  :reqjson string genre1: The new channel sub-genre
  :reqjson string unSubscribedMessage: The new channel message for unsubscribed watchers
  :reqjson integer epgSourceId: *(mandatory)* – The new channel ID in the EPG
  :reqjson boolean recordable: *(default: true)* – A flag, true if the new channel is recordable
  :reqjson boolean safe: *(default: true)* – A flag, true if the new channel is safe
  :reqjson boolean searchAZ: *(default: true)* – A flag, true if the channel is listed on search functionality
  :reqjson boolean surfFlag: *(default: true)* – A flag, true if the channel is listed through the surfing with P+/P-
  :reqjson boolean searchScanFlag: *(default: true)* – A flag, true if the channel is listed through scan arrows UP/DOWN
  :reqjson boolean listingFlag: *(default: true)* – A flag, true if the new channel is listed
  :reqjson integer channelCode: The new channel code
  :reqjson string sourceChannelID: *(mandatory)* – The new channel source id

  **- Request example**:

    .. sourcecode:: http
    
     POST /xyz987/channel/channel HTTP/1.1
     Accept: application/json, text/javascript
     Content-Type: application/json
    
    {
     "serviceKey": "123AZ",
     "channelName": "TESTApp",
     "type": "IP",
     "contentDescription": "Description of the channel",
     "sourceChannelID": "1",
     "epgSourceId": 1,
     "genre": "Bambini",
     "contentType": "Video SD"
    }

  :resjson string _id: Record id.
  :resjson integer serviceKey: The WyClub Token.
  :resjson string type: type.
  :resjson string channelName: Channel Name.
  :resjson string contentType: Content Type.
  :resjson string contentVideoUrl: Content Video URL.
  :resjson string genre: Channel Genre.
  :resjson string contentDescription: Content Description.
  :resjson integer epgSourceId: EPG Source ID.
  :resjson string unSubscribedMessage: Unsubscribed Message.
  :resjson string channelCode: Channel Code.
  :resjson string sourceChannelID: Source Channel ID.
  :resjson boolean listingFlag: Listing Flag.
  :resjson string __t: Type of the channel MongoDB Schema.
  :resjson boolean searchScanFlag: Search Scan Flag.
  :resjson boolean surfFlag: Surf Flag.
  :resjson boolean searchAZ: Search A-Z.
  :resjson boolean safe: Safe.
  :resjson boolean recordable: Recordable.

  :statuscode 200: Success

  :statuscode 403: Forbidden

    + *code*:  1101: Channel type is wrong. Must be IP, DTT or Radio

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Content-Type: application/json; charset=utf-8
    
    {
     "code": 0,
     "content": "Success",
     "data": {
       "serviceKey": 110,
       "channelName": "TEST",
       "type": "IP",
       "contentDescription": "TEST CH",
       "sourceChannelID": 1,
       "epgSourceId": "0001",
       "genre": "Bambini",
       "contentType": "Video SD",
       "__t": "channelIp",
       "listingFlag": true,
       "searchScanFlag": true,
       "surfFlag": true,
       "searchAZ": true,
       "safe": true,
       "recordable": true,
       "_id": "544e7461f20ad37c703f83c4"
     }

