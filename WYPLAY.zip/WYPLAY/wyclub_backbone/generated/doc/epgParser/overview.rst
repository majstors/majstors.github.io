****
EPG Parser
****

Introduction
============
This module is a parser used by EPG the module.

Note that it is not standalone and it won't work without the generic EPG module.

The goal of this parser is to understand Sky XML files and translate them to
generic data for the EPG.
It also translate generic data to SQLite or JSON files understandable by Polka
project set-top-boxes.