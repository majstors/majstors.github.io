.. http:get:: /(string:wyclubToken)/commonCertificate/commonCertificate/(string:certificateId)
  :noindex:

  :synopsis:
    Read a common certificates

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter string certificateId: *(mandatory)* – The ID of the channel

  **- Request example**:

    .. sourcecode:: http
    
     GET /xyz987/commonCertificate/commonCertificate/308 HTTP/1.1
     Accept: application/json, text/javascript

  :resjson string _id: Record id.
  :resjson integer certificateId: Certificate id.
  :resjson string certificateExpiry: Certificate expiration time.
  :resjson string certificateRevokedFlag: Certificate Revoked flag.

  :statuscode 200: Success

  :statuscode 403: Forbidden

  :statuscode 404: Resource not found

    + *code*:  104: No entry: see details in data property

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Content-Type: application/json; charset=utf-8
    
    {
    "code": 0,
    "content": "Success",
    "data": {
      "_id": "5464ac3b28a91503244968b6",
      "certificateId": "CERT_VALID_ID",
      "certificateExpiry": 1800000000,
      "certificateRevokedFlag": false
    }
    }

