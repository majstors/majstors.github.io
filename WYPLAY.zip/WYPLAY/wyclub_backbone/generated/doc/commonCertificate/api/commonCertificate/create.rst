.. http:post:: /(string:wyclubToken)/commonCertificate/commonCertificate
  :noindex:

  :synopsis:
    Create a common certificate

  :parameter string wyclubToken: *(mandatory)* – A session ID

