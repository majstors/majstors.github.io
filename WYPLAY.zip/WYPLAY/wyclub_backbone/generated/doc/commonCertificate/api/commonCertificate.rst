*****************
commonCertificate
*****************

create
======
.. include:: commonCertificate/create.rst
read
====
.. include:: commonCertificate/read.rst
