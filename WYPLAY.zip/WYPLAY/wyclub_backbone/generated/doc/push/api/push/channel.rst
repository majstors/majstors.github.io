.. http:get:: /(string:wyclubToken)/push/channel
  :noindex:

  :synopsis:
    Establish the push notification channel (SSE)

  :Version follow-up:

    * .. versionadded:: 0.4.0

  :parameter string wyclubToken: *(mandatory)* – The WyclubToken

  :query string pskv: *(mandatory)* – Project Specific Keys and Values. URL encoded JSON object.

  **- Request example**:

    .. sourcecode:: http
    
     GET /123abc/push/channel?pskv= \
         %7B \
         %22lineUpVersion%22%3A%20%22a808b908df%22%2C%20 \
         %22iappsCatalogVersion%22%3A%20%22a808b908df%22%2C%20 \
         %22epgVersion%22%3A%20%22a808b908df%22%2C%20 \
         %22middlewareVersion%22%3A%20%22a808b908df%22%2C%20 \
         %22bootloaderVersion%22%3A%20%22a808b908df%22%2C%20 \
         %22bouquetId%22%3A%20%2242%22 \
         %7D HTTP/1.1
     Host: example.com
     Accept: text/event-stream

  :statuscode 200: Success

  :statuscode 403: Forbidden

    + *code*:  4: Your session is not valid

  **- Response example**:

    .. sourcecode:: http
     
     HTTP/1.1 200 OK
     Date: Wed, 08 Oct 2014 12:00:00 GMT
     Content-Type: text/event-stream
     
     
     data: {"type": "lineup", "url": "..."}
     
     

  **- JSON PSKV example**:

    .. sourcecode:: json
     
     {
       "lineUpVersion": "a808b908df",
       "iappsCatalogVersion": "a808b908df",
       "epgVersion": "a808b908df",
       "middlewareVersion": "a808b908df",
       "bootloaderVersion": "a808b908df",
       "bouquetId": "42"
     }

  **- Lineup event example**:

    .. sourcecode:: json
     
     {
       "type": "lineup",
       "url": "http://somewhere.else.com/resource/lineup_5"
     }

  **- Javscript client sample**:

    .. sourcecode:: json
     
     function connect() {
       var source =
         new EventSource(
           "http://somewhere.com/123abc/push/channel? \
              filter={URL encoded JSON object}");
       
       source.addEventListener("lineup", function(event) { 
         // event.data contains data of the event
       }, false);
       
       source.addEventListener("open", function(event) {
         // connected
       }, false);
     }

