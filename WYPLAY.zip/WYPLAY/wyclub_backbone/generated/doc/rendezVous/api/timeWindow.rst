**********
timeWindow
**********

create
======
.. include:: timeWindow/create.rst
delete
======
.. include:: timeWindow/delete.rst
