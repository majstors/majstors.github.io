.. http:delete:: /(string:wyclubToken)/rendezVous/(string:resourceType)/maxValidity
  :noindex:

  :synopsis:
    delete the max validity of a wyplay middleware with its resourceType

  :Version follow-up:

    * .. versionadded:: R3S1

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter string resourceType: *(mandatory)* – the resourceType of max validity to delete

  **- delete the max validity of a wyplay middleware image with its resourceType**:

    DELETE /softwareupgrade12345678912345601/rendezVous/maxValidity HTTP/1.1
    Accept: application/json
    Content-Type: application/json
    
    {
     "resourceType":"epg"
    }

  :resjson int code: 
  :resjson string content: 
  :resjson object data: 

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 404: Not Found

    + *code*:  702: This type of resource does not exists.

  **- a valid max validity deletion response**:

    HTTP/1.1 200 OK
    Date: Wed, 08 Oct 2014 12:14:20 GMT
    Content-Type: application/json; charset=utf-8
    
    {
     code: 0
     content: "Success"
     data: {}
    }

