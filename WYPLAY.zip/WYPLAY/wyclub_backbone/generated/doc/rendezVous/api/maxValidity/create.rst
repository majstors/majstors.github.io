.. http:post:: /(string:wyclubToken)/rendezVous/(string:resourceType)/maxValidity
  :noindex:

  :synopsis:
    Set the max validity of a resource in hours

  :Version follow-up:

    * .. versionadded:: R3S1

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter string resourceType: *(mandatory)* – A resource type : values within [epg, lineup, software]

  :reqjson int maxValidity: *(mandatory)* – the max validity of a resource in hours

  **- set the max validity of a software to 60 hours**:

    POST /softwareupgrade12345678912345601/rendezVous/software/maxValidity HTTP/1.1
    Accept: application/json
    Content-Type: application/json
    
    {
     "maxValidity":60
    }

  :resjson int code: 
  :resjson string content: 
  :resjson object data: 
  :resjson object data.maxValidity: 
  :resjson object data.resourceType: the resource type : accordingly to request.params.resourceType [epg, lineup, software]
  :resjson object data._id: 

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 404: Not Found

    + *code*:  702: This type of resource does not exists.

  **- a valid max validity creation response**:

    HTTP/1.1 200 OK
    Date: Wed, 08 Oct 2014 12:14:20 GMT
    Content-Type: application/json; charset=utf-8
    
    {
     code: 0
     content: "Success"
     data: {
       __v: 0
       maxValidity: 60
       resourceType: "lineup" or "epg" or "software"
       _id: "542e570c09b2419b6f35244a"
     }
    }

