.. http:delete:: /(string:wyclubToken)/rendezVous/(string:resourceType)/timeWindow/(string:id)
  :noindex:

  :synopsis:
    remove a time window from a resource type

  :Version follow-up:

    * .. versionadded:: R3S1

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter string resourceType: *(mandatory)* – A resource type : a value within [epg, software, lineup]
  :parameter string id: *(mandatory)* – the ID of the time window to delete

  **- remove a time window from a resource type**:

    DELETE /softwareupgrade12345678912345601/rendezVous/software/timeWindow/123 HTTP/1.1
    Accept: application/json
    Content-Type: application/json
    
    {}

  :resjson number code: 
  :resjson string content: 
  :resjson object data: 

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 404: Not Found

    + *code*:  702: This type of resource does not exists.

  **- a valid deleted time window response**:

    HTTP/1.1 200 OK
    Date: Wed, 08 Oct 2014 12:14:20 GMT
    Content-Type: application/json; charset=utf-8
    
    {
     code: 0
     content: "Success"
     data: {}
    }

