.. http:post:: /(string:wyclubToken)/rendezVous/(string:resourceType)/timeWindow
  :noindex:

  :synopsis:
    Add a time window to a resource type

  :Version follow-up:

    * .. versionadded:: R3S1

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter string resourceType: *(mandatory)* – A resource type : a value within [epg, software, lineup]

  :reqjson int hMin: *(mandatory)* – The minimal hour of the time window
  :reqjson int hMax: *(mandatory)* – The maximal hour of the time window

  **- Add a new time window to a lineup**:

    POST /softwareupgrade12345678912345601/rendezVous/software/timeWindow HTTP/1.1
    Accept: application/json
    Content-Type: application/json
    
    {
     "hMin":8,
     "hMax":10
    }

  :resjson object data: 
  :resjson object data.hMax: 
  :resjson object data.hMin: 
  :resjson object data.resourceType: accordingly to request.params.resourceType
  :resjson object data._id: 

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 404: Not Found

    + *code*:  702: This type of resource does not exists.

  **- a valid time window**:

    HTTP/1.1 200 OK
    Date: Wed, 08 Oct 2014 12:14:20 GMT
    Content-Type: application/json; charset=utf-8
    
    {
     code: 0
     content: "Success"
     data: {
       __v: 0
       "hMin":8,
       "hMax":10,
       resourceType: "lineup"
       _id: "542e570c09b2419b6f35244a"
     }
    }

