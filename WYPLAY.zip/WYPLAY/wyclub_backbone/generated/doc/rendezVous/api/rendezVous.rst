**********
rendezVous
**********

getResource
===========
.. include:: rendezVous/getResource.rst
