.. http:get:: /(string:wyclubToken)/resource/(string:resourceType)
  :noindex:

  :synopsis:
    Get a resource location and its associated next rendez-vous.

  :Version follow-up:

    * .. versionadded:: 0.1

  :reqheader If-None-Match: The previous resource ETag.

  :parameter string wyclubToken: *(mandatory)* – The WyClub token.
  :parameter string resourceType: *(mandatory)* – The resource type. Allowed values: "``epg``", "``iapps``", ``lineup``", , "``software``".

  :resheader Date: Server side response generation date and time.
  :resheader Expires: Resource expiry, next Rendez-Vous date and time.
  :resheader X-Next-RendezVous: Resource expiry, next Rendez-Vous in SECONDS from "now".
  :resheader ETag: The current resource ETag.

  :resjson int code: operation result code 0 indicates a success; any other value, a failure.
  :resjson string content: operation result human readable message (if any).
  :resjson object data: operation result data.
  :resjson int data.nextRendezVous: Resource expiry, next Rendez-Vous in SECONDS from "now".
  :resjson string data.ETag: The current resource ETag.
  :resjson string data.url: The location of the resource, from where it should be downloaded.
  :resjson object data.customData: Resource specific data (see below). Depends of the requested resource.

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 304: Not Modified

  :statuscode 403: Forbidden

    + *code*:  4: Your session is not valid.

  :statuscode 404: Not Found

    + *code*:  700: A resource profile was found but nothing seems to be linked to that profile in database.
    + *code*:  701: Your session has no tag concerning this resource.
    + *code*:  702: This type of resource does not exist.
    + *code*:  800: No resource found.

  :statuscode 503: Not Available

    + *code*:  9: A module is needed to perform that but it is missing.

  **- Response example when there is NOT a new available version of the resource**:

    .. sourcecode:: http
    
     HTTP/1.1 304 Not Modified
     Date: Wed, 08 Oct 2014 12:00:00 GMT
     Expires: Thu, 09 Oct 2014 12:00:00 GMT
     Content-Type: application/json; charset=utf-8
     ETag: ebcae1c95f2322cc71b510d624cdc8b6
     X-Next-RendezVous: 86400

.. http:get:: /(string:wyclubToken)/resource/lineup
  :noindex:

  :synopsis:
    Get a lineup location and its associated next rendez-vous.

  :Version follow-up:

    * .. versionadded:: 0.5

  :reqheader If-None-Match: The previous resource ETag.

  :parameter string wyclubToken: *(mandatory)* – The WyClub Token.

  :query string bouquetId: *(mandatory)* – The requested lineup bouquet ID.
  :query string smartcardSN: *(mandatory)* – The smartcard serial number currently in use.

  **- Request example, for the bouquet ID 5 and the smartcard SN 9876543210, without previous ETag**:

    .. sourcecode:: http
    
     GET /123abc/resource/lineup?bouquetId=5&smartcardSN=9876543210 HTTP/1.1
     Accept: application/json
     Content-Type: application/json

  :resheader Date: Server side response generation date and time.
  :resheader Expires: Resource expiry, next Rendez-Vous date and time.
  :resheader X-Next-RendezVous: Resource expiry, next Rendez-Vous in SECONDS from "now".
  :resheader ETag: The current resource ETag.

  :resjson int code: operation result code 0 indicates a success; any other value, a failure.
  :resjson string content: operation result human readable message (if any).
  :resjson object data: operation result data.
  :resjson int data.nextRendezVous: Resource expiry, next Rendez-Vous in SECONDS from "now".
  :resjson string data.ETag: The current resource ETag.
  :resjson string data.url: The location of the resource, from where it should be downloaded.
  :resjson object data.customData: Resource specific data.
  :resjson string data.customData.resourceName: The human readable name of the resource.
  :resjson string data.customData.resourceType: The type of the resource, here it is "``lineup``".
  :resjson string data.customData.resourceVersion: The human readable version of the delivered resource.

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

    + *code*:  4: Your session is not valid.
    + *code*:  704: A bouquetId is needed to get your lineup.

  :statuscode 404: Not Found

    + *code*:  700: A resource profile was found but nothing seems to be linked to that profile in database.
    + *code*:  701: Your session have no tag concerning this resource.
    + *code*:  702: This type of resource does not exists.
    + *code*:  800: No resource found.

  :statuscode 503: Not Available

    + *code*:  9: A module is needed to perform that and it is missing.

  **- Response example when a new version is available**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Date: Wed, 08 Oct 2014 12:00:00 GMT
     Expires: Thu, 09 Oct 2014 12:00:00 GMT
     Content-Type: application/json; charset=utf-8
     ETag: ebcae1c95f2322cc71b510d624cdc8b6
     X-Next-RendezVous: 86400
    
     {
       "code": 0,
       "content": "Success",
       "data": {
         "nextRendezVous": 86400,
         "ETag": "ebcae1c95f2322cc71b510d624cdc8b6",
         "url": "http://somewhere.else.com/resource/lineup_5",
         "customData": {
           "resourceName": "lineupB5",
           "resourceType": "lineup",
           "resourceVersion": "1.0.1"
         }
       }
     }

.. http:get:: /(string:wyclubToken)/resource/iapps
  :noindex:

  :synopsis:
    Get an iApps catalog location and its associated next rendez-vous.

  :Version follow-up:

    * .. versionadded:: 0.5

  :reqheader If-None-Match: The previous resource ETag.

  :parameter string wyclubToken: *(mandatory)* – The WyClub Token.

  :query string bouquetId: *(mandatory)* – The requested bouquet ID iApps catalog.

  **- Request example, for the bouquet ID 5, without previous ETag**:

    .. sourcecode:: http
    
     GET /123abc/resource/iapps?bouquetId=5 HTTP/1.1
     Accept: application/json
     Content-Type: application/json

  :resheader Date: Server side response generation date and time.
  :resheader Expires: Resource expiry, next Rendez-Vous date and time.
  :resheader X-Next-RendezVous: Resource expiry, next Rendez-Vous in SECONDS from "now".
  :resheader ETag: The current resource ETag.

  :resjson int code: operation result code 0 indicates a success; any other value, a failure.
  :resjson string content: operation result human readable message (if any).
  :resjson object data: operation result data.
  :resjson int data.nextRendezVous: Resource expiry, next Rendez-Vous in SECONDS from "now".
  :resjson string data.ETag: The current resource ETag.
  :resjson string data.url: The location of the resource, from where it should be downloaded.
  :resjson object data.customData: Resource specific data.
  :resjson string data.customData.resourceName: The human readable name of the resource.
  :resjson string data.customData.resourceType: The type of the resource, here it is "``iapps``".
  :resjson string data.customData.resourceVersion: The human readable version of the delivered resource.

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

    + *code*:  4: Your session is not valid.
    + *code*:  704: A bouquetId is needed to get the iApps catalog.

  :statuscode 404: Not Found

    + *code*:  700: A resource profile was found but nothing seems to be linked to that profile in database.
    + *code*:  701: Your session have no tag concerning this resource.
    + *code*:  702: This type of resource does not exists.
    + *code*:  800: No resource found.

  :statuscode 503: Not Available

    + *code*:  9: A module is needed to perform that and it is missing.

  **- Response example when a new version is available**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Date: Wed, 08 Oct 2014 12:00:00 GMT
     Expires: Thu, 09 Oct 2014 12:00:00 GMT
     Content-Type: application/json; charset=utf-8
     ETag: ebcae1c95f2322cc71b510d624cdc8b6
     X-Next-RendezVous: 86400
    
     {
       "code": 0,
       "content": "Success",
       "data": {
         "nextRendezVous": 86400,
         "ETag": "ebcae1c95f2322cc71b510d624cdc8b6",
         "url": "http://somewhere.else.com/resource/iApps_5",
         "customData": {
           "resourceName": "iAppsB5",
           "resourceType": "iapps",
           "resourceVersion": "1.0.1"
         }
       }
     }

.. http:get:: /(string:wyclubToken)/resource/epg
  :noindex:

  :synopsis:
    Get an EPG location and its associated next rendez-vous.

  :Version follow-up:

    * .. versionadded:: 0.5

  :reqheader If-None-Match: The previous resource ETag.

  :parameter string wyclubToken: *(mandatory)* – The WyClub Token.

  **- Request example, with a previous version ETag available**:

    .. sourcecode:: http
    
     GET /123abc/resource/epg HTTP/1.1
     Accept: application/json
     Content-Type: application/json
     If-None-Match: e6e8ea7465f12e4d3b5a067a4c4dc698436b3478

  :resheader Date: Server side response generation date and time.
  :resheader Expires: Resource expiry, next Rendez-Vous date and time.
  :resheader X-Next-RendezVous: Resource expiry, next Rendez-Vous in SECONDS from "now".
  :resheader ETag: The current resource ETag.

  :resjson int code: operation result code 0 indicates a success; any other value, a failure.
  :resjson string content: operation result human readable message (if any).
  :resjson object data: operation result data.
  :resjson int data.nextRendezVous: Resource expiry, next Rendez-Vous in SECONDS from "now".
  :resjson string data.ETag: The current resource ETag.
  :resjson string data.url: The location of the resource, from where it should be downloaded.
  :resjson object data.customData: Resource specific data.
  :resjson string data.customData.resourceName: The human readable name of the resource.
  :resjson string data.customData.resourceType: The type of the resource, here it is "``epg``".
  :resjson string data.customData.resourceVersion: The human readable version of the delivered resource.

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

    + *code*:  4: Your session is not valid.

  :statuscode 404: Not Found

    + *code*:  700: A resource profile was found but nothing seems to be linked to that profile in database.
    + *code*:  701: Your session have no tag concerning this resource.
    + *code*:  702: This type of resource does not exists.
    + *code*:  800: No resource found.

  :statuscode 503: Not Available

    + *code*:  9: A module is needed to perform that and it is missing.

  **- Response example when a new version is available**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Date: Wed, 08 Oct 2014 12:00:00 GMT
     Expires: Thu, 09 Oct 2014 12:00:00 GMT
     Content-Type: application/json; charset=utf-8
     ETag: ebcae1c95f2322cc71b510d624cdc8b6
     X-Next-RendezVous: 86400
    
     {
       "code": 0,
       "content": "Success",
       "data": {
         "nextRendezVous": 86400,
         "ETag": "ebcae1c95f2322cc71b510d624cdc8b6",
         "url": "http://somewhere.else.com/resource/epg_20141009",
         "customData": {
           "resourceName": "epg_20141009",
           "resourceType": "epg",
           "resourceVersion": "1.0.1",
         }
       }
     }

.. http:get:: /(string:wyclubToken)/resource/software
  :noindex:

  :synopsis:
    Get a software update location and its associated next rendez-vous.

  :Version follow-up:

    * .. versionadded:: 0.5

  :reqheader If-None-Match: The previous resource ETag.

  :parameter string wyclubToken: *(mandatory)* – The WyClub Token.

  **- Request example, with a previous version ETag available**:

    .. sourcecode:: http
    
     GET /123abc/resource/software HTTP/1.1
     Accept: application/json
     Content-Type: application/json
     If-None-Match: e6e8ea7465f12e4d3b5a067a4c4dc698436b3478

  :resheader Date: Server side response generation date and time.
  :resheader Expires: Resource expiry, next Rendez-Vous date and time.
  :resheader X-Next-RendezVous: Resource expiry, next Rendez-Vous in SECONDS from "now".
  :resheader ETag: The current resource ETag.

  :resjson int code: operation result code 0 indicates a success; any other value, a failure.
  :resjson string content: operation result human readable message (if any).
  :resjson object data: operation result data.
  :resjson int data.nextRendezVous: Resource expiry, next Rendez-Vous in SECONDS from "now".
  :resjson string data.ETag: The current resource ETag.
  :resjson string data.url: The location of the resource, from where it should be downloaded.
  :resjson object data.customData: Resource specific data.
  :resjson string data.customData.resourceName: The human readable name of the resource.
  :resjson string data.customData.resourceType: The type of the resource, here it is "``software``"
  :resjson string data.customData.resourceVersion: The version of the delivered resource.
  :resjson boolean data.customData.mandatory: Tells if this update is mandatory or optionnal.
  :resjson boolean data.customData.forced: Tells if this update is forced or not.
  :resjson string data.customData.installationType: Tells when this update should be performed. Allowed values: immediately after the download: "``immediate``", upon next power-on: "``poweron``", when entering in stand-by mode: "``standby``".

  :statuscode 200: Success

    + *code*:  0: Success

  :statuscode 403: Forbidden

    + *code*:  4: Your session is not valid.

  :statuscode 404: Not Found

    + *code*:  700: A resource profile was found but nothing seems to be linked to that profile in database.
    + *code*:  701: Your session have no tag concerning this resource.
    + *code*:  702: This type of resource does not exists.
    + *code*:  800: No resource found.

  :statuscode 503: Not Available

    + *code*:  9: A module is needed to perform that and it's missing.

  **- Response example when a new version is available**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Date: Wed, 08 Oct 2014 12:00:00 GMT
     Expires: Thu, 09 Oct 2014 12:00:00 GMT
     Content-Type: application/json; charset=utf-8
     ETag: ebcae1c95f2322cc71b510d624cdc8b6
     X-Next-RendezVous: 86400
    
     {
       "code": 0,
       "content": "Success",
       "data": {
         "nextRendezVous": 86400,
         "ETag": "ebcae1c95f2322cc71b510d624cdc8b6",
         "url": "http://somewhere.else.com/resource/sw_image42",
         "customData": {
           "resourceName": "software_image_42",
           "resourceType": "software",
           "resourceVersion": "1.0.1",
           "mandatory": true,
           "forced": true,
           "installationType: "immediate"
         }
       }
     }

