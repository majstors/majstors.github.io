******************
Rendez-Vous Module
******************

Introduction
============
Rendez-Vous is a module used to provide a "rendez-vous" to the STB.


API Documentation
=================
.. toctree::
   :maxdepth: 1
   :glob:

   api/*
   api/statuscodes/*