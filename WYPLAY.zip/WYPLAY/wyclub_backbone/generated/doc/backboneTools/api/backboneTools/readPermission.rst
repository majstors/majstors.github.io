.. http:get:: /(string:wyclubToken)/permission
  :noindex:

  :synopsis:
    Read permissions needed for all APIs of all modules

  :parameter string wyclubToken: *(mandatory)* – A session ID

