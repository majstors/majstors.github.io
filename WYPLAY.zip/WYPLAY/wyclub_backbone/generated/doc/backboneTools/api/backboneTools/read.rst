.. http:get:: /(string:wyclubToken)/(string:module)/schema
  :noindex:

  :synopsis:
    Read all schemas of a module

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter string module: *(mandatory)* – A module name e.g. epg

