**********
EPG Module
**********

Introduction
============
The EPG module uses a parser to import data from different sources and stores them
in a generic database.
This data can then be read via the module's API.

Data can also be exported using the parser to a specific format.


API Documentation
=================
.. toctree::
   :maxdepth: 1
   :glob:

   api/*
   api/statuscodes/*