.. http:get:: /(string:wyclubToken)/epg/epg
  :noindex:

  :synopsis:
    Read epg with param

  :parameter string wyclubToken: *(mandatory)* – A session ID

  :query number trafficKey: The traffic key
  :query number serviceId: The channel ID
  :query number start: Find all programs starting later than
  :query number stop: Find all programs ending earlier than
  :query number paginationSkip: Number of programs to skip
  :query number paginationLimit: Number of programs to return (a large number may freeze swagger)

