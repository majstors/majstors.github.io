.. http:get:: /(string:wyclubToken)/(string:module)/permission
  :noindex:

  :synopsis:
    Read all permissions

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter string module: *(mandatory)* – A module name e.g. epg

  **- Request example**:

    .. sourcecode:: http
    
     GET /123abc/epg/permission HTTP/1.1
     Accept: application/json
     Content-Type: application/json
     If-None-Match: e6e8ea7465f12e4d3b5a067a4c4dc698436b3478

  :resjson string _id: Permission Id.
  :resjson string type: Permission type.
  :resjson string group: List of permissions.

  :statuscode 200: Success

  **- Response example**:

    .. sourcecode:: http
    
     HTTP/1.1 200 OK
     Vary: Accept
     Content-Type: application/json
    
    {
    "code": 0,
    "content": "Success",
    "data": [
      {
        "_id": "5450c371d25868fb485f7451",
        "type": "read",
        "__v": 0,
        "group": [
          "read"
        ]
      },
      {
        "_id": "5450c371d25868fb485f7452",
        "type": "write",
        "__v": 0,
        "group": [
          "write"
        ]
      }

