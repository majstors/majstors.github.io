.. http:patch:: /(string:wyclubToken)/(string:module)/permission
  :noindex:

  :synopsis:
    Update a permission

  :parameter string wyclubToken: *(mandatory)* – A session ID
  :parameter string module: *(mandatory)* – A module name e.g epg
  :parameter string type: *(mandatory)* – The new type of permission

  :reqjson array group: *(mandatory)* – An array of permission group

