**********
permission
**********

readAll
=======
.. include:: permission/readAll.rst
update
======
.. include:: permission/update.rst
