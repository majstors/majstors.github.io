//
// Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//

'use strict';

var _ = require('lodash');
var fs = require('fs');
var files = {};
var customTypes = {};
var dashRegex = / [-—] /;

exports.handlers = {
  newDoclet: function (e) {
    if (e.doclet.kind === 'typedef') {
      var typeName = e.doclet.name.toLowerCase();
      var optTypeName = 'opt' + typeName;
      customTypes[typeName] = customTypes['array.<' + typeName + '>'] = e.doclet;
      customTypes[optTypeName] = customTypes['array.<' + optTypeName + '>'] = _.cloneDeep(e.doclet);
      for (var j = 0; j < customTypes[optTypeName].properties.length; j++) {
        customTypes[optTypeName].properties[j].optional = true;
      }
    } else if (!_.isEmpty(e.doclet.params)) {
      var models = {};
      var modelsName = [];
      var api = {path: e.doclet.description};

      var parameters = [];
      var bodyParams = {};

      var docletBaseFilename = e.doclet.meta.filename.replace('.js', '');
      var mainModelName = docletBaseFilename + '.' + e.doclet.meta.lineno;

      for (var i = 0; i < e.doclet.params.length; ++i) {
        var dataType = e.doclet.params[i].type.names[0].toLowerCase();
        var name = e.doclet.params[i].name;

        if (customTypes[dataType]) {
          for (var j = 0; j < customTypes[dataType].properties.length; j++) {
            var newIndex = i + j + 1;
            e.doclet.params.splice(newIndex, 0, _.cloneDeep(customTypes[dataType].properties[j]));
            e.doclet.params[newIndex].name = name + '.' + e.doclet.params[newIndex].name;
          }
          dataType = e.doclet.params[i].type.names[0] = (dataType.indexOf('array.') === 0 ? 'array' : 'object');
        }

        // Query param
        if (name.indexOf('request.params.') === 0) {
          var pathParams = {
            paramType: 'path',
            name: name.replace(/request\.params\./, ''),
            description: e.doclet.params[i].description,
            dataType: 'string',
            required: !e.doclet.params[i].optional,
            defaultValue: e.doclet.params[i].defaultvalue
          };
          parameters.push(pathParams);
        }

        // Body param
        if (name.indexOf('request.body.') === 0) {
          if (_.isEmpty(bodyParams)) {
            bodyParams = {
              paramType: 'body',
              name: 'data',
              description: 'JSON data object',
              dataType: mainModelName
            };
            parameters.push(bodyParams);
          }

          var paramTree = name.split('.').slice(2);
          var paramNameInModel = paramTree[paramTree.length - 1];
          if (paramTree.length > 1) {
            var parentModelName = mainModelName + '.' + paramTree.slice(0, -1).join('.');
          } else {
            var parentModelName = mainModelName;
          }
          if (!models[parentModelName]) {
            models[parentModelName] = {
              id: parentModelName,
              properties: {}
            };
            modelsName.push(parentModelName);
          }

          if (dataType === "object" || dataType === "array") {
            // Object param
            models[parentModelName].properties[paramNameInModel] = {
              "type": dataType,
              "required": !e.doclet.params[i].optional,
              "description": e.doclet.params[i].description,
              "items": {
                "$ref": parentModelName + "." + paramNameInModel
              }
            };
          } else {
            // Non object param
            models[parentModelName].properties[paramNameInModel] = {
              type: dataType,
              required: !e.doclet.params[i].optional,
              description: e.doclet.params[i].description,
              defaultValue: e.doclet.params[i].defaultvalue
            };
          }
        }

        if (name.indexOf('request.query.') === 0) {
          var queryParams = {
            paramType: 'query',
            name: name.replace(/request\.query\./, ''),
            description: e.doclet.params[i].description,
            dataType: e.doclet.params[i].type.names[0],
            required: !e.doclet.params[i].optional,
            defaultValue: e.doclet.params[i].defaultvalue
          };
          parameters.push(queryParams);
        }

        if (name.indexOf('request.header.') === 0) {
          var headerParams = {
            paramType: 'header',
            name: name.replace(/request\.header\./, ''),
            description: e.doclet.params[i].description,
            dataType: e.doclet.params[i].type.names[0],
            required: !e.doclet.params[i].optional,
            defaultValue: e.doclet.params[i].defaultvalue
          };
          parameters.push(headerParams);
        }
      }

      var method = '';
      var bma = undefined;
      if (e.doclet.tags[0].title === 'bma') {
        method = e.doclet.tags[1].value;
        bma = e.doclet.tags[0].value;
      } else {
        method = e.doclet.tags[0].value;
      }
      api.operations = [
        {
          method: method,
          nickname: e.doclet.name,
          summary: e.doclet.summary,
          parameters: parameters
        }
      ];

      var summaryDetails = e.doclet.summary.split(dashRegex);
      var apiDetails = summaryDetails[0];
      var controller = apiDetails.split('.')[0];
      var fileId = bma + '.' + controller;
      if (_.isEmpty(files[fileId])) {
        files[fileId] = {};
        files[fileId]['file'] = controller + '.js'
        files[fileId]['ressourcePath'] = controller;
        files[fileId]['bma'] = bma;
        files[fileId]['apis'] = [];
        files[fileId]['apis'].push(api);
      } else {
        files[fileId]['apis'].push(api);
      }

      for (var i = 0; i < modelsName.length; ++i) {
        var nameParam = modelsName[i];
        if (_.isEmpty(files[fileId]['models'])) {
          files[fileId]['models'] = {};
        }
        files[fileId]['models'][nameParam] = models[nameParam];
      }
    }
  },
  parseComplete: function () {
    for (var fileId in files) {
      if (files.hasOwnProperty(fileId)) {

        var moduleDir = '';

        if (files[fileId].bma !== undefined) {
          moduleDir = 'generated/swagger/docs/' + files[fileId].bma.charAt(0).toLowerCase() + files[fileId].bma.slice(1);
        } else {
          moduleDir = 'generated/swagger/docs';
        }

        if (!fs.existsSync(moduleDir)) {
          fs.mkdirSync(moduleDir);
        }
        fs.writeFileSync(moduleDir + '/' + files[fileId].file + 'on', JSON.stringify(files[fileId], null, 2));
        console.log('Writting generated/swagger/docs/' + moduleDir + '/' + fileId + 'on');
      }
    }
    console.log('Done');
  }
};
