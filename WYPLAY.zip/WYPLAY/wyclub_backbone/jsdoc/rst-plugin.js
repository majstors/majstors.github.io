//
// Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//

// Plugin used to generate RST documentation form JSDoc on controllers (sphinx rst syntax: http://sphinx-doc.org/markup/para.html, http://pythonhosted.org/sphinxcontrib-httpdomain/)
// JSDoc is used to generate RST documentation, swagger files and testapp libs. Some tags are used by one generator only, so don't remove any tags

// Structure of JSDoc to put on each API:
/**
 * @bma bmaName
 * @method controllerName - methodName (no space in methodName)
 * @desc /{param1}/bmaName/route.json
 * @httpmethod POST
 * @summary controllerName.methodName (no space in methodName) - Description of the API (you can use...
 * ... several lines)
 * @since X.Y.Z (tag that indicate when the API has been added)
 * @update X.Y.Z - Short description (set a new update tag each time that version tag is updated)
 * @update X.Y.Z - Short description (set a new update tag each time that version tag is updated)
 * @deprecated X.Y.Z - Optional description (tag to set only if API is deprecated)
 * i.e. on @since/@update/@deprecated tags, version must be X.Y.Z format (no 0.1, always 0.1.0 or 0.1.1...)
 *
 * @param {string} request.header.header1 - A request header
 * @param {string} request.params.param1 - A request parameter in the url
 * @param {string} request.query.param1 - A request parameter in the query
 * @param {string} request.body.param1 - A request parameter in the body (if body is JSON)
 * @param {string} request.body - Request body content (if body is not JSON but directly a string)
 * @param {string} [request.query.param2] - A request parameter in the query that is optional
 * @param {string} [request.query.param3=default value] - A request parameter in the query that is optional and have "default value" as default value
 * i.e. if parameter name is wrapped by [], it is optional, else it is mandatory
 *
 * @example {request} - Title of the request example (one line)
 * Content of the example (you can use several lines)
 * For Json request example, write that is below (space and line break are important, respect it).
 * .. sourcecode:: http
 *
 *   POST /pathUrl HTTP/1.1
 *   Accept: application/json, text/javascript
 *   Content-Type: application/json
 *
 *     {
 *       "jsonProp":"jsonValue"
 *     }
 *
 * @param {string} response.body.param1 - A response parameter in the body
 * @param {string} response.body - Response body content (if body is not JSON but directly a string)
 * i.e. not need to wrap parameter name with [], it's a response
 *
 * @httpcode httpCode(int)  Description of the code
 * e.g.
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 *
 * @errorcode {httpCode(int)} errorCode(int) Description of the cod
 * e.g.
 * @errorcode {200} 0 Success (this errorCode is returned with a 200 header)
 * @errorcode {403} 10 Duplicate entry (this errorCode is returned with a 403 header)

 * @example {response} - Title of the response example (one line)
 * Content of the example (you can use several lines)
 * For Json response example, write that is below (space and line break are important, respect it).
 * .. sourcecode:: http
 *
 *   HTTP/1.1 200 OK
 *   Vary: Accept
 *   Content-Type: application/json
 *
 *     {
 *       "code": 0,
 *       "content": "success",
 *       "data": {
 *         "jsonProp":"jsonValue"
 *       }
 *     }
 */

// To define JSDoc type (used to describe an object that is used on several API request/response, add:
/**
 * @typedef {Object} typeName
 * @property {string} customTypeParam1 - Parameter one
 * @property {string} [customTypeParam2] - Parameter two that is optional
 */
// ... and on API doc, use {typeName}:
/**
 * ...
 * @param {typeName} request.body.param1 - Request body parameter that is an object typeName
 * i.e. is like:
 * @param {string} request.body.param1.customTypeParam1 - Parameter one
 * @param {string} [request.body.param1.customTypeParam2] - Parameter two that is optional
 */
//... and to add more flexibility, when a custom type is defined, a second type is defined automatically. It is prefixed by "opt" and all proerpeties are optionals:
/**
 * @param {optTypeName} request.body.param1 - Request body parameter that is an object typeName and where all properties of the object are optionals
 * i.e. is like:
 * @param {string} [request.body.param1.customTypeParam1] - Parameter one that is optional (mandatory on type definition but call with {optTypeName} so all properties are optionals)
 * @param {string} [request.body.param1.customTypeParam2] - Parameter two that is optional
 * ...
 */


'use strict';

var _ = require('lodash');
var fs = require('fs');
var path = require('path');
var files = {};
var controllers = {};
var dashRegex = / [-—] /;
var customTypes = {};

String.prototype.repeat = function (num) {
  return new Array(num + 1).join(this);
}

// Return formatted tags
var formatTags = function (doclet) {
  var formattedTags = {};

  if (!doclet.tags) {
    return formattedTags;
  }

  doclet.tags.forEach(function (tag) {
    // Tag bma or httpmethod
    if (tag.title === 'bma' || tag.title === 'httpmethod') {
      formattedTags[tag.title] = tag.value;
    }

    // Tag about http code
    if (tag.title === 'httpcode') {
      if (!formattedTags[tag.title]) {
        formattedTags[tag.title] = {};
      }

      var codeDetails = /^([0-9]+) (.+)$/.exec(tag.value);
      if (!codeDetails) {
        return;
      }

      var httpCode = codeDetails[1];
      var text = codeDetails[2];
      formattedTags[tag.title][httpCode] = text;
    }

    // Tag about error codes
    if (tag.title === 'errorcode') {
      if (!formattedTags[tag.title]) {
        formattedTags[tag.title] = {};
      }

      var codeDetails = /^\{([^}]+)\} ([0-9]+) (.+)$/.exec(tag.value);
      if (codeDetails) {
        var httpCode = codeDetails[1];
        var errorCode = codeDetails[2];
        var text = codeDetails[3];
        if (!formattedTags[tag.title][httpCode]) {
          formattedTags[tag.title][httpCode] = {};
        }
        formattedTags[tag.title][httpCode][errorCode] = text;
      }
    }

    // Tag about http code
    if (tag.title === 'update') {
      if (!formattedTags[tag.title]) {
        formattedTags[tag.title] = {};
      }

      var version = tag.value.split(dashRegex)[0];
      var description = tag.value.split(dashRegex)[1]
      formattedTags[tag.title][version] = description;
    }
  });

  return formattedTags;
};

// Return formatted examples
var formatExamples = function (doclet) {
  var formattedExamples = {
    request: {},
    response: {}
  };

  if (!doclet.examples) {
    return formattedExamples;
  }

  doclet.examples.forEach(function (example) {
    var exempleDetails = /^\{([^}]+)\} ([^\n]+)\n([\s\S]+)$/.exec(example);
    if (exempleDetails) {
      var type = exempleDetails[1];
      var name = exempleDetails[2];
      var text = exempleDetails[3];
      formattedExamples[type][name] = text;
    }
  });

  return formattedExamples;
};

// Add parameter to a rst
var getRstParameters = function (parameters, type) {
  var content = '';
  var jsonPrefix;
  var getReqDescr = function (param, noType) {
    return (noType ? '' : param.dataType + ' ') + param.name + ': ' +
      (param.required ? '*(mandatory)* – ' : '') +
      (param.defaultvalue ? '*(default: ' + param.defaultvalue + ')* – ' : '') +
      (param.description ? param.description : '') +
      '\n';
  };
  var getResDescr = function (param, noType) {
    return (noType ? '' : param.dataType + ' ') + param.name + ': ' +
      (param.description ? param.description : '') +
      '\n';
  }

  jsonPrefix = (type === 'request' ? 'reqheader' : 'resheader');
  parameters.header.forEach(function (param) {
    var descr = (type === 'request' ? getReqDescr(param, true) : getResDescr(param, true));
    content += '  :' + jsonPrefix + ' ' + descr;
  });
  if (parameters.header.length) {
    content += '\n';
  }

  parameters.params.forEach(function (param) {
    content += '  :parameter ' + getReqDescr(param);
  });
  if (parameters.params.length) {
    content += '\n';
  }

  parameters.query.forEach(function (param) {
    content += '  :query ' + getReqDescr(param);
  });
  if (parameters.query.length) {
    content += '\n';
  }

  if (_.isArray(parameters.body)) {
    jsonPrefix = (type === 'request' ? 'reqjson' : 'resjson');
    parameters.body.forEach(function (param) {
      var descr = (type === 'request' ? getReqDescr(param) : getResDescr(param));
      content += '  :' + jsonPrefix + ' ' + descr;
    });
    if (parameters.body.length) {
      content += '\n';
    }
  } else {
    jsonPrefix = (type === 'request' ? 'Request content' : 'Response content');
    content += '  :' + jsonPrefix + ': (' + parameters.body.dataType + ') – ' + parameters.body.description + '\n\n';
  }

  return content;
};

exports.handlers = {
  newDoclet: function (e) {
    if (env.opts.query.controller) {
      if (e.doclet.kind === 'typedef') {
        var typeName = e.doclet.name.toLowerCase();
        var optTypeName = 'opt' + typeName;
        customTypes[typeName] = customTypes['array.<' + typeName + '>'] = e.doclet;
        customTypes[optTypeName] = customTypes['array.<' + optTypeName + '>'] = _.cloneDeep(e.doclet);
        for (var j = 0; j < customTypes[optTypeName].properties.length; j++) {
          customTypes[optTypeName].properties[j].optional = true;
        }
      } else if (!_.isEmpty(e.doclet.params)) {
        var call = {};
        var tags = formatTags(e.doclet);
        var parameters = {
          request: {
            header: [],
            query: [],
            params: [],
            body: []
          },
          response: {
            header: [],
            query: [],
            params: [],
            body: []
          }
        };

        // Get params
        for (var i = 0; i < e.doclet.params.length; ++i) {
          var param = e.doclet.params[i];
          var paramNameArray = param.name.split('.');
          var paramGroup = paramNameArray[0];
          var paramType = paramNameArray[1];
          var paramName = paramNameArray.slice(2).join('.');
          var dataType = param.type.names[0].toLowerCase();

          if (customTypes[dataType]) {
            for (var j = 0; j < customTypes[dataType].properties.length; j++) {
              var newIndex = i + j + 1;
              e.doclet.params.splice(newIndex, 0, _.cloneDeep(customTypes[dataType].properties[j]));
              e.doclet.params[newIndex].name = param.name + '.' + e.doclet.params[newIndex].name;
            }
            dataType = e.doclet.params[i].type.names[0] = (dataType.indexOf('array.') === 0 ? 'array' : 'object');
          }

          if (paramNameArray.length >= 3) {
            parameters[paramGroup][paramType].push({
              name: paramName,
              description: param.description,
              dataType: dataType,
              required: !param.optional,
              defaultvalue: param.defaultvalue
            });
          } else if (paramNameArray.length === 2 && dataType !== 'object') {
            // For case request.body/response.body is a string and not a JSON object
            parameters[paramGroup][paramType] = {
              name: paramName,
              description: param.description,
              dataType: dataType,
              required: !param.optional,
              defaultvalue: param.defaultvalue
            }
          }
        }

        var summaryDetails = e.doclet.summary.split(dashRegex);
        var api = summaryDetails[0];
        call.path = e.doclet.description;
        call.operation = {
          since: e.doclet.since,
          update: tags.update,
          httpmethod: tags.httpmethod,
          nickname: e.doclet.name,
          summary: summaryDetails.slice(1).join(dashRegex),
          parameters: parameters,
          tags: tags,
          examples: formatExamples(e.doclet)
        };

        if (e.doclet.deprecated) {
          call.operation.deprecated = {
            version: e.doclet.deprecated.split(dashRegex)[0],
            description: e.doclet.deprecated.split(dashRegex)[1]
          }
        }

        if (_.isEmpty(files[api])) {
          files[api] = {};
          files[api].calls = [];
          files[api].bma = tags.bma;
          files[api].controller = api.split('.')[0];
          files[api].method = api.split('.')[1];
        }
        files[api].calls.push(call);

        var apiParams = files[api];
        var controllerName = apiParams.bma + '.' + apiParams.controller;
        if (_.isEmpty(controllers[controllerName])) {
          controllers[controllerName] = {};
          controllers[controllerName].bma = tags.bma;
          controllers[controllerName].controller = apiParams.controller;
          controllers[controllerName].methods = {};
        }
        controllers[controllerName].methods[apiParams.method] = true;
      }
    } else if (env.opts.query.statuscode === true) {
      if (e.doclet.meta.code.type === 'ObjectExpression' && e.doclet.meta.code.name !== 'module.exports') {
        files[e.doclet.meta.code.name] = JSON.parse(e.doclet.meta.code.value);
      }
    }
  },
  parseComplete: function () {
    if (env.opts.query.controller === true) {
      // Generate doc for each API
      for (var api in files) {
        var content = '';
        var apiParams = files[api];
        if (files.hasOwnProperty(api)) {
          for (var i in apiParams.calls) {
            var call = apiParams.calls[i];
            var operation = call.operation;

            // Request
            var path = call.path;
            operation.parameters.request.params.forEach(function (param) {
              path = path.replace('{' + param.name + '}', '(' + param.dataType + ':' + param.name + ')');
            });

            // Route
            content += '.. http:' + operation.httpmethod.toLowerCase() + ':: ' + path + '\n';
            content += '  :noindex:\n\n';

            // Summary
            content += '  :synopsis:\n'
            content += '    ' + operation.summary.replace(/\n/g, '\n    ') + '\n\n';

            // Versions
            if (operation.since || operation.update) {
              content += '  :Version follow-up:\n\n';
            }
            if (operation.since) {
              content += '    * .. versionadded:: ' + operation.since + '\n\n';
            }
            if (operation.update) {
              for (var version in operation.update) {
                content += '    * .. versionchanged:: ' + version + '\n';
                if (operation.update[version]) {
                  content += '         ' + operation.update[version] + '\n';
                }
                content += '\n';
              }
            }
            if (operation.deprecated) {
              content += '    * .. deprecated:: ' + operation.deprecated.version + '\n';
              if (operation.deprecated.description) {
                content += '         ' + operation.deprecated.description + '\n';
              }
              content += '\n';
            }

            // Request parameters
            content += getRstParameters(operation.parameters.request, 'request');

            // Request examples
            for (var exampleName in operation.examples.request) {
              content += '  **' + exampleName + '**:\n\n';
              content += '    ' + operation.examples.request[exampleName].replace(/\n/g, '\n    ') + '\n\n';
            }

            // Response parameters
            content += getRstParameters(operation.parameters.response, 'response');

            // HTTP and error codes
            if (operation.tags.httpcode) {
              for (var httpCode in operation.tags.httpcode) {
                content += '  :statuscode ' + httpCode + ': ' + operation.tags.httpcode[httpCode] + '\n\n';
                if (operation.tags.errorcode && operation.tags.errorcode[httpCode]) {
                  for (var errorCode in operation.tags.errorcode[httpCode]) {
                    content += '    + *code*:  ' + errorCode + ': ' + operation.tags.errorcode[httpCode][errorCode] + '\n';
                  }
                  content += '\n';
                }
              }
            }

            // Response examples
            for (var exampleName in operation.examples.response) {
              content += '  **' + exampleName + '**:\n\n';
              content += '    ' + operation.examples.response[exampleName].replace(/\n/g, '\n    ') + '\n\n';
            }
          }

          var apiDir = 'generated/doc/' + apiParams.bma;
          if (!fs.existsSync(apiDir)) {
            fs.mkdirSync(apiDir);
          }
          apiDir += '/api';
          if (!fs.existsSync(apiDir)) {
            fs.mkdirSync(apiDir);
          }
          apiDir += '/' + apiParams.controller;
          if (!fs.existsSync(apiDir)) {
            fs.mkdirSync(apiDir);
          }
          fs.writeFileSync(apiDir + '/' + apiParams.method + '.rst', content);
        }
      }

      // Generate doc for each controller (with PI includes)
      for (var controller in controllers) {
        var controllerParams = controllers[controller];
        var content = '';
        content += '*'.repeat(controllerParams.controller.length) + '\n';
        content += controllerParams.controller + '\n';
        content += '*'.repeat(controllerParams.controller.length) + '\n\n';
        for (var method in controllerParams.methods) {
          content += method + '\n';
          content += '='.repeat(method.length) + '\n';
          content += '.. include:: ' + controllerParams.controller + '/' + method + '.rst\n';
        }
        var apiDir = 'generated/doc/' + controllerParams.bma + '/api/';
        fs.writeFileSync(apiDir + controllerParams.controller + '.rst', content);
      }
      console.log('Done');
    } else if (env.opts.query.statuscode === true) {

      content = '************';
      content += '\n' + 'Status codes' + '\n';
      content += '************';
      content += '\n\n';

      for (var fileStatusCode in files) {
        var code = files[fileStatusCode].code;
        content += code + '\n';
        for (var k = 0; k < code.toString().length; k++) {
          content += '-';
        }
        content += '\n';
        content += ':Reference:' +
          '\n ' + fileStatusCode + '\n\n';
        content += ':Description:' +
          '\n ' + files[fileStatusCode].content + '\n\n';
      }
      var moduleDir = 'generated/doc/' + env.opts.query.bma;
      if (!fs.existsSync(moduleDir)) {
        fs.mkdirSync(moduleDir);
      }
      moduleDir += '/api';
      if (!fs.existsSync(moduleDir)) {
        fs.mkdirSync(moduleDir);
      }
      moduleDir += '/statuscodes';
      if (!fs.existsSync(moduleDir)) {
        fs.mkdirSync(moduleDir);
      }
      fs.writeFileSync(moduleDir + '/statuscodes.rst', content);
    }
  }
};
