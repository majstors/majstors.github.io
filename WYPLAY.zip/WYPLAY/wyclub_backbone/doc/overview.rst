*******************
Wyclub BMA Backbone
*******************

Introduction
============
The WyClub BMA Backbone is a big container, it can contain all the BMAs of the WyClub or just one.
In the params file, the developper can configure which module he wants and where it is (in folder or in dependence).
This backbone shares several tools to help the BMA developper to go faster.
For example, the server (based on expressjs) is in the backbone.
So, the BMAs have just controllers, models and their database, the backbone does the rest.


Install dependencies
====================
::

  npm install


Install global dependencies
===========================
::

  npm install -g jsdoc


Generate the swagger file
=========================
Requires PHP 5.4, jsDoc::

  ./console.js -s


Generate API documentation in rST format
========================================
Requires jsDoc::

  ./console.js -r


Generate the fixtures
=====================
::

  ./console.js -f


Launch all unit tests
=====================
::

  ./console.js -t


Launch unit test of a module
============================
Assuming current directory is module's root::

  ./console.js -t <module_name>

Where ``<module_name>`` is the module's name, i.e. ``epg`` for ``wyclub_epg``.


Starting the Server
===================
::

  node app.js on port 3010


File lib/extender.js
====================
File used to extend default node or node module objects.

findOneAndSave method on mogoose models
---------------------------------------
Ability to update a document easily with all mogoose middlewares
(like validators) enabled because update method don't use them.
