#!/usr/bin/env node
//
// Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//
/*jshint -W020 */

if (typeof(Container) === 'undefined') {
  global.Container = {};
}
Container.express = require('express')();
Container.http = require('http');
Container.async = require('async');
Container.extender = require(__dirname + '/lib/extender.js');
Container.logger = require(__dirname + '/lib/logger.js');
Container.autoloader = require(__dirname + '/lib/autoloader.js');
Container.tools = require(__dirname + '/lib/tools.js');
Container.parentRepository = require(__dirname + '/lib/repository.js');
Container.mongoDb = require(__dirname + '/lib/mongoDb.js');
Container.redis = require(__dirname + '/lib/redis.js');
Container.parentMongodbQuery = require(__dirname + '/lib/mongodbQuery.js');
Container.parentRedisQuery = require(__dirname + '/lib/redisQuery.js');
Container.httpTools = require(__dirname + '/lib/httpTools.js');
Container.parentController = require(__dirname + '/lib/controller.js');
Container.parentControllerWithDefaultApi = require(__dirname + '/lib/controllerWithDefaultApi.js');
Container.parentMongooseSchemaWithId = require(__dirname + '/lib/mongooseSchemaWithId.js');
Container.parentRoute = require(__dirname + '/lib/route.js');
Container.root = __dirname + '/';
Container.jsonSchemas = require(__dirname + '/config/jsonSchemas.js');

Container.wyclubtools = require('wyclub_tools');

if (!module.parent) {
  require(__dirname + '/config/config.js')();
} else {
  module.exports = require(__dirname + '/config/config.js');
}
