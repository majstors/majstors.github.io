/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expthis.responsesed written
 * permission of Wyplay.
 */

// Load module
var async = require('async');
var Controller = Container.parentController;

var Subscriber = function (params) {
  'use strict';

  // Call parent constructor with container
  Controller.call(this, params);
  // Add wyclubToken to default jsonSchema
  this.addEntryToJsonSchema('subscribers', this.request.body.subscribers, {
    type: 'array',
    items: {
      type: 'object',
      properties: {
        polkaId: {
          type: 'string',
          required: true,
          pattern: /^[0-9]{10}$/
        }
      }
    },
    required: true
  });
};

// Inherited all functions of the parent controller
Subscriber.prototype = Object.create(Controller.prototype);

// key: method, value: permission
Subscriber.prototype.applicationId = 'H87KhkWV6gSz3qam55Sq4J10pe9PV5YP';

/**
 * @bma subscriber
 * @method scms - create
 * @desc /{wyclubToken}/subscriber/scms
 * @httpmethod POST
 * @summary scms.create — Create subscriber throw SCMS API.
 *
 * @param {string} request.params.wyclubToken - Wyclub Token
 * @param {Array} request.body.subscribers - Array of subscribers
 * @param {string} request.body.subscribers.polkaId - Subscriber ID (10 digits)
 * @param {string} request.body.subscribers.accountId - Account ID (20 chars)
 * @param {string} request.body.subscribers.pdaId - PDA ID (30 chars)
 * @param {string} request.body.subscribers.smartcardSN - Serial number of the smartcard (11 chars)
 * @param {string} request.body.subscribers.stbSN - Serial number of the STB (16 chars)
 * @param {string} request.body.subscribers.stbId - ID of the STB (10 chars)
 * @param {string} [request.body.subscribers.stbMACAddress] - MAC address of the STB (AA:AA:AA:AA:AA:AA)
 * @param {boolean} [request.body.subscribers.stbCertificateRevokedFlag=false] - Subscriber certificate is revoked?
 * @param {string} request.body.subscribers.telcoId - Telco ID (16 chars)
 * @param {string} [request.body.subscribers.bouquetId] - Bouquet ID (16 chars)
 * @param {boolean} [request.body.subscribers.bouquetIdFlag=false]
 * @param {string} [request.body.subscribers.telcoFlag=true] - (can be true, false or 'passed')
 * @param {string} request.body.subscribers.skyStatus - (can be 'provisioned' or 'installed')
 * @param {string} request.body.subscribers.telcoStatus - (can be 'provisioned', 'installed' or 'inactive')
 *
 * @example {request} - Request create subscriber with Id 3686914412
 * .. sourcecode:: http
 *
 *   POST /9BvMMXWSOoqzgKbHbC86E1KwAuSxTeN3/subscriber/scms HTTP/1.1
 *   Accept: application/json, text/javascript
 *   Content-Type: application/json
 *
 *     {
 *       "subscribers": [
 *         {
 *           "polkaId": "3686914412",
 *           "accountId": "12345678901234567892",
 *           "pdaId": "789456123078945678901234567890",
 *           "smartcardSN": "64613390956",
 *           "stbSN": "1RTOBERD396WOXWG",
 *           "stbId": "1689454642",
 *           "stbMACAddress": "12:12:12:12:12:12",
 *           "bouquetId": "0JUBYTDI5NXTEE2T",
 *           "telcoId": "BGG1NPBMV1NUD2VL",
 *           "skyStatus": "installed",
 *           "telcoStatus": "provisioned",
 *           "stbCertificateSN": "xxx",
 *           "stbCertificateExpiry": 1420000000,
 *           "stbSoftwareVersion": "1",
 *           "stbBootloader2Version": "2"
 *         }
 *       ]
 *     }
 *
 * @param {integer} response.body.code - code of response
 * @param {integer} response.body.content - Status of response
 * @param {array} response.body.data - array of module result
 * @param {string} response.body.data.polkaId - Subscriber ID
 * @param {object} response.body.data.subscriber - Subscriber object
 * @param {string} response.body.data.subscriber.polkaId - Subscriber ID
 * @param {string} response.body.data.subscriber.accountId - Account ID
 * @param {string} response.body.data.subscriber.pdaId - PDA ID
 * @param {string} response.body.data.subscriber.smartcardSN - Serial number of the STB
 * @param {string} response.body.data.subscriber.bouquetId - Bouquet ID
 * @param {string} response.body.data.subscriber.telcoId - Telco ID
 * @param {string} response.body.data.subscriber.skyStatus -
 * @param {string} response.body.data.subscriber.telcoStatus -
 * @param {string} response.body.data.subscriber.telcoFlag -
 * @param {boolean} response.body.data.subscriber.bouquetIdFlag -
 * @param {array} response.body.data.subscriber.deviceInstances -
 * @param {array} response.body.data.subscriber.profiles -
 * @param {array} response.body.data.subscriber.devices -
 * @param {string} response.body.data.subscriber.devices.uuid -
 * @param {string} response.body.data.subscriber.devices.stbId - Serial number of the STB
 * @param {string} response.body.data.subscriber.devices.stbSN - ID of the STB
 * @param {string} response.body.data.subscriber.devices.stbMACAddress - MAC address of the STB
 * @param {string} response.body.data.subscriber.devices.stbBootloader2Version
 * @param {boolean} response.body.data.subscriber.devices.stbSoftwareVersion
 * @param {string} response.body.data.subscriber.devices.stbCertificateRevokedFlag
 * @param {integer} response.body.data.subscriber.devices.stbCertificateExpiry
 * @param {string} response.body.data.subscriber.devices.stbCertificateSN
 * @param {integer} response.body.data.subscriber.devices.status
 * @param {string} response.body.data.subscriber.devices.label
 * @param {string} response.body.data.subscriber.devices._id
 * @param {string} response.body.data.subscriber._id
 * @param {integer} response.body.data.errorCode - code of error
 * @param {string} response.body.data.errorMessage - Error message
 * @param {object} response.body.data.errorData -
 *
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbidden
 *
 * @errorcode {200} 0 Success
 * @errorcode {403} 5 invalid request parameter
 * @errorcode {403} 999 An unexpected error occured (read body.data.errorMessage in response body for more details)
 *
 *
 * @example {response} - Subscriber create request example
 * .. sourcecode:: http
 *
 *   HTTP/1.1 200 OK
 *   Vary : Accept
 *   Content-Type: application/json
 *
 *     {
 *       "code": 0,
 *       "content": "Success",
 *       "data": [
 *         {
 *           "polkaId": "3686914412",
 *           "subscriber": {
 *             "polkaId": "3686914412",
 *             "accountId": "12345678901234567892",
 *             "pdaId": "789456123078945678901234567890",
 *             "smartcardSN": "64613390956",
 *             "bouquetId": "0JUBYTDI5NXTEE2T",
 *             "telcoId": "BGG1NPBMV1NUD2VL",
 *             "skyStatus": "installed",
 *             "telcoStatus": "provisioned",
 *             "telcoFlag": "true",
 *             "bouquetIdFlag": false,
 *             "deviceInstances": [],
 *             "profiles": [],
 *             "devices": [
 *               {
 *                 "uuid": "1689454642",
 *                 "stbId": "1689454642",
 *                 "stbSN": "1RTOBERD396WOXWG",
 *                 "stbMACAddress": "12:12:12:12:12:12",
 *                 "stbBootloader2Version": "",
 *                 "stbSoftwareVersion": "",
 *                 "stbCertificateRevokedFlag": false,
 *                 "stbCertificateExpiry": 0,
 *                 "stbCertificateSN": "",
 *                 "status": 1,
 *                 "label": "device",
 *                 "_id": "544f6d062940706d1fc48b31"
 *               }
 *             ],
 *             "_id": "544f6d062940706d1fc48b30"
 *           },
 *         "errorCode": 0,
 *         "errorMessage": "",
 *         "errorData": null
 *         }
 *       ]
 *     }
 *
 */
Subscriber.prototype.create = function () {
  'use strict';
  var self = this;

  /* jshint unused:false */
  this.process(function (values) {
    var finalResult = [];
    var finalError = false;

    async.each(values.subscribers, function (object, callback) {
      object = self.formatParams(object);
      // Force empty device if not existing to have mongoose validator activated on device
      if (!object.devices) {
        object.devices = [
          {}
        ];
      }

      var sub = new Container.subscriber.model.subscriber(object);
      sub.save(function (err, result, nb) {
        if (err) {
          if (err.code === 11000) {
            finalResult.push({
              polkaId: object.polkaId,
              subscriber: null,
              errorCode: Container.httpTools.statusCodes.subscriber['DUPLICATE_ENTRY'].code,
              errorMessage: 'Duplicate entry',
              errorData: err
            });
          } else {
            finalResult.push({
              polkaId: object.polkaId,
              subscriber: null,
              errorCode: Container.httpTools.statusCodes.subscriber['POST_ERROR'].code,
              errorMessage: 'Could not create entry: ' + err.toString(),
              errorData: err
            });
          }
          finalError = true;
        } else {
          finalResult.push({
            polkaId: object.polkaId,
            subscriber: result,
            errorCode: 0,
            errorMessage: '',
            errorData: null
          });
        }
        callback();
      });
    }, function (err) {
      if (finalError) {
        self.postProcessError('DEFAULT', finalResult);
      } else {
        self.postProcessSuccess(finalResult);
      }
    });
  });
};


/**
 * @bma subscriber
 * @method scms - update
 * @desc /{wyclubToken}/subscriber/scms
 * @httpmethod PATCH
 * @summary scms.update — Update subscriber throw SCMS API.
 *
 * @param {string} request.params.wyclubToken - Wyclub Token
 * @param {Array} request.body.subscribers Array of subscribers
 * @param {string} request.body.subscribers.polkaId - Subscriber ID (10 digits)
 * @param {string} [request.body.subscribers.accountId] - Account ID (20 chars)
 * @param {string} [request.body.subscribers.pdaId] - PDA ID (30 chars)
 * @param {string} [request.body.subscribers.smartcardSN] - Serial number of the smartcard (11 chars)
 * @param {string} [request.body.subscribers.stbSN] - Serial number of the STB (16 chars)
 * @param {string} [request.body.subscribers.stbId] - ID of the STB (10 chars)
 * @param {string} [request.body.subscribers.stbMACAddress] - MAC address of the STB (AA:AA:AA:AA:AA:AA)
 * @param {boolean} [request.body.subscribers.stbCertificateRevokedFlag] - Subscriber certificate is revoked?
 * @param {string} [request.body.subscribers.telcoId] - Telco ID (16 chars)
 * @param {string} [request.body.subscribers.bouquetId] - Bouquet ID (16 chars)
 * @param {boolean} [request.body.subscribers.bouquetIdFlag]
 * @param {string} [request.body.subscribers.telcoFlag] - (can be true, false or 'passed')
 * @param {string} [request.body.subscribers.skyStatus] - (can be 'provisioned' or 'installed')
 * @param {string} [request.body.subscribers.telcoStatus] - (can be 'provisioned', 'installed' or 'inactive')
 *
 * @example {request} - Subscriber update request example (update telcoStatus provisioned to installed)
 * .. sourcecode:: http
 *
 *   POST /9BvMMXWSOoqzgKbHbC86E1KwAuSxTeN3/subscriber/scms HTTP/1.1
 *   Accept: application/json, text/javascript
 *   Content-Type: application/json
 *
 *     {
 *       "subscribers": [
 *         {
 *           "polkaId": "1284567892",
 *           "accountId": "12345678901234567892",
 *           "telcoStatus": "installed"
 *         }
 *       ]
 *     }
 *
 * @param {integer} response.body.code - code of response
 * @param {integer} response.body.content - Status of response
 * @param {array} response.body.data - array of module result
 * @param {string} response.body.data.polkaId - Subscriber ID
 * @param {object} response.body.data.subscriber - Subscriber object
 * @param {string} response.body.data.subscriber.polkaId - Subscriber ID
 * @param {string} response.body.data.subscriber.accountId - Account ID
 * @param {string} response.body.data.subscriber.pdaId - PDA ID
 * @param {string} response.body.data.subscriber.smartcardSN - Serial number of the STB
 * @param {string} response.body.data.subscriber.bouquetId - Bouquet ID
 * @param {string} response.body.data.subscriber.telcoId - Telco ID
 * @param {string} response.body.data.subscriber.skyStatus
 * @param {string} response.body.data.subscriber.telcoStatus
 * @param {string} response.body.data.subscriber.telcoFlag
 * @param {boolean} response.body.data.subscriber.bouquetIdFlag
 * @param {array} response.body.data.subscriber.deviceInstances
 * @param {array} response.body.data.subscriber.profiles
 * @param {array} response.body.data.subscriber.devices
 * @param {string} response.body.data.subscriber.devices.uuid
 * @param {string} response.body.data.subscriber.devices.stbId - Serial number of the STB
 * @param {string} response.body.data.subscriber.devices.stbSN - ID of the STB
 * @param {string} response.body.data.subscriber.devices.stbMACAddress - MAC address of the STB
 * @param {string} response.body.data.subscriber.devices.stbBootloader2Version
 * @param {boolean} response.body.data.subscriber.devices.stbSoftwareVersion
 * @param {string} response.body.data.subscriber.devices.stbCertificateRevokedFlag
 * @param {integer} response.body.data.subscriber.devices.stbCertificateExpiry
 * @param {string} response.body.data.subscriber.devices.stbCertificateSN
 * @param {integer} response.body.data.subscriber.devices.status
 * @param {string} response.body.data.subscriber.devices.label
 * @param {string} response.body.data.subscriber.devices._id
 * @param {string} response.body.data.subscriber._id
 * @param {integer} response.body.data.errorCode
 * @param {string} response.body.data.errorMessage
 * @param {object} response.body.data.errorData
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbiden
 * @httpcode 503 Service Unavailable
 *
 * @errorcode {200} 0 Success
 * @errorcode {403} 5 Invalid request parameter
 * @errorcode {403} 999 An unexpected error occured (read body.data.errorMessage in response body for more details)
 * @errorcode {503} 2000 stbId, stbSN and stbMACAddress must be updated together. At least one of these fields is missing
 *
 * @example {response} - Subscriber update response example
 * .. sourcecode:: http
 *
 *   HTTP/1.1 200 OK
 *   Vary : Accept
 *   Content-Type: application/json
 *
 *     {
 *       "code": 0,
 *       "content": "Success",
 *       "data": [
 *         {
 *           "polkaId": "1284567892",
 *             "subscriber": {
 *             "_id": "XHPiMFOgAD0KzimPeitfH6WgJVJP6r1b",
 *             "polkaId": "1284567892",
 *             "accountId": "12345678901234567892",
 *             "pdaId": "789456123078945678901234567890",
 *             "smartcardSN": "12345678902",
 *             "telcoId": "7894561594256842",
 *             "skyStatus": "provisioned",
 *              "telcoStatus": "installed",
 *             "telcoFlag": "passed",
 *             "bouquetIdFlag": false,
 *             "deviceInstances": [
 *               {
 *                 "_id": "bvQDB3RKpGxCgxU18r7vI20sDAJPVBTV",
 *                 "deviceId": "gtk7Ca2HAXp5R15ZjcXOHOAZYlJQkL6U",
 *                 "applicationId": "XHPiMdpchfugjthdjitfH6WgJVJP6r62"
 *               }
 *             ],
 *             "profiles": [],
 *             "devices": [
 *               {
 *                 "_id": "GW8i3fdu7v1c1oyExSYmnBL009sLnQkn",
 *                 "uuid": "4561327886",
 *                 "stbSN": "2234567891234534",
 *                 "stbId": "2619259546",
 *                 "stbBootloader2Version": "",
 *                 "stbSoftwareVersion": "",
 *                 "stbCertificateRevokedFlag": false,
 *                 "stbCertificateExpiry": 0,
 *                 "stbCertificateSN": "",
 *                 "status": 1,
 *                 "label": "device_forUpdate"
 *               }
 *             ]
 *           },
 *         "errorCode": 0,
 *         "errorMessage": "",
 *         "errorData": null
 *       }
 *     ]
 *   }
 */
Subscriber.prototype.update = function () {
  'use strict';
  var self = this;

  /* jshint unused:false */
  this.process(function (values) {
      var finalResult = [];
      var finalError = false;

      async.each(values.subscribers, function (object, callback) {
        var formatParams = self.formatParams(object);
        var checkDeviceChanges = 0;
        if (formatParams.devices && formatParams.devices.length) {
          if (formatParams.devices[0].hasOwnProperty('stbId')) {
            checkDeviceChanges++;
          }
          if (formatParams.devices[0].hasOwnProperty('stbSN')) {
            checkDeviceChanges++;
          }
          if (formatParams.devices[0].hasOwnProperty('stbMACAddress')) {
            checkDeviceChanges++;
          }
          if (checkDeviceChanges && checkDeviceChanges !== 3) {
            finalResult.push({
              polkaId: formatParams.polkaId,
              subscriber: null,
              errorCode: Container.httpTools.statusCodes.subscriber['UPDATE_DEVICE_INFO_ERROR'].code,
              errorMessage: Container.httpTools.statusCodes.subscriber['UPDATE_DEVICE_INFO_ERROR'].content,
              errorData: null
            });

            finalError = true;
            return callback();
          }
        }

        Container.subscriber.model.subscriber.findOneAndSave({polkaId: object.polkaId}, formatParams, function (document, data) {
          var device = data.devices
          delete data.devices
          document.set(data);
          if (device) {
            if (document.devices.length) {
              document.devices[0].set(device[0])
            } else {
              document.devices.push(device[0]);
            }
          }
        }, function (err, result, nb) {
          if (err) {
            if (err.code === 'NO_DOCUMENT') {
              finalResult.push({
                polkaId: object.polkaId,
                subscriber: null,
                errorCode: Container.httpTools.statusCodes.subscriber['NOTHING_ERROR'].code,
                errorMessage: 'No entry',
                errorData: err
              });
            } else {
              finalResult.push({
                polkaId: object.polkaId,
                subscriber: null,
                errorCode: Container.httpTools.statusCodes.subscriber['PATCH_ERROR'].code,
                errorMessage: 'Could not update entry: ' + err.toString(),
                errorData: err
              });
            }
            finalError = true;
          } else {
            finalResult.push({
              polkaId: object.polkaId,
              subscriber: result,
              errorCode: 0,
              errorMessage: '',
              errorData: null
            });
          }
          callback();
        });
      }, function (err) {
        if (finalError) {
          self.postProcessError('DEFAULT', finalResult);
        } else {
          self.postProcessSuccess(finalResult);
        }
      });
    }
  );
};


/**
 * @bma subscriber
 * @method scms - delete
 * @desc /{wyclubToken}/subscriber/scms
 * @httpmethod DELETE
 * @summary scms.delete — Delete subscriber throw SCMS API.
 *
 * @param {string} request.params.wyclubToken - Wyclub Token
 * @param {Array} request.body.subscribers - Array of subscribers
 * @param {string} request.body.subscribers.polkaId - Subscriber ID (10 digits)
 *
 *
 * @example {request} - Subscriber delete request example
 * .. sourcecode:: http
 *
 *   POST /9BvMMXWSOoqzgKbHbC86E1KwAuSxTeN3/subscriber/scms HTTP/1.1
 *   Accept: application/json, text/javascript
 *   Content-Type: application/json
 *
 *     {
 *       "subscribers": [
 *         {
 *           "polkaId": "1284567892"
 *         }
 *       ]
 *     }
 *
 * @param {integer} response.body.code - code of a response
 * @param {integer} response.body.content - Content of a response
 * @param {array} response.body.data - data of a response
 * @param {string} response.body.data.polkaId - Subscriber ID
 * @param {integer} response.body.data.errorCode - Subscriber object
 * @param {string} response.body.data.errorMessage - Subscriber ID
 * @param {object} response.body.data.errorData
 *
 * @httpcode 200 Success
 * @httpcode 403 Forbiden
 *
 * @errorcode {200} 0 Success
 * @errorcode {403} 5 Invalid request parameter
 * @errorcode {403} 999 An unexpected error occured (read body.data.errorMessage in response body for more details)
 *
 * @example {response} - Subscriber delete response example
 * .. sourcecode:: http
 *
 *   HTTP/1.1 200 OK
 *   Vary: Accept
 *   Content-Type: application/json
 *
 *     {
 *       "code": 0,
 *       "content": "Success",
 *       "data": [
 *         {
 *           "polkaId": "1284567892",
 *           "errorCode": 0,
 *           "errorMessage": "",
 *           "errorData": null
 *         }
 *       ]
 *     }
 */
Subscriber.prototype.delete = function () {
  'use strict';
  var self = this;

  /* jshint unused:false */
  this.process(function (values) {
      var finalResult = [];
      var finalError = false;

      async.each(values.subscribers, function (object, callback) {
        var subModel = Container.subscriber.model.subscriber;
        var filter = {polkaId: object.polkaId};
        subModel.findOneAndRemove(filter, function (err, result) {
          if (err && err.code !== 'NO_DOCUMENT') {
            finalResult.push({
              polkaId: object.polkaId,
              errorCode: Container.httpTools.statusCodes.subscriber['DELETE_ERROR'].code,
              errorMessage: 'Could not delete entry: ' + err.toString(),
              errorData: err
            });
            finalError = true;
          } else if (!result || err) {
            finalResult.push({
              polkaId: object.polkaId,
              errorCode: Container.httpTools.statusCodes.subscriber['NOTHING_ERROR'].code,
              errorMessage: 'No entry',
              errorData: err
            });
            finalError = true;
          } else {
            finalResult.push({
              polkaId: object.polkaId,
              errorCode: 0,
              errorMessage: '',
              errorData: null
            });
          }
          callback();
        });
      }, function (err) {
        if (finalError) {
          self.postProcessError('DEFAULT', finalResult);
        } else {
          self.postProcessSuccess(finalResult);
        }
      });
    }
  );
};


/*
 * Format data from API before insertion
 */
Subscriber.prototype.formatParams = function (params) {
  'use strict';

  // Remove devices to be sure we are in a proper condition
  delete params.devices;

  // Fill device fields (stbCertificateSN, stbCertificateExpiry, stbCertificateRevokedFlag can't be save with this api)
  var device = {};
  if (params.hasOwnProperty('stbId')) {
    device.stbId = params.stbId;
  }
  if (params.hasOwnProperty('stbSN')) {
    device.stbSN = params.stbSN;
  }
  if (params.hasOwnProperty('stbMACAddress')) {
    device.stbMACAddress = params.stbMACAddress;
  }
  if (params.hasOwnProperty('stbCertificateRevokedFlag')) {
    device.stbCertificateRevokedFlag = params.stbCertificateRevokedFlag;
  }

  if (Object.keys(device).length > 0) {
    params.devices = [device];
  }

  return params;
};

module.exports = Subscriber;
