// List of default permissions
// type: right to save
// group: list of tag(s) from the core that are attached to the permission
var tools = Container.tools;
var deviceId_1 = 'gtk7Ca2HAXp5R15ZjcXOHOAZYlJQkL6U'; // Hard coded to be able to use it on the test of the core
var deviceId_2 = 'phgoNVov0BBlFoh0TOtlFdKpGehsfnU9'; // Hard coded to be able to use it on the test of the core
var deviceId_toBeSigned = 'QtiBCa2HAXp5R15ZjcXOHOAZYlJQkL6U'; // Hard coded to be able to use it on the test of auth bma

var permission = {

  subscriber_bootloaderTests40: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492000430',
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },

  subscriber_bootloaderTests41: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492000443',
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },

  subscriber_bootloaderTests42: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492000344',
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },

  subscriber_bootloaderTests43: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492000307',
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },

  subscriber_bootloaderTests44: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492000335',
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },

  subscriber_bootloaderTests45: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492000374',
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },
  subscriber_bootloaderTests46: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492000080',
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },
  subscriber_bootloaderTests47: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492000035',
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },

  subscriber_bootloaderTests48: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492000309',
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },

  subscriber_bootloaderTests49: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492000324',
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },

  subscriber_bootloaderTests50: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492000057',
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },

  subscriber_bootloaderTests51: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492000342',
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },

  subscriber_bootloaderTests52: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492000390',
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },

  subscriber_bootloaderTests54: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492017440',
        stbId: 3398542357
      }
    ]
  },

  subscriber_bootloaderTests55: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492017343',
        stbId: 3398552794
      }
    ]
  },

  subscriber_bootloaderTests56: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492017325',
        stbId: 3398548290
      }
    ]
  },

  subscriber_bootloaderTests57: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492017324',
        stbId: 3398551198
      }
    ]
  },

  subscriber_bootloaderTests59: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492017360',
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },

  subscriber_bootloaderTests60: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: tools.generatePublicKey(32)
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: tools.generatePublicKey(10, 'number'),
        status: 1,
        stbSN: 'AF13010492000013',
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },


  subscriber_toBeSigned: {
    polkaId: '3334867890',
    accountId: '33345678901234567890',
    pdaId: '789456123078945678901234997890',
    smartcardSN: '12345008901',
    telcoFlag: 'passed',
    telcoId: '7894561590056845',
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        _id: deviceId_toBeSigned,
        deviceId: deviceId_1,
        applicationId: "RHgncrKFhVMzYhLYMw7osjka3IeDhivl"
      }
    ],
    devices: [
      {
        _id: deviceId_toBeSigned,
        label: 'device_forUpdate',
        uuid: '4561327800',
        status: 1,
        stbSN: '1234569991234534',
        stbId: tools.generatePublicKey(10, 'number')
      }
    ],
    profiles: [
      {
        label: 'Family',
        birthdate: '19000515',
        position: '0',
        password: null
      },
      {
        label: 'Marion',
        birthdate: '19650515',
        position: '0',
        password: null
      },
      {
        label: 'Justin',
        birthdate: '20130515',
        position: '0',
        password: null
      },
      {
        label: 'Turtle',
        birthdate: '20130818',
        position: '0',
        password: null
      }
    ]
  },
  subscriber_premium: {
    polkaId: '1234567890',
    accountId: '12345678901234567890',
    pdaId: '789456123078945678901234567890',
    smartcardSN: '12345678901',
    telcoFlag: 'true',
    telcoId: '7894561594256845',
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: "XHPiMdpchfugjthdjitfH6WgJVJP6r1Z"
      }
    ],
    devices: [
      {
        _id: deviceId_1,
        label: 'device_1',
        uuid: '4561327895',
        status: 1,
        stbSN: "E9yWWIlJ8uM7HjVz",
        stbId: 8562851130,
        stbMACAddress: 'AA:AA:AA:AA:AA:AA'
      },
      {
        label: 'device_forUpdate',
        uuid: '4561327896',
        status: 1,
        stbSN: '1234567891234534',
        stbId: tools.generatePublicKey(10, 'number')
      },
      {
        label: 'device_cert_valid',
        uuid: '9561327892',
        status: 1,
        stbSN: tools.generatePublicKey(16),
        stbId: tools.generatePublicKey(10, 'number'),
        stbCertificateSN: 'CERT_VALID_ID',
        stbCertificateExpiry: 1800000000, // Date in 2027,
        stbCertificateRevokedFlag: false,
        stbMACAddress: '11:22:33:44:55:66'
      },
      {
        label: 'device_cert_expiry',
        uuid: '9561327893',
        status: 1,
        stbSN: tools.generatePublicKey(16),
        stbId: tools.generatePublicKey(10, 'number'),
        stbCertificateSN: 'CERT_EXPIRY_ID',
        stbCertificateExpiry: 1000000000, // Date in 2001,
        stbCertificateRevokedFlag: false
      },
      {
        label: 'device_cert_revoked',
        uuid: '9561327891',
        status: 1,
        stbSN: tools.generatePublicKey(16),
        stbId: tools.generatePublicKey(10, 'number'),
        stbCertificateSN: 'CERT_REVOKED_ID',
        stbCertificateExpiry: 1800000000, // Date in 2001,
        stbCertificateRevokedFlag: true
      },
      {
        _id: deviceId_2,
        label: 'device_cert_revoked_warn',
        uuid: '9561327890',
        status: 1,
        stbSN: tools.generatePublicKey(16),
        stbId: tools.generatePublicKey(10, 'number'),
        stbCertificateSN: 'CERT_EXPIRY_ID_WARN',
        stbCertificateExpiry: parseInt(new Date().getTime() + (86400 * 1000 * 25)), // Date in a 60 days time window from now, -> actually in 25 days
        stbCertificateRevokedFlag: false
      }
    ],
    profiles: [
      {
        label: 'Family',
        birthdate: '19000515',
        position: '0',
        password: null
      },
      {
        label: 'Marion',
        birthdate: '19650515',
        position: '0',
        password: null
      },
      {
        label: 'Justin',
        birthdate: '20130515',
        position: '0',
        password: null
      },
      {
        label: 'Turtle',
        birthdate: '20130818',
        position: '0',
        password: null
      }
    ]
  },
  subscriber_noPremiumAndNoPassword: {
    polkaId: '1234567891',
    accountId: '12345678901234567891',
    pdaId: '789456123078945678901234567891',
    smartcardSN: '12345678902',
    telcoId: '7894561594256846',
    telcoFlag: 'passed',
    skyStatus: 'provisioned',
    profiles: [
      {
        _id: 'RjkwdtbQ5hoqlA754cRQ4yXnmH7fCOBX', // Hard coded to be able to use it on the test of the core
        label: 'John',
        birthdate: '19650515',
        position: 0,
        password: 'password'
      },
      {
        label: 'Toto',
        birthdate: '19650515',
        position: 0,
        password: null
      },
      {
        label: 'Marion',
        birthdate: '19650515',
        position: 0,
        password: null
      },
      {
        label: 'Justin',
        birthdate: '20130515',
        position: 0,
        password: null
      },
      {
        label: 'Family',
        birthdate: '19000515',
        position: 0,
        password: null
      }
    ],
    devices: [
      {
        label: 'device_3',
        uuid: '4561327892',
        status: 1,
        stbSN: tools.generatePublicKey(16),
        stbId: tools.generatePublicKey(10, 'number')
      },
      {
        label: 'device_4',
        uuid: '4561327893',
        status: 1,
        stbSN: tools.generatePublicKey(16),
        stbId: tools.generatePublicKey(10, 'number')
      },
      {
        label: 'device_5',
        uuid: '4561327891',
        status: 1,
        stbSN: tools.generatePublicKey(16),
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },
  subscriber_matchCampaignModelAndSN: {
    polkaId: '1234567892',
    accountId: '12345678901234567891',
    pdaId: '789456123078945678901234567891',
    smartcardSN: '12345678902',
    telcoId: '7894561594256846',
    telcoFlag: 'passed',
    skyStatus: 'provisioned',
    profiles: [
      {
        _id: 'RjkwdtbQ5hoqlA754cRQ4yXnmH7fCXXA', // Hard coded to be able to use it on the test of the core
        label: 'Family',
        birthdate: '19000515',
        position: 0,
        password: null
      }
    ],
    devices: [
      {
        _id: 'gtk7Ca2HAXp5R15ZjcXOHOAZYlJQkXXA',
        label: 'device_3',
        uuid: '4561327892',
        status: 1,
        stbSN: 1234017891234567,
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },
  subscriber_matchCampaignModelOnly: {
    polkaId: '1234567893',
    accountId: '12345678901234567891',
    pdaId: '789456123078945678901234567891',
    smartcardSN: '12345678902',
    telcoId: '7894561594256846',
    telcoFlag: 'passed',
    skyStatus: 'provisioned',
    profiles: [
      {
        _id: 'RjkwdtbQ5hoqlA754cRQ4yXnmH7fCXXZ', // Hard coded to be able to use it on the test of the core
        label: 'Family',
        birthdate: '19000515',
        position: 0,
        password: null
      }
    ],
    devices: [
      {
        _id: 'gtk7Ca2HAXp5R15ZjcXOHOAZYlJQkXXZ',
        label: 'device_3',
        uuid: '4561327892',
        status: 1,
        stbSN: 9234017891234567,
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },
  subscriber_DontMatchCampaign: {
    polkaId: '1234567894',
    accountId: '12345678901234567891',
    pdaId: '789456123078945678901234567891',
    smartcardSN: '12345678902',
    telcoId: '7894561594256846',
    telcoFlag: 'passed',
    skyStatus: 'provisioned',
    profiles: [
      {
        _id: 'RjkwdtbQ5hoqlA754cRQ4yXnmH7fCXXX', // Hard coded to be able to use it on the test of the core
        label: 'Family',
        birthdate: '19000515',
        position: 0,
        password: null
      }
    ],
    devices: [
      {
        _id: 'gtk7Ca2HAXp5R15ZjcXOHOAZYlJQkXXX',
        label: 'device_3',
        uuid: '4561327892',
        status: 1,
        stbSN: 9234027891234567,
        stbId: tools.generatePublicKey(10, 'number')
      }
    ]
  },
  subscriber_register: {
    polkaId: '1284567892',
    accountId: '12345678901234567892',
    pdaId: '789456123078945678901234567890',
    smartcardSN: '12345678902',
    telcoFlag: 'passed',
    telcoId: '7894561594256842',
    skyStatus: 'provisioned',
    deviceInstances: [
      {
        deviceId: deviceId_1,
        applicationId: "XHPiMdpchfugjthdjitfH6WgJVJP6r62"
      }
    ],
    devices: [
      {
        label: 'device_forUpdate',
        uuid: '4561327886',
        status: 1,
        stbSN: '2234567891234534',
        stbId: 2619259546
      }
    ]
  },
  subscriber_bootloaderTests1: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is1',
        stbSN: 'AF13010492000832',
        stbId: 4272230630,
        stbMACAddress: '54:E2:E0:FB:81:4C',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests2: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is2',
        stbSN: 'AF13010492000891',
        stbId: 4272230907,
        stbMACAddress: '54:E2:E0:FB:81:C2',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests3: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is3',
        stbSN: 'AF13010492000672',
        stbId: 4272230898,
        stbMACAddress: '70:85:C6:EF:FA:F8',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests4: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is4',
        stbSN: 'AF13010492000903',
        stbId: 4272230660,
        stbMACAddress: '54:E2:E0:FB:81:DA',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests5: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is5',
        stbSN: 'AF13010492000900',
        stbId: 4272230650,
        stbMACAddress: '54:E2:E0:FB:81:D4',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests6: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is6',
        stbSN: 'AF13010492000960',
        stbId: 4272230655,
        stbMACAddress: '54:E2:E0:FB:82:4C',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests7: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is7',
        stbSN: 'AF13010492000937',
        stbId: 4272230693,
        stbMACAddress: '54:E2:E0:FB:82:1E',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests8: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is8',
        stbSN: 'AF13010492000922',
        stbId: 4272230647,
        stbMACAddress: '54:E2:E0:FB:82:00',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests9: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is9',
        stbSN: 'AF13010492000851',
        stbId: 4272230652,
        stbMACAddress: '54:E2:E0:FB:81:72',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests10: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is10',
        stbSN: 'AF13010492000859',
        stbId: 4272230698,
        stbMACAddress: '54:E2:E0:FB:81:82',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests11: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is11',
        stbSN: 'AF13010492000311',
        stbId: 4272230417,
        stbMACAddress: '70:85:C6:EF:F8:26',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests12: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is12',
        stbSN: 'AF13010492000456',
        stbId: 4272230167,
        stbMACAddress: '70:85:C6:EF:F9:48',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests13: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is13',
        stbSN: 'AF13010492000457',
        stbId: 4272230268,
        stbMACAddress: '70:85:C6:EF:F9:4A',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests14: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is14',
        stbSN: 'AF13010492000422',
        stbId: 4272230193,
        stbMACAddress: '70:85:C6:EF:F9:04',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests15: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is15',
        stbSN: 'AF13010492000399',
        stbId: 4272230508,
        stbMACAddress: '70:85:C6:EF:F8:D6',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests16: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is16',
        stbSN: 'AF13010492000407',
        stbId: 4272230251,
        stbMACAddress: '70:85:C6:EF:F8:E6',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests17: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is17',
        stbSN: 'AF13010492000403',
        stbId: 4272230504,
        stbMACAddress: '70:85:C6:EF:F8:DE',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests18: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is18',
        stbSN: 'AF13010492000406',
        stbId: 4272230502,
        stbMACAddress: '70:85:C6:EF:F8:E4',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests19: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is19',
        stbSN: 'AF13010492000421',
        stbId: 4272230484,
        stbMACAddress: '70:85:C6:EF:F9:02',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests20: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is20',
        stbSN: 'AF13010492000414',
        stbId: 4272230235,
        stbMACAddress: '70:85:C6:EF:F8:F4',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests21: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is21',
        stbSN: 'AF13010492000370',
        stbId: 4272230385,
        stbMACAddress: '70:85:C6:EF:F8:9C',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests22: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is22',
        stbSN: 'AF13010492000394',
        stbId: 4272230466,
        stbMACAddress: '70:85:C6:EF:F8:CC',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests23: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is23',
        stbSN: 'AF13010492000387',
        stbId: 4272230350,
        stbMACAddress: '70:85:C6:EF:F8:BE',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests24: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is24',
        stbSN: 'AF13010492000365',
        stbId: 4272230544,
        stbMACAddress: '70:85:C6:EF:F8:92',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests25: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is25',
        stbSN: 'AF13010492000303',
        stbId: 4272230393,
        stbMACAddress: '70:85:C6:EF:F8:16',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests26: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is26',
        stbSN: 'AF13010492000309',
        stbId: 4272230420,
        stbMACAddress: '70:85:C6:EF:F8:22',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests27: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is27',
        stbSN: 'AF13010492000316',
        stbId: 4272230537,
        stbMACAddress: '70:85:C6:EF:F8:30',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests28: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is28',
        stbSN: 'AF13010492000364',
        stbId: 4272230469,
        stbMACAddress: '70:85:C6:EF:F8:90',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests29: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is29',
        stbSN: 'AF13010492000013',
        stbId: 4272230428,
        stbMACAddress: '70:85:C6:18:1F:B6',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests30: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is30',
        stbSN: 'AF13010492000393',
        stbId: 4272230263,
        stbMACAddress: '70:85:C6:EF:F8:CA',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests31: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is31',
        stbSN: 'AF13010492000259',
        stbId: 4272230080,
        stbMACAddress: '70:85:C6:EF:F7:BE',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests32: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is32',
        stbSN: 'AF13010492000032',
        stbId: 4272229735,
        stbMACAddress: '70:85:C6:18:1F:DC',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests33: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is33',
        stbSN: 'AF13010492000016',
        stbId: 4272229761,
        stbMACAddress: '70:85:C6:18:1F:BC',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests34: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is34',
        stbSN: 'AF13010492000002',
        stbId: 4272229750,
        stbMACAddress: '70:85:C6:18:1F:A0',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests35: {
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is35',
        stbSN: 'AF13010492000343',
        stbId: 4272230548,
        stbMACAddress: '70:85:C6:EF:F8:66',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests36: {
    bouquetId: "78sk33z159634785",
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: "789456123078945678901234567890",
    smartcardSN: "78945612307",
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: 'Is35',
        stbSN: 'AF13010492000343',
        stbId: 4272230548,
        stbMACAddress: '70:85:C6:EF:F8:66',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests38: {
    bouquetId: tools.generatePublicKey(16),
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: '789456123078945678901234567890',
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: tools.generatePublicKey(4),
        stbSN: 'AF13010492000825',
        stbId: tools.generatePublicKey(10, 'number'),
        stbMACAddress: '70:85:C6:EF:F8:66',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests39: {
    bouquetId: tools.generatePublicKey(16),
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: '789456123078945678901234567890',
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: tools.generatePublicKey(4),
        stbSN: 'AF13010492000848',
        stbId: tools.generatePublicKey(10, 'number'),
        stbMACAddress: '70:85:C6:EF:F8:66',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests61: {
    bouquetId: tools.generatePublicKey(16),
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: '789456123078945678901234567890',
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: tools.generatePublicKey(4),
        stbSN: 'AF13010492000913',
        stbId: tools.generatePublicKey(10, 'number'),
        stbMACAddress: '70:85:C6:EF:F8:66',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests62: {
    bouquetId: tools.generatePublicKey(16),
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: '789456123078945678901234567890',
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: tools.generatePublicKey(4),
        stbSN: 'AF13010492000863',
        stbId: tools.generatePublicKey(10, 'number'),
        stbMACAddress: '70:85:C6:EF:F8:66',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests63: {
    bouquetId: tools.generatePublicKey(16),
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: '789456123078945678901234567890',
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: tools.generatePublicKey(4),
        stbSN: 'AF13010492000841',
        stbId: tools.generatePublicKey(10, 'number'),
        stbMACAddress: '70:85:C6:EF:F8:66',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests64: {
    bouquetId: tools.generatePublicKey(16),
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: '789456123078945678901234567890',
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: tools.generatePublicKey(4),
        stbSN: 'AF13010492000884',
        stbId: tools.generatePublicKey(10, 'number'),
        stbMACAddress: '70:85:C6:EF:F8:66',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests69: {
    bouquetId: tools.generatePublicKey(16),
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: '789456123078945678901234567890',
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: tools.generatePublicKey(4),
        stbSN: 'AF13010492017449',
        stbId: '0492017449',
        stbMACAddress: '00:10:18:00:23:88',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests70: {
    bouquetId: tools.generatePublicKey(16),
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: '789456123078945678901234567890',
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: tools.generatePublicKey(4),
        stbSN: 'AF13010492000355',
        stbId: '0492000355',
        stbMACAddress: '00:10:18:00:23:38',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests71: {
    bouquetId: tools.generatePublicKey(16),
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: '789456123078945678901234567890',
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: tools.generatePublicKey(4),
        stbSN: 'AF13010492000017',
        stbId: '0492000017',
        stbMACAddress: '00:10:18:00:23:BF',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests72: {
    bouquetId: tools.generatePublicKey(16),
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: '789456123078945678901234567890',
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: tools.generatePublicKey(4),
        stbSN: 'AF13010492000119',
        stbId: '0492000119',
        stbMACAddress: '00:10:18:00:23:BA',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests73: {
    bouquetId: tools.generatePublicKey(16),
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: '789456123078945678901234567890',
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: tools.generatePublicKey(4),
        stbSN: 'AF13010492000954',
        stbId: '0492000954',
        stbMACAddress: '00:10:18:9C:23:46',
        status: 1
      }
    ]
  },

  //SERBIAN STB
  subscriber_bootloaderTests65: {
    bouquetId: tools.generatePublicKey(16),
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: '789456123078945678901234567890',
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: tools.generatePublicKey(4),
        stbSN: 'AF13010492000378',
        stbId: '0492000378',
        stbMACAddress: '',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests66: {
    bouquetId: tools.generatePublicKey(16),
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: '789456123078945678901234567890',
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: tools.generatePublicKey(4),
        stbSN: 'AF13010492000865',
        stbId: '0492000865',
        stbMACAddress: '',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests67: {
    bouquetId: tools.generatePublicKey(16),
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: '789456123078945678901234567890',
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: tools.generatePublicKey(4),
        stbSN: 'AF13010492000445',
        stbId: '0492000445',
        stbMACAddress: '',
        status: 1
      }
    ]
  },
  subscriber_bootloaderTests68: {
    bouquetId: tools.generatePublicKey(16),
    polkaId: tools.generatePublicKey(10, 'number'),
    accountId: tools.generatePublicKey(20, 'number'),
    pdaId: '789456123078945678901234567890',
    smartcardSN: tools.generatePublicKey(11, 'number'),
    telcoFlag: 'passed',
    telcoId: tools.generatePublicKey(16, 'number'),
    skyStatus: 'provisioned',
    devices: [
      {
        uuid: String(tools.generatePublicKey(10, 'number')),
        label: tools.generatePublicKey(4),
        stbSN: 'AF13010492000173',
        stbId: '0492000173',
        stbMACAddress: '',
        status: 1
      }
    ]
  },

  subsciber_cj9IfVksmF7otGQhG4Ik: {
    bouquetId: 'cIp9aCeSzsG1Lqyt',
    polkaId: '8096340873',
    accountId: '19922284680794027800',
    pdaId: 'ckkEJTnXjqY0BwmyibTKa6xyo5ILZ2',
    smartcardSN: '55524498760',
    telcoFlag: 'passed',
    telcoId: '3992859824712820',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'B0Idvcuw95q43HEwqIjefoedfG4T37Up',
        uuid: '9544249490',
        label: 'kpvT',
        stbSN: 'AF13010492017440',
        stbId: '3398542357',
        stbMACAddress: 'D8:25:22:41:E4:0C',
        status: 1 }
    ] },
  subsciber_AOOjbWA1dMtyITEMMiWG: {
    bouquetId: 'Y9HvnlrpB01ipuOs',
    polkaId: '0416001863',
    accountId: '60259263939209954937',
    pdaId: 'ioebojY4eD2Gzg7etpSsTb77Cbko3U',
    smartcardSN: '30197256622',
    telcoFlag: 'passed',
    telcoId: '6584371250374204',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'oeBnEFPE9GgZOPomgXdCXYULokaB5oXZ',
        uuid: '6853813758',
        label: 'Oq9U',
        stbSN: 'AF13010492017496',
        stbId: '3398540738',
        stbMACAddress: '',
        status: 1 }
    ] },
  subsciber_dv9SdCbAN1bYkP1iBSBG: {
    bouquetId: 'HRGH4sHyXJMqp2O8',
    polkaId: '4083026812',
    accountId: '81471898447051772864',
    pdaId: 'w0YHrMec9JrO6wrvOQQXa14U228gb2',
    smartcardSN: '83501298524',
    telcoFlag: 'passed',
    telcoId: '2032483622033319',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'GItx6OcFamEOm4V9uCPWybVNQKDMAMIn',
        uuid: '2270036975',
        label: 'S1gj',
        stbSN: 'AF13010492017405',
        stbId: '3398552953',
        stbMACAddress: '',
        status: 1 }
    ] },
  subsciber_DrFj1W9uOxLIVijkbaZ2: {
    bouquetId: 'Ppg8TPPMpSLZV230',
    polkaId: '0124844712',
    accountId: '57825590818988724664',
    pdaId: 'hQ5qdOyRifbtAs7DxSqCC0g7VFBOET',
    smartcardSN: '31034777319',
    telcoFlag: 'passed',
    telcoId: '8915433356818140',
    skyStatus: 'provisioned',
    devices: [
      { _id: '06fIgnHQPmeQc0NvQbXefzl9Luxcw1rd',
        uuid: '0225844194',
        label: 'v5b9',
        stbSN: 'AF13010492017333',
        stbId: '3398551152',
        stbMACAddress: '',
        status: 1 }
    ] },
  subsciber_xusyigx3v7s7IAQF8WiW: {
    bouquetId: 'XNtHEWaul7YEMOkY',
    polkaId: '1431370486',
    accountId: '98686406652470537771',
    pdaId: 'lKRg9nNh4AZXuEdi7ng7odshXoEfWT',
    smartcardSN: '60064588186',
    telcoFlag: 'passed',
    telcoId: '1150534439105847',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'KJjr26BCs3nkmEqLolttKq6pwZdfUisl',
        uuid: '4858808496',
        label: 'jNJO',
        stbSN: 'AF13010492017344',
        stbId: '3398552029',
        stbMACAddress: '',
        status: 1 }
    ] },
  subsciber_Lt6XLOgmGkRek4pf6Ivo: {
    bouquetId: 'ZZqUMFAODho1g2LI',
    polkaId: '3655152358',
    accountId: '61102642281975552202',
    pdaId: 'NPoq9WKfrAmNqOURd4FXrVITGpSkxa',
    smartcardSN: '78854988007',
    telcoFlag: 'passed',
    telcoId: '7575064270946420',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'fipnY8hjYBeAbvWlWFYt2VaVYvDFeSor',
        uuid: '1861299319',
        label: 'vTAe',
        stbSN: 'AF13010492017346',
        stbId: '3398550754',
        stbMACAddress: '',
        status: 1 }
    ] },
  subsciber_hRpMDiR340p9yxxsUQzm: {
    bouquetId: 'sTRs6HP1vUZmgLFZ',
    polkaId: '2914014248',
    accountId: '18542272906842666926',
    pdaId: '7EIzOhaIvGFXYkRKMSJdf87RWeAnvC',
    smartcardSN: '24420674471',
    telcoFlag: 'passed',
    telcoId: '2337272427864968',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'qgcVMrM6IqtzeaCwJhgu6QIe5YdLXoiu',
        uuid: '6601944644',
        label: 'JD2o',
        stbSN: 'AF13010492017347',
        stbId: '3398549879',
        stbMACAddress: '',
        status: 1 }
    ] },
  subsciber_V0VRO9HaVNu5IsRE3fb1: {
    bouquetId: 'F1vYo8pBhgfF9V5Z',
    polkaId: '3680633088',
    accountId: '08045488758373234517',
    pdaId: 'jtgKQ8butdBrLhFKtyS6hYIkVHEMeK',
    smartcardSN: '07428051325',
    telcoFlag: 'passed',
    telcoId: '8731318962258394',
    skyStatus: 'provisioned',
    devices: [
      { _id: '9GiDoMzGtC940cjoeU5YKYPixKUQq77M',
        uuid: '8004330174',
        label: 'OBx3',
        stbSN: 'AF13010492017422',
        stbId: '3398547752',
        stbMACAddress: '',
        status: 1 }
    ] },
  subsciber_A3WbcrLWuL39kNqd1gD9: {
    bouquetId: 'jig8mw7oFub0N9mq',
    polkaId: '0613267823',
    accountId: '65453662733276425666',
    pdaId: '6FgNkKXVriaxasHbu2DA4MFfa2J6op',
    smartcardSN: '81439576937',
    telcoFlag: 'passed',
    telcoId: '1402974731926977',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'R6sNH3WzbQT04QPPD1U9plufi8v14qYL',
        uuid: '0224981075',
        label: 'y1Wf',
        stbSN: 'AF13010492017426',
        stbId: '3398550442',
        stbMACAddress: '',
        status: 1 }
    ] },
  subsciber_RB4IGwM3T76uPcyFX6q6: {
    bouquetId: 'uPySi5W0lphTuCYW',
    polkaId: '0100643635',
    accountId: '95694258089971138846',
    pdaId: 'P2Dj3UIfutDtcxr4Y3sHjLZJMZ91H5',
    smartcardSN: '29787003055',
    telcoFlag: 'passed',
    telcoId: '7938132280912198',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'EIC2oI85HhOfN5jLAtH0F44HnprkBPcM',
        uuid: '7421011660',
        label: 'xy7b',
        stbSN: 'AF13010492000941',
        stbId: '6954818566',
        stbMACAddress: '',
        status: 1 }
    ] },
  subsciber_EaKJ05sKIQ4S3H9BxJWZ: {
    bouquetId: 'qEA403TZOr7gugjA',
    polkaId: '1241191459',
    accountId: '23718633430045801697',
    pdaId: 'B1SYj5yLu2SmaroPVHDwc7a6kLtGLn',
    smartcardSN: '16998098277',
    telcoFlag: 'passed',
    telcoId: '6375933770468895',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'lwnwplqPZo5yE69vTjWPkunertUf3dD7',
        uuid: '3464081517',
        label: 'gn9f',
        stbSN: 'AF13010492000670',
        stbId: '6358989017',
        stbMACAddress: '00:10:18:00:23:6A',
        status: 1 }
    ] },
  subsciber_TDxhGT6JemnfMlyX1beb: {
    bouquetId: 'mpClysAJA6XEepBm',
    polkaId: '0251276062',
    accountId: '39671566521837631264',
    pdaId: '5kI2amNsYjE8kCCTyFDTskb6e9ox82',
    smartcardSN: '36338545532',
    telcoFlag: 'passed',
    telcoId: '0589259248125273',
    skyStatus: 'provisioned',
    devices: [
      { _id: '6pJi5sjXyWYJ1Dgl6ryfYtZf36UzxRyp',
        uuid: '2788026935',
        label: '4HvN',
        stbSN: 'AF13010492017328',
        stbId: '7691434974',
        stbMACAddress: '00:10:18:00:23:06',
        status: 1 }
    ] },
  subsciber_EUc3kmapsrz4byYvnMuS: {
    bouquetId: 'XgkeFVjUpK7GBJag',
    polkaId: '7427463986',
    accountId: '40622272460782245717',
    pdaId: 'vFdSKUgMHtDNtpXDoLmHrfNxJSAvXO',
    smartcardSN: '15557956654',
    telcoFlag: 'passed',
    telcoId: '4780893574173996',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'jqLLjkb2Mw8WKy8twRcWnd4GMDt2EfGs',
        uuid: '0882810554',
        label: 'Hqfb',
        stbSN: 'ZDVAAAC432240003',
        stbId: '6817141747',
        stbMACAddress: '00:10:18:00:23:64',
        status: 1 }
    ] },
  subsciber_yeqG32p9x8OGEwrR6U7s: {
    bouquetId: 'V8LoOoi0y47m2yNG',
    polkaId: '4558304174',
    accountId: '43169909290994527365',
    pdaId: 'vMHjCU2HdYlDXrsZgHH64xsrKgZrjE',
    smartcardSN: '48555406685',
    telcoFlag: 'passed',
    telcoId: '0116225595139450',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'k5GxgU48a6fr4VzALIAIsf38xmfb5guJ',
        uuid: '1466524949',
        label: 'lO1a',
        stbSN: 'AF13010492017467',
        stbId: '1883311482',
        stbMACAddress: '00:10:18:00:23:6B',
        status: 1 }
    ] },
  subsciber_soC3Z5kqlVnGEqs5hmRh: {
    bouquetId: 'mVUpq8RMfzg5kqdk',
    polkaId: '4374321597',
    accountId: '47856987374288778273',
    pdaId: 'ykAgCc801m0tG63znz6CuE1Kf1Xbxt',
    smartcardSN: '89755759982',
    telcoFlag: 'passed',
    telcoId: '0886047331844542',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'RB6aJfVyGlNVNGfgMLiSJKFvbawH4WEq',
        uuid: '7058187649',
        label: 'N5gI',
        stbSN: 'AF13010492017473',
        stbId: '6522927019',
        stbMACAddress: '00:10:18:00:23:92',
        status: 1 }
    ] },
  subsciber_lWQpEUoczHXm0UdPCWSe: {
    bouquetId: 'DPWrtuOVHKJuxHwB',
    polkaId: '0427382171',
    accountId: '10518988253127352452',
    pdaId: 'U3ZE9LLO6Ak9IRb64oVjmtAVPon9St',
    smartcardSN: '36556980111',
    telcoFlag: 'passed',
    telcoId: '3987726593017450',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'BPGi2bc0AKCEXmT18hd6hxog7etjGBIk',
        uuid: '1099924421',
        label: '6c9T',
        stbSN: 'AF13010492000847',
        stbId: '9181502811',
        stbMACAddress: '00:10:18:01:23:1E',
        status: 1 }
    ] },
  subsciber_NZCjGhoSbCOYP7tCFLF2: {
    bouquetId: 'vhboCynlaK3qE4uC',
    polkaId: '4560799585',
    accountId: '10210095589419367615',
    pdaId: 'fTV2Dyr5eJ2YT3Tf1MFwSqwQL66YF9',
    smartcardSN: '27905987635',
    telcoFlag: 'passed',
    telcoId: '6767896065435468',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'JhKth0aSn5ybs6MM6px8oqQlO9ylLSrk',
        uuid: '6730861479',
        label: 'QwIV',
        stbSN: 'AF13010492017399',
        stbId: '9714838388',
        stbMACAddress: '00:10:18:00:23:AC',
        status: 1 }
    ] },
  subsciber_yeVe2vw5d6ZPA829iiDK: {
    bouquetId: '03AV99NbumGeIHg4',
    polkaId: '5494667744',
    accountId: '78645306009186380182',
    pdaId: 'dKnUeHqyIpZLW7E5tYEIYR3AMCBNwT',
    smartcardSN: '68368774473',
    telcoFlag: 'passed',
    telcoId: '8134363922981356',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'W5W4MFTkjuhzqE6WHm0g1MRF1alH7PyX',
        uuid: '7704975267',
        label: 'nPpE',
        stbSN: 'AF13010492017372',
        stbId: '9711033214',
        stbMACAddress: '00:10:18:00:23:60',
        status: 1 }
    ] },
  subsciber_BrNuBAxklNCkSAJxIHWC: {
    bouquetId: 'Jpl53niTki8L4rVv',
    polkaId: '3777742101',
    accountId: '96990460319662698742',
    pdaId: 'pT8ppOLe29HJ9VJVoNQo8EFR7WWHoa',
    smartcardSN: '71730763662',
    telcoFlag: 'passed',
    telcoId: '5337842197774059',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'W4UTRAJPpi5EdJnYmUszS8DMfeXPYgV2',
        uuid: '5516964262',
        label: '6Llh',
        stbSN: 'AF13010492017412',
        stbId: '4175682085',
        stbMACAddress: '00:10:18:00:23:2C',
        status: 1 }
    ] },
  subsciber_unxcO3ruilWIMf2uB23E: {
    bouquetId: '8ZfYMvyTq8GIhamR',
    polkaId: '5187946411',
    accountId: '33544952802584538151',
    pdaId: 'unmEpG7qGX62Wz7J2PqFthQkuFtTJ7',
    smartcardSN: '87537709943',
    telcoFlag: 'passed',
    telcoId: '9741725862835829',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'rJIvIJOGmP3owL7VKp8wFrkRXCBWtuRa',
        uuid: '3303813550',
        label: 'OTST',
        stbSN: 'AF13010492017330',
        stbId: '0915692756',
        stbMACAddress: '',
        status: 1 }
    ] },
  subsciber_1L5ojYOIBgHzRdNIEsuO: {
    bouquetId: 'mcG5TUjmGSYcb8aW',
    polkaId: '3202227815',
    accountId: '27522467053577288484',
    pdaId: 'Q9cV8WF9qDmzKfpWd5Z8ANiDp6W9KT',
    smartcardSN: '31616605992',
    telcoFlag: 'passed',
    telcoId: '1668902796348722',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'Bg6QKsms2nvXy9NTxqsvSNMOhSpFiMDy',
        uuid: '7273868475',
        label: 'uebt',
        stbSN: 'AF13010492017357',
        stbId: '0265588621',
        stbMACAddress: '',
        status: 1 }
    ] },
  subsciber_sbTOzEIJEVPdmknmDMDW: {
    bouquetId: 'zF2b7Yka9DZtKXQt',
    polkaId: '7737339407',
    accountId: '56418869757114261065',
    pdaId: 'Z1o4EnHBpKE5ktXQHYtnlieAZioqNT',
    smartcardSN: '40834256028',
    telcoFlag: 'passed',
    telcoId: '1616405110225463',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'obVsFbMCbhudBern8xLZMnVkbpSyJXmN',
        uuid: '1809434086',
        label: 'MoMz',
        stbSN: 'AF13010492017380',
        stbId: '3207704093',
        stbMACAddress: '00:10:18:00:23:5D',
        status: 1 }
    ] },
  subsciber_KNq36QDWfMNCfZL4wVk7: {
    bouquetId: '7YWqwbbZb8modYEz',
    polkaId: '6543252240',
    accountId: '69031445549266777106',
    pdaId: '2qBhAgW8JabPEkoYf7VsGPZ0GGlVbw',
    smartcardSN: '79203543859',
    telcoFlag: 'passed',
    telcoId: '2721010335940949',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'JY1J0yUxiN0VPfLkJH7K8p2F9yRnUViC',
        uuid: '0527977577',
        label: 'tK3c',
        stbSN: 'AF13010492000869',
        stbId: '6307502535',
        stbMACAddress: '00:10:18:00:23:58',
        status: 1 }
    ] },
  subsciber_DOg5IGClm1DZzAOp8Yjs: {
    bouquetId: 'oMLKbATKSleQ3Og0',
    polkaId: '1700397053',
    accountId: '80755269315194759547',
    pdaId: 'am4egKxpzxbzRTMIx0c8dSVd1QIz73',
    smartcardSN: '04171573007',
    telcoFlag: 'passed',
    telcoId: '9383045857654646',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'FjjrvtJQpMVCOVlrEZ4QLLgTAu7iE1O9',
        uuid: '7366192069',
        label: '3bTc',
        stbSN: 'AF13010492017490',
        stbId: '5348737600',
        stbMACAddress: '00:10:18:00:23:A8',
        status: 1 }
    ] },
  subsciber_KLgEUKAVcCERq44Vknfl: {
    bouquetId: 'YGaUlQVefuF7D7JX',
    polkaId: '6897719230',
    accountId: '63143771018476303648',
    pdaId: 'XKikBNOgI5Ayvb1ETfUktzgRjQ3U1u',
    smartcardSN: '20170685220',
    telcoFlag: 'passed',
    telcoId: '5455640926244229',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'vS74wqbG7vm3zGLiLqqheYYQBNkeJ5j8',
        uuid: '3967718563',
        label: 'xbsm',
        stbSN: 'AF13010492000965',
        stbId: '2640860717',
        stbMACAddress: '00:10:18:00:23:00',
        status: 1 }
    ] },
  subsciber_8OJPlI47QU1qfgv53f7Y: {
    bouquetId: 'RhuLxAZTYkFDFBuF',
    polkaId: '9782524811',
    accountId: '13016249425311780842',
    pdaId: '5GsvnveloLolSPpVc8esB5667mX1oL',
    smartcardSN: '61230183939',
    telcoFlag: 'passed',
    telcoId: '6810249595401247',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'KFwDc3wjaUgaW99qQu4Jer7RPHpHZROJ',
        uuid: '2722751742',
        label: 'oxeG',
        stbSN: 'AF13010492000318',
        stbId: '6205466845',
        stbMACAddress: '00:10:18:00:23:33',
        status: 1 }
    ] },
  subsciber_lEt7FIeiNoTDF0XqJWRd: {
    bouquetId: 'COK8T1imH1HEywiW',
    polkaId: '8965050785',
    accountId: '41430389128838122735',
    pdaId: 'xsbifhqvuqqM4ABFbW8lJAzlA8IeIh',
    smartcardSN: '23849644207',
    telcoFlag: 'passed',
    telcoId: '4856749336581682',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'rApNnxjPG4OZB0kM18el16yO50v9T7Ul',
        uuid: '8552981443',
        label: '75MT',
        stbSN: 'AF13010492017424',
        stbId: '1208727619',
        stbMACAddress: '00:10:18:00:23:0B',
        status: 1 }
    ] },
  subsciber_Tp7jmcUpAZ6DzYHozeOu: {
    bouquetId: 'snLykRcjRN3Ctk8R',
    polkaId: '8012929960',
    accountId: '22015913412758070535',
    pdaId: 'ivp4sxk8zLBjZe2kH2Xli1L9z6SdB1',
    smartcardSN: '05100586073',
    telcoFlag: 'passed',
    telcoId: '4761968860666021',
    skyStatus: 'provisioned',
    devices: [
      { _id: '7vJeJf1DVbOSKIBkNqrjUjbiMXtNQU7d',
        uuid: '7703107222',
        label: 'Fk6o',
        stbSN: 'AF13010492017375',
        stbId: '7942756042',
        stbMACAddress: '00:10:18:00:23:45',
        status: 1 }
    ] },
  subsciber_Q7hLv51rvGYfE9QPwZrM: {
    bouquetId: 'PbCedUbQpPeyfsXB',
    polkaId: '2971160535',
    accountId: '88636031155400567905',
    pdaId: 'euF3IFYt9M4JxybeK5f5PNqYIlGWwK',
    smartcardSN: '04087516672',
    telcoFlag: 'passed',
    telcoId: '6955086020488188',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'qXW6PqlDiNcCFX7bTYZLcWnxtvhmEA7L',
        uuid: '5574471791',
        label: 'V3XV',
        stbSN: 'AF13010492017434',
        stbId: '7261196751',
        stbMACAddress: '00:10:18:9C:23:CC',
        status: 1 }
    ] },
  subsciber_viiqSsIxDmgSPuooCF7i: {
    bouquetId: 'T4IgwLyqxxTpQDMH',
    polkaId: '7666617465',
    accountId: '95022368659289169864',
    pdaId: 'N5sIo4j02BlFbd5V5ABdCXntlSQeL1',
    smartcardSN: '14478258370',
    telcoFlag: 'passed',
    telcoId: '1517973643321753',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'BDiLRnxjKlR20GA8fu6G2eXZJv1rcAyh',
        uuid: '2700488506',
        label: 'Pebc',
        stbSN: 'AF13010492000095',
        stbId: '0604711079',
        stbMACAddress: '00:10:18:00:23:CB',
        status: 1 }
    ] },
  subsciber_VQCPJdA3lf6XqoenVgrN: {
    bouquetId: 'Itfxo2koWEy4IKYz',
    polkaId: '6653640245',
    accountId: '90927083293623185395',
    pdaId: 'EmY1dtpQHw69SDmHOFvnxCghpKgRQd',
    smartcardSN: '93878173278',
    telcoFlag: 'passed',
    telcoId: '1275049484418483',
    skyStatus: 'provisioned',
    devices: [
      { _id: '46iiSau36jOdRUuZMhTHoENwSdlxV1V7',
        uuid: '5518124095',
        label: 'rpL1',
        stbSN: 'AF13010492017363',
        stbId: '4869340043',
        stbMACAddress: '00:10:18:00:23:6F',
        status: 1 }
    ] },
  subsciber_ObcmCp3cnRqzKaX60jtX: {
    bouquetId: '7r4hBVGWy33Xn12G',
    polkaId: '5267531031',
    accountId: '31402575303020947513',
    pdaId: '4hPTcxtkYbMxuIA1Qpcxz83aYO69cx',
    smartcardSN: '42490906656',
    telcoFlag: 'passed',
    telcoId: '3777378228501264',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'LLyGmbVl0kplYNE9Lgms7tUMvpRU8f2u',
        uuid: '3146550190',
        label: 'XlMn',
        stbSN: 'AF13010492000872',
        stbId: '9742220129',
        stbMACAddress: '54:E2:E0:FB:81:9C',
        status: 1 }
    ] },
  subsciber_1C191lSpr28xMHfFzedv: {
    bouquetId: 'XEzf2bLa2c2L2nBf',
    polkaId: '5423025943',
    accountId: '21369711628118652802',
    pdaId: 'p5AOpzhbjcDGsN3coymCh0uMCDf2EH',
    smartcardSN: '21314673871',
    telcoFlag: 'passed',
    telcoId: '6711102556030973',
    skyStatus: 'provisioned',
    devices: [
      { _id: '9INl6sBpqOGnZMaYuZfJqeUx7nNDNkq5',
        uuid: '5174553051',
        label: 'xMGv',
        stbSN: 'AF13010492000944',
        stbId: '8037871950',
        stbMACAddress: '54:E2:E0:FB:82:2C',
        status: 1 }
    ] },
  subsciber_Xs9UAeezJxy0ail8eZRm: {
    bouquetId: 'LToLsMNihpsduTEo',
    polkaId: '1910298086',
    accountId: '08128708070645905076',
    pdaId: 'zhXzyrkSpoaKFswLPiwgOYjbynQIdM',
    smartcardSN: '02396695972',
    telcoFlag: 'passed',
    telcoId: '7893311136332764',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'QCSzMLQnagD2wCknHMD3ksTULUuFxHVm',
        uuid: '1459397177',
        label: 'L5Rs',
        stbSN: 'AF13010492000358',
        stbId: '6804349080',
        stbMACAddress: '70:85:C6:EF:F8:84',
        status: 1 }
    ] },
  subsciber_tNPeV3WJp4ZpwbFrxIo1: {
    bouquetId: '28cWbhuylT8DARMM',
    polkaId: '8196027491',
    accountId: '58070116886916331691',
    pdaId: 'qnt0hZFaQv0JPXJAOYJ9EnPGRmP4GP',
    smartcardSN: '87951435464',
    telcoFlag: 'passed',
    telcoId: '0700338364133174',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'eXu1YNSWLYn0XvcmdHZSkBoL2tX40wAr',
        uuid: '5432326161',
        label: 'x75e',
        stbSN: 'AF13010492000681',
        stbId: '4272231003',
        stbMACAddress: '70:85:C6:EF:FB:0A',
        status: 1 }
    ] },
  subsciber_XwD9aUeVnacmawgHLsuA: {
    bouquetId: 'Y7JGLdPTn4sgqFjq',
    polkaId: '2183522198',
    accountId: '61091647045506259036',
    pdaId: 'UkGKSEoWJPXLT3rXWerWXBGoIJJfXB',
    smartcardSN: '43745203091',
    telcoFlag: 'passed',
    telcoId: '6712595183342920',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'IgX5ilOoF15k8qCwJLM6jMzbSQACw6TA',
        uuid: '8838673406',
        label: 'qLHL',
        stbSN: 'AF13010492000340',
        stbId: '4500034706',
        stbMACAddress: '70:85:C6:EF:F8:60',
        status: 1 }
    ] },
  subsciber_SyPQ0m0xLk91LtLK1wJE: {
    bouquetId: 'ys5FyXPdv7JlVm84',
    polkaId: '2280121963',
    accountId: '60404133273776611439',
    pdaId: '80siYTchbtUHvPo1pMCSYBAqGE8zY7',
    smartcardSN: '17154698112',
    telcoFlag: 'passed',
    telcoId: '3293735518614321',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'KPfrywCfdeEaevJLQCyoxYDEpLlpp0jb',
        uuid: '2989437662',
        label: 'uD1l',
        stbSN: 'AF13010492000615',
        stbId: '1844861384',
        stbMACAddress: '70:85:C6:EF:FA:86',
        status: 1 }
    ] },
  subsciber_qbMpgvlD3uy2QfxGKKWd: {
    bouquetId: 'yyLk8xo7uuhgISOL',
    polkaId: '3063038764',
    accountId: '29402149208386143644',
    pdaId: 'xJXMn68SNvC1zPAWDNJatkgC9HPQt8',
    smartcardSN: '68377384743',
    telcoFlag: 'passed',
    telcoId: '9525770279236330',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'RoDH61iu9busTNl1gZ1ueJ6zybxYDqJZ',
        uuid: '8112354616',
        label: 'RYsM',
        stbSN: 'AF13010492000396',
        stbId: '9341873014',
        stbMACAddress: '70:85:C6:EF:F8:D0',
        status: 1 }
    ] },
  subsciber_iaDPSRbY05wp8EMasYTe: {
    bouquetId: 'FAh6n9W5Ox6VBMcz',
    polkaId: '4259007027',
    accountId: '20154188278511613174',
    pdaId: 'TbKCCVmMfAIsdLaAmYDEfhbNnioQXs',
    smartcardSN: '57426948072',
    telcoFlag: 'passed',
    telcoId: '9859942719393238',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'IlLmdERcRZNF2sK5ZN25XHOejpfQcAO5',
        uuid: '8024496917',
        label: 'BedD',
        stbSN: 'AF13010492000268',
        stbId: '4272229726',
        stbMACAddress: '70:85:C6:EF:F7:D0',
        status: 1 }
    ] },
  subsciber_TBnuyDfehBd9KGmVYdFv: {
    bouquetId: 'b3VQft0HihZ4om1E',
    polkaId: '5580655788',
    accountId: '25834667180721069857',
    pdaId: 'IV4DjpB1arDmLVXmHWJQP3Ndg7c6BW',
    smartcardSN: '22943861512',
    telcoFlag: 'passed',
    telcoId: '6344680908016816',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'zpcmVQDZAhu7RTZFBLmNEfFl6sdwDT3Y',
        uuid: '9319524991',
        label: 'iKQF',
        stbSN: 'AF13010492000796',
        stbId: '6813870637',
        stbMACAddress: '54:E2:E0:FB:81:04',
        status: 1 }
    ] },
  subsciber_KXWYLbwQDi6uUB6hd6Ge: {
    bouquetId: '9b3d8q08MUHaKFQz',
    polkaId: '1211904689',
    accountId: '11587577275243770012',
    pdaId: 'llOyaskTAuApU6pCdY2tHrmNIGZcxR',
    smartcardSN: '05900992036',
    telcoFlag: 'passed',
    telcoId: '1830836788455483',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'F903Eh5eiI3ILKKEIbdB8vCnz4Ioa0Sl',
        uuid: '8387925537',
        label: 'LWMW',
        stbSN: 'AF13010492000812',
        stbId: '5299932498',
        stbMACAddress: '54:E2:E0:FB:81:24',
        status: 1 }
    ] },
  subsciber_yTGfKg8UKtC5mQcUNrNZ: {
    bouquetId: 'fiz79boC47eSKjSm',
    polkaId: '3171155578',
    accountId: '15558071254426686059',
    pdaId: 'gApTeeSOY4fZJSwepzksc1aDIcRaLt',
    smartcardSN: '89862027439',
    telcoFlag: 'passed',
    telcoId: '4050123675466249',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'a28pYBITYcyYkUOudmarN2SvDuhF72kZ',
        uuid: '3459688418',
        label: 'gLyC',
        stbSN: 'AF13010492000791',
        stbId: '8152966553',
        stbMACAddress: '54:E2:E0:FB:80:FA',
        status: 1 }
    ] },
  subsciber_R4QnpQ8ZWRnredeM76v4: {
    bouquetId: 'YJFNyv3LWJqA6BnU',
    polkaId: '6174973718',
    accountId: '61311211443142192758',
    pdaId: 'i9yiGsuPNpqTD0MyNeteahJ7df5wP7',
    smartcardSN: '39168912358',
    telcoFlag: 'passed',
    telcoId: '5494713394316495',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'gND1saOnZlCy3yatgKPsvFSud7kSWtd7',
        uuid: '7617297291',
        label: 'gB9I',
        stbSN: 'AF13010492003774',
        stbId: '3398560165',
        stbMACAddress: '54:E2:E0:FB:98:48',
        status: 1 }
    ] },
  subsciber_Gkhq32M9gMUnjAuBy53r: {
    bouquetId: 'dyDg0kp8PYzlL09G',
    polkaId: '4610510076',
    accountId: '00983042476299939820',
    pdaId: 'u9eBSgDweUl9tMwtPOL5SblvC850wm',
    smartcardSN: '29136707006',
    telcoFlag: 'passed',
    telcoId: '6913254599292872',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'FMSD773ZeFDwmebl69aBT4KFhMwKQpeB',
        uuid: '1942442159',
        label: '2WHj',
        stbSN: 'AF13010492000784',
        stbId: '4272230766',
        stbMACAddress: '54:E2:E0:FB:80:EC',
        status: 1 }
    ] },
  subsciber_SBh7by85tANOtZ4Ydhh7: {
    bouquetId: 'Ndr1In1qVJCXFcPP',
    polkaId: '0909712231',
    accountId: '21809086365444361419',
    pdaId: 'F2nVR0lQC2J931a4Zkuq9Uer9taqHe',
    smartcardSN: '52169838329',
    telcoFlag: 'passed',
    telcoId: '4112025491674064',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'vEhVfnK9hV1PEHorRXV3s4c3ff5GFqaf',
        uuid: '1019481619',
        label: 'W9nu',
        stbSN: 'AF13010492000686',
        stbId: '4272230808',
        stbMACAddress: '70:85:C6:EF:FB:14',
        status: 1 }
    ] },
  subsciber_Y30e51yXvkS5GvRk5Wkt: {
    bouquetId: 'j5zPrF9USMCDdElq',
    polkaId: '0021293946',
    accountId: '31528716263872938670',
    pdaId: 'sAxanD97In0I9iXgblL6sCUShxizK6',
    smartcardSN: '39269744648',
    telcoFlag: 'passed',
    telcoId: '3357559847778482',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'SS5FMZJonCob8o8zvOIOhurnBpSwP2uB',
        uuid: '1801849022',
        label: 'xIIG',
        stbSN: 'AF13010492000735',
        stbId: '4272230744',
        stbMACAddress: '54:E2:E0:FB:80:8A',
        status: 1 }
    ] },
  subsciber_Y2Y1b872MGtSRtXFXAnt: {
    bouquetId: 'iERmslGug3Zm0XGp',
    polkaId: '7874496667',
    accountId: '48968042003154352286',
    pdaId: 'b4HPlGJ5OaIlIB9kwyFMFPJWhCVT0Z',
    smartcardSN: '29419438229',
    telcoFlag: 'passed',
    telcoId: '9119937427428870',
    skyStatus: 'provisioned',
    devices: [
      { _id: 'aL0ac9M2HGgzuDKBQzFZqYKOiPmNMHmk',
        uuid: '4686543685',
        label: 'Yy2y',
        stbSN: 'AF13010492000785',
        stbId: '4272230772',
        stbMACAddress: '54:E2:E0:FB:80:EE',
        status: 1 }
    ] }


  //SERBIAN STB
};

module.exports = permission;