/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expthis.responsesed written
 * permission of Wyplay.
 */

// Default schema for channel/radio document
var validate = require('mongoose-validator');
var util = require('util');
var deviceSchema = new (require('./device'))();
var profileSchema = new (require('./profile'))();
var deviceInstanceSchema = new (require('./deviceInstance'))();

function subscriberSchema() {
  /* jshint validthis:true */
  'use strict';

  var validateLength = function (min, max) {
    return validate({
      validator: 'isLength',
      arguments: [min, max]
    });
  }

  Container.parentMongooseSchemaWithId.apply(this, arguments);
  this.add({
    polkaId: {
      type: 'string',
      required: true,
      validate: validateLength(10, 10),
      unique: true,
      match: /^[0-9]+$/,
      set: function (val) {
        this._id = val;
        return val;
      }
    },
    accountId: {
      type: 'string',
      required: true,
      validate: validateLength(20, 20)
    },
    pdaId: {
      type: 'string',
      required: true,
      validate: validateLength(30, 30)
    },
    smartcardSN: {
      type: 'number',
      required: true,
      isInteger: true,
      validate: validateLength(1, 11)
    },
    devices: {
      type: [deviceSchema],
      uniqueKey: [
        ['uuid', 'stbId']
      ],
      primaryKey: 'stbId'
    },
    profiles: {
      type: [profileSchema],
      uniqueKey: [
        ['label']
      ]
    },
    deviceInstances: {
      type: [deviceInstanceSchema],
      uniqueKey: [
        [
          ['deviceId', 'applicationId']
        ]
      ]
    },
    telcoId: {
      type: 'string',
      required: true,
      validate: validateLength(16, 16)
    },
    bouquetId: {
      type: 'string',
      validate: validateLength(16, 16)
    },
    bouquetIdFlag: {
      type: 'boolean',
      default: false
    },
    telcoFlag: {
      type: 'string',
      enum: ['passed', 'true', 'false'],
      default: true,
      lowercase: true
    },
    skyStatus: {
      type: 'string',
      enum: ['provisioned', 'installed'],
      required: true,
      lowercase: true
    },
    telcoStatus: {
      type: 'string',
      enum: ['provisioned', 'installed', 'inactive'],
      lowercase: true
    }
  });

  // Hook to remove session associated to a subscriber when subscriber is updated (disable during fixtures loading)
  if (!Container.fixturesMode) {
    this.hook = function (doc, callback) {
      if (typeof doc !== 'object') {
        doc = {_id: doc};
      }
      var repositorySession = new Container.sessionManager.repository.repositorySession();
      repositorySession.delete({subscriberId: doc._id}, function (err, documents) {
        if (callback) {
          callback();
        }
      });
    };
    this.post('save', this.hook);
    this.post('remove', this.hook);
  }
}

util.inherits(subscriberSchema, Container.parentMongooseSchemaWithId);
module.exports = subscriberSchema;
