/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expthis.responsesed written
 * permission of Wyplay.
 */

// Default schema for channel/radio document
var validate = require('mongoose-validator');
var util = require('util');

function deviceSchema() {
  /* jshint validthis:true */
  'use strict';

  var validateLength = function (min, max) {
    return validate({
      validator: 'isLength',
      arguments: [min, max]
    });
  }

  Container.parentMongooseSchemaWithId.apply(this, arguments);
  this.add({
    uuid: {
      type: 'string',
      required: true,
      validate: validateLength(10, 10),
      notUpdateable : true
    },
    label: {
      type: 'string',
      required: true,
      default: 'device'
    },
    status: {
      type: 'number',
      enum: [0, 1],
      required: true,
      default: 1
    },
    stbSN: {
      type: 'string',
      required: true,
      validate: validateLength(16, 16)
    },
    stbId: {
      type: 'string',
      required: true,
      validate: validateLength(10, 10),
      match: /^[0-9]+$/,
      set: function (value) {
        this.uuid = value;
        return value;
      }
    },
    stbMACAddress: {
      type: 'string',
      match: /^((([0-9A-F]{2}:){5}[0-9A-F]{2})|)$/
    },
    stbCertificateSN: {
      type: 'string',
      default: ''
    },
    stbCertificateExpiry: {
      type: 'number', // Number because date must be saved as a GMT timestamp
      isInteger: true,
      default: 0
    },
    stbCertificateRevokedFlag: {
      type: 'boolean',
      default: false
    },
    stbSoftwareVersion: {
      type: 'string',
      default: ''
    },
    stbBootloader2Version: {
      type: 'string',
      default: ''
    }
  });
}
util.inherits(deviceSchema, Container.parentMongooseSchemaWithId);
module.exports = deviceSchema;