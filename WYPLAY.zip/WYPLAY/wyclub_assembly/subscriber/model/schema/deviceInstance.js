/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expthis.responsesed written
 * permission of Wyplay.
 */

// Default schema for channel/radio document
var util = require('util');

function deviceInstanceSchema() {
  /* jshint validthis:true */
  'use strict';

  Container.parentMongooseSchemaWithId.apply(this, arguments);
  this.add({
    deviceId: {
      type: 'string'
    },
    applicationId: {
      type: 'string'
    }
  });
}
util.inherits(deviceInstanceSchema, Container.parentMongooseSchemaWithId);
module.exports = deviceInstanceSchema;
