var globalSettings = [
  {
    'key': 'telcoFlag',
    'value': 'true'
  }
];

module.exports = globalSettings;
