var params = {};

params.databaseUrl = process.env.MONGODB_PORT_27017_TCP_ADDR;
params.databaseName = 'schedule';
params.databaseUser = 'schedule';
params.databasePassword= 'schedule';
params.databaseAuthdb = 'schedule';

params.storageMongo = {
  local: {
    'hosts': [process.env.MONGODB_PORT_27017_TCP_ADDR],
    'port': 27017,
    'user': 'storage',
    'password': 'storage',
    'options': {
      'auto_reconnect': true,
      'poolSize': 5,
      'socketOptions': {}
    }
  }
};

params.storageDatabase = {
  'dbName': 'storage',
  'server': 'local',
  'options': { 'w': 1 }
};


params.OriginLinkUrl = process.env.ORIGIN_SERVER_HOST;
params.envName = process.env.ORIGIN_SERVER_ENVNAME;
params.OriginLinkInitialPath = (params.envName==="WPDEVBE")?'/cdn_proxy':'';
params.cdnUrl = 'http://data.oscdn.any.sky.it/';

module.exports = params;


params.cdnUrl = 'http://data.oscdn.any.sky.it/';

//no db needed for that module
module.exports = params;
