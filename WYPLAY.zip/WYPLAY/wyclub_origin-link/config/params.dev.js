var params = {};

params.databaseUrl = 'localhost';
params.databaseName = 'schedule';

params.storageMongo = {
  local: {
    'hosts': ['127.0.0.1'],
    'port': 27017,
    'user': '',
    'password': '',
    'options': {
      'auto_reconnect': true,
      'poolSize': 5,
      'socketOptions': {}
    }
  }
};

params.storageDatabase = {
  'dbName': 'storage',
  'server': 'local',
  'options': { 'w': 1 }
};

params.OriginLinkUrl = (process.env.ORIGIN_SERVER_HOST)?process.env.ORIGIN_SERVER_HOST:'10.60.50.200';
params.envName = (process.env.ORIGIN_SERVER_ENVNAME)?process.env.ORIGIN_SERVER_ENVNAME:'WPDEVBE';
params.OriginLinkInitialPath = (params.envName==="WPDEVBE")?'/cdn_proxy':'';
params.cdnUrl = 'http://data.oscdn.any.sky.it/';

module.exports = params;
