var path = require('path');
var async = require('async');
var resourceDeliveryToolBck = Container.resourceDelivery.lib.resourceDeliveryTool;

Container.resourceDelivery.lib.resourceDeliveryTool.declareResource = function(params, callback){
  params.resourceName="modified";
  callback(null, params);
};

exports.testRequiredFunction = function(test){

  Container.originLink.lib.originLinkTool.declareResource({resourceName: 'fullEpg.json', resourcePath:'/var/lib/toto/epg.json', resourceType:'epg', resourceVersion:'1.1.6'}, function(err,data){
    test.equal(err, "RESOURCE_PATH_INCORRECT");
    test.done();
  });
};


exports.testRequiredFunction = function(test){

  var resourcePath = path.resolve('./app.js');
  Container.originLink.lib.originLinkTool.declareResource({resourceName: 'fullEpg.json', resourcePath:resourcePath, resourceType:'epg', resourceVersion:'1.1.6'}, function(err,data){
    console.log(err);
    test.equal(err, null, 'No error should be raised');
    test.equal(typeof data.resourceUrl, 'string', 'data should have a field resourceUrl');
    test.equal(data.resourceName, 'modified', 'resourceDelivery.declareResource should have been called');

    Container.resourceDelivery.lib.resourceDeliveryTool = resourceDeliveryToolBck;

    test.done();
  });
};
