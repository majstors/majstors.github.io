//rule: swipeFrom
var rule_NCLShHI3YBj20MjaysTyqg8Vwy0WktfO = function(req, sentData, finalCallback){
    Core.log('RULES ---- swipeFrom execution');
    var cbFired = false;
    var ruleCallback = function(err, data){
        clearTimeout(timeout);
        if(!cbFired){cbFired = true;finalCallback(err,data);}
    };
    var timeout = setTimeout(function(){finalCallback('timeout',false);},1000);
    var system = require('../../lib/ruleTools.js');
    var sessionContext = require('../../lib/sessionContext.js');
    var async = require('async');
    var underscore = require('underscore');
    try{
///////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Begin Rule Source Code ////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
var myEvent = {};
myEvent = {};
myEvent.eventName = req.body.eventName;
myEvent.eventValue = req.body.eventValue;
if(myEvent.eventValue && myEvent.eventName && myEvent.eventName == "swipeFrom"){
  //Core.log("Swipe From".yellow);
  var wyclubToken = null;
  if(req && req.params && req.params.wyclubToken){
      wyclubToken = req.params.wyclubToken;
  }
  sessionContext.read(req, function(err,currentSession){
    if(err !== null){
        ruleCallback(err, false);
    } else {
      if(currentSession &&       currentSession.application &&       currentSession.application._id &&       currentSession.application._id == "simpleui123456789123456789123456"){
        var swipe = JSON.parse(myEvent.eventValue);
        if(typeof swipe == 'object') {
          Core.repository.session.read({wyclubToken: swipe.sessionOrigin},            function(err,swipeFromSession){
              if(err !== null){
                  ruleCallback(err,false);
              } else {
                  swipeFromSession.status = 0;
                  Core.repository.session.update({session: swipeFromSession},                    function(err, swipeFromSessionDisable){
                      if(err !== null){
                          ruleCallback(err,false);
                      } else {
                          var mySession = system.clone(currentSession);
                          Core.repository.session.createHalfSisterSession(                             {                               applicationId:swipeFromSession.application._id,                               session: mySession                             },                             function(err,halfSisterSess){
                              if(err !== null) {
                                  ruleCallback(err,false);
                              } else {
                                  halfSisterSess.device = swipeFromSession.device;
                                  Core.repository.session.update({session: halfSisterSess},                                   function(err, swipedSession){
                                      swipe.newSession = halfSisterSess._id;
                                      swipe.myProfile = currentSession.profile._id;
                                      myEvent.eventValue = JSON.stringify(swipe);
                                      Core.eventBroker.publishChannel(                                       swipeFromSession.application._id,                                       {                                        'session': swipeFromSession._id,                                        'event': myEvent,                                        'otherInformations': {}                                       }                                      );
                                      for( var i = 0; i < currentSession.subscriber.profiles.length; i++){
                                          if(currentSession.subscriber.profiles[i].label == "Family"){
                                              currentSession.profile = currentSession.subscriber.profiles[i];
                                              i = currentSession.subscriber.profiles.length;
                                          }
                                      }
                                      var eventOriginSession = system.clone(myEvent);
                                      if(currentSession.profile.label == "Family"){
                                        eventOriginSession.eventValue = JSON.stringify(                                          {"myProfile":currentSession.profile._id}                                        );
                                        Core.eventBroker.publishChannel(currentSession.application._id,                                         {                                           'session': wyclubToken,                                           'event': eventOriginSession,                                           'otherInformations': {}                                         });
                                        ruleCallback();
                                      } else {
                                          ruleCallback("No Profile Family for this sub",false);
                                      }
                                  });
                              }
                          });
                      }
                  });
              }
          });
        } else {
            ruleCallback(null,false);
        }
      } else {
          ruleCallback(null, true);
      }
    }
  });
} else {
 ruleCallback(null, true);
}
///////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////// End Rule Source Code /////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
    } catch(err) {
      Core.log(Core.colors.red(err.toString()));
      Core.log(new Error().stack);
      ruleCallback(err,false);
    }
};
module.exports = rule_NCLShHI3YBj20MjaysTyqg8Vwy0WktfO;