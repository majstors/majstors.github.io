//rule: swipeTo
var rule_OnmvbCMT270MURsLSxiDPrPoACBtD5MS = function(req, sentData, finalCallback){
    Core.log('RULES ---- swipeTo execution');
    var cbFired = false;
    var ruleCallback = function(err, data){
        clearTimeout(timeout);
        if(!cbFired){cbFired = true;finalCallback(err,data);}
    };
    var timeout = setTimeout(function(){finalCallback('timeout',false);},1000);
    var system = require('../../lib/ruleTools.js');
    var sessionContext = require('../../lib/sessionContext.js');
    var async = require('async');
    var underscore = require('underscore');
    try{
///////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Begin Rule Source Code ////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
var myEvent = {};
myEvent.eventName = req.body.eventName;
myEvent.eventValue = req.body.eventValue;
if (myEvent.eventValue && myEvent.eventName && myEvent.eventName === 'swipeTo') {
  Core.log('Swipe To'.yellow);
  var wyclubToken = null;
  if (req && req.params && req.params.wyclubToken) {
    wyclubToken = req.params.wyclubToken;
  }
  sessionContext.read(req, function (err, currentSession) {
    if (err !== null) {
      ruleCallback(err, false);
    } else {
      if (currentSession &&         currentSession.application &&         currentSession.application._id &&         currentSession.application._id === 'simpleui123456789123456789123456') {
        var swipe = JSON.parse(myEvent.eventValue);
        if (typeof swipe === 'object') {
          Core.repository.session.read({ wyclubToken: swipe.sessionTarget }, function (err, swipeToSession) {
            if (err !== null) {
              ruleCallback(err, false);
            } else {
              var mySession = system.clone(currentSession);
              Core.repository.session.createHalfSisterSession({
                applicationId: swipeToSession.application._id,
                session: mySession
              }, function (err, halfSisterSess) {
                if (err !== null) {
                  ruleCallback(err, false);
                } else {
                  swipeToSession.status = 0;
                  Core.repository.session.update({ session: swipeToSession },                    function (err, swipeToSessionDisable) {
                    if (err !== null) {
                      ruleCallback(err, false);
                    }
                  });
                  halfSisterSess.deviceId = swipeToSession.device._id;
                  Core.repository.session.update({ session: halfSisterSess }, function (err, swipedSession) {
                    swipe.newSession = halfSisterSess._id;
                    myEvent.eventValue = JSON.stringify(swipe);
                    Core.eventBroker.publishChannel(swipeToSession.application._id, {
                      'session': swipeToSession._id,
                      'event': myEvent,
                      'otherInformations': {}
                    });
                    for (var i = 0; i < currentSession.subscriber.profiles.length; i++) {
                      if (currentSession.subscriber.profiles[i].label === 'Family') {
                        currentSession.profile = currentSession.subscriber.profiles[i];
                        i = currentSession.subscriber.profiles.length;
                      }
                    }
                    var eventOriginSession = system.clone(myEvent);
                    if (currentSession.profile.label === 'Family') {
                      eventOriginSession.eventValue = JSON.stringify({                       'myProfile': currentSession.profile._id                       });
                      Core.eventBroker.publishChannel(currentSession.application._id, {
                        'session': wyclubToken,
                        'event': eventOriginSession,
                        'otherInformations': {}
                      });
                    } else {
                      ruleCallback('No Profile Family for this sub', false);
                    }
                  });
                }
              });
            }
          });
        } else {
          ruleCallback(null, false);
        }
      } else {
        ruleCallback(null, true);
      }
    }
  });
} else {
  ruleCallback(null, true);
}
///////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////// End Rule Source Code /////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
    } catch(err) {
      Core.log(Core.colors.red(err.toString()));
      Core.log(new Error().stack);
      ruleCallback(err,false);
    }
};
module.exports = rule_OnmvbCMT270MURsLSxiDPrPoACBtD5MS;