//rule: contactSession
var rule_aaaaaaaaaaaaaaaaaaaaaaa = function(req, sentData, finalCallback){
    Core.log('RULES ---- contactSession execution');
    var cbFired = false;
    var ruleCallback = function(err, data){
        clearTimeout(timeout);
        if(!cbFired){cbFired = true;finalCallback(err,data);}
    };
    var timeout = setTimeout(function(){finalCallback('timeout',false);},1000);
    var system = require('../../lib/ruleTools.js');
    var sessionContext = require('../../lib/sessionContext.js');
    var async = require('async');
    var underscore = require('underscore');
    try{
///////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Begin Rule Source Code ////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
var myEvent = {};
myEvent.eventName = req.body.eventName;
myEvent.eventValue = req.body.eventValue;
try {
    myEvent.eventValue = JSON.parse(myEvent.eventValue);
} catch(error){
    //ruleCallback(null, false);
}
if(myEvent.eventValue && myEvent.eventName && myEvent.eventName == "contactSession"){
    console.log(Core.colors.green("contactSession"));
	sessionContext.read(req, function(err,currentSession){
        console.log("session source trouvée".yellow, currentSession);
		if(err !== null){
            console.log("error".red, err);
			ruleCallback(null, false);
		} else {
            console.log(Core.colors.green("no error"));
            var _ = require('underscore');
            if(_.isArray(myEvent.eventValue.targetedSession) &&             myEvent.eventValue.targetedSession.length > 0){
                async.eachSeries(myEvent.eventValue.targetedSession, function(session, cb){
                    var where = {};
                    if(currentSession.subscriber){
                        where.subscriberId = currentSession.subscriber._id;
                    }
                    where.wyclubToken = session;
                    Core.repository.session.read(where, function(err,targetedSessions){
                        if(err){
                            console.log("error".red, err);
                            cb(null, false);
                        } else {
                            console.log(Core.colors.green("no error"));
                            if(targetedSessions && !targetedSessions[0]){
                                targetedSessions = [targetedSessions];
                            }
                            async.eachSeries(targetedSessions, function(targetedSession, cb){
                                console.log("session target trouvée".yellow, targetedSession);
                                var sessionOk = true;
                                if(myEvent.eventValue.where && myEvent.eventValue.where.tags){
                                }
                                if(sessionOk){
                                    console.log("event launched".yellow);
                                    Core.eventBroker.publishChannel(targetedSession.application._id,                                     {                                       'session': targetedSession._id,                                       'event': myEvent.eventValue.message,                                       'otherInformations': {}                                     });
                                }
                                cb(null);
                            }, function(){
                                cb(null, true);
                            });
                        }
                    });
                }, function(err){
                    ruleCallback(err, true);
                });
            } else {
                var where = {};
                if(currentSession.subscriber){
                    where.subscriberId = currentSession.subscriber._id;
                }
                console.log(myEvent);
                if(myEvent.eventValue.targetedSession){
                    where.wyclubToken = myEvent.eventValue.targetedSession;
                } else if (myEvent.eventValue.where) {
                    if(myEvent.eventValue.where.sameProfile){
                        where.profileId = currentSession.profile._id;
                    }
                    if(myEvent.eventValue.where.sameDevice){
                        where.deviceId = currentSession.device._id;
                    }
                }
                console.log("selector".yellow, where);
                Core.repository.session.read(where, function(err,targetedSessions){
                    if(err){
                        console.log("error".red, err);
                        ruleCallback(null, false);
                    } else {
                        console.log("no error".green);
                        if(targetedSessions && !targetedSessions[0]){
                            targetedSessions = [targetedSessions];
                        }
                        async.eachSeries(targetedSessions, function(targetedSession, cb){
                            console.log("session target trouvée".yellow, targetedSession);
                            var sessionOk = true;
                            if(myEvent.eventValue.where && myEvent.eventValue.where.tags){
                            }
                            if(sessionOk){
                                console.log("event launched".yellow);
                                Core.eventBroker.publishChannel(targetedSession.application._id,                                 {                                   'session': targetedSession._id,                                   'event': myEvent.eventValue.message,                                   'otherInformations': {}                                 });
                            }
                            cb(null);
                        }, function(){
                            ruleCallback(null, true);
                        });
                    }
                });
            }
		}
	});	
} else {
	ruleCallback(null, true);
}
///////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////// End Rule Source Code /////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
    } catch(err) {
      Core.log(Core.colors.red(err.toString()));
      Core.log(new Error().stack);
      ruleCallback(err,false);
    }
};
module.exports = rule_aaaaaaaaaaaaaaaaaaaaaaa;