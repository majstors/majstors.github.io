//rule: recoverContent
var rule_Ga3MCBE7NN3V97TJyhWr1HvPE26Coxfi = function(req, sentData, finalCallback){
    Core.log('RULES ---- recoverContent execution');
    var cbFired = false;
    var ruleCallback = function(err, data){
        clearTimeout(timeout);
        if(!cbFired){cbFired = true;finalCallback(err,data);}
    };
    var timeout = setTimeout(function(){finalCallback('timeout',false);},1000);
    var system = require('../../lib/ruleTools.js');
    var sessionContext = require('../../lib/sessionContext.js');
    var async = require('async');
    var underscore = require('underscore');
    try{
///////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Begin Rule Source Code ////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
var myEvent = {};
myEvent.eventName = req.body.eventName;
myEvent.eventValue = req.body.eventValue;
if(myEvent.eventValue && myEvent.eventName && myEvent.eventName == "recoverContent"){
    Core.log("Recover content".yellow);
    var wyclubToken = null;
    if(req && req.params && req.params.wyclubToken){
        wyclubToken = req.params.wyclubToken;
    }
    sessionContext.read(req, function(err,currentSession){
        if(err !== null){
            ruleCallback(err, false);
        } else {
            if(currentSession &&             currentSession.application &&             currentSession.application._id &&             currentSession.application._id == "simpleui123456789123456789123456"){
                var swipe = JSON.parse(myEvent.eventValue);
                if(typeof swipe == "object") {
                    Core.repository.session.read({wyclubToken: swipe.sessionTarget},function(err,targetSess){
                        if(err !== null) {
                            ruleCallback(err,false);
                        } else {
                            Core.eventBroker.publishChannel(targetSess.application._id,                             {'session': targetSess._id, 'event': myEvent,'otherInformations': {}});
                            ruleCallback();
                        }
                    });
                }
            } else {
                ruleCallback(null, true);
            }
        }
    });
} else {
    ruleCallback(null, true);
}
///////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////// End Rule Source Code /////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
    } catch(err) {
      Core.log(Core.colors.red(err.toString()));
      Core.log(new Error().stack);
      ruleCallback(err,false);
    }
};
module.exports = rule_Ga3MCBE7NN3V97TJyhWr1HvPE26Coxfi;