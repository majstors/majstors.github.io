//rule: settingChange
var rule_6OWlIOcaXlhqO4bQsaAUadtWTOM8wLAQ = function(req, sentData, finalCallback){
    Core.log('RULES ---- settingChange execution');
    var cbFired = false;
    var ruleCallback = function(err, data){
        clearTimeout(timeout);
        if(!cbFired){cbFired = true;finalCallback(err,data);}
    };
    var timeout = setTimeout(function(){finalCallback('timeout',false);},1000);
    var system = require('../../lib/ruleTools.js');
    var sessionContext = require('../../lib/sessionContext.js');
    var async = require('async');
    var underscore = require('underscore');
    try{
///////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Begin Rule Source Code ////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
var myEvent = {}; 
myEvent.eventName = req.body.eventName; 
myEvent.eventValue = req.body.eventValue; 
if(myEvent.eventValue && myEvent.eventName && myEvent.eventName == "settingChange"){ 
	var wyclubToken = null; 
	if(req && req.params && req.params.wyclubToken){ 
		wyclubToken = req.params.wyclubToken; 
	} 
	sessionContext.read(req, function(err,currentSession){ 
		if(err !== null){ 
			ruleCallback(null, false); 
		} else { 
			if(currentSession &&       currentSession.application &&       currentSession.application._id &&       currentSession.application._id == "simpleui123456789123456789123456"){ 
				Core.repository.session.readHalfSisterSessions(currentSession, function(err,otherSessions){ 
					if(err == 'NO_SESSION'){ 
						err = null; 
					} 
					otherSessions.push(currentSession);
					if(err !== null || !otherSessions || otherSessions.length <= 0){ 
						ruleCallback(null, false); 
					} else { 
						async.eachSeries(otherSessions,function(mySess,callback){ 
							Core.repository.session.read({wyclubToken: mySess._id}, function(err, mySess){
								if(mySess && mySess.application && mySess.application._id){ 
									Core.eventBroker.publishChannel(mySess.application._id,                   {'session': mySess._id, 'event': myEvent,'otherInformations': {}}                 );
									callback();
								} else { 
									callback(); 
								} 
							});
						}, function(err){ 
							ruleCallback(null, true); 
						}) 
					} 
				}); 
			} else { 
				ruleCallback(null, true); 
			} 
		} 
	});	 
} else { 
	ruleCallback(null, true); 
}
///////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////// End Rule Source Code /////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
    } catch(err) {
      Core.log(Core.colors.red(err.toString()));
      Core.log(new Error().stack);
      ruleCallback(err,false);
    }
};
module.exports = rule_6OWlIOcaXlhqO4bQsaAUadtWTOM8wLAQ;