//rule: unlockVideo
var rule_KtPY9JPVrnGooruKwWMsXqrh9UzCuo0W = function(req, sentData, finalCallback){
    Core.log('RULES ---- unlockVideo execution');
    var cbFired = false;
    var ruleCallback = function(err, data){
        clearTimeout(timeout);
        if(!cbFired){cbFired = true;finalCallback(err,data);}
    };
    var timeout = setTimeout(function(){finalCallback('timeout',false);},1000);
    var system = require('../../lib/ruleTools.js');
    var sessionContext = require('../../lib/sessionContext.js');
    var async = require('async');
    var underscore = require('underscore');
    try{
///////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Begin Rule Source Code ////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
var myEvent = {};
myEvent.eventName = req.body.eventName;
myEvent.eventValue = req.body.eventValue;
if(myEvent.eventValue && myEvent.eventName && myEvent.eventName == "unlockVideo"){
	var wyclubToken = null;
	if(req && req.params && req.params.wyclubToken){
		wyclubToken = req.params.wyclubToken;
	}
	sessionContext.read(req, function(err,currentSession){
		if(err !== null){
			ruleCallback(null, false);
		} else {
			if(currentSession &&       currentSession.application &&       currentSession.application._id &&       currentSession.application._id == "simpleui123456789123456789123456" &&       currentSession.profile &&       system.getAgeFromDate(currentSession.profile.birthdate) > 18){
				myEvent.eventValue = JSON.parse(myEvent.eventValue);
				var where = {wyclubToken: myEvent.eventValue.targetedSession}; 
				Core.repository.session.read(where, function(err,targetedSession){
					if(targetedSession &&           targetedSession._id &&           targetedSession.application &&           targetedSession.application._id){
						Core.eventBroker.publishChannel(targetedSession.application._id,           {            'session': targetedSession._id,            'event': {              eventName:"unlockVideo",              eventValue: {                profileName: myEvent.eventValue.profileName                }              },            'otherInformations': {}           });
						ruleCallback(null, true);
					} else {
						ruleCallback(null, false);
					}
				});
			} else {
				ruleCallback(null, false);
			}
		}
	});	
} else {
	ruleCallback(null, true);
}
///////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////// End Rule Source Code /////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
    } catch(err) {
      Core.log(Core.colors.red(err.toString()));
      Core.log(new Error().stack);
      ruleCallback(err,false);
    }
};
module.exports = rule_KtPY9JPVrnGooruKwWMsXqrh9UzCuo0W;