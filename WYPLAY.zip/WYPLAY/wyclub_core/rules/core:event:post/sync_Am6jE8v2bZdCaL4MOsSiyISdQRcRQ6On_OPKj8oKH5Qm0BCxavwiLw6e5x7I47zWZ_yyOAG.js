//rule: updateCurrentContent
var rule_Am6jE8v2bZdCaL4MOsSiyISdQRcRQ6On = function(req, sentData, finalCallback){
    Core.log('RULES ---- updateCurrentContent execution');
    var cbFired = false;
    var ruleCallback = function(err, data){
        clearTimeout(timeout);
        if(!cbFired){cbFired = true;finalCallback(err,data);}
    };
    var timeout = setTimeout(function(){finalCallback('timeout',false);},1000);
    var system = require('../../lib/ruleTools.js');
    var sessionContext = require('../../lib/sessionContext.js');
    var async = require('async');
    var underscore = require('underscore');
    try{
///////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Begin Rule Source Code ////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
var wyclubToken = null;
if(req && req.params && req.params.wyclubToken){
   wyclubToken = req.params.wyclubToken;
}
sessionContext.read(req, function(err,currentSession){
   if(err !== null){
       ruleCallback(err, true);
   } else {
       if(currentSession && currentSession._id){
           var currentContent = req.body.currentContent;
            if(typeof currentContent == "string"){
                try {
                    currentContent = JSON.parse(currentContent);
                } catch (err) {
                    currentContent = undefined;
                }
            }
           if(currentContent !== null && currentContent !== undefined)
            {
               Core.repository.session.updateCurrentContent({                 wyclubToken: currentSession._id,                 content: currentContent.content,                 origin: currentContent.origin               },function(err,data){
               if(data.content == currentContent.content && data.origin == currentContent.origin)
                    {
                        ruleCallback(null,true);
                    } else {
                        Core.log("current content insertion has failed.".red);
                        ruleCallback("current content insertion has failed.",true);
                    }
               });
            } else {
               ruleCallback(null, true);
            }
       } else {
           ruleCallback(null, true);
       }
   }
});

///////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////// End Rule Source Code /////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
    } catch(err) {
      Core.log(Core.colors.red(err.toString()));
      Core.log(new Error().stack);
      ruleCallback(err,false);
    }
};
module.exports = rule_Am6jE8v2bZdCaL4MOsSiyISdQRcRQ6On;