//rule: bootloaderUpdateProfile
var rule_ruleBootloaderUpdateProfile = function(req, sentData, finalCallback){
    Core.log('RULES ---- bootloaderUpdateProfile execution');
    var cbFired = false;
    var ruleCallback = function(err, data){
        clearTimeout(timeout);
        if(!cbFired){cbFired = true;finalCallback(err,data);}
    };
    var timeout = setTimeout(function(){finalCallback('timeout',false);},1000);
    var system = require('../../lib/ruleTools.js');
    var sessionContext = require('../../lib/sessionContext.js');
    var async = require('async');
    var underscore = require('underscore');
    try{
///////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Begin Rule Source Code ////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
//Helpers
function parseJSON(val){
  var result;
  try{
    result = JSON.parse(val);
  }catch(err){
    result = null;
  }
  return result;
}
var simpleCompare = function (object, value) {
  if(!object){
    return true
  }
  var isMultiple = (typeof object.value !== 'undefined' && typeof object.value.indexOf === "function" && object.value.indexOf(';') !== -1);
  var test = true;
  console.log('try to compare: ' + object.value + ' and ' + value + ' with operator ' + object.operator);
  if (isMultiple) {
    test = (object.value.indexOf(value) !== -1);
  } else {
    switch (object.operator) {
      case '=':
        test = (object.value === value);
        break;
      case '!=':
        test = (object.value !== value);
        break;
      case '<':
        test = (object.value < value);
        break;
      case '>':
        test = (object.value > value);
        break;
      case '<=':
        test = (object.value <= value);
        break;
      case '>=':
        test = (object.value >= value);
        break;
      default:
        test = (object.value === value);
        break;
    }
  }
  if (object.range && object.range.length > 0) {
    object.range.forEach(function (range) {
      test = test || rangeCompare(value, range.min, range.max);
    });
  }
  return test;
};
var rangeCompare = function (value, min, max) {
  var test = (min <= value && value <= max);
  return test;
};
//end of helpers

if(req && req.body && req.body.eventName && typeof req.body.eventName.indexOf !== 'undefined' && req.body.eventName.toLowerCase().indexOf("getbootloader") !== -1) {
  var activated = 'true' === 'true';
  if(activated === true) {
    var wyclubToken = null;
    if (req && req.params && req.params.wyclubToken) {
      wyclubToken = req.params.wyclubToken;
    }
    sessionContext.read(req, function (err, currentSession) {
      if (err !== null) {
        ruleCallback(err, true);
      } else {
        if (currentSession && currentSession._id) {

          /* set session variables */
          var stbSN = currentSession.device.stbSN;
          var currentResourceVersion = currentSession.device.stbSoftwareVersion;

          //see if these ones aren't set in sub information
          var hardwareModel = stbSN.substr(4, 2);
          var allTests = {};

          var hardwareModel_object = parseJSON('{"value":"01","operator":"="}');
          allTests.hardwareModel_Test = simpleCompare(hardwareModel_object, hardwareModel);

          var currentSoftwareVersion_object = parseJSON('{{currentSoftwareVersion}}');
          allTests.currentSoftwareVersion_Test = simpleCompare(currentSoftwareVersion_object, currentResourceVersion);

          /* set the tag to deliver if conditions are ok */
          var resourceName = 'wyplay_bootloader_1';
          var resourceVersion = '1';
          var mandatory = 'true';
          var forced = 'false';
          var installationType = 'standby';
          var priority = '5';
          if (isNaN(priority)) {
            priority = 0;
          }
          var allTestsResult = true;
          console.log(allTests);
          Object.keys(allTests).forEach(function (currentTestResult) {
            allTestsResult = allTestsResult && allTests[currentTestResult];
          });
          if (allTestsResult) {
            //campain is ok for that session
            if (!req.beforeRulesResults) {
              req.beforeRulesResults = {};
            }
            if (!req.beforeRulesResults.bootloader || req.beforeRulesResults.bootloader.priority < priority) {
              req.beforeRulesResults.bootloader = {
                resourceName: resourceName,
                resourceVersion: resourceVersion,
                mandatory: mandatory,
                forced: forced,
                installationType: installationType,
                priority: priority
              };
              ruleCallback(null, true);
            } else {
              ruleCallback(err, false);
            }
          } else {
            ruleCallback(null, false);
          }
        }
      }
    });
  } else {
    ruleCallback(null, false);
  }
} else {
  ruleCallback(null, false);
}


///////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////// End Rule Source Code /////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
    } catch(err) {
      Core.log(Core.colors.red(err.toString()));
      Core.log(new Error().stack);
      ruleCallback(err,false);
    }
};
module.exports = rule_ruleBootloaderUpdateProfile;