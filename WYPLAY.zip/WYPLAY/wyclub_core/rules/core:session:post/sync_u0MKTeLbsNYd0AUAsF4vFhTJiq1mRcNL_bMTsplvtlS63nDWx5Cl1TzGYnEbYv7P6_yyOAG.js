//rule: maxNumberOfSessions
var rule_u0MKTeLbsNYd0AUAsF4vFhTJiq1mRcNL = function(req, sentData, finalCallback){
    Core.log('RULES ---- maxNumberOfSessions execution');
    var cbFired = false;
    var ruleCallback = function(err, data){
        clearTimeout(timeout);
        if(!cbFired){cbFired = true;finalCallback(err,data);}
    };
    var timeout = setTimeout(function(){finalCallback('timeout',false);},1000);
    var system = require('../../lib/ruleTools.js');
    var sessionContext = require('../../lib/sessionContext.js');
    var async = require('async');
    var underscore = require('underscore');
    try{
///////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Begin Rule Source Code ////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
var uuId = null;var subscriberId = null;var applicationId = null;var x = 50;
if(req && req.body && req.body.subscriberId){
   subscriberId = req.body.subscriberId;
}
if(req && req.params && req.params.applicationId){
   applicationId = req.params.applicationId;
}
if(req && req.body && req.body.uuid){
   uuId = req.body.uuid;
}
if(applicationId !== undefined && applicationId !== null && applicationId === 'simpleui123456789123456789123456') {
if (uuId !== null && subscriberId === null) {
	Core.query.mongodbStatic.subscriber.readQuery({'devices.uuid': uuId}, function(err, subscriber) {
       if(err === null) {
           subscriberId = subscriber._id;
       }
       if(subscriberId !== undefined &&         applicationId !== undefined &&         subscriberId !== null &&         applicationId !== null) {	         Core.query.mongodbSession.session.readCustom({status: 1, applicationId: applicationId,           subscriberId: subscriberId}, function(err, session) {
               if(err !== null) {                 ruleCallback(null, true);
               } else {
                   if(session.length >= x) {
                       ruleCallback('Max session', false);
                   } else {
                       ruleCallback(null, true);
                   }
               }
           });
       } else {         ruleCallback(null, true);
       }
   });
} else if (uuId !== null && subscriberId !== null) {
   if(subscriberId !== undefined &&     applicationId !== undefined &&     subscriberId !== null &&     applicationId !== null) {     Core.query.mongodbSession.session.readCustom({status: 1, applicationId: applicationId,       subscriberId: subscriberId}, function(err, session) {
           if(err !== null) {             ruleCallback(null, true);
           } else {
               if(session.length >= x) {
                   ruleCallback('Max session', false);
               } else {
                   ruleCallback(null, true);
               }
           }
       });
   } else {       ruleCallback(null, true);
   }
} else {   ruleCallback(null, true);}
} else {
   ruleCallback(null, true);
}

///////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////// End Rule Source Code /////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
    } catch(err) {
      Core.log(Core.colors.red(err.toString()));
      Core.log(new Error().stack);
      ruleCallback(err,false);
    }
};
module.exports = rule_u0MKTeLbsNYd0AUAsF4vFhTJiq1mRcNL;