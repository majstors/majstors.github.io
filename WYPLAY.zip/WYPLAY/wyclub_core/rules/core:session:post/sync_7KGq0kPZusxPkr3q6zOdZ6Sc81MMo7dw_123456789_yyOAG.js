//rule: maxNumberOfDevices
var rule_7KGq0kPZusxPkr3q6zOdZ6Sc81MMo7dw = function(req, sentData, finalCallback){
    Core.log('RULES ---- maxNumberOfDevices execution');
    var cbFired = false;
    var ruleCallback = function(err, data){
        clearTimeout(timeout);
        if(!cbFired){cbFired = true;finalCallback(err,data);}
    };
    var timeout = setTimeout(function(){finalCallback('timeout',false);},1000);
    var system = require('../../lib/ruleTools.js');
    var sessionContext = require('../../lib/sessionContext.js');
    var async = require('async');
    var underscore = require('underscore');
    try{
///////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Begin Rule Source Code ////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
var uuid = null;
var subscriberId = null;
var applicationId = null;
var x = 4;
if(req && req.body && req.body.uuid){
  uuid = req.body.uuid;
}
if(req && req.body && req.body.subscriberId){
  subscriberId = req.body.subscriberId;
}
if(req && req.body && req.params.applicationId){
  applicationId = req.params.applicationId;
}
if(uuid !== null && subscriberId !== null && applicationId !== null) {
   Core.repository.subscriber.read({subscriberId: subscriberId}, function(err, subscriber){
     if(err !== null){
       ruleCallback(err, true);
     } else {
           if(subscriber !== undefined && subscriber.deviceInstances !== undefined) {
               var device = underscore.where(subscriber.devices, {'uuid':uuid});
                if (device.length > 0) {
                   var deviceId = device[0]._id;
                   var deviceInstanceExists = underscore.where(subscriber.deviceInstances,                   {applicationId: applicationId, deviceId: deviceId}).length;
                   if (deviceInstanceExists === 0) {
                       var deviceInstance = underscore.where(subscriber.deviceInstances,                       {applicationId: applicationId});
                       if(deviceInstance.length >= x) {
                         ruleCallback('Max devices for this subscriber', false);
                       } else {
                         ruleCallback(null, true);
                       }
                   } else {
                     ruleCallback(null, true);
                   }
               } else { 
                   var deviceInstance = underscore.where(subscriber.deviceInstances,                  {applicationId: applicationId});
                   if(deviceInstance.length >= x) {
                       ruleCallback('Max devices for this subscriber', false);
                   } else {
                       ruleCallback(null, true);
                   }
               }
            } else {
               ruleCallback(null, true);
            }
      }
   });
} else if(uuid !== null && applicationId !== null) {
   Core.repository.subscriber.readCustom({'devices.uuid': uuid}, function(err, subscriber){
     if(err !== null){
       ruleCallback(err, true);
     } else {
           if(subscriber !== undefined && subscriber.deviceInstances !== undefined) {
               var device = underscore.where(subscriber.devices, {'uuid':uuid});
                var deviceId = device[0]._id;
                   var deviceInstanceExists = underscore.where(subscriber.deviceInstances,                   {applicationId: applicationId, deviceId: deviceId}).length;
                   if (deviceInstanceExists === 0) {
                       var deviceInstance = underscore.where(subscriber.deviceInstances,                       {applicationId: applicationId});
                       if(deviceInstance.length >= x) {
                         ruleCallback('Max devices for this subscriber', false);
                       } else {
                         ruleCallback(null, true);
                       }
                   } else {
                     ruleCallback(null, true);
                   }
            } else {
               ruleCallback(null, true);
            }
      }
   });
} else {
   ruleCallback(null, true);
}

///////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////// End Rule Source Code /////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
    } catch(err) {
      Core.log(Core.colors.red(err.toString()));
      Core.log(new Error().stack);
      ruleCallback(err,false);
    }
};
module.exports = rule_7KGq0kPZusxPkr3q6zOdZ6Sc81MMo7dw;