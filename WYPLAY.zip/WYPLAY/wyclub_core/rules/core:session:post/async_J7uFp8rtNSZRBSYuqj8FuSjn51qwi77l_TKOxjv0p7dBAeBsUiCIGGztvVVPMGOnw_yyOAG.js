//rule: deleteSiamezeSessions
var rule_J7uFp8rtNSZRBSYuqj8FuSjn51qwi77l = function(req, sentData, finalCallback){
    Core.log('RULES ---- deleteSiamezeSessions execution');
    var cbFired = false;
    var ruleCallback = function(err, data){
        clearTimeout(timeout);
        if(!cbFired){cbFired = true;finalCallback(err,data);}
    };
    var timeout = setTimeout(function(){finalCallback('timeout',false);},1000);
    var system = require('../../lib/ruleTools.js');
    var sessionContext = require('../../lib/sessionContext.js');
    var async = require('async');
    var underscore = require('underscore');
    try{
///////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Begin Rule Source Code ////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
var wyclubToken = null;
if(req && req.params && req.params.wyclubToken){
   wyclubToken = req.params.wyclubToken;
}
sessionContext.read(req, function(err,currentSession){
   Core.repository.session.deleteSiamezeSessions({session: currentSession},function(err,data){
       if(err !== null){
           ruleCallback(null, false)
       } else {
           ruleCallback(null, true);
       }
   });
});
///////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////// End Rule Source Code /////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
    } catch(err) {
      Core.log(Core.colors.red(err.toString()));
      Core.log(new Error().stack);
      ruleCallback(err,false);
    }
};
module.exports = rule_J7uFp8rtNSZRBSYuqj8FuSjn51qwi77l;