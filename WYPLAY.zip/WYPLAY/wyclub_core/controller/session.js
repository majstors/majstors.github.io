/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/**
 * Session Controller
 */

// Get repositories
var sessionRepo = Core.repository.session;
var subscriberRepo = Core.repository.subscriber;
var tagRepo = Core.repository.tag;

// Get dependencies
var underscore = require('underscore');
var Controller = require('../lib/controller');

// Init controller prototype
var Session = function () {
  'use strict';
};

Session.prototype = Object.create(Controller.prototype);

/**
 * Generic methods of session
 */
// Read tags from DB
Session.prototype.readTags = function (request, response, reqType, values) {
  'use strict';
  var self = this;
  var lstTag = [];
  sessionRepo.readTags(values, function (err, sessionTags) {
    if (err !== null) {
      self.postProcessError(request, response, 200, reqType, err);
    } else {
      sessionTags = JSON.parse(sessionTags);
      async.each(sessionTags.tag, function (idTag, callback) {
        tagRepo.read({id: idTag}, function (err, labelTag) {
          if (err === null) {
            lstTag.push(labelTag.label);
          } else {
            lstTag.push(idTag);
          }
          callback();
        });
      }, function (err) {
        if (err !== null) {
          self.postProcessError(request, response, 200, reqType, err);
        } else {
          sessionTags.tag = lstTag;
          self.postProcessSuccess(request, sessionTags, response, 200, reqType);
        }
      });
    }
  });
};

/**
 * End generic methods of session
 */

/**
 * @method Session - readSubscriber
 * @desc /{wyclubToken}/session/sub.json
 * @httpmethod GET
 * @summary Session.readSubscriber — Read the requested subscriber's info.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} request.query.accessToken - A session access token.
 * @param {Object} response
 * @param {Object} response.subscriber
 *
 * @public
 */
Session.prototype.readSubscriber = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: ['wyclubToken'],
      schema: {
        'wyclubToken': {
          type: 'string',
          'required': true
        }
      },
      values: {wyclubToken: request.params.wyclubToken}
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        if (session.subscriber !== undefined && session.subscriber !== null) {
          self.postProcessSuccess(request, session.subscriber, response, 200, reqType);
        } else {
          self.postProcessError(request, response, 200, reqType, 'SUBSCRIBERS_EMPTY');
        }
      });
    }
  });
};

/**
 * @method Session - readSubscriberProfile
 * @desc /{wyclubToken}/session/sub/profile.json
 * @httpmethod GET
 * @summary Session.readSubscriberProfile — Read the profiles of the current subscriber.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {Object} response
 * @param {Object} response.profile
 *
 * @public
 */
Session.prototype.readSubscriberProfile = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: ['wyclubToken'],
      schema: {
        'wyclubToken': {
          type: 'string',
          'required': true
        }
      },
      values: {wyclubToken: request.params.wyclubToken}
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        if (session.subscriber !== undefined && session.subscriber !== null) {
          if (session.subscriber.profiles !== undefined && session.subscriber.profiles !== null && session.subscriber.profiles.length !== 0) {
            self.postProcessSuccess(request, session.subscriber.profiles, response, 200, reqType);
          } else {
            self.postProcessError(request, response, 200, reqType, 'PROFILES_EMPTY');
          }
        } else {
          self.postProcessError(request, response, 200, reqType, 'SUBSCRIBERS_EMPTY');
        }
      });
    }
  });
};

/**
 * @method Session - readSubscriberDevices
 * @desc /{wyclubToken}/session/sub/device.json
 * @httpmethod GET
 * @summary Session.readSubscriberDevice — Read the devices of the current subscriber.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {Object} response
 * @param {Object} response.device
 *
 * @public
 */
Session.prototype.readSubscriberDevices = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: ['wyclubToken'],
      schema: {
        'wyclubToken': {
          type: 'string',
          'required': true
        }
      },
      values: {wyclubToken: request.params.wyclubToken}
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        if (session.subscriber !== undefined && session.subscriber !== null) {
          if (session.subscriber.devices !== undefined && session.subscriber.devices !== null && session.subscriber.devices.length !== 0) {
            self.postProcessSuccess(request, session.subscriber.devices, response, 200, reqType);
          } else {
            self.postProcessError(request, response, 200, reqType, 'DEVICES_EMPTY');
          }
        } else {
          self.postProcessError(request, response, 200, reqType, 'SUBSCRIBERS_EMPTY');
        }
      });
    }
  });
};

/**
 * @method Session - readTwinSister
 * @desc /{wyclubToken}/session/twinSister.json
 * @httpmethod GET
 * @summary Session.readTwinSister — Read the twin sister of the current subscriber.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {Object} response
 * @param {Object} response.session
 *
 * @public
 */
Session.prototype.readTwinSister = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: ['wyclubToken'],
      schema: {
        'wyclubToken': {
          type: 'string',
          'required': true
        }
      },
      values: {wyclubToken: request.params.wyclubToken}
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        sessionRepo.readTwinSisterSessions(session, function (err, sessions) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, sessions, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Session - readProfile
 * @desc /{wyclubToken}/session/profile.json
 * @httpmethod GET
 * @summary Session.readProfile — Read the current profile of the current subscriber.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} request.query.accessToken - An access token to replace session ID
 * @param {Object} response
 * @param {Object} response.profile
 *
 * @public
 */
Session.prototype.readProfile = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: ['wyclubToken'],
      schema: {
        'wyclubToken': {
          type: 'string',
          'required': true
        }
      },
      values: {wyclubToken: request.params.wyclubToken}
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        if (session.subscriber !== undefined && session.subscriber !== null) {
          if (session.profile !== undefined && session.profile !== null) {
            self.postProcessSuccess(request, session.profile, response, 200, reqType);
          } else {
            self.postProcessError(request, response, 200, reqType, 'PROFILES_EMPTY');
          }
        } else {
          self.postProcessError(request, response, 200, reqType, 'SUBSCRIBERS_EMPTY');
        }
      });
    }
  });
};

/**
 * @method Session - readDevice
 * @desc /{wyclubToken}/session/device.json
 * @httpmethod GET
 * @summary Session.readCurrentDevice — Read the current device of the session.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {Object} response
 * @param {Object} response.device
 *
 * @public
 */
Session.prototype.readDevice = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: ['wyclubToken'],
      schema: {
        'wyclubToken': {
          type: 'string',
          'required': true
        }
      },
      values: {wyclubToken: request.params.wyclubToken}
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        if (session.subscriber !== undefined && session.subscriber !== null) {
          if (session.device !== undefined && session.device !== null) {
            self.postProcessSuccess(request, session.device, response, 200, reqType);
          } else {
            self.postProcessError(request, response, 200, reqType, 'DEVICES_EMPTY');
          }
        } else {
          self.postProcessError(request, response, 200, reqType, 'SUBSCRIBERS_EMPTY');
        }
      });
    }
  });
};

/**
 * @method Session - readTag
 * @desc /{wyclubToken}/session/tag.json
 * @httpmethod GET
 * @summary Session.readTag — Read the session tags of the current subscriber.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {Object} response
 * @param {Object} response.tag
 *
 * @public
 */
Session.prototype.readTag = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: ['wyclubToken'],
      schema: {
        'wyclubToken': {
          type: 'string',
          'required': true
        }
      },
      values: {wyclubToken: request.params.wyclubToken}
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        self.readTags(request, response, reqType, {wyclubToken: session._id});
      });
    }
  });
};

/**
 * @method Session - create
 * @desc /{applicationId}/session.json
 * @httpmethod POST
 * @summary Session.create — Create a new session.
 * @param {Object} request
 * @param {string} [request.params.applicationId] - The application ID of the apps that wan't to create a session
 * @param {string} request.body.uuid - The unique ID of the subscriber device
 * @param {string} request.body.type - The device type
 * @param {string} request.body.label - The device label
 * @param {string} request.body.subscriberId - The subscriber ID
 * @param {Object} response
 * @param {Object} response.session
 *
 * @public
 */
Session.prototype.create = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: [
        'applicationId',
        'uuid',
        'subscriberId',
        'type',
        'label'
      ],
      schema: {
        applicationId: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        uuid: {
          type: 'string',
          required: false
        },
        type: {
          type: 'string',
          required: false
        },
        label: {
          type: 'string',
          required: false
        },
        subscriberId: {
          type: 'string',
          required: false,
          minLength: 32,
          maxLength: 32
        }
      },
      values: {
        'applicationId': request.params.applicationId,
        'uuid': request.body.uuid,
        'subscriberId': request.body.subscriberId,
        'type': request.body.type,
        'label': request.body.label
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      var newValues = {};
      if (request.params.applicationId !== undefined) {
        newValues.applicationId = values.applicationId;
      }
      if (request.body.uuid !== undefined) {
        newValues.uuid = values.uuid;
      }
      if (request.body.subscriberId !== undefined) {
        newValues.subscriberId = values.subscriberId;
      }
      if (request.body.type !== undefined) {
        newValues.type = values.type;
      }
      if (request.body.label !== undefined) {
        newValues.label = values.label;
      }
      sessionRepo.create(newValues, function (err, session) {
        if (err !== null) {
          self.postProcessError(request, response, 200, reqType, err);
        } else {
          var sessionContext = require('../lib/sessionContext');
          sessionContext.set(null, {_id: session._id}, request, function () {
            self.postProcessSuccess(request, session, response, 200, reqType);
          });
        }
      });
    }
  });
};

//TODO ensure params in comments: the fields to update are not listed
/**
 * @method Session - updateProfile
 * @desc /{wyclubToken}/session/profile.json
 * @httpmethod PUT
 * @summary Session.updateProfile — Update the current profile.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.profileId] - The ID of the profile to update
 * @param {string} request.body.password - The updated password
 * @param {Object} response
 * @param {Object} response.profile
 *
 * @public
 */
Session.prototype.updateProfile = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: [
        'wyclubToken',
        'profileId'
      ],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        profileId: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        password: {
          type: 'string',
          required: false
        }
      },
      values: {
        wyclubToken: request.params.wyclubToken,
        profileId: request.body.profileId,
        password: request.body.password
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        sessionRepo.updateProfile(session, values, function (err, session) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, session, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Session - delete
 * @desc /{wyclubToken}/session.json
 * @httpmethod DELETE
 * @summary Session.delete — Delete the current session.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} request.body
 * @param {Object} response
 * @param {Object} response.session
 *
 * @public
 */
Session.prototype.delete = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: ['wyclubToken'],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        }
      },
      values: {wyclubToken: request.params.wyclubToken}
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      sessionRepo.delete(values, function (err, session) {
        if (err !== null) {
          self.postProcessError(request, response, 200, reqType, err);
        } else {
          self.postProcessSuccess(request, session, response, 200, reqType);
        }
      });
    }
  });
};

/**
 * @method Session - readAccessToken
 * @desc /{wyclubToken}/session/accesstoken.json
 * @httpmethod GET
 * @summary Session.readAccessToken — Read the access token for the current session.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {Object} response
 * @param {Object} response.accessToken
 *
 * @public
 */
Session.prototype.readAccessToken = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: ['wyclubToken'],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        }
      },
      values: {wyclubToken: request.params.wyclubToken}
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function () {
        sessionRepo.createAccessToken(values, function (err, accessToken) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, {accessToken: accessToken}, response, 200, reqType);
          }
        });
      });
    }
  });
};

//TODO care with params: seems to miss the source session ID to create the half sister
/**
 * @method Session - createHalfSister
 * @desc /{applicationId}/halfsistersession.json
 * @httpmethod POST
 * @summary Session.createHalfSister — Create a new half-sister session.
 * @param {Object} request
 * @param {string} [request.params.applicationId] - The application ID of the new session
 * @param {Object} response
 * @param {Object} response.session
 *
 * @public
 */
Session.prototype.createHalfSister = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: ['applicationId'],
      schema: {
        applicationId: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        }
      },
      values: {applicationId: request.params.applicationId}
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        sessionRepo.createHalfSisterSession({
          session: session,
          applicationId: values.applicationId
        }, function (err, session) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, session, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Session - createCurrentContent
 * @desc /{wyclubToken}/session/currentcontent.json
 * @httpmethod POST
 * @summary Session.createCurrentContent — Create content in the sesssion.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.content] - A content
 * @param {string} request.body.origin - The origin of the content
 * @param {string} request.body.info - The informations about this content
 * @param {Object} response
 * @param {Object} response.session
 *
 * @public
 */
Session.prototype.createCurrentContent = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: [
        'wyclubToken',
        'content',
        'origin',
        'info'
      ],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        content: {
          type: 'string',
          required: true
        },
        origin: {
          type: 'string',
          required: false
        },
        info: {
          type: 'string',
          required: false
        }
      },
      values: {
        wyclubToken: request.params.wyclubToken,
        content: request.body.content,
        origin: request.body.origin,
        info: request.body.info
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function () {
        sessionRepo.updateCurrentContent(values, function (err, content) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, content, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Session - readCurrentContent
 * @desc /{wyclubToken}/session/currentcontent.json
 * @httpmethod GET
 * @summary Session.readCurrentContent — Read the session's current content.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {Object} response
 * @param {Object} response.session
 *
 * @public
 */
Session.prototype.readCurrentContent = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: ['wyclubToken'],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        }
      },
      values: {wyclubToken: request.params.wyclubToken}
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function () {
        sessionRepo.readCurrentContent(values, function (err, currentContent) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, currentContent, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Session - createDevice
 * @desc /{wyclubToken}/session/device.json
 * @httpmethod POST
 * @summary Session.createDevice — Create a new device for the subscriber.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.uuid] - The new device unique ID
 * @param {string} request.body.label - The new device label
 * @param {string} [request.body.type] - The new device type
 * @param {Object} response
 * @param {Object} response.session
 *
 * @public
 */
Session.prototype.createDevice = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: [
        'wyclubToken',
        'uuid',
        'label',
        'type'
      ],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        uuid: {
          type: 'string',
          required: true
        },
        label: {type: 'string'},
        type: {
          type: 'string',
          required: true
        }
      },
      values: {
        wyclubToken: request.params.wyclubToken,
        uuid: request.body.uuid,
        label: request.body.label,
        type: request.body.type
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        var device = underscore.where(session.subscriber.devices, {'uuid': values.uuid});
        var params = {};

        if (device.length === 0) {
          params = {
            wyclubToken: values.wyclubToken,
            uuid: values.uuid,
            label: values.label,
            type: values.type,
            status: 1,
            subscriberId: session.subscriber._id
          };

          subscriberRepo.addDevice(params, function (err, device) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              params = {
                subscriberId: session.subscriber._id,
                applicationId: session.application._id,
                deviceId: device._id
              };
              subscriberRepo.addDeviceInstance(params, function (err, deviceInstance) {
                self.cleanSession(request, response, function () {
                  self.readSession(request, response, reqType, values.wyclubToken, function (session) {
                    if (err !== null) {
                      self.postProcessError(request, response, 200, reqType, err);
                    } else {
                      sessionRepo.updateDevice(session, device._id, function (err, session) {
                        if (err !== null) {
                          self.postProcessError(request, response, 200, reqType, err);
                        } else {
                          sessionRepo.updateDeviceInstance(session, deviceInstance._id, function (err, deviceInstance) {
                            if (err !== null) {
                              self.postProcessError(request, response, 200, reqType, err);
                            } else {
                              self.postProcessSuccess(request, deviceInstance, response, 200, reqType);
                            }
                          });
                        }
                      });
                    }
                  });
                });
              });
            }
          });
        } else {
          params = {
            deviceId: device[0]._id,
            applicationId: session.application._id
          };

          var deviceInstance = underscore.where(session.subscriber.deviceInstances, params);
          if (deviceInstance.length === 0) {
            params = {
              subscriberId: session.subscriber._id,
              applicationId: session.application._id,
              deviceId: device[0]._id
            };

            subscriberRepo.addDeviceInstance(params, function (err, deviceInstance) {
              self.cleanSession(request, response, function () {
                self.readSession(request, response, reqType, values.wyclubToken, function (session) {
                  if (err !== null) {
                    self.postProcessError(request, response, 200, reqType, err);
                  } else {
                    sessionRepo.updateDeviceInstance(session, deviceInstance._id, function (err, deviceInstance) {
                      if (err !== null) {
                        self.postProcessError(request, response, 200, reqType, err);
                      } else {
                        self.postProcessSuccess(request, deviceInstance, response, 200, reqType);
                      }
                    });
                  }
                });
              });
            });
          } else {
            self.postProcessSuccess(request, deviceInstance, response, 200, reqType);
          }
        }
      });
    }
  });
};

//TODO Care with params, seems to miss the new informations of the device
/**
 * @method Session - updateDevice
 * @desc /{wyclubToken}/session/device.json
 * @httpmethod PUT
 * @summary Session.updateDevice — Update the current device.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.deviceId] - The updated device ID
 * @param {Object} response
 * @param {Object} response.profile
 *
 * @public
 */
Session.prototype.updateDevice = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: [
        'wyclubToken',
        'deviceId'
      ],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        deviceId: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        }
      },
      values: {
        wyclubToken: request.params.wyclubToken,
        deviceId: request.body.deviceId
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        sessionRepo.updateDevice(session, values.deviceId, function (err, session) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, session, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Session - deleteDevice
 * @desc /{wyclubToken}/session/device.json
 * @httpmethod DELETE
 * @summary Session.deleteDevice — Delete a subscriber's device.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.uuid] - Unique ID of the device to delete.
 * @param {Object} response
 * @param {Object} response.session
 *
 * @public
 */
Session.prototype.deleteDevice = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: [
        'wyclubToken',
        'uuid'
      ],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        uuid: {
          type: 'string',
          required: true
        }
      },
      values: {
        wyclubToken: request.params.wyclubToken,
        uuid: request.body.uuid
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        var device = underscore.where(session.subscriber.devices, {'uuid': values.uuid});
        if (device.length !== 0) {
          var params = {
            subscriberId: session.subscriber._id,
            applicationId: session.application._id,
            deviceId: device[0]._id
          };

          subscriberRepo.deleteDeviceInstances(params, function (err, deviceInstance) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              self.postProcessSuccess(request, {delete: deviceInstance}, response, 200, reqType);
            }
          });
        } else {
          self.postProcessError(request, response, 200, reqType, 'DEVICE_EMPTY');
        }
      });
    }
  });
};

/**
 * @method Session - readAllDevices
 * @desc /{wyclubToken}/session/alldevices.json
 * @httpmethod GET
 * @summary Session.readAllDevices — read all the device instances associated to the subscriber.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {Object} response
 * @param {Object} response.session
 *
 * @public
 */
Session.prototype.readAllDevices = function (request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: ['wyclubToken'],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        }
      },
      values: {wyclubToken: request.params.wyclubToken}
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        var deviceInstance = underscore.where(session.subscriber.deviceInstances, {applicationId: session.application._id});

        if (deviceInstance.length > 0) {
          var listDevice = [];
          for (var key in deviceInstance) {
            listDevice.push(underscore.where(session.subscriber.devices, {_id: deviceInstance[key].deviceId})[0]);
          }
          self.postProcessSuccess(request, listDevice, response, 200, reqType);
        } else {
          self.postProcessError(request, response, 200, reqType, 'DEVICE_EMPTY');
        }
      });
    }
  });
};

module.exports = new Session();
