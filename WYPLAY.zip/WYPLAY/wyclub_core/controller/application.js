/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/**
 *  Application Controller
 */

// Get repositories
var applicationRepo = Core.repository.application;

// Get dependencies
var Controller = require('../lib/controller');

// Init controller prototype
var Application = function() {
  'use strict';
};

Application.prototype = Object.create(Controller.prototype);

/**
 * @method Application - readService
 * @desc /{wyclubToken}/applicationService.json
 * @httpmethod GET
 * @summary Application.readService — Read the services associated to this application.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.query.applicationId] - The new application ID (length = 32)
 * @param {Object} response
 * @param {Object} response.services
 *
 * @public
 */
Application.prototype.readService = function(request, response) {
  'use strict';
  var self = Core.controller.application;
  self.process({
    jsonSchema: {
      keys: [
        'applicationId',
        'wyclubToken'
      ],
      schema: {
        applicationId: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        wyclubToken: {
          type: 'string',
          'required': true
        }
      },
      values: {
        applicationId: request.query.applicationId,
        wyclubToken: request.params.wyclubToken
      }
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        applicationRepo.readApplicationWebservices({publicId: values.applicationId}, function(err, services) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, services, response, 200, reqType);
          }
        });
      });
    }
  });

  return undefined;
};

/**
 * @method Application - read
 * @desc /{wyclubToken}/application.json
 * @httpmethod GET
 * @summary Application.read — Read the applications associated to the session.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {Object} response
 * @param {Object} response.application
 *
 * @public
 */
Application.prototype.read = function(request, response) {
  'use strict';
  var self = Core.controller.application;
  self.process({
    jsonSchema: {
      keys: ['wyclubToken'],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        }
      },
      values: {wyclubToken: request.params.wyclubToken}
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        applicationRepo.readAll(null, function(err, applications) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, applications, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Application - readPublic
 * @desc /{applicationId}/applicationPublic.json
 * @httpmethod GET
 * @summary Application.readPublic — Read public information on the application.
 * @param {Object} request
 * @param {string} [request.params.applicationId] - An application ID
 * @param {string} [request.query.applicationPublicId] - The public ID of the concerned application
 * @param {Object} response
 * @param {Object} response.application
 *
 * @public
 */
Application.prototype.readPublic = function(request, response) {
  'use strict';
  var self = Core.controller.application;
  self.process({
    jsonSchema: {
      keys: [
        'applicationPublicId',
        'applicationId'
      ],
      schema: {
        applicationId: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        applicationPublicId: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        }
      },
      values: {
        applicationId: request.params.applicationId,
        applicationPublicId: request.query.applicationPublicId
      }
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      applicationRepo.read({_id: values.applicationId}, function(errValid) {
        if (errValid === null) {
          applicationRepo.readPublic(values.applicationPublicId, function(err, application) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              self.postProcessSuccess(request, application, response, 200, reqType);
            }
          });
        } else {
          self.postProcessError(request, response, 200, reqType, errValid);
        }
      });
    }
  });

  return undefined;
};

module.exports = new Application();