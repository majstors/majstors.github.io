/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/**
 * Webservice Controller
 */

/* Get repos */
var webserviceRepo = Core.repository.webservice;

// Get dependencies
var Controller = require('../lib/controller');

var serviceSchema = {
  'name': {
    'type': 'string',
    'minLength': 2,
    'required': true
  },
  'url': {
    'type': 'string',
    'minLength': 1,
    'required': true
  },
  'protocol': {
    'type': 'string',
    'minLength': 1,
    'required': true
  },
  'path': {
    'type': 'string',
    'minLength': 1,
    'required': true
  },
  'port': {
    'type': 'integer',
    'required': true
  },
  'method': {
    'type': 'string',
    'minLength': 1,
    'required': true
  },
  'types': {
    'type': 'string',
    'minLength': 1,
    'required': true
  }
};

// Init controller prototype
var Webservice = function() {
  'use strict';
};

Webservice.prototype = Object.create(Controller.prototype);

/**
 * @method Webservice - read
 * @desc /{wyclubToken}/webservice.json
 * @httpmethod GET
 * @summary Webservice.read — Read a protected webservice.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} request.query.serviceId - A service ID
 * @param {string} request.query.serviceName - A service name
 * @param {Object} response
 * @param {Object} response.webservice
 *
 * @public
 */
Webservice.prototype.read = function(request, response) {
  'use strict';

  var self = Core.controller.webService;
  self.process({
    jsonSchema: {
      keys: [
        'serviceId',
        'serviceName',
        'wyclubToken'
      ],
      schema: {
        'serviceId': {
          'type': 'string',
          'required': false
        },
        'serviceName': {
          'type': 'string',
          'required': false
        },
        'wyclubToken': {
          'type': 'string',
          'required': true
        }
      },
      values: {
        serviceId: request.query.serviceId,
        serviceName: request.query.serviceName,
        wyclubToken: request.params.wyclubToken
      }
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        if (values.serviceId !== undefined) {
          webserviceRepo.read({_id: values.serviceId}, function(err, service) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              self.postProcessSuccess(request, service, response, 200, reqType);
            }
          });
        } else if (values.serviceName !== undefined) {
          webserviceRepo.readCustom({name: values.serviceName}, function(err, service) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              self.postProcessSuccess(request, service, response, 200, reqType);
            }
          });
        } else {
          self.postProcessError(request, response, 200, reqType, {
            code: 'MISSING_REQ_PARAM',
            params: {param: 'wyclubToken, serviceName'}
          });
        }
      });
    }
  });
};

/**
 * @method Webservice - readPublic
 * @desc /{wyclubToken}/publicwebservice.json
 * @httpmethod GET
 * @summary Webservice.readPublic — Read a public webservice.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} request.query.applicationName - The name of the webservices application
 * @param {string} request.query.serviceName - The name of the webservice
 * @param {Object} response
 * @param {Object} response.webservice
 *
 * @public
 */
Webservice.prototype.readPublic = function(request, response) {
  'use strict';

  var self = Core.controller.webService;
  self.process({
    jsonSchema: {
      keys: [
        'applicationName',
        'serviceName',
        'wyclubToken'
      ],
      schema: {
        'applicationName': {
          'type': 'string',
          'minLength': 2,
          'required': false
        },
        'serviceName': {
          'type': 'string',
          'minLength': 2,
          'required': false
        },
        'wyclubToken': {
          'type': 'string',
          'required': true
        }
      },
      values: {
        applicationName: request.query.applicationName,
        serviceName: request.query.serviceName,
        wyclubToken: request.params.wyclubToken
      }
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        if (values.applicationName !== undefined && values.serviceName !== undefined) {
          webserviceRepo.readPublic(values, function(err, webservice) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              self.postProcessSuccess(request, webservice, response, 200, reqType);
            }
          });
        } else if (values.applicationName === undefined && values.serviceName === undefined){
          webserviceRepo.readAllPublic(values, function(err, webservices) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else if (webservices !== null && webservices !== undefined) {
              self.postProcessSuccess(request, webservices, response, 200, reqType);
            } else {
              self.postProcessError(request, response, 200, reqType, 'NO_WEBSERVICE');
            }
          });
        } else if(values.serviceName !== undefined){
          var where = {};
          where.name = values.serviceName;
          webserviceRepo.readCustom(where, function(err, webservices) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else if (webservices !== null && webservices !== undefined) {
              self.postProcessSuccess(request, webservices, response, 200, reqType);
            } else {
              self.postProcessError(request, response, 200, reqType, 'NO_WEBSERVICE');
            }
          });
        } else {
          webserviceRepo.readAllPublicFromApplicationName(values, function(err, webservices) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else if (webservices !== null && webservices !== undefined) {
              var returnArr= [];
              for(var webserviceKey in webservices){
                returnArr.push(JSON.parse(webservices[webserviceKey]));
              }
              webservices = returnArr;
              self.postProcessSuccess(request, webservices, response, 200, reqType);
            } else {
              self.postProcessError(request, response, 200, reqType, 'NO_WEBSERVICE');
            }
          });
        }
      });
    }
  });
};

/**
 * @method Webservice - createPublic
 * @desc /{applicationId}/publicwebservice.json
 * @httpmethod POST
 * @summary Webservice.createPublic — Create a public webservice.
 * @param {Object} request
 * @param {string} [request.params.applicationId] - An application ID
 * @param {string} [request.body.name] - The created webservice name
 * @param {string} [request.body.url] - The created webservice URL e.g example.com
 * @param {string} [request.body.protocol] - The created webservice protocol (http/https)
 * @param {string} [request.body.path] - The created webservice path e.g. /subscriber/read.json
 * @param {integer} [request.body.port] - The created webservice port
 * @param {string} [request.body.method] - The created webservice method (GET/POST/PUT/DELETE)
 * @param {string} [request.body.types] - The created webservice types
 * @param {Object} response
 * @param {Object} response.webservice
 *
 * @public
 */
Webservice.prototype.createPublic = function(request, response) {
  'use strict';

  var self = Core.controller.webService;
  self.process({
    jsonSchema: {
      keys: [
        'name',
        'url',
        'protocol',
        'path',
        'port',
        'method',
        'types'
      ],
      schema: serviceSchema,
      values: {
        applicationId: request.params.applicationId,
        name: request.body.name,
        url: request.body.url,
        protocol: request.body.protocol,
        path: request.body.path,
        port: request.body.port,
        method: request.body.method,
        types: request.body.types
      }
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      webserviceRepo.createPublic(values, function(err) {
        if (err !== null) {
          self.postProcessError(request, response, 200, reqType, err);
        } else {
          var dataOk = {created: 1};
          self.postProcessSuccess(request, dataOk, response, 200, reqType);
        }
      });
    }
  });
};

/**
 * @method Webservice - updatepublic
 * @desc /{applicationId}/publicwebservice.json
 * @httpmethod PUT
 * @summary Webservice.updatePublic — Update a public webservice.
 * @param {Object} request
 * @param {string} [request.params.applicationId] - An application ID
 * @param {string} [request.body.name] - The updated webservice name
 * @param {string} [request.body.url] - The updated webservice URL e.g example.com
 * @param {string} [request.body.protocol] - The updated webservice protocol (http/https)
 * @param {string} [request.body.path] - The updated webservice path e.g. /subscriber/read.json
 * @param {integer} [request.body.port] - The updated webservice port
 * @param {string} [request.body.method] - The updated webservice method (GET/POST/PUT/DELETE)
 * @param {string} [request.body.types] - The updated webservice types
 * @param {Object} response
 * @param {Object} response.webservice
 *
 * @public
 */
Webservice.prototype.updatePublic = function(request, response) {
  'use strict';

  var self = Core.controller.webService;
  self.process({
    jsonSchema: {
      keys: [
        'name',
        'url',
        'protocol',
        'path',
        'port',
        'method',
        'types'
      ],
      schema: serviceSchema,
      values: {
        applicationId: request.params.applicationId,
        name: request.body.name,
        url: request.body.url,
        protocol: request.body.protocol,
        path: request.body.path,
        port: request.body.port,
        method: request.body.method,
        types: request.body.types
      }
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      webserviceRepo.updatePublic(values, function(err) {
        if (err !== null) {
          self.postProcessError(request, response, 200, reqType, err);
        } else {
          var dataOk = {updated: 1};
          self.postProcessSuccess(request, dataOk, response, 200, reqType);
        }
      });
    }
  });
};

module.exports = new Webservice();