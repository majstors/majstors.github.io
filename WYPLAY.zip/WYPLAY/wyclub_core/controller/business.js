/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/**
 * Business Controller
 */

// Get repositories
var businessRepo = Core.repository.business;

// Get dependencies
var Controller = require('../lib/controller');

// Init controller prototype
var Business = function() {
  'use strict';
};

Business.prototype = Object.create(Controller.prototype);

/**
 * @method Business - createPackage
 * @desc /{wyclubToken}/businesspackage.json
 * @httpmethod POST
 * @summary Business.createPackage — Create a new business package.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.businessId] - The package ID
 * @param {string} [request.body.state] - The package state
 * @param {string} [request.body.label] - The package label
 * @param {Array}  request.body.tags - The package tags
 * @param {Object} request.body.services - The package services list
 * @param {Object} request.body.assets - The package assets list
 * @param {Object} response
 * @param {Object} response.package
 *
 * @public
 */
Business.prototype.createPackage = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: [
        'businessId',
        'label',
        'tags',
        'state'
      ],
      schema: {
        'businessId': {'required': true},
        'state': {'required': true},
        'label': {
          'required': true,
          'minLength': 1
        },
        'tags': {'required': false}
      },
      values: request.body
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var businessId = values.businessId;
        var label = values.label;
        var tags = values.tags;
        var state = values.state;
        var services = values.services;
        var assets = values.assets;

        businessRepo.createPackage({
          businessId: businessId,
          label: label,
          tags: tags,
          state: state,
          services: services,
          assets: assets
        }, function(err, bouquet) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, bouquet, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Business - createService
 * @desc /{wyclubToken}/businessservice.json
 * @httpmethod POST
 * @summary Business.createService — Create a new business service.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.businessId] - The service ID
 * @param {string} [request.body.label] - The service label
 * @param {string} request.body.appId - A ID of a applciation linked to this service
 * @param {Array} request.body.tags - The service tags list
 * @param {Array} request.body.assets - The service assets list
 * @param {Array} request.body.packages - The service packages list
 * @param {string} request.body.state - The service status
 * @param {Object} response
 * @param {Object} response.service
 *
 * @public
 */
Business.prototype.createService = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: [
        'businessId',
        'label',
        'tags',
        'appId',
        'state'
      ],
      schema: {
        'businessId': {'required': true},
        'label': {
          'required': true,
          'minLength': 1
        },
        'tags': {'required': false},
        'appId': {'required': false}
      },
      values: request.body
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var businessId = values.businessId;
        var label = values.label;
        var tags = values.tags;
        var appId = values.applicationId;
        var state = values.state;
        var assets = values.assets;
        var packages = values.packages;

        businessRepo.createService({
          businessId: businessId,
          label: label,
          tags: tags,
          applicationId: appId,
          state: state,
          packages: packages,
          assets: assets
        }, function(err, service) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, service, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Business - createAsset
 * @desc /{wyclubToken}/businessasset.json
 * @httpmethod POST
 * @summary Business.createAsset — Create a new business asset.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.businessId] - The asset ID
 * @param {string} [request.body.label] - The asset label
 * @param {Array} request.body.services - The asset services list
 * @param {Array} request.body.tags - The asset tags list
 * @param {Array} request.body.packages - The asset packages list
 * @param {string} request.body.state - The asset status
 * @param {Object} response
 * @param {Object} response.asset
 *
 * @public
 */
Business.prototype.createAsset = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: [
        'businessId',
        'label',
        'tags',
        'services',
        'state'
      ],
      schema: {
        'businessId': {'required': true},
        'label': {
          'required': true,
          'minLength': 1
        },
        'tags': {'required': false},
        'services': {'required': false}
      },
      values: request.body
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var params = {
          businessId: values.businessId,
          label: values.label,
          tags: values.tags,
          state: values.state,
          packages: values.packages,
          services: values.services
        };

        businessRepo.createAsset(params, function(err, asset) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, asset, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Business - readPackage
 * @desc /{wyclubToken}/businesspackage.json
 * @httpmethod GET
 * @summary Business.readPackage — Read a specified business package.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} request.query.id - The package technical ID
 * @param {string} request.query.businessId - The package business ID
 * @param {string} request.query.public_id - The package public_id
 * @param {string} request.query.service - The package service
 * @param {string} request.query.asset - The package asset
 * @param {string} request.query.state - The package status
 * @param {Object} response
 * @param {Object} response.subscriber
 *
 * @public
 */
Business.prototype.readPackage = function(request, response) {
  'use strict';
  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: [
        'businessId',
        'public_id'
      ],
      schema: {
        'businessId': {'required': false},
        'public_id': {'required': false}
      },
      values: request.query
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var businessId = values.businessId;
        var packageId = values.id;
        var services = values.service;
        var assets = values.asset;
        var params = {}, state = values.state;

        if (state !== undefined) {
          params.state = state;
        }
        if (packageId !== undefined) {
          params._id = packageId;
        }
        if (businessId !== undefined) {
          params.businessId = businessId;
        }
        if (services !== undefined) {
          params.services = services;
        }
        if (assets !== undefined) {
          params.assets = assets;
        }

        businessRepo.readPackageCustom(params, function(err, bouquet) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, bouquet, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Business - readService
 * @desc /{wyclubToken}/businessservice.json
 * @httpmethod GET
 * @summary Business.readService — Read a specified business service.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} request.query.businessId - The service business ID
 * @param {string} request.query.serviceId - The service ID
 * @param {string} request.query.id - The service ID
 * @param {string} request.query.applicationId - The service application ID
 * @param {string} request.query.package - The service package
 * @param {string} request.query.asset - The service asset
 * @param {Object} response
 * @param {Object} response.service
 *
 * @public
 */
Business.prototype.readService = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: ['businessId'],
      schema: {'businessId': {'required': false}},
      values: request.query
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var businessId = values.businessId;
        var serviceId = values.serviceId;
        var packages = values.package;
        var assets = values.asset;
        var applicationId = values.applicationId;
        var id = values.id;
        var params = {};
        var state = request.query.state;

        if (state !== undefined) {
          params.state = state;
        }
        if (serviceId !== undefined) {
          params._id = serviceId;
        }
        if (applicationId !== undefined) {
          params.applicationId = applicationId;
        }
        if (businessId !== undefined) {
          params.businessId = businessId;
        }
        if (packages !== undefined) {
          params.packages = packages;
        }
        if (assets !== undefined) {
          params.assets = assets;
        }
        if (id !== undefined) {
          params._id = id;
        }

        businessRepo.readServiceCustom(params, function(err, service) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, service, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Business - readAsset
 * @desc /{wyclubToken}/businessasset.json
 * @httpmethod GET
 * @summary Business.readAsset — Read a specified business asset.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} request.query.businessId - The asset business ID
 * @param {string} request.query.assetId - The asset id
 * @param {string} request.query.service - The asset service
 * @param {string} request.query.package - The asset package
 * @param {string} request.query.state - The asset status
 * @param {Object} response
 * @param {Object} response.asset
 *
 * @public
 */
Business.prototype.readAsset = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: [
        'businessId',
        'assetId'
      ],
      schema: {
        'businessId': {
          type: 'string',
          'required': false
        },
        'assetId': {
          type: 'string',
          'required': false
        },
        'service': {
          type: 'Array',
          'required': false
        },
        'package': {
          type: 'Array',
          'required': false
        }
      },
      values: request.query
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var businessId = values.businessId;
        var assetId = values.assetId;
        var services = values.service;
        var packages = values.package;
        var params = {};
        var state = values.state;

        if (state !== undefined) {
          params.state = state;
        }
        if (assetId !== undefined) {
          params._id = assetId;
        }
        if (businessId !== undefined) {
          params.businessId = businessId;
        }
        if (services !== undefined) {
          params.services = services;
        }
        if (packages !== undefined) {
          params.packages = packages;
        }

        businessRepo.readAssetCustom(params, function(err, asset) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, asset, response, 200, reqType);
          }
        });
      });
    }
  });
};

//TODO les params sont louches
//TODO sans rire ?
/**
 * @method Business - updatePackage
 * @desc /{wyclubToken}/businesspackage.json
 * @httpmethod PUT
 * @summary Business.updatePackage — Update a specified business package.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.businessId] - The package business ID
 * @param {string} [request.body.packageId] - The package ID
 * @param {string} request.body.label - The package label
 * @param {string} request.body.state - The package status
 * @param {Array} request.body.tags - The package tags
 * @param {Object} response
 * @param {Object} response.package
 *
 * @public
 */
Business.prototype.updatePackage = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: ['packageId'],
      schema: {
        'packageId': {'required': true},
        'state': {'required': true},
        'label': {
          'required': true,
          'minLength': 1
        },
        'tags': {'required': false}
      },
      values: request.body
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var tags = values.tags;
        var params;

        params = {
          _id: values.packageId,
          businessId: values.businessId,
          label: values.label,
          tags: tags,
          state: values.state
        };

        if (values.tags === undefined) {
          params.tags = [];
        }

        businessRepo.updatePackage(params, function(err, bouquet) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, bouquet, response, 200, reqType);
          }
        });
      });
    }
  });
};

//TODO les params sont louches
/**
 * @method Business - updateService
 * @desc /{wyclubToken}/businessservice.json
 * @httpmethod PUT
 * @summary Business.updateService — Update a specified business service.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.businessId] - A service business ID
 * @param {string} [request.body.serviceId] - A service ID
 * @param {string} [request.body.label] - A service label
 * @param {Array} request.body.tags - A service lags list
 * @param {string} request.body.state - A service state
 * @param {Object} response
 * @param {Object} response.service
 *
 * @public
 */
Business.prototype.updateService = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: ['serviceId'],
      schema: {
        'serviceId': {'required': true},
        'label': {
          'required': true,
          'minLength': 1
        },
        'tags': {'required': false}
      },
      values: request.body
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var tags = values.tags;
        var params;

        if (tags === undefined) {
          tags = [];
        }

        params = {
          businessId: values.businessId,
          _id: values.serviceId,
          label: values.label,
          tags: tags,
          state: values.state
        };

        businessRepo.updateService(params, function(err, service) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, service, response, 200, reqType);
          }
        });
      });
    }
  });
};

//TODO les params sont louches
/**
 * @method Business - updateAsset
 * @desc /{wyclubToken}/businessasset.json
 * @httpmethod PUT
 * @summary Business.updateAsset — Update a specified business asset.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.businessId] - A asset business ID
 * @param {string} [request.body.assetId] - A asset ID
 * @param {string} [request.body.label] - A asset label
 * @param {Array} request.body.tags - A asset tags list
 * @param {string} request.body.state - A asset status
 * @param {Object} response
 * @param {Object} response.service
 *
 * @public
 */
Business.prototype.updateAsset = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: ['assetId'],
      schema: {
        'assetId': {'required': true},
        'businessId': {'required': true},
        'label': {
          'required': true,
          'minLength': 1
        },
        'tags': {'required': false}
      },
      values: request.body
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var assetId = values.assetId;
        var businessId = values.businessId;
        var label = values.label;
        var tags = values.tags === undefined ? [] : values.tags;
        var state = values.state;
        var params;

        params = {
          _id: assetId,
          businessId: businessId,
          label: label,
          tags: tags,
          state: state
        };

        businessRepo.updateAsset(params, function(err, asset) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, asset, response, 200, reqType);
          }
        });
      });
    }
  });
};

//TODO les params sont louches
/**
 * @method Business - deletePackage
 * @desc /{wyclubToken}/businesspackage.json
 * @httpmethod DELETE
 * @summary Business.deletePackage — Delete a specified business package.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.packageId] - ID of the package to delete
 * @param {Object} response
 * @param {Object} response.status
 *
 * @public
 */
Business.prototype.deletePackage = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: ['packageId'],
      schema: {'packageId': {'required': true}},
      values: request.body
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var packageId = values.packageId;
        var params = {_id: packageId};

        businessRepo.delete(params, 'package', function(err, numberOfRemove) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, {deleted: numberOfRemove}, response, 200, reqType);
          }
        });
      });
    }
  });
};

//TODO les params sont louches
/**
 * @method Business - deleteService
 * @desc /{wyclubToken}/businessservice.json
 * @httpmethod DELETE
 * @summary Business.deleteService — Delete a specified business service.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.serviceId] - ID of the service to delete
 * @param {Object} response
 * @param {Object} response.status
 *
 * @public
 */
Business.prototype.deleteService = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: ['serviceId'],
      schema: {'serviceId': {'required': true}},
      values: request.body
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var serviceId = values.serviceId;
        var params = {_id: serviceId};

        businessRepo.delete(params, 'service', function(err, numberOfRemove) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, {deleted: numberOfRemove}, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Business - deleteAsset
 * @desc /{wyclubToken}/businessasset.json
 * @httpmethod DELETE
 * @summary Business.deleteAsset — Delete a specified business asset.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - Id of the package to delete
 * @param {string} [request.body.assetId] - ID of the asset to delete
 * @param {Object} response
 * @param {Object} response.status
 *
 * @public
 */
Business.prototype.deleteAsset = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: ['assetId'],
      schema: {'assetId': {'required': true}},
      values: request.body
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var assetId = values.assetId;
        var params = {_id: assetId};

        businessRepo.delete(params, 'asset', function(err, numberOfRemove) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, {deleted: numberOfRemove}, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Business - linkPackageToService
 * @desc /{wyclubToken}/businesslinkpackageservice.json
 * @httpmethod POST
 * @summary Business.linkPackageToService — Link a business package to a business service.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.service_id] - The ID of the service to link
 * @param {string} [request.body.package_id] - The ID of the package to link
 * @param {Object} response
 * @param {Object} response.status
 *
 * @public
 */
Business.prototype.linkPackageToService = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: [
        'package_id',
        'service_id'
      ],
      schema: {
        'service_id': {'required': true},
        'package_id': {'required': true}
      },
      values: request.body
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var package_id = values.package_id; //jshint ignore:line
        var service_id = values.service_id; //jshint ignore:line

        businessRepo.linkPackageToService({
          package_id: package_id, //jshint ignore:line
          service_id: service_id //jshint ignore:line
        }, function(err, status) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            if (status !== 0) {
              status = {linked: 1};
            } else {
              status = {linked: 0};
            }
            self.postProcessSuccess(request, status, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Business - unlinkPackageToService
 * @desc /{wyclubToken}/businesslinkpackageservice.json
 * @httpmethod DELETE
 * @summary Business.unlinkPackageToService — Unlink a business package from a business service.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.service_id] - The ID of the service to unlink
 * @param {string} [request.body.package_id] - The ID of the package to unlink
 * @param {Object} response
 * @param {Object} response.status
 *
 * @public
 */
Business.prototype.unlinkPackageToService = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: [
        'package_id',
        'service_id'
      ],
      schema: {
        'service_id': {'required': true},
        'package_id': {'required': true}
      },
      values: request.body
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var package_id = values.package_id;  //jshint ignore:line
        var service_id = values.service_id;  //jshint ignore:line

        businessRepo.unlinkPackageToService({
          package_id: package_id, //jshint ignore:line
          service_id: service_id //jshint ignore:line
        }, function(err, status) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            if (status !== 0) {
              status = {unlinked: 1};
            } else {
              status = {unlinked: 0};
            }
            self.postProcessSuccess(request, status, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Business - linkPackageToAsset
 * @desc /{wyclubToken}/businesslinkpackageasset.json
 * @httpmethod POST
 * @summary Business.linkPackageToAsset — Link a business package to a business asset.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.asset_id] - The ID of the asset to link
 * @param {string} [request.body.package_id] - The ID of the package to link
 * @param {Object} response
 * @param {Object} response.status
 *
 * @public
 */
Business.prototype.linkPackageToAsset = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: [
        'package_id',
        'asset_id'
      ],
      schema: {
        'asset_id': {'required': true},
        'package_id': {'required': true}
      },
      values: request.body
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var package_id = values.package_id; //jshint ignore:line
        var asset_id = values.asset_id;  //jshint ignore:line

        businessRepo.linkPackageToAsset({
          package_id: package_id, //jshint ignore:line
          asset_id: asset_id //jshint ignore:line
        }, function(err, status) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            if (status !== 0) {
              status = {linked: 1};
            } else {
              status = {linked: 0};
            }
            self.postProcessSuccess(request, status, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Business - unlinkPackageToAsset
 * @desc /{wyclubToken}/businesslinkpackageasset.json
 * @httpmethod DELETE
 * @summary Business.unlinkPackageToAsset — Unlink a business package from a business asset.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.asset_id] - The ID of the asset to unlink
 * @param {string} [request.body.package_id] - The ID of the package to unlink
 * @param {Object} response
 * @param {Object} response.status
 *
 * @public
 */
Business.prototype.unlinkPackageToAsset = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: [
        'package_id',
        'asset_id'
      ],
      schema: {
        'asset_id': {'required': true},
        'package_id': {'required': true}
      },
      values: request.body
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var package_id = values.package_id; //jshint ignore:line
        var asset_id = values.asset_id; //jshint ignore:line

        businessRepo.unlinkPackageToAsset({
          package_id: package_id, //jshint ignore:line
          asset_id: asset_id //jshint ignore:line
        }, function(err, status) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            if (status !== 0) {
              status = {unlinked: 1};
            } else {
              status = {unlinked: 0};
            }
            self.postProcessSuccess(request, status, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Business - linkServiceToAsset
 * @desc /{wyclubToken}/businesslinkassetservice.json
 * @httpmethod POST
 * @summary Business.linkServiceToAsset — Link a business service to a business asset.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.asset_id] - The ID of the service to link
 * @param {string} [request.body.service_id] - The ID of the asset to link
 * @param {Object} response
 * @param {Object} response.status
 *
 * @public
 */
Business.prototype.linkServiceToAsset = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: [
        'service_id',
        'asset_id'
      ],
      schema: {
        'asset_id': {'required': true},
        'service_id': {'required': true}
      },
      values: request.body
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var service_id = values.service_id; //jshint ignore:line
        var asset_id = values.asset_id; //jshint ignore:line

        businessRepo.linkServiceToAsset({
          service_id: service_id, //jshint ignore:line
          asset_id: asset_id //jshint ignore:line
        }, function(err, status) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            if (status !== 0) {
              status = {linked: 1};
            } else {
              status = {linked: 0};
            }
            self.postProcessSuccess(request, status, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Business - unlinkServiceToAsset
 * @desc /{wyclubToken}/businesslinkassetservice.json
 * @httpmethod DELETE
 * @summary Business.unlinkServiceToAsset — Unlink a business service from a business asset.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.asset_id] - The ID of the service to unlink
 * @param {string} [request.body.service_id] - The ID of the asset to unlink
 * @param {Object} response
 * @param {Object} response.status
 *
 * @public
 */
Business.prototype.unlinkServiceToAsset = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: [
        'service_id',
        'asset_id'
      ],
      schema: {
        'asset_id': {'required': true},
        'service_id': {'required': true}
      },
      values: request.body
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var service_id = values.service_id; //jshint ignore:line
        var asset_id = values.asset_id; //jshint ignore:line

        businessRepo.unlinkServiceToAsset({
          service_id: service_id, //jshint ignore:line
          asset_id: asset_id //jshint ignore:line
        }, function(err, status) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            if (status !== 0) {
              status = {unlinked: 1};
            } else {
              status = {unlinked: 0};
            }
            self.postProcessSuccess(request, status, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Business - linkServiceToApplication
 * @desc /{wyclubToken}/businesslinkapplicationservice.json
 * @httpmethod POST
 * @summary Business.linkServiceToApplication — Link a business service to an application.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.application_id] - The ID of the application to link
 * @param {string} [request.body.service_id] - The ID of the service to link
 * @param {Object} response
 * @param {Object} response.status
 *
 * @public
 */
Business.prototype.linkServiceToApplication = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: [
        'application_id',
        'service_id'
      ],
      schema: {
        'application_id': {'required': true},
        'service_id': {'required': true}
      },
      values: request.body
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var application_id = values.application_id; //jshint ignore:line
        var service_id = values.service_id; //jshint ignore:line

        businessRepo.linkApplicationToService({
          service_id: service_id, //jshint ignore:line
          application_id: application_id //jshint ignore:line
        }, function(err, status) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            if (status.applicationId !== null) {
              status = {linked: 1};
            } else {
              status = {linked: 0};
            }
            self.postProcessSuccess(request, status, response, 200, reqType);
          }
        });
      });
    }
  });
};

/**
 * @method Business - unlinkServiceToApplication
 * @desc /{wyclubToken}/businesslinkapplicationservice.json
 * @httpmethod DELETE
 * @summary Business.unlinkServiceToApplication — Unlink a business service from an application.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
   * @param {string} request.body.application_id - The ID of the application to unlink
 * @param {string} [request.body.service_id] - The ID of the service to unlink
 * @param {Object} response
 * @param {Object} response.status
 *
 * @public
 */
Business.prototype.unlinkServiceToApplication = function(request, response) {
  'use strict';

  var self = Core.controller.business;
  self.process({
    jsonSchema: {
      keys: [
        'application_id',
        'service_id'
      ],
      schema: {
        'application_id': {'required': false},
        'service_id': {'required': true}
      },
      values: request.body
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        var application_id = values.application_id; //jshint ignore:line
        var service_id = values.service_id; //jshint ignore:line

        businessRepo.unlinkApplicationToService({
          service_id: service_id, //jshint ignore:line
          application_id: application_id //jshint ignore:line
        }, function(err, status) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            if (status.applicationId === null) {
              status = {unlinked: 1};
            } else {
              status = {unlinked: 0};
            }
            self.postProcessSuccess(request, status, response, 200, reqType);
          }
        });
      });
    }
  });
};

module.exports = new Business();