/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */
/**
 * System Controller
 */

// Get dependencies
var httpTools = require('../lib/httpTools');
var asyncblock = require('asyncblock');
var Controller = require('../lib/controller');

// Init controller prototype
var System = function() {
  'use strict';
};

System.prototype = Object.create(Controller.prototype);

/**
 * @method System - reset
 * @desc /{wyclubToken}/reset.json
 * @httpmethod GET
 * @summary System.reset — Reset the Core data.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {Object} response
 * @param {boolean} response.result
 *
 * @public
 */
System.prototype.reset = function(req, res) {
  'use strict';

  var cmdTestPool = 'app/console -f';
  var exec = require('child_process').exec;
  asyncblock(function(flow) {
    //testpool
    exec(cmdTestPool, {maxBuffer: 1024 * 1024}, flow.add());
    var result1 = flow.wait();

    console.log(result1);
    Core.log(result1.indexOf('Restore is done'));

    var resetData;
    if (result1.indexOf('Restore is done') > -1) {
      resetData = {isReseted: true};
      httpTools.setResponse(req, resetData, res, 200, 'JSON');
    } else {
      resetData = {
        msg: 'Error during the execution of command',
        code: 47
      };
      httpTools.setResponse(req, resetData, res, 200, 'JSON');
    }
  });
};

/**
 * @method System - generateRules
 * @desc /{applicationId}/generateRules.json
 * @httpmethod GET
 * @summary System.generateRules — Generate rules.
 * @param {Object} reuest
 * @param {string} [request.params.applicationId] - An application ID
 * @param {Object} response
 * @param {boolean} response.result
 *
 * @public
 */
System.prototype.generateRules = function(req, res) {
  'use strict';

  Core.repository.application.read({_id: req.params.applicationId}, function(err, application) {
    var error;
    if (err) {
      error = httpTools.getError(err);
      httpTools.setResponse(req, error, res, 200, 'JSON');
    } else {
      if (application.label === 'backOffice') {
        var rules = require('../lib/rule');
        rules.generateRule(function(err) {
          if (err) {
            httpTools.setResponse(req, err, res, 200, 'JSON');
          } else {
            rules.loadRules(function() {
              httpTools.setResponse(req, 'rules loaded', res, 200, 'JSON');
            });
          }
        });
      } else {
        error = httpTools.getError('NOT_AUTHORIZED');
        httpTools.setResponse(req, error, res, 200, 'JSON');
      }
    }
  });
};

/**
 * @method System - generateWebservices
 * @desc /{applicationId}/generateWebservices.json
 * @httpmethod GET
 * @summary System.generateWebservices — Generate webservices.
 * @param {Object} request
 * @param {string} [request.params.applicationId] - An application ID
 * @param {Object} response
 * @param {boolean} response.result
 *
 * @public
 */
System.prototype.generateWebservices = function(req, res) {
  'use strict';

  Core.repository.application.read({_id: req.params.applicationId}, function(err, application) {
    var error;

    if (err) {
      error = httpTools.getError(err);
      httpTools.setResponse(req, error, res, 200, 'JSON');
    } else {
      if (application.label === 'backOffice') {
        Core.repository.webservice.delete({types: 'core'}, function() {
          var rules = require('../lib/rule');
          rules.generateServicesFromRoutes('Core', function(err) {
            if (err) {
              httpTools.setResponse(req, err, res, 200, 'JSON');
            } else {
              httpTools.setResponse(req, 'Webservices created', res, 200, 'JSON');
            }
          });
        });
      } else {
        error = httpTools.getError('NOT_AUTHORIZED');
        httpTools.setResponse(req, error, res, 200, 'JSON');
      }
    }
  });
};

module.exports = new System();