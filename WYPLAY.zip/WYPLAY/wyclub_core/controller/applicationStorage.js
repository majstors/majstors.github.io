/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/**
 *  Application Storage Controller
 */

// Get repositories
var applicationStorageRepo = Core.repository.applicationStorage;

// Get dependencies
var Controller = require('../lib/controller');

// Init controller prototype
var ApplicationStorage = function() {
  'use strict';
};

ApplicationStorage.prototype = Object.create(Controller.prototype);

/**
 * @method ApplicationStorage - create
 * @desc /{wyclubToken}/applicationStorage.json
 * @httpmethod POST
 * @summary ApplicationStorage.create — Create application storage data in the current session.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.key] - The key of the new storage
 * @param {string} [request.body.value] - The value of the new storage
 * @param {Object} response
 * @param {Object} response.applicationStorage
 *
 * @public
 */
ApplicationStorage.prototype.create = function(request, response) {
  'use strict';

  var self = Core.controller.applicationStorage;
  self.process({
    jsonSchema: {
      keys: [
        'wyclubToken',
        'key',
        'value'
      ],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        key: {required: true},
        value: {required: true}
      },
      values: {
        wyclubToken: request.params.wyclubToken,
        key: request.body.key,
        value: request.body.value
      }
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function(session) {
        if (session !== undefined && session.application !== undefined && session.application._id !== undefined) {
          var params = {
            key: values.key,
            value: values.value,
            optimisticLock: new Date().getTime(),
            applicationId: session.application._id
          };

          if (session.subscriber !== undefined && session.subscriber._id !== undefined) {
            params.subscriberId = session.subscriber._id;
            if (session.profile !== undefined && session.profile._id !== undefined) {
              params.profileId = session.profile._id;
            }
          }

          applicationStorageRepo.create(params, function(err, applicationStorage) {
            if (err === null) {
              self.postProcessSuccess(request, applicationStorage, response, 200, reqType);
            } else {
              self.postProcessError(request, response, 200, reqType, 'NO_SESSION', err);
            }
          });
        } else {
          self.postProcessError(request, response, 200, reqType, 'NO_SESSION');
        }
      });
    }
  });
  return undefined;
};

/**
 * @method ApplicationStorage - read
 * @desc /{wyclubToken}/applicationstorage.json
 * @httpmethod GET
 * @summary ApplicationStorage.prototype.read — Read a specific application storage key's data from the current session.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.query.key] - The storage key.
 * @param {Object} response
 * @param {Object} response.applicationStorage
 *
 * @public
 */
ApplicationStorage.prototype.read = function(request, response) {
  'use strict';

  var self = Core.controller.applicationStorage;
  self.process({
    jsonSchema: {
      keys: [
        'wyclubToken',
        'key'
      ],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        }
      },
      values: {
        wyclubToken: request.params.wyclubToken,
        key: request.query.key
      }
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function(session) {
        if (session !== undefined && session.subscriber !== undefined && session.profile !== undefined &&
            session.application !== undefined) {
          var params = {
            key: request.query.key,
            subscriberId: session.subscriber._id,
            profileId: session.profile._id,
            applicationId: session.application._id
          };

          applicationStorageRepo.read(params, function(err, applicationStorage) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              self.postProcessSuccess(request, applicationStorage, response, 200, reqType);
            }
          });
        } else {
          self.postProcessError(request, response, 200, reqType, 'NO_SESSION');
        }
      });
    }
  });
  return undefined;
};

/**
 * @method ApplicationStorage - readAll
 * @desc /{wyclubToken}/applicationallstorage.json
 * @httpmethod GET
 * @summary ApplicationStorage.readAll — Read all the application storage data in the current session.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {Object} response
 * @param {Object} response.applicationAllStorage
 *
 * @public
 */
ApplicationStorage.prototype.readAll = function(request, response) {
  'use strict';

  var self = Core.controller.applicationStorage;
  self.process({
    jsonSchema: {
      keys: ['wyclubToken'],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        }
      },
      values: {wyclubToken: request.params.wyclubToken}
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function(session) {
        if (session !== undefined && session.subscriber !== undefined && session.profile !== undefined &&
            session.application !== undefined) {
          var params = {
            subscriberId: session.subscriber._id,
            profileId: session.profile._id,
            applicationId: session.application._id
          };

          applicationStorageRepo.readAll(params, function(err, applicationStorage) {
            if (err === null) {
              self.postProcessSuccess(request, applicationStorage, response, 200, reqType);
            } else {
              self.postProcessError(request, response, 200, reqType, err);
            }
          });
        } else {
          self.postProcessError(request, response, 200, reqType, 'NO_SESSION');
        }
      });
    }
  });
};

/**
 * @method ApplicationStorage - update
 * @desc /{wyclubToken}/applicationstorage.json
 * @httpmethod PUT
 * @summary ApplicationStorage.update — Update specific application storage data in the current session.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.key] - The key of the storage to update
 * @param {string} [request.body.value] - The new storage value
 * @param {integer} request.body.optimisticLock - A random generated key to prevent update conflicts (leave it empty to force)
 * @param {Object} response
 * @param {Object} response.applicationStorage
 *
 * @public
 */
ApplicationStorage.prototype.update = function(request, response) {
  'use strict';

  var self = Core.controller.applicationStorage;
  var jsonSchema = {
    keys: [
      'wyclubToken',
      'key',
      'value'
    ],
    schema: {
      wyclubToken: {
        type: 'string',
        required: true,
        minLength: 32,
        maxLength: 32
      },
      value: {required: true}
    },
    values: {
      wyclubToken: request.params.wyclubToken,
      key: request.body.key,
      value: request.body.value
    }
  };

  if (request.body.optimisticLock !== undefined) {
    jsonSchema.values.optimisticLock = request.body.optimisticLock;
    jsonSchema.schema.optimisticLock = {
      type: 'integer',
      required: false
    };
    jsonSchema.keys.push('optimisticLock');
  }

  self.process({
    jsonSchema: jsonSchema,
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function(session) {
        if (session !== undefined && session.subscriber !== undefined && session.profile !== undefined &&
            session.application !== undefined) {
          var params = {
            key: values.key,
            subscriberId: session.subscriber._id,
            profileId: session.profile._id,
            applicationId: session.application._id
          };

          async.waterfall([
            function(callback) {
              if (values.optimisticLock !== undefined) {
                applicationStorageRepo.read(params, function(err, applicationStorage) {
                  if (err !== null) {
                    callback(err);
                  } else {
                      console.log(values.optimisticLock);
                      console.log(applicationStorage.optimisticLock);
                    if (values.optimisticLock !== applicationStorage.optimisticLock) {
                      callback('OPTIMISTICLOCK_EMPTY');
                    } else {
                      callback(null, 'done');
                    }
                  }
                });
              } else {
                callback(null, 'done');
              }
            },
            function(result, callback) {
              params.value = values.value;
              applicationStorageRepo.update(params, function(err, applicationStorage) {
                if (err !== null) {
                  callback(err);
                } else {
                  callback(null, applicationStorage);
                }
              });
            }
          ], function(err, applicationStorage) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              self.postProcessSuccess(request, applicationStorage, response, 200, reqType);
            }
          });
        }
      });
    }
  });
};

/**
 * @method ApplicationStorage - delete
 * @desc /{wyclubToken}/applicationstorage.json
 * @httpmethod DELETE
 * @summary ApplicationStorage.delete — Delete application storage data from the current session.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.key] - The key of the storage to delete
 * @param {integer} request.body.optimisticLock - A random generated key to prevent update conflicts (leave it empty to force)
 * @param {Object} response
 * @param {Object} response.applicationStorage
 *
 * @public
 */
ApplicationStorage.prototype.delete = function(request, response) {
  'use strict';

  var self = Core.controller.applicationStorage;
  var jsonSchema = {
    keys: [
      'wyclubToken',
      'key'
    ],
    schema: {
      wyclubToken: {
        type: 'string',
        required: true,
        minLength: 32,
        maxLength: 32
      }
    },
    values: {
      wyclubToken: request.params.wyclubToken,
      key: request.body.key
    }
  };

  if (request.body.optimisticLock !== undefined) {
    jsonSchema.values.optimisticLock = request.body.optimisticLock;
    jsonSchema.schema.optimisticLock = {
      type: 'integer',
      required: false
    };
    jsonSchema.keys.push('optimisticLock');
  }

  self.process({
    jsonSchema: jsonSchema,
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function(session) {
        if (session !== undefined && session.subscriber !== undefined && session.profile !== undefined &&
            session.application !== undefined) {
          var params = {
            key: values.key,
            subscriberId: session.subscriber._id,
            profileId: session.profile._id,
            applicationId: session.application._id
          };

          async.waterfall([
            function(callback) {
              if (values.optimisticLock !== undefined) {
                applicationStorageRepo.read(params, function(err, applicationStorage) {
                  if (err !== null) {
                    callback(err);
                  } else {
                    Core.log(values.optimisticLock);
                    Core.log(applicationStorage.optimisticLock);
                    if (values.optimisticLock !== applicationStorage.optimisticLock) {
                      callback('OPTIMISTICLOCK_EMPTY');
                    } else {
                      callback(null, 'done');
                    }
                  }
                });
              } else {
                callback(null, 'done');
              }
            },
            function(result, callback) {
              applicationStorageRepo.delete(params, function(err, numberOfRemovedDocs) {
                if (err !== null) {
                  callback(err);
                } else {
                  callback(null, numberOfRemovedDocs);
                }
              });
            }
          ], function(err, numberOfRemovedDocs) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              self.postProcessSuccess(request, {deleted: numberOfRemovedDocs}, response, 200, reqType);
            }
          });
        } else {
          self.postProcessError(request, response, 200, reqType, 'NO_SESSION');
        }
      });
    }
  });
  return undefined;
};

module.exports = new ApplicationStorage();