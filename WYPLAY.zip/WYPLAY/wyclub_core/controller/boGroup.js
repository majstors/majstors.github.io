/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/**
 *  BO Groups Controller
 */

// Get repositories

// Get dependencies
var Controller = require('../lib/controller');

// Init controller prototype
var boGroup = function () {
  'use strict';
};

boGroup.prototype = Object.create(Controller.prototype);

boGroup.prototype.readSession = function (request, response, reqType, wyclubToken, callback) {
  var self = this;
  Controller.prototype.readSession.call(this, request, response, reqType, wyclubToken, function (session) {
    Core.repository.session.hasTag({wyclubToken: wyclubToken, tag: 'NHKqF75FeJWJZ4e7xYgXMLHwzEpPuOkR'}, function (err, result) {
      if (err) {
        self.postProcessError(request, response, 200, reqType, err);
      } else if (!result) {
        self.postProcessError(request, response, 200, reqType, 'NO_SUPERADMIN');
      } else {
        callback(session);
      }
    });
  });
}

/**
 * @method boGroup - read
 * @desc /{wyclubToken}/boGroup.json
 * @httpmethod GET
 * @summary boGroup.read — Read a group.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.query._id] - A backoffice group id
 * @param {Object} response
 *
 * @public
 */
boGroup.prototype.read = function (request, response) {
  'use strict';
  var self = Core.controller.boGroup;

  self.process({
    jsonSchema: self.getDefaultIdJsonSchema(request),
    request: request,
    response: response,
    checkSession: true,
    action: function (values, reqType, request, response) {
      Core.repository.boGroup.read({_id: values._id}, function (err, group) {
        if (err !== null) {
          self.postProcessError(request, response, 200, reqType, err);
        } else {
          self.postProcessSuccess(request, group, response, 200, reqType);
        }
      });
    }
  });
};

/**
 * @method boGroup - readAll
 * @desc /{wyclubToken}/boGroup/list.json
 * @httpmethod GET
 * @summary boGroup.readAll — Read all groups.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {Object} response
 *
 * @public
 */
boGroup.prototype.readAll = function (request, response) {
  'use strict';
  var self = Core.controller.boGroup;

  self.process({
    jsonSchema: self.getDefaultSessionJsonSchema(request),
    request: request,
    response: response,
    checkSession: true,
    action: function (values, reqType, request, response) {
      Core.repository.boGroup.readAll({}, function (err, group) {
        if (err !== null) {
          self.postProcessError(request, response, 200, reqType, err);
        } else {
          self.postProcessSuccess(request, group, response, 200, reqType);
        }
      });
    }
  });
};

/**
 * @method boGroup - create
 * @desc /{wyclubToken}/boGroup.json
 * @httpmethod POST
 * @summary boGroup.create — Create a group.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.name] - A backoffice group name
 * @param {Object} response
 *
 * @public
 */
boGroup.prototype.create = function (request, response) {
  'use strict';
  var self = Core.controller.boGroup;

  var schema = self.getDefaultSessionJsonSchema(request);
  self.addEntryToJsonSchema(schema, 'name', request.body.name, {
    type: 'string',
    required: true
  });
  self.process({
    jsonSchema: schema,
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      Core.repository.boGroup.create(request.body, function (err, group) {
        if (err !== null) {
          if (err.code === 11000) {
            self.postProcessError(request, response, 200, reqType, 'DUPLICATE_ENTRY', err);
          } else {
            self.postProcessError(request, response, 200, reqType, err);
          }
        } else {
          self.postProcessSuccess(request, group[0], response, 200, reqType);
        }
      });
    }
  });
}

/**
 * @method boGroup - update
 * @desc /{wyclubToken}/boGroup.json
 * @httpmethod PUT
 * @summary boGroup.update — Update a group.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body._id] - A backoffice group id
 * @param {string} [request.body.name] - A backoffice group name
 * @param {Object} response
 *
 * @public
 */
boGroup.prototype.update = function (request, response) {
  'use strict';
  var self = Core.controller.boGroup;

  self.process({
    jsonSchema: self.getDefaultIdJsonSchema(request),
    request: request,
    response: response,
    checkSession: true,
    action: function (values, reqType, request, response) {
      Core.repository.boGroup.update(request.body, function (err, group) {
        if (err !== null) {
          self.postProcessError(request, response, 200, reqType, err);
        } else {
          self.postProcessSuccess(request, {updated: group}, response, 200, reqType);
        }
      });
    }
  });
};

/**
 * @method boGroup - delete
 * @desc /{wyclubToken}/boGroup.json
 * @httpmethod DELETE
 * @summary boGroup.delete — Delete a group.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body._id] - A backoffice group id
 * @param {Object} response
 *
 * @public
 */
boGroup.prototype.delete = function (request, response) {
  'use strict';
  var self = Core.controller.boGroup;

  self.process({
    jsonSchema: self.getDefaultIdJsonSchema(request),
    request: request,
    response: response,
    checkSession: true,
    action: function (values, reqType, request, response) {
      Core.repository.boGroup.delete({_id: values._id}, function (err, group) {
        if (err !== null) {
          self.postProcessError(request, response, 200, reqType, err);
        } else {
          self.postProcessSuccess(request, {updated: group}, response, 200, reqType);
        }
      });
    }
  });
};

module.exports = new boGroup();