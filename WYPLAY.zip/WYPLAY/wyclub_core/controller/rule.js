/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* global tools:true */

/*
 * Rule Controller
 */

// Get repositories
var ruleRepo = Core.repository.rule;
var webserviceRepo = Core.repository.webservice;
var underscore = require('underscore');
var Controller = require('../lib/controller');
var ruleLib = require('../lib/rule');
var tools = require('../lib/tools');

// Init controller prototype
var Rule = function () {
  'use strict';
};

Rule.prototype = Object.create(Controller.prototype);

/**
 * @method Rule - readProtoRule
 * @desc /{wyclubToken}/rule.json
 * @httpmethod GET
 * @summary Rule.readProtoRule — Read all associated rules associated to the protorule,
 * including the protorule itself.
 * @param {Object} request
  * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} request.query.ruleId - The rule ID
 * @param {string} request.query.webserviceName - The webservice name to link with the rule
 * @param {Object} response
 * @param {Object} response.protorule
 *
 * @public
 */
Rule.prototype.readProtoRule = function (request, response) {
  'use strict';

  var self = Core.controller.rule;
  self.process({
    jsonSchema: {
      keys: [
        'ruleId',
        'webserviceName'
      ],
      schema: {
        'ruleId': {
          type: 'string',
          'required': false
        },
        'webserviceName': {
          type: 'string',
          'required': false
        }
      },
      values: request.query
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      var params = {
        'ruleId': values.ruleId,
        'webserviceName': values.webserviceName
      };

      if (params.ruleId !== undefined) {
        ruleRepo.read({_id: params.ruleId}, function (err, rule) {
          if (err === null) {
            self.postProcessSuccess(request, rule, response, 200, reqType);
          } else {
            self.postProcessError(request, response, 200, reqType, err);
          }
        });
      } else if (params.webserviceName !== undefined) {
        ruleRepo.readRulesByServiceName({webservicename: params.webserviceName}, function (err, rules) {
          if (err === null) {
            self.postProcessSuccess(request, rules, response, 200, reqType);
          } else {
            self.postProcessError(request, response, 200, reqType, err);
          }
        });
      } else {
        ruleRepo.readAll(null, function (err, rule) {
          if (err === null) {
            self.postProcessSuccess(request, rule, response, 200, reqType);
          } else {
            self.postProcessError(request, response, 200, reqType, err);
          }
        });
      }
    }
  });
};

/**
 * @method Rule - create
 * @desc /{wyclubToken}/rule.json
 * @httpmethod POST
 * @summary Rule.create — Create a new rule: associate values and a webservice to a protorule.
 * @param {Object} request
  * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body._id] - The protorule ID
 * @param {string} [request.body.webservice] - The new rule linked webservice
 * @param {Object} [request.body.values] - The new rule value of all proto rule variables
 * @param {Object} response
 * @param {Object} response.protorule
 *
 * @public
 */
Rule.prototype.create = function (request, response) {
  'use strict';

  var self = Core.controller.rule;
  var values = {
    '_id': request.body._id,
    'webservice': request.body.webservice,
    wyclubToken: request.params.wyclubToken
  };

  if (request.body.values !== undefined) {
    values.values = request.body.values;
  }

  self.process({
    jsonSchema: {
      keys: [
        '_id',
        'values',
        'webservice'
      ],
      schema: {
        '_id': {
          'type': 'string',
          'required': true
        },
        'values': {
          type: 'object',
          'required': true
        },
        'webservice': {
          type: 'string',
          'required': true
        }
      },
      values: values
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function () {
        ruleRepo.read({_id: values._id}, function (err, rule) {
          webserviceRepo.readCustom({name: values.webservice}, function (err, webservice) {
            if (webservice !== null && err === null) {
              if (rule !== null && err === null) {
                if (rule.schema !== undefined || underscore.where(rule.rules, {webservice: webservice[0].name}).length < 1) {
                  if (rule.schema !== undefined) {
                    var rulesForThatWebservice = underscore.where(rule.rules, {webservice: values.webservice});
                    var allAreDifferent = true;
                    rulesForThatWebservice.forEach(function(rule){
                      var isDifferent = false;
                      for(var key in values.values){
                        if(rule.values[key] !== values.values[key]){
                          isDifferent = true;
                        }
                      }
                      allAreDifferent = allAreDifferent && isDifferent
                    });
                    if(allAreDifferent) {
                      var validity = Core.rulesValidator.validate(values.values, rule.schema);
                      if (validity.errors.length === 0) {
                        var subRuleId = tools.generatePublicKey(32);
                        if(!rule.rules){
                          rule.rules = [];
                        }
                        rule.rules.push({
                          _id: subRuleId,
                          webservice: values.webservice,
                          values: values.values
                        });
                        ruleRepo.update(rule, function (err) {
                          if (err === null) {
                            ruleLib.generateRule(function () {
                              self.postProcessSuccess(request, rule, response, 200, reqType);
                            }, values._id, values.webservice, rule.type, false, subRuleId);
                          } else {
                            self.postProcessError(request, response, 200, reqType, err);
                          }
                        });
                      } else {
                        self.postProcessError(request, response, 200, reqType, 'JSON_SCHEMA_ERROR');
                      }
                    } else {
                      self.postProcessError(request, response, 200, reqType, 'RULES_ALREADY_EXIST');
                    }
                  } else if (values.values !== undefined && tools.isEmpty(values.values)) {
                    if (rule.rules === undefined) {
                      rule.rules = [];
                    }
                    var subRuleId = tools.generatePublicKey(32);
                    rule.rules.push({_id:subRuleId, webservice: values.webservice});
                    ruleRepo.update(rule, function (err) {
                      if (err === null) {
                        ruleLib.generateRule(function () {
                          self.postProcessSuccess(request, rule, response, 200, reqType);
                        }, values._id, values.webservice, rule.type, false, subRuleId);
                      } else {
                        self.postProcessError(request, response, 200, reqType, err);
                      }
                    });
                  } else {
                    self.postProcessError(request, response, 200, reqType, 'NO_RULES_VALUES');
                  }
                } else {
                  self.postProcessError(request, response, 200, reqType, 'RULES_ALREADY_EXIST');
                }
              } else {
                self.postProcessError(request, response, 200, reqType, 'NO_RULE');
              }
            } else {
              self.postProcessError(request, response, 200, reqType, 'NO_WEBSERVICE');
            }
          });
        });
      });
    }
  });
};

/**
 * @method Rule - createProtoRule
 * @desc /{wyclubToken}/protorule.json
 * @httpmethod POST
 * @summary Rule.createProtoRule — Create a new protorule.
 * @param {Object} request
  * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.label] - The new rule name
 * @param {string} [request.body.type] - The new rule type (sync, async...)
 * @param {string} [request.body.sourcecode] - The new rule source code
 * @param {string} [request.body.schema] - The new rule schema
 * @param {Object} response
 * @param {Object} response.protorule
 *
 * @public
 */
Rule.prototype.createProtoRule = function (request, response) {
  'use strict';

  var self = Core.controller.rule;
  self.process({
    jsonSchema: {
      keys: [
        'label',
        'type',
        'sourcecode',
        'wyclubToken'
      ],
      schema: {
        'label': {
          type: 'string',
          'required': true
        },
        'type': {'required': true},
        'wyclubToken': {
          type: 'string',
          'required': true
        },
        'sourcecode': {
          type: 'string',
          'required': true
        },
        'schema': {
          type: 'object',
          'required': true
        }
      },
      values: {
        'label': request.body.label,
        'type': request.body.type,
        'sourcecode': request.body.sourcecode,
        'schema': request.body.schema,
        wyclubToken: request.params.wyclubToken
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function () {
        if (values.label !== '' && values.type !== '' && values.sourcecode !== '') {
          ruleRepo.create(values, function (err, rule) {
            if (err === null) {
              self.postProcessSuccess(request, rule, response, 200, reqType);
            } else {
              self.postProcessError(request, response, 200, reqType, err);
            }
          });
        } else {
          self.postProcessError(request, response, 200, reqType, 'INVALID_REQ_PARAM');
        }
      });
    }
  });
};

/**
 * @method Rule - updateProtoRule
 * @desc /{wyclubToken}/protorule.json
 * @httpmethod PUT
 * @summary Rule.updateProtoRule — Update a protorule. If the protorule has related rules,
 * updating the type and schema will be prohibited.
 * @param {Object} request
  * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body._id] - The updated rule ID
 * @param {string} request.body.label - The updated rule new label
 * @param {string} request.body.type - The updated rule new type
 * @param {string} request.body.sourcecode - The updated rule new sourcecode
 * @param {string} request.body.schema - The updated rule new schema
 * @param {Object} response
 * @param {Object} response.protorule
 *
 * @public
 */
Rule.prototype.updateProtoRule = function (request, response) {
  'use strict';

  var self = Core.controller.rule;
  self.process({
    jsonSchema: {
      keys: [
        '_id',
        'label',
        'type',
        'sourcecode',
        'wyclubToken'
      ],
      schema: {
        '_id': {
          'required': true,
          type: 'string'
        },
        'label': {type: 'string'},
        'type': {type: 'string'},
        'wyclubToken': {
          type: 'string',
          'required': true
        },
        'sourcecode': {type: 'string'},
        'schema': {type: 'object'}
      },
      values: {
        '_id': request.body._id,
        'label': request.body.label,
        'type': request.body.type,
        'sourcecode': request.body.sourcecode,
        'schema': request.body.schema,
        wyclubToken: request.params.wyclubToken
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function () {
        var params = {_id: values._id};
        if (values.label !== undefined) {
          params.label = values.label;
        }
        if (values.type !== undefined) {
          params.type = values.type;
        }
        if (values.sourcecode !== undefined) {
          params.sourcecode = values.sourcecode;
        }
        if (values.schema !== undefined) {
          params.schema = values.schema;
        }

        ruleRepo.protoUpdate(params, function (err, rule) {
          if (err === null) {
            self.postProcessSuccess(request, rule, response, 200, reqType);
          } else {
            self.postProcessError(request, response, 200, reqType, err);
          }
        });
      });
    }
  });
};

/**
 * @method Rule - update
 * @desc /{wyclubToken}/rule.json
 * @httpmethod PUT
 * @summary Rule.update — Update the values and webservice associated to a protorule.
 * @param {Object} request
  * @param {string} [request.params.wyclubToken] - A session ID
 * @param {Object} [request.body.values] - The updated rule new values for its variables
 * @param {string} [request.body.webservice] - The updated protorule webservice
 * @param {Object} response
 * @param {Object} response.rule
 *
 * @public
 */
Rule.prototype.update = function (request, response) {
  'use strict';

  var self = Core.controller.rule;
  self.process({
    jsonSchema: {
      keys: [
        '_id',
        'values',
        'webservice'
      ],
      schema: {
        '_id': {
          'type': 'string',
          'required': true
        },
        'values': {
          type: 'object',
          'required': true
        },
        'webservice': {
          type: 'string',
          'required': true
        }
      },
      values: {
        '_id': request.body._id,
        'values': request.body.values,
        'webservice': request.body.webservice,
        wyclubToken: request.params.wyclubToken
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function () {
        ruleRepo.read({_id: values._id}, function (err, rule) {
          webserviceRepo.readCustom({name: values.webservice}, function (err, webservice) {
            if (webservice !== null && err === null) {
              if (!tools.isEmpty(rule) && err === null) {
                var subRuleId = request.body.subRuleId;
                if (rule.schema !== undefined) {
                  if(subRuleId !== undefined) {
                    var valueToUpdate = underscore.where(rule.rules, {webservice: values.webservice, _id: subRuleId});
                    if(valueToUpdate.length > 0) {
                      var validity = Core.rulesValidator.validate(values.values, rule.schema);

                      if (validity.errors.length === 0) {
                        var rulesForThatWebservice = underscore.where(rule.rules, {webservice: values.webservice});
                        var allAreDifferent = true;
                        rulesForThatWebservice.forEach(function(rule){
                          var isDifferent = false;
                          for(var key in values.values){
                            if(rule.values[key] !== values.values[key]){
                              isDifferent = true;
                            }
                          }
                          allAreDifferent = allAreDifferent && isDifferent
                        });
                        if(allAreDifferent) {
                          valueToUpdate[0].values = values.values;
                          ruleRepo.update(rule, function (err) {
                            if (err === null) {
                              ruleLib.generateRule(function () {
                                self.postProcessSuccess(request, valueToUpdate, response, 200, reqType);
                              }, values._id, values.webservice, rule.type, true, subRuleId);
                            } else {
                              self.postProcessError(request, response, 200, reqType, err);
                            }
                          });
                        } else {
                          self.postProcessError(request, response, 200, reqType, 'RULES_ALREADY_EXIST');
                        }
                      } else {
                        self.postProcessError(request, response, 200, reqType, 'JSON_SCHEMA_ERROR');
                      }
                    } else {
                      self.postProcessError(request, response, 200, reqType, 'NO_RULE');
                    }
                  } else {
                    self.postProcessError(request, response, 200, reqType, 'SUBRULEID_NEEDED_FOR_PROTORULE');
                  }
                } else if (rule.schema === undefined && values.values !== undefined) {
                  self.postProcessError(request, response, 200, reqType, 'JSON_SCHEMA_ERROR');
                }
              } else {
                self.postProcessError(request, response, 200, reqType, 'NO_RULE');
              }
            } else {
              self.postProcessError(request, response, 200, reqType, 'NO_WEBSERVICE');
            }
          });
        });
      });
    }
  });
};

/**
 * @method Rule - deleteProtoRule
 * @desc /{wyclubToken}/protorule.json
 * @httpmethod DELETE
 * @summary Rule.deleteProtoRule — Delete a protorule and all its associated rules (instances and files).
 * @param {Object} request
  * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body._id] - The deleted protorule ID
 * @param {Object} response
 * @param {Object} response.confirmation
 *
 * @public
 */
Rule.prototype.deleteProtoRule = function (request, response) {
  'use strict';

  var self = Core.controller.rule;
  self.process({
    jsonSchema: {
      keys: [
        '_id',
        'wyclubToken'
      ],
      schema: {
        '_id': {'required': true},
        'wyclubToken': {
          type: 'string',
          'required': true
        }
      },
      values: {
        '_id': request.body._id,
        wyclubToken: request.params.wyclubToken
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function () {
        ruleRepo.read({_id: values._id}, function (err, protoRule) {
          if (err !== null || protoRule === null) {
            self.postProcessError(request, response, 200, reqType, 'NO_RULE');
          } else {
            var queue = async.queue(function (rule, callback) {
              ruleLib.deleteRuleInstance(callback, protoRule._id, rule.webservice, protoRule.type);
            });
            queue.push(protoRule.rules);
            queue.drain = function () {
              ruleRepo.delete(values, function (err) {
                if (err === null) {
                  self.postProcessSuccess(request, {deleted: 1}, response, 200, reqType);
                } else {
                  self.postProcessError(request, response, 200, reqType, err);
                }
              });
            };
          }
        });
      });
    }
  });
};

/**
 * @method Rule - delete
 * @desc /{wyclubToken}/rule.json
 * @httpmethod DELETE
 * @summary Rule.delete — Delete the values and webservice associated to a protorule.
 * @param {Object} request
  * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body._id] - The protorule ID
 * @param {string} [request.body.webservice] - The webservice linked to this protorule
 * @param {Object} response
 * @param {Object} response.confirmation
 *
 * @public
 */
Rule.prototype.delete = function (request, response) {
  'use strict';

  var self = Core.controller.rule;
  self.process({
    jsonSchema: {
      keys: [
        '_id',
        'webservice'
      ],
      schema: {
        '_id': {
          'type': 'string',
          'required': true
        },
        'webservice': {
          'required': true,
          'type': 'string'
        },
        'wyclubToken': {
          type: 'string',
          'required': true
        }
      },
      values: {
        '_id': request.body._id,
        'webservice': request.body.webservice,
        wyclubToken: request.params.wyclubToken
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function () {
        ruleRepo.read({_id: values._id}, function (err, protoRule) {
          if (protoRule !== null && err === null) {
            var rules = protoRule.rules;
            var newRulesArray = [];
            var subRuleId = request.body.subRuleId;
            for (var rulesKey in rules) {
              var identifiedWebservice = (rules[rulesKey].webservice === values.webservice);
              var identifiedProtorule = (rules[rulesKey]._id === undefined || subRuleId === rules[rulesKey]._id);
              var identifiedDeleteRule = (identifiedWebservice && identifiedProtorule);
              if (!identifiedWebservice || !identifiedDeleteRule) {
                newRulesArray.push(rules[rulesKey]);
              }
            }

            if (protoRule.rules.length !== newRulesArray.length) {
              protoRule.rules = newRulesArray;
              ruleRepo.update(protoRule, function (err) {
                if (err === null) {
                  ruleLib.deleteRuleInstance(function () {
                    self.postProcessSuccess(request, protoRule, response, 200, reqType);
                  }, values._id, values.webservice, protoRule.type, subRuleId);
                } else {
                  self.postProcessError(request, response, 200, reqType, err);
                }
              });
            } else {
              self.postProcessError(request, response, 200, reqType, 'NO_RULE');
            }
          } else {
            self.postProcessError(request, response, 200, reqType, err);
          }
        });
      });
    }
  });
};

module.exports = new Rule();