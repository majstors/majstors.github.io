/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

var Controller = require('../lib/controller');

// Init controller prototype
var Event = function() {
  'use strict';
};

Event.prototype = Object.create(Controller.prototype);

/**
 * @method Event - create
 * @desc /{wyclubToken}/event.json
 * @httpmethod POST
 * @summary Event.create — Create a new event.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} request.body.eventName - The name of the event
 * @param {Object} request.body.eventValue - An object containing all values of this event
 * @param {Object} response
 * @param {Object} response.event
 *
 * @public
 */
Event.prototype.create = function(request, response) {
  'use strict';

  var self = Core.controller.session;
  self.process({
    jsonSchema: {
      keys: ['wyclubToken'],
      schema: {
        'wyclubToken': {
          type: 'string',
          'required': true
        },
        'eventName': {
          type: 'string',
          'required': false
        },
        'eventValue': {
          type: 'object',
          'required': false
        }
      },
      values: {wyclubToken: request.params.wyclubToken}
    },
    request: request,
    response: response,
    action: function(values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function() {
        self.postProcessSuccess(request, {}, response, 200, reqType);
      });
    }
  });
};

module.exports = new Event();