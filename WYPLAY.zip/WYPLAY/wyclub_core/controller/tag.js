/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/**
 * Module dependencies.
 */
var tagRepo = Core.repository.tag;

// Get dependencies
var Controller = require('../lib/controller');

// Init controller prototype
var Tag = function () {
  'use strict';
};

Tag.prototype = Object.create(Controller.prototype);

/**
 * @method Tag - read
 * @desc /{wyclubToken}/tag.json
 * @httpmethod GET
 * @summary Tag.read — Read the requested tags.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} request.query.tagPID - Requested tag ID
 * @param {string} request.query.page - number of tags to skip and select e.g { offset: 0, limit: 50}
 * @param {Object} response
 * @param {Object} response.tag
 *
 * @public
 */
Tag.prototype.read = function (request, response) {
  'use strict';

  var self = Core.controller.subscriber;
  self.process({
    jsonSchema: {
      keys: [
        'tagPID',
        'page'
      ],
      schema: {
        'tagPID': { type: 'string' },
        'page': { type: 'string' }
      },
      values: request.query
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function () {
        var tagPID = values.tagPID;
        var page = values.page;
        var whereParams;
        var pageParams;
        var pageDefault = {
          offset: 0,
          limit: 5000
        };

        if (tagPID) {
          whereParams = { _id: tagPID };
          pageParams = [0,1];
        } else {
          whereParams = undefined;
          if (page) {
            pageParams = page.split(',');
            if (!tools.isNumber(pageParams[0])) {
              pageParams[0] = pageDefault.offset;
            }
            if (!tools.isNumber(pageParams[1])) {
              pageParams[1] = pageDefault.limit;
            }
          } else {
            pageParams = [
              pageDefault.offset,
              pageDefault.limit
            ];
          }
        }
        if ( ! tagPID) {
          tagRepo.readAllTags({
            limit: pageParams[1],
            offset: pageParams[0]
          }, function (err, tags) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              self.postProcessSuccess(request, tags, response, 200, reqType);
            }
          });
        } else {
          tagRepo.read({ _id: whereParams._id }, function (err, tags) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              self.postProcessSuccess(request, tags, response, 200, reqType);
            }
          });
        }
      });
    }
  });

  return undefined;
};

/**
 * @method Tag - create
 * @desc /{wyclubToken}/tag.json
 * @httpmethod POST
 * @summary Tag.create — Create new tag.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.label] - The new tag label
 * @param {Object} response
 * @param {Object} response.tag
 *
 * @public
 */
Tag.prototype.create = function (request, response) {
  'use strict';
  var self = Core.controller.tag;
  self.process({
    jsonSchema: {
      keys: [
        'wyclubToken',
        'label'
      ],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        label: {
          type: 'string',
          required: true
        }
      },
      values: {
        'wyclubToken': request.params.wyclubToken,
        'label': request.body.label
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function () {
        tagRepo.create({ label: values.label }, function (err, tag) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, tag, response, 200, reqType);
          }
        });
      });
    }
  });

  return undefined;
};

/**
 * @method Tag - update
 * @desc /{wyclubToken}/tag.json
 * @httpmethod PUT
 * @summary Tag.update — Update a tag.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.tagId] - The updated tag ID
 * @param {string} [request.body.label] - The updated tag new label
 * @param {Object} response
 * @param {Object} response.tag
 *
 * @public
 */
Tag.prototype.update = function (request, response) {
  'use strict';
  var self = Core.controller.tag;
  self.process({
    jsonSchema: {
      keys: [
        'wyclubToken',
        'label',
        'tagId'
      ],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        label: {
          type: 'string',
          required: true
        },
        tagId: {
          type: 'string',
          required: true
        }
      },
      values: {
        'wyclubToken': request.params.wyclubToken,
        'label': request.body.label,
        'tagId': request.body.tagId
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function () {
        tagRepo.update({
          label: values.label,
          _id: values.tagId
        }, function (err, tag) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, { updated: tag }, response, 200, reqType);
          }
        });
      });
    }
  });

  return undefined;
};

/**
 * @method Tag - delete
 * @desc /{wyclubToken}/tag.json
 * @httpmethod DELETE
 * @summary Tag.delete — Delete a tag.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.tagId] - The tag to delete ID
 * @param {Object} response
 * @param {Object} response.tag
 *
 * @public
 */
Tag.prototype.delete = function (request, response) {
  'use strict';

  var self = Core.controller.tag;
  self.process({
    jsonSchema: {
      keys: [
        'wyclubToken',
        'tagId'
      ],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        tagId: {
          type: 'string',
          required: true
        }
      },
      values: {
        'wyclubToken': request.params.wyclubToken,
        'tagId': request.body.tagId
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function () {
        tagRepo.delete({ _id: values.tagId }, function (err, tag) {
          if (err !== null) {
            self.postProcessError(request, response, 200, reqType, err);
          } else {
            self.postProcessSuccess(request, { deleted: tag }, response, 200, reqType);
          }
        });
      });
    }
  });

  return undefined;
};

module.exports = new Tag();