/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/**
 * Module dependencies.
 */

// Get repositories
var subscriberRepo = Core.repository.subscriber;
var applicationRepo = Core.repository.application;

// Get dependencies
var Controller = require('../lib/controller');

// Init controller prototype
var Subscriber = function () {
  'use strict';
};

Subscriber.prototype = Object.create(Controller.prototype);

/**
 * Generic methods of subscriber
 */

// Validate subscriber
Subscriber.prototype.subscriberIsValid = function (session, values, request, response, reqType, callback) {
  'use strict';

  var self = this;
  if (session !== undefined && session.subscriber !== undefined && session.subscriber._id === values.subscriberId) {
    callback();
  } else {
    self.postProcessError(request, response, 200, reqType, 'NO_SUBSCRIBER');
  }
};

/**
 * End generic methods of subscriber
 */

/**
 * @method Subscriber - readProfile
 * @desc /{wyclubToken}/sub/profile.json
 * @httpmethod GET
 * @summary Subscriber.readProfile — Read all profiles of the requested subscriber.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.query.subscriberId] - The requested subscriber id
 * @param {Object} response
 * @param {Object} response.profiles
 *
 * @public
 */
Subscriber.prototype.readProfile = function (request, response) {
  'use strict';
  var self = Core.controller.subscriber;
  self.process({
    jsonSchema: {
      keys: [
        'wyclubToken',
        'subscriberId'
      ],
      schema: {
        subscriberId: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        'wyclubToken': {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        }
      },
      values: {
        'subscriberId': request.query.subscriberId,
        'wyclubToken': request.params.wyclubToken
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function () {
        subscriberRepo.readProfiles(values, function (err, profiles) {
          if (err === null) {
            if (profiles.length > 0) {
              self.postProcessSuccess(request, profiles, response, 200, reqType);
            } else {
              self.postProcessError(request, response, 200, reqType, 'PROFILES_EMPTY');
            }
          } else {
            self.postProcessError(request, response, 200, reqType, err);
          }
        });
      });
    }
  });
};

/**
 * @method Subscriber - readDevice
 * @desc /{wyclubToken}/sub/device.json
 * @httpmethod GET
 * @summary Subscriber.readDevice — Read all devices of the requested subscriber.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.query.subscriberId] - The requested subscriber ID
 * @param {Object} response
 * @param {Object} response.devices
 *
 * @public
 */
Subscriber.prototype.readDevice = function (request, response) {
  'use strict';

  var self = Core.controller.subscriber;
  self.process({
    jsonSchema: {
      keys: [
        'wyclubToken',
        'subscriberId'
      ],
      schema: {
        subscriberId: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        'wyclubToken': {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        }
      },
      values: {
        'subscriberId': request.query.subscriberId,
        'wyclubToken': request.params.wyclubToken
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function () {
        subscriberRepo.readDevices(values, function (err, devices) {
          if (err === null) {
            if (devices.length > 0) {
              self.postProcessSuccess(request, devices, response, 200, reqType);
            } else {
              self.postProcessError(request, response, 200, reqType, 'DEVICES_EMPTY');
            }
          } else {
            self.postProcessError(request, response, 200, reqType, err);
          }
        });
      });
    }
  });
};

/**
 * @method Subscriber - readSessionRecorder
 * @desc /{wyclubToken}/sub/sessionRecorder.json
 * @httpmethod GET
 * @summary Subscriber.readSessionRecorder — Read session with app recorder of the requested subscriber.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.query.subscriberId] - The requested subscriber ID
 * @param {Object} response
 * @param {Object} response.sessions
 *
 * @public
 */
Subscriber.prototype.readSessionRecorder = function (request, response) {
  'use strict';

  var self = Core.controller.subscriber;
  self.process({
    jsonSchema: {
      keys: [
        'wyclubToken',
        'subscriberId'
      ],
      schema: {
        subscriberId: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        'wyclubToken': {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        }
      },
      values: {
        'subscriberId': request.query.subscriberId,
        'wyclubToken': request.params.wyclubToken
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        if (session.application._id === 'mpvr1234567891234567891234567891') { //TODO add condition in a rule
          subscriberRepo.readSessionRecorder(values.subscriberId, function (err, sessionRecorder) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              self.postProcessSuccess(request, sessionRecorder, response, 200, reqType);
            }
          });
        } else {
          self.postProcessError(request, response, 200, reqType, 'NO_SESSION');
        }
      });
    }
  });
};

/**
 * @method Subscriber - createProfile
 * @desc /{wyclubToken}/sub/profile.json
 * @httpmethod POST
 * @summary Subscriber.createProfile — Create profile(s) for the requested subscriber.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.subscriberId] - The requested subscriber ID
 * @param {string} [request.body.label] - The new profile label
 * @param {string} [request.body.birthdate] - The new profile birthdate (YYYY/MM/DD)
 * @param {string} request.body.position - The new profile prosition in profile list
 * @param {string} request.body.password - The new profile password
 * @param {Object} response
 * @param {Object} response.profiles
 *
 * @public
 */
Subscriber.prototype.createProfile = function (request, response) {
  'use strict';

  var self = Core.controller.subscriber;
  self.process({
    jsonSchema: {
      keys: [
        'wyclubToken',
        'subscriberId',
        'label',
        'birthdate',
        'position'
      ],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        subscriberId: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        birthdate: {
          type: 'string',
          required: true,
          minLength: 8,
          maxLength: 8
        }
      },
      values: {
        wyclubToken: request.params.wyclubToken,
        subscriberId: request.body.subscriberId,
        label: request.body.label,
        birthdate: request.body.birthdate,
        position: request.body.position,
        password: request.body.password
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        self.subscriberIsValid(session, values, request, response, reqType, function () {
          var subscriberId = session.subscriber._id;
          var label = values.label;
          var birthdate = values.birthdate;
          var position = values.position;
          var password = values.password;

          if (position === undefined) {
            position = 1;
          }
          if (password === undefined) {
            password = '';
          }

          Core.repository.subscriber.addProfile({
            label: label,
            password: password,
            subscriberId: subscriberId,
            birthdate: birthdate,
            position: position
          }, function (err, profile) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              self.postProcessSuccess(request, profile, response, 200, reqType);
            }
          });
        });
      });
    }
  });
};

/**
 * @method Subscriber - createDevice
 * @desc /{wyclubToken}/sub/device.json
 * @httpmethod POST
 * @summary Subscriber.createDevice — Create device(s) for the requested subscriber.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.subscriberId] - The requested subscriber ID
 * @param {string} request.body.label - The new device label
 * @param {string} request.body.status - The new device status
 * @param {string} request.body.uuid  - The new device unique ID
 * @param {string} request.body.type  - The new device type
 * @param {Object} response
 * @param {Object} response.device
 *
 * @public
 */
Subscriber.prototype.createDevice = function (request, response) {
  'use strict';

  var self = Core.controller.subscriber;
  self.process({
    jsonSchema: {
      keys: [
        'wyclubToken',
        'subscriberId',
        'label',
        'uuid',
        'type'
      ],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        subscriberId: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        }
      },
      values: {
        wyclubToken: request.params.wyclubToken,
        subscriberId: request.body.subscriberId,
        label: request.body.label,
        status: request.body.status,
        uuid: request.body.uuid,
        type: request.body.type
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        self.subscriberIsValid(session, values, request, response, reqType, function () {
          var subscriberId = session.subscriber._id;
          var label = values.label;
          var uuid = values.uuid;
          var type = values.type;
          var status = values.status;

          if (status === undefined) {
            status = '1';
          }

          Core.repository.subscriber.addDevice({
            label: label,
            uuid: uuid,
            type: type,
            subscriberId: subscriberId,
            status: status
          }, function (err, device) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              self.postProcessSuccess(request, device, response, 200, reqType);
            }
          });
        });
      });
    }
  });
};

/**
 * @method Subscriber - updateProfile
 * @desc /{wyclubToken}/sub/profile.json
 * @httpmethod PUT
 * @summary Subscriber.updateProfile — Update a specific profile of the requested subscriber.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.subscriberId] - The requested subscriber ID
 * @param {string} [request.body.profileId] - The updated profile ID
 * @param {string} [request.body.label] - The updated profile new label
 * @param {string} request.body.birthdate - The updated profile new birthdate
 * @param {string} request.body.position - The updated profile new position
 * @param {string} request.body.password - The updated profile new password
 * @param {Object} response
 * @param {Object} response.profile
 *
 * @public
 */
Subscriber.prototype.updateProfile = function (request, response) {
  'use strict';

  var self = Core.controller.subscriber;
  self.process({
    jsonSchema: {
      keys: [
        'subscriberId',
        'profileId',
        'label',
        'birthdate',
        'position'
      ],
      schema: {
        wyclubToken: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        subscriberId: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        profileId: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        }
      },
      values: {
        wyclubToken: request.params.wyclubToken,
        subscriberId: request.body.subscriberId,
        profileId: request.body.profileId,
        label: request.body.label,
        birthdate: request.body.birthdate,
        position: request.body.position,
        password: request.body.password
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        self.subscriberIsValid(session, values, request, response, reqType, function () {
          var params = {
            label: values.label,
            birthdate: values.birthdate,
            position: values.position,
            _id: values.profileId,
            subscriberId: session.subscriber._id
          };

          if (values.password !== undefined) {
            params.password = values.password;
          }

          subscriberRepo.updateProfile(params, function (err, profile) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              self.postProcessSuccess(request, profile, response, 200, reqType);
            }
          });
        });
      });
    }
  });
};

/**
 * @method Subscriber - updateDevice
 * @desc /{wyclubToken}/sub/device.json
 * @httpmethod PUT
 * @summary Subscriber.updateDevice — Update a specific device of the requested subscriber.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.subscriberId] - The updated subsriber ID
 * @param {string} [request.body.uuid] - The updated device new unique ID
 * @param {string} [request.body.type] - The updated device new type
 * @param {string} [request.body.deviceId] - The updated device ID
 * @param {string} request.body.label - The updated device new label
 * @param {string} request.body.status - The updated device new status
 * @param {Object} response
 * @param {Object} response.device
 *
 * @public
 */
Subscriber.prototype.updateDevice = function (request, response) {
  'use strict';

  var self = Core.controller.subscriber;
  self.process({
    jsonSchema: {
      keys: [
        'subscriberId',
        'deviceId',
        'label',
        'uuid',
        'type'
      ],
      schema: {
        subscriberId: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        },
        uuid: {
          type: 'string',
          required: true,
          minLength: 1
        },
        type: {
          type: 'string',
          required: true,
          minLength: 1,
          maxLength: 32
        },
        deviceId: {
          type: 'string',
          required: true,
          minLength: 32,
          maxLength: 32
        }
      },
      values: {
        wyclubToken: request.params.wyclubToken,
        subscriberId: request.body.subscriberId,
        uuid: request.body.uuid,
        type: request.body.type,
        deviceId: request.body.deviceId,
        label: request.body.label,
        status: request.body.status
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      self.readSession(request, response, reqType, values.wyclubToken, function (session) {
        self.subscriberIsValid(session, values, request, response, reqType, function () {
          var params = {
            label: values.label,
            uuid: values.uuid,
            type: values.type,
            _id: values.deviceId,
            subscriberId: session.subscriber._id
          };

          if (values.status !== undefined) {
            params.status = values.status;
          }

          subscriberRepo.updateDevice(params, function (err, device) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              self.postProcessSuccess(request, device, response, 200, reqType);
            }
          });
        });
      });
    }
  });
};

/**
 * @method Subscriber - readPublic
 * @desc /{applicationId}/sub/profile.json
 * @httpmethod GET
 * @summary Subscriber.readPublic — Read all of the subscriber's public information.
 * @param {Object} request
 * @param {string} request.query.email - The requested subscriber email
 * @param {string} request.query.password - The requested subscriber password
 * @param {string} [request.params.applicationId] - An application ID
 * @param {Object} response
 * @param {Object} response.subscriber
 *
 * @public
 */
Subscriber.prototype.readPublic = function (request, response) {
  'use strict';

  var self = Core.controller.subscriber;
  self.process({
    jsonSchema: {
      keys: [
        'email',
        'password',
        'applicationId'
      ],
      schema: {
        email: {
          type: 'string',
          required: false
        },
        password: {
          type: 'string',
          required: false
        },
        applicationId: {
          type: 'string',
          required: true
        }
      },
      values: {
        email: request.query.email,
        password: request.query.password,
        applicationId: request.params.applicationId
      }
    },
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      applicationRepo.read({_id: values.applicationId}, function (errValid) {
        if (errValid === null) {
          subscriberRepo.readPublic(values, function (err, subscriber) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              self.postProcessSuccess(request, subscriber, response, 200, reqType);
            }
          });
        } else {
          self.postProcessError(request, response, 200, reqType, errValid);
        }
      });
    }
  });
};

module.exports = new Subscriber();