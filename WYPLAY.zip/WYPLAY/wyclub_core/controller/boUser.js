/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/**
 *  BO Users Controller
 */

// Get repositories

// Get dependencies
var Controller = require('../lib/controller');

// Init controller prototype
var boUser = function () {
  'use strict';
};

boUser.prototype = Object.create(Controller.prototype);

boUser.prototype.readSession = function (request, response, reqType, wyclubToken, callback) {
  var self = this;

  Controller.prototype.readSession.call(this, request, response, reqType, wyclubToken, function (session) {
    Core.repository.session.hasTag({wyclubToken: wyclubToken, tag: 'NHKqF75FeJWJZ4e7xYgXMLHwzEpPuOkR'}, function (err, result) {
      if (err) {
        self.postProcessError(request, response, 200, reqType, err);
      } else if (!result) {
        self.postProcessError(request, response, 200, reqType, 'NO_SUPERADMIN');
      } else {
        callback(session);
      }
    });
  });
}

/**
 * @method boUser - read
 * @desc /{wyclubToken}/boUser.json
 * @httpmethod GET
 * @summary boUser.read — Read a user.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.query._id] - A backoffice user id
 * @param {Object} response
 *
 * @public
 */
boUser.prototype.read = function (request, response) {
  'use strict';
  var self = Core.controller.boUser;

  self.process({
    jsonSchema: self.getDefaultIdJsonSchema(request),
    request: request,
    response: response,
    checkSession: true,
    action: function (values, reqType, request, response) {
      Core.repository.boUser.read({_id: values._id}, function (err, user) {
        if (err !== null) {
          self.postProcessError(request, response, 200, reqType, err);
        } else {
          self.postProcessSuccess(request, user, response, 200, reqType);
        }
      });
    }
  });
};

/**
 * @method boUser - readAll
 * @desc /{wyclubToken}/boUser/list.json
 * @httpmethod GET
 * @summary boUser.readAll — Read all users.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {Object} response
 *
 * @public
 */
boUser.prototype.readAll = function (request, response) {
  'use strict';
  var self = Core.controller.boUser;

  self.process({
    jsonSchema: self.getDefaultSessionJsonSchema(request),
    request: request,
    response: response,
    checkSession: true,
    action: function (values, reqType, request, response) {
      Core.repository.boUser.readAll({}, function (err, user) {
        if (err !== null) {
          self.postProcessError(request, response, 200, reqType, err);
        } else {
          self.postProcessSuccess(request, user, response, 200, reqType);
        }
      });
    }
  });
};

/**
 * @method boUser - create
 * @desc /{wyclubToken}/boUser.json
 * @httpmethod POST
 * @summary boUser.create — Create a user.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body.login] - A backoffice user login
 * @param {string} [request.body.passwd] -  - A backoffice user password
 * @param {Object} response
 *
 * @public
 */
boUser.prototype.create = function (request, response) {
  'use strict';
  var self = Core.controller.boUser;

  var schema = self.getDefaultSessionJsonSchema(request);
  self.addEntryToJsonSchema(schema, 'login', request.body.login, {
    type: 'string',
    required: true
  });
  self.addEntryToJsonSchema(schema, 'passwd', request.body.passwd, {
    type: 'string',
    required: true
  });
  self.process({
    jsonSchema: schema,
    request: request,
    response: response,
    checkSession: true,
    action: function (values, reqType, request, response) {
      Core.repository.boUser.create(request.body, function (err, user) {
        if (err !== null) {
          if (err.code === 11000) {
            self.postProcessError(request, response, 200, reqType, 'DUPLICATE_ENTRY', err);
          } else {
            self.postProcessError(request, response, 200, reqType, err);
          }
        } else {
          self.postProcessSuccess(request, user[0], response, 200, reqType);
        }
      });
    }
  });
}

/**
 * @method boUser - update
 * @desc /{wyclubToken}/boUser.json
 * @httpmethod PUT
 * @summary boUser.update — Update a user.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body._id] - A bakoffice user id
 * @param {string} request.body.login - A backoffice user login
 * @param {string} request.body.passwd -  - A backoffice user password
 * @param {Object} response
 *
 * @public
 */
boUser.prototype.update = function (request, response) {
  'use strict';
  var self = Core.controller.boUser;

  self.process({
    jsonSchema: self.getDefaultIdJsonSchema(request),
    request: request,
    response: response,
    checkSession: true,
    action: function (values, reqType, request, response) {
      Core.repository.boUser.update(request.body, function (err, user) {
        if (err !== null) {
          self.postProcessError(request, response, 200, reqType, err);
        } else {
          self.postProcessSuccess(request, {updated: user}, response, 200, reqType);
        }
      });
    }
  });
};

/**
 * @method boUser - delete
 * @desc /{wyclubToken}/boUser.json
 * @httpmethod DELETE
 * @summary boUser.delete — Delete a user.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body._id] - A bakoffice user id
 * @param {Object} response
 *
 * @public
 */
boUser.prototype.delete = function (request, response) {
  'use strict';
  var self = Core.controller.boUser;

  self.process({
    jsonSchema: self.getDefaultIdJsonSchema(request),
    request: request,
    response: response,
    checkSession: true,
    action: function (values, reqType, request, response) {
      Core.repository.boUser.delete({_id: values._id}, function (err, user) {
        if (err !== null) {
          self.postProcessError(request, response, 200, reqType, err);
        } else {
          self.postProcessSuccess(request, {updated: user}, response, 200, reqType);
        }
      });
    }
  });
};

/**
 * @method boUser - addGroup
 * @desc /{wyclubToken}/boUser/group.json
 * @httpmethod POST
 * @summary boUser.addGroup — Add group(s) to an user.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body._id] - A bakoffice user id
 * @param {Array} [request.body.group] - Id of group(s) to add on the user
 * @param {Object} response
 *
 * @public
 */
boUser.prototype.addGroup = function (request, response) {
  'use strict';
  var self = Core.controller.boUser;

  var schema = self.getDefaultIdJsonSchema(request);
  self.addEntryToJsonSchema(schema, 'group', request.body.group, {
    required: true,
    type: 'array',
    items: {
      type: 'string'
    },
    minItems: 1
  });
  self.process({
    jsonSchema: schema,
    request: request,
    response: response,
    checkSession: true,
    action: function (values, reqType, request, response) {
      Core.repository.boUser.addGroup(values, function (err, user) {
        if (err !== null) {
          self.postProcessError(request, response, 200, reqType, err);
        } else {
          self.postProcessSuccess(request, user, response, 200, reqType);
        }
      });
    }
  });
};

/**
 * @method boUser - deleteGroup
 * @desc /{wyclubToken}/boUser/group.json
 * @httpmethod DELETE
 * @summary boUser.deleteGroup — Delete group(s) from an user.
 * @param {Object} request
 * @param {string} [request.params.wyclubToken] - A session ID
 * @param {string} [request.body._id] - The bakoffice user id
 * @param {Array} [request.body.group] Id of group(s) to delete from the user
 * @param {Object} response
 *
 * @public
 */
boUser.prototype.deleteGroup = function (request, response) {
  'use strict';
  var self = Core.controller.boUser;

  var schema = self.getDefaultIdJsonSchema(request);
  self.addEntryToJsonSchema(schema, 'group', request.body.group, {
    required: true,
    type: 'array',
    items: {
      type: 'string'
    },
    minItems: 1
  });
  self.process({
    jsonSchema: schema,
    request: request,
    response: response,
    checkSession: true,
    action: function (values, reqType, request, response) {
      Core.repository.boUser.deleteGroup(values, function (err, user) {
        if (err !== null) {
          self.postProcessError(request, response, 200, reqType, err);
        } else {
          self.postProcessSuccess(request, user, response, 200, reqType);
        }
      });
    }
  });
};

/**
 * @method boUser - login
 * @desc /{applicationId}/boUser/login.json
 * @httpmethod POST
 * @summary boUser.login — Create a session with a BO user.
 * @param {Object} request
 * @param {string} [request.params.applicationId] - A application ID
 * @param {string} [request.body.login] - Login of the user
 * @param {string} [request.body.passwd] - Password of the user
 * @param {Object} response
 *
 * @public
 */
boUser.prototype.login = function (request, response) {
  'use strict';
  var self = Core.controller.boUser;

  var bcrypt = require('bcrypt');
  var schema = self.getEmptySchema();
  self.addEntryToJsonSchema(schema, 'applicationId', request.params.applicationId, {
    type: 'string',
    required: true
  });
  self.addEntryToJsonSchema(schema, 'login', request.body.login, {
    type: 'string',
    required: true
  });
  self.addEntryToJsonSchema(schema, 'passwd', request.body.passwd, {
    type: 'string',
    required: true
  });
  self.process({
    jsonSchema: schema,
    request: request,
    response: response,
    action: function (values, reqType, request, response) {
      // Application is not BO Application
      if (values.applicationId !== 'backoffice1234567891234567891234') {
        self.postProcessError(request, response, 200, reqType, 'INVALID_REQ_PARAM', 'applicationId');
        return;
      }

      // Get user
      Core.repository.boUser.read({login: values.login}, function (err, user) {
        // Check if user exists and check password
        if (user && bcrypt.compareSync(values.passwd, user.passwd)) {
          // Create session
          Core.repository.session.create({applicationId: values.applicationId}, function (err, session) {
            if (err !== null) {
              self.postProcessError(request, response, 200, reqType, err);
            } else {
              // Add tags (bo + groups) and return session
              var tags = ['2Qtz17m1wVcAHLDO4D36uchJm6BJyhbg'];
              if (user.group) {
                tags = tags.concat(user.group);
              }
              Core.repository.session.addTags({wyclubToken: session._id, tags: {tag: tags}}, function () {
                self.postProcessSuccess(request, session, response, 200, reqType);
              });
            }
          });
        } else {
          self.postProcessError(request, response, 200, reqType, 'BAD_BO_LOGIN', err);
        }
      });
    }
  });
}

module.exports = new boUser();