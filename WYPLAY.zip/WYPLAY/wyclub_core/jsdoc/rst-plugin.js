//
// Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//

'use strict';

var _ = require('underscore');
var fs = require('fs-extra');
var path = require('path');
var files = {};
var controllers = {};

String.prototype.repeat = function (num) {
  return new Array(num + 1).join(this);
}

exports.handlers = {
  newDoclet: function (e) {
    if (env.opts.query.controller) {
      if (!_.isEmpty(e.doclet.params)) {
        var model = {};
        var modelsName = [];
        var call = {};

        call.path = e.doclet.description;

        var parameters = [];
        var bodyParams = {};
        var i;
        var index;
        var name;

        for (i = 0; i < e.doclet.params.length; ++i) {
          name = e.doclet.params[i].name;
          index = name.indexOf('request.params');
          if (index >= 0) {
            var pathParams = {
              paramType: 'path',
              name: name.substr('request.params'.length + 1),
              description: e.doclet.params[i].description,
              dataType: 'string',
              required: e.doclet.params[i].optional
            };
            parameters.push(pathParams);
          }

          index = name.indexOf('request.body');
          if (index >= 0) {
            var paramName = name.substr('request.body'.length + 1);
            var paramsName = e.doclet.name;
            if (_.isEmpty(bodyParams)) {
              bodyParams = {
                'paramType': 'body',
                'name': 'data',
                'description': 'JSON data object',
                'dataType': paramsName
              };
              parameters.push(bodyParams);
              modelsName.push(paramsName);
              model[paramsName] = {
                'id': paramsName,
                'properties': {}
              };
            }
            model[paramsName].properties[paramName] = {
              'type': e.doclet.params[i].type.names[0],
              'required': e.doclet.params[i].optional,
              'description': e.doclet.params[i].description
            };
          }

          index = name.indexOf('request.query');
          if (index >= 0) {
            var queryParams = {
              paramType: 'query',
              name: name.substr('request.query'.length + 1),
              description: e.doclet.params[i].description,
              dataType: 'string',
              required: e.doclet.params[i].optional
            };
            parameters.push(queryParams);
          }
        }

        call.operations = [
          {
            method: e.doclet.tags[0].value,
            nickname: e.doclet.name,
            summary: e.doclet.summary,
            parameters: parameters
          }
        ];

        var api = e.doclet.summary.split(' ')[0];
        if (_.isEmpty(files[api])) {
          files[api] = {};
          files[api].calls = [];
          files[api].controller = api.split('.')[0];
          files[api].method = api.split('.')[1];
        }
        files[api].calls.push(call);
        var apiParams = files[api];

        var controllerName = apiParams.controller;
        if (_.isEmpty(controllers[controllerName])) {
          controllers[controllerName] = {};
          controllers[controllerName].controller = apiParams.controller;
          controllers[controllerName].methods = {};
        }
        controllers[controllerName].methods[apiParams.method] = true;

        for (i = 0; i < modelsName.length; ++i) {
          var nameParam = modelsName[i];
          if (_.isEmpty(apiParams.models)) {
            apiParams.models = {};
          }
          apiParams.models[nameParam] = model[nameParam];
        }
      }
    } else if (env.opts.query.statuscode === true) {
      if (e.doclet.meta.code.type === 'ObjectExpression' && e.doclet.meta.code.name !== 'module.exports') {
        files[e.doclet.meta.code.name] = JSON.parse(e.doclet.meta.code.value);
      }
    }
  },
  parseComplete: function (e) {
    if (env.opts.query.controller === true) {
      for (var api in files) {
        if (files.hasOwnProperty(api)) {
          var content = '';
          var apiParams = files[api];
          for (var i in apiParams.calls) {
            var call = apiParams.calls[i];
            var operation = call.operations[0];

            content += '.. http:' + operation.method.toLowerCase() + ':: ' + call.path + '\n\n';
            content += '  ' + operation.summary + '\n\n';

            var contentParam = '';
            var contentQuery = '';
            var contentJson = '';

            for (var paramId in operation.parameters) {
              if (operation.parameters[paramId].paramType === 'path') {
                contentParam += '  :param ' + operation.parameters[paramId].dataType + ' ' +
                  operation.parameters[paramId].name + ': ' +
                  (operation.parameters[paramId].description ? operation.parameters[paramId].description : '') + '\n';
              } else if (operation.parameters[paramId].paramType === 'query') {
                contentQuery += '  :qparam ' + operation.parameters[paramId].dataType + ' ' +
                  operation.parameters[paramId].name + ': ' +
                  (operation.parameters[paramId].description ? operation.parameters[paramId].description : '') + '\n';
              } else if (operation.parameters[paramId].paramType === 'body') {
                var properties = apiParams.models[operation.parameters[paramId].dataType].properties;
                for (var propName in properties) {
                  contentJson += '  :jsonparam ' + properties[propName].type + ' ' + propName + ': ' +
                    (properties[propName].description ? properties[propName].description : '');
                  contentJson += '\n';
                }
              }
            }

            if (contentParam !== '') {
              content += contentParam + '\n';
            }
            if (contentQuery !== '') {
              content += contentQuery + '\n';
            }
            if (contentJson !== '') {
              content += contentJson + '\n';
            }

            content += '  :statuscode 200: Operation performed normally\n';
            content += '\n\n';
          }

          var apiDir = 'generated/doc/core';
          if (!fs.existsSync(apiDir)) {
            fs.mkdirSync(apiDir);
          }
          apiDir += '/api';
          if (!fs.existsSync(apiDir)) {
            fs.mkdirSync(apiDir);
          }
          apiDir += '/' + apiParams.controller.toLowerCase();
          if (!fs.existsSync(apiDir)) {
            fs.mkdirSync(apiDir);
          }
          fs.writeFileSync(apiDir + '/' + apiParams.method + '.rst', content);
        }
      }

      // Generate doc for each controller (with PI includes)
      for (var controller in controllers) {
        var controllerParams = controllers[controller];
        var content = '';
        content += '*'.repeat(controllerParams.controller.length) + '\n';
        content += controllerParams.controller + '\n';
        content += '*'.repeat(controllerParams.controller.length) + '\n\n';
        for (var method in controllerParams.methods) {
          content += method + '\n';
          content += '='.repeat(method.length) + '\n';
          content += '.. include:: ' + controllerParams.controller.toLowerCase() + '/' + method + '.rst\n';
        }
        var apiDir = 'generated/doc/core/api/';
        fs.writeFileSync(apiDir + controllerParams.controller.toLowerCase() + '.rst', content);
      }
    } else if (env.opts.query.statuscode === true) {

      content = '************';
      content += '\n' + 'Status codes' + '\n';
      content += '************';
      content += '\n\n';

      for (var fileStatusCode in files) {
        var code = files[fileStatusCode].code;
        content += code + '\n';
        for (var k = 0; k < code.toString().length; k++) {
          content += '-';
        }
        content += '\n';
        content += ':Reference:' +
          '\n ' + fileStatusCode + '\n\n';
        content += ':Description:' +
          '\n ' + files[fileStatusCode].content + '\n\n';
      }
      var moduleDir = 'generated/doc/core/api';
      if (!fs.existsSync(moduleDir)) {
        fs.mkdirSync(moduleDir);
      }
      if (!fs.existsSync(moduleDir + '/statuscodes')) {
        fs.mkdirSync(moduleDir + '/statuscodes');
      }
      fs.writeFileSync(moduleDir + '/statuscodes/statuscodes.rst', content);
    }
    console.log('Done');
  }
};