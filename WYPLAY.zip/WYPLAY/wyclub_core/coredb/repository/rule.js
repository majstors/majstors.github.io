/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/*global Core*/
/* jshint -W079, -W098 */

/**
 * Rule Repository
 */
var Repository = require('../../lib/repository');
var tools = require('../../lib/tools');
var underscore = require('underscore');
var ruleLib = require('../../lib/rule');
var Rule;

Rule = function () {
  'use strict';
  this.setDefaultCollection('rule');
};

Rule.prototype = Object.create(Repository.prototype);

/**
 * # Description
 * Display the rules for an optionnal core service (all if no service provided)
 *
 * @param {Object} params (contains _id)
 * @param {Function} callback return rule object
 * @return undefined
 *
 */
Rule.prototype.readRulesByServiceName = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.rule.readCustom({}, function (err, rule) {
    var ruleResponse = [];
    for (var ruleKey in rule) {
      for (var ruleRuleKey in rule[ruleKey].rules) {
        var ruleValue = rule[ruleKey].rules[ruleRuleKey];
        if (ruleValue.webservice === params.webservicename) {
          ruleResponse.push(rule[ruleKey]);
        }
      }
    }
    if (err !== null) {
      callback(err);
    } else {
      if (ruleResponse.length > 0) {
        callback(null, ruleResponse);
      } else {
        callback('NO_RULE', null);
      }
    }
  });
  return undefined;
};
/**
 * # Description
 * Display the rules for an optional core service (all if no service provided)
 *
 * @param {Object} params (contains _id)
 * @param {Function} callback function return rules array
 * @return undefined
 *
 */
Rule.prototype.readCustom = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.rule.readCustom(params, function (err, rule) {
    if (err !== null) {
      callback(err);
    } else {
      if (rule !== undefined && rule !== null) {
        callback(null, rule);
      } else {
        callback('NO_RULE');
      }
    }
  });
  return undefined;
};

/**
 * # Description
 * update a protorule from a provided public id
 *
 * @param {Object} params (contains _id, label, type, sourceCode)
 * @param {Function} callback function return rules object
 * @return undefined
 *
 */
Rule.prototype.protoUpdate = function (params, callback) {
  'use strict';
  if (params.rules === undefined) {
    if (params.schema !== undefined || params.type !== undefined) {
      this.read({ _id: params._id }, function (err, rules) {
        if (rules.rules !== undefined && rules.rules.length > 0) {
          callback('UPDATE_SCHEMA_BUT_PROTORULE_HAVE_RULES', null);
        } else {
          Core.query.mongodbStatic.rule.update(params, function (err, document) {
            if (err !== null) {
              callback(err);
            } else {
              callback(null, document);
            }
          });
        }
      });
    } else {
      Core.query.mongodbStatic.rule.update(params, function (err, document) {
        if (err !== null) {
          callback(err);
        } else {
          ruleLib.generateRule(function () {
            callback(null, document);
          }, document._id, undefined, document.type, true, document);
        }
      });
    }
  } else {
    callback('NO_UPDATE_RULES');
  }
  return undefined;
};

/**
 * # Description
 * delete a rule from a provided public id
 *
 * @param {Object} params (contains _id)
 * @param {Function} callback function
 * @return {Object} empty array
 *
 */
Rule.prototype.delete = function (params, callback) {
  'use strict';
  var self = this;
  Core.query.mongodbStatic.rule.delete(params, function (err, rule) {
    if (err !== null) {
      callback(err);
    } else {
      if (rule !== undefined && rule !== null) {
        callback(null, rule);
        Core.query.mongodbStatic.webservice.readCustom({}, function (err, webservices) {
          var i, y, rules, up;
          for (i = webservices.length - 1; i >= 0; i--) {
            rules = webservices[i].rules;
            if (rules !== undefined && rules.length > 0) {
              y = rules.length - 1;
              for (y; y >= 0; y--) {
                if (rules[y] === params._id) {
                  rules.splice(y, 1);
                  up = {
                    name: webservices[i].name,
                    applicationId: webservices[i].applicationId,
                    rules: rules
                  };
                  Core.query.mongodbStatic.webservice.update(up, self.logWebserviceStatus);
                }
              }
            }
          }
        });
      } else {
        callback('NO_RULE');
      }
    }
  });
  return undefined;
};
Rule.prototype.logWebserviceStatus = function (err, webserviceUp) {
  'use strict';
  if (err !== null) {
    Core.log('Webservice update Error: ' + err);
  } else {
    Core.log('Webservice update: ' + JSON.stringify(webserviceUp));
  }
};

module.exports = new Rule();
