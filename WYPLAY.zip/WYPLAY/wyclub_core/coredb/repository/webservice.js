/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* jshint -W079, -W098 */

/**
 * Webservice Repository
 */
var async = require('async');
var tools = require('../../lib/tools');
var Repository = require('../../lib/repository');
var Webservice = function () {
};

Webservice.prototype = Object.create(Repository.prototype);

/**
 * # Description
 * Output the requested webservice
 *
 * @param {Object} params (contain _id)
 * @return {Object} webservice
 *
 */
Webservice.prototype.read = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.webservice.read(params, function (err, webservice) {
    if (err !== null) {
      callback(err);
    } else {
      if (webservice !== undefined && webservice !== null) {
        callback(null, webservice);
      } else {
        callback('NO_WEBSERVICE', null);
      }
    }
  });
};

Webservice.prototype.readCustom = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.webservice.readCustom(params, function (err, webservice) {
    if (err !== null) {
      callback(err);
    } else {
      if (webservice !== undefined && webservice !== null && webservice.length > 0) {
        callback(null, webservice);
      } else {
        callback('NO_WEBSERVICE', null);
      }
    }
  });
};

/**
 * # Description
 * Output the requested public webservice
 *
 * @param {Object} params (contain applicationName and webserviceName)
 * @return {Object} webservice
 *
 */
Webservice.prototype.readPublic = function (params, callback) {
  'use strict';
  Core.query.redisStatic.webservice.readPublic(params, function (err, webservice) {
    if (err !== null) {
      callback(err);
    } else {
      if (webservice !== undefined && webservice !== null) {
        callback(null, webservice);
      } else {
        callback('NO_WEBSERVICE', null);
      }
    }
  });
};

/**
 * # Description
 * Output the requested public webservice
 *
 * @param {Object} params (contain applicationName)
 * @return {Object} webservices
 *
 */
Webservice.prototype.readAllPublicFromApplicationName = function (params, callback) {
  'use strict';
  Core.query.redisStatic.webservice.readAllPublic(params, function (err, webservice) {
    if (err !== null) {
      callback(err);
    } else {
      if (webservice !== undefined && webservice !== null) {
        callback(null, webservice);
      } else {
        callback('NO_WEBSERVICE', null);
      }
    }
  });
};

/**
 * # Description
 * Output all the public webservices
 *
 * @param {Object} params (contain applicationName)
 * @return {Object} webservices
 *
 */
Webservice.prototype.readAllPublic = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.webservice.readCustom({}, function (err, webservices) {
    if (err !== null) {
      callback(err);
    } else {
      if (webservices !== undefined && webservices !== null) {
        callback(null, webservices);
      } else {
        callback('NO_WEBSERVICE', null);
      }
    }
  });
};

/**
 * # Description
 * Create a public webservice
 *
 * @param {Object} params (contains applicationId, name, url, protocol, path, {Integer} port, method, types)
 * @return {Object} webservice
 *
 */
Webservice.prototype.createPublic = function (params, callback) {
  'use strict';
  params._id = tools.generatePublicKey(32);
  Core.query.mongodbStatic.webservice.create(params, function (err, webservice) {
    if (err !== null) {
      callback(err, null);
    } else {
      if (webservice !== undefined && webservice !== null) {
        callback(null, webservice);
        Core.query.mongodbStatic.application.readPublic({ publicId: params.applicationId }, function (err, data) {
          if (err !== null) {
            Core.log(err);
          } else {
            var params2 = {};
            params2.webService = params;
            params2.name = params.name;
            if (data.length > 0) {
              params2.label = data[0].label;
            }
            Core.query.redisStatic.webservice.create(params2, function (err, data) {
              if (err !== null) {
                Core.log(err);
              }
            });
          }
        });
      } else {
        callback('DB_ERROR');
      }
    }
  });
};

/**
 * # Description
 * Update a public webservice
 *
 *	@param {Object} params (contains applicationId, name)
 *  @param {Object} params optionnal (url, protocol, path, {Integer} port, method, types)
 *  @return {Object} webservice
 *
 */
Webservice.prototype.updatePublic = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.webservice.update(params, function (err, webservice) {
    if (err !== null) {
      callback(err);
    } else {
      if (webservice !== undefined && webservice !== null) {
        callback(null, webservice);
      } else {
        callback('DB_ERROR');
      }
    }
  });
};

Webservice.prototype.delete = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.webservice.delete(params, function (err, webservice) {
    if (err !== null) {
      callback(err, null);
    } else {
      if (webservice !== undefined && webservice !== null) {
        callback(null, webservice);
      } else {
        callback('DB_ERROR');
      }
    }
  });
};

/**
 * # Description
 * Clean collection
 *
 */
Webservice.prototype.clean = function (callback) {
  'use strict';
  Core.query.mongodbStatic.webService.clean(callback);
};

module.exports = new Webservice();
