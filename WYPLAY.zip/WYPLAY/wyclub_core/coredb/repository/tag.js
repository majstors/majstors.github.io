/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* jshint -W079 */

/**
 * Tag Repository
 */
/*global Core*/
var Repository = require('../../lib/repository');
var tools = require('../../lib/tools.js');
var Tag;

/**
 * @return {undefined}
 */
Tag = function () {
  'use strict';
  this.setDefaultCollection('tag');
  this.setUseCache(true);
};

Tag.prototype = Object.create(Repository.prototype);

/**
 * # Description
 * Display the tags
 *
 * @param {Object} params (contains _id or id)
 * @return {Object} tags
 *
 */
Tag.prototype.read = function (params, callback) {
  'use strict';

  if (params.id) {
    params._id = params.id;
    delete params.id;
  }
  Repository.prototype.read.call(this, params, function (err, tag) {
    if (err) {
      callback(err, tag);
    } else {
      if (typeof(tag) === 'object') {
        callback(err, tag);
      } else {
        callback(err, {'_id': params.id ? params.id : params._id, 'label': tag});
      }
    }
  });
};


/**
 * # Description
 * Return all tags
 *
 * @return {Array} tags
 *
 */
Tag.prototype.readAllTags = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.tag.readCustom({}, function (err, tags) {
    if (err !== null) {
      callback(err);
    } else {
      if (tags !== undefined && tags !== null) {
        callback(null, tags);
      } else {
        callback('NO_TAG');
      }
    }
  });
};
Tag.prototype.update = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.tag.update(params, function (err, tag) {
    if (err !== null) {
      callback(err);
    } else {
      Core.query.redisStatic.tag.delete(params._id, function () {
      });
      callback(null, tag);
    }
  });
};
/**
 * # Description
 * Insert a tag
 *
 * @param {Object} params (contains _id, label)
 * @param {Function} callback function
 * @return {Object} tag
 *
 */
Tag.prototype.create = function (params, callback) {
  'use strict';

  Repository.prototype.create.call(this, params, function (err, document) {
    if (err !== null) {
      callback(err);
    } else {
      callback(null, document[0]);
    }
  });
};

/**
 * # Description
 * delete a tag from a provided public id
 *
 * @param {Object} params (contains _id)
 * @return {Object} empty array
 *
 */
Tag.prototype.logCore = function (err, webserviceUp) {
  'use strict';
  if (err !== null) {
    Core.log('Webservice update Error: ' + err);
  } else {
    Core.log('Webservice update: ' + JSON.stringify(webserviceUp));
  }
};

Tag.prototype.delete = function (params, callback) {
  'use strict';
  var self = this;
  Core.query.mongodbStatic.tag.delete(params, function (err, tag) {
    if (err !== null) {
      callback(err);
    } else {
      if (tag !== undefined && tag !== null) {
        Core.query.redisStatic.tag.delete(params._id, function () {
          callback(null, tag);
        });
        Core.query.mongodbStatic.webservice.readCustom({}, function (err, webservices) {
          if (err !== null) {
            var i = webservices.length - 1, y = null, tags = null, up = {};
            for (i; i >= 0; i--) {
              tags = webservices[i].tags;
              if (tags !== undefined && tags.length > 0) {
                y = tags.length - 1;
                for (y; y >= 0; y--) {
                  if (tags[y] === params._id) {
                    tags.splice(y, 1);
                    up = {
                      name: webservices[i].name,
                      applicationId: webservices[i].applicationId,
                      tags: tags
                    };
                    Core.query.mongodbStatic.webservice.update(up, self.logCore);
                  }
                }
              }
            }
          }
        });
      } else {
        callback('NO_TAG', null);
      }
    }
  });
};

module.exports = new Tag();
