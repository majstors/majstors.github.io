/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* Application Repo with publicId */

var Repository = require('../../lib/repository');
var Application = function () {
  'use strict';
  this.setDefaultCollection('application');
  this.setUseCache(true);
};

Application.prototype = Object.create(Repository.prototype);

/**
 * # Description
 * Return all webservices related to the publicId.
 *
 * @param {Object} params (contain publicId)
 * @return {Array} webservices
 */
Application.prototype.readApplicationWebservices = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.application.read({ _id: params.publicId }, function (err, application) {
    if (err !== null) {
      callback(err);
    } else {
      if (application !== undefined && application !== null) {
        Core.query.mongodbStatic.webservice.readCustom({ applicationId: application._id }, function (err, webservices) {
          if (err !== null) {
            callback(err);
          } else if (webservices.length === 0) {
            callback('WEBSERVICES_EMPTY', null);
          } else {
            callback(null, webservices);
          }
        });
      } else {
        callback('NO_APPLICATION', null);
      }
    }
  });
};

/**
 * # Description
 * Return application information according to applicationPublicId
 *
 * @param {Object} params (contain publicId)
 * @return {Array} webservices
 */
Application.prototype.readPublic = function (applicationPublicId, callback) {
  'use strict';
  this.read({ publicId: applicationPublicId },callback);
};

module.exports = new Application();
