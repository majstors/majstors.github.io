/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* jshint -W079 */

/* Application Storage Repo */
var tools = require('../../lib/tools.js');
var Repository = require('../../lib/repository');
var ApplicationStorage = function () {
};

ApplicationStorage.prototype = Object.create(Repository.prototype);

/**
 * Add a new application storage document.
 *
 * @param {object} object containing session ID (optionally application ID)
 * and values to insert.
 * @param {function} callback
 */
ApplicationStorage.prototype.create = function (params, callback) {
  'use strict';
  params._id = tools.generatePublicKey(32);
  params.optimisticLock = new Date().getTime();
  Core.query.mongodbAppStorage.appStorage.create(params, function (err, appStorage) {
    if (err !== null) {
      callback(err, null);
    } else {
      if (appStorage !== undefined && appStorage !== null) {
        callback(null, appStorage);
      } else {
        callback('NO_APPLICATION_DATA', null);
      }
    }
  });
};

/**
 * Read an existing application storage document.
 *
 * @param {object} object containing session ID, optionally application ID.
 * @param {function} callback
 */
ApplicationStorage.prototype.read = function (params, callback) {
  'use strict';
  Core.query.mongodbAppStorage.appStorage.read(params, function (err, appStorage) {
    if (err !== null) {
      callback(err, null);
    } else {
      if (appStorage !== undefined && appStorage !== null) {
        callback(null, appStorage);
      } else {
        callback('NO_APPLICATION_DATA', null);
      }
    }
  });
};

/**
 * Read all existing application storage document for an application.
 *
 * @param {object} object containing session ID, optionally application ID.
 * @param {function} callback
 */
ApplicationStorage.prototype.readAll = function (params, callback) {
  'use strict';
  Core.query.mongodbAppStorage.appStorage.readAll(params, function (err, appStorage) {
    if (err !== null) {
      callback(err);
    } else {
      if (appStorage !== undefined && appStorage !== null && appStorage.length > 0) {
        callback(null, appStorage);
      } else {
        callback('NO_APPLICATION_DATA', null);
      }
    }
  });
};

/**
 * Update an existing application storage document.
 *
 * @param {object} object containing session ID (optionally application ID)
 * and values (indexed by field) to update.
 * @param {function} callback
 */
ApplicationStorage.prototype.update = function (params, callback) {
  'use strict';
  params.optimisticLock = new Date().getTime();
  Core.query.mongodbAppStorage.appStorage.update(params, function (err, appStorage) {
    if (err !== null) {
      callback(err);
    } else {
      if (appStorage !== undefined && appStorage !== null) {
        callback(null, appStorage);
      } else {
        callback('NO_APPLICATION_DATA');
      }
    }
  });
};

/**
 * Delete an application storage document.
 * 
 * @param {object} object containing session ID, optionally application ID.
 * @param {function} callback
 */
ApplicationStorage.prototype.delete = function (params, callback) {
  'use strict';
  Core.query.mongodbAppStorage.appStorage.delete(params, function (err, numberOfRemovedDocs) {
    if (err !== null) {
      callback(err);
    } else {
      if (numberOfRemovedDocs === 0) {
        callback('NO_APPLICATION_DATA');
      } else {
        callback(null, numberOfRemovedDocs);
      }
    }
  });
};

/**
 * # Description
 * Clean collection
 *
 */
ApplicationStorage.prototype.clean = function (callback) {
  'use strict';
  Core.query.mongodbAppStorage.appStorage.clean(callback);
};

module.exports = new ApplicationStorage();
