/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* jshint -W079, -W083 */

var tools = require('../../lib/tools.js');
var Repository = require('../../lib/repository');
var Subscriber = function () {
    'use strict';
    this.setDefaultCollection('subscriber');
};

Subscriber.prototype = Object.create(Repository.prototype);

/**
 * # Description
 * Delete all redis sessions of the subscriber
 *
 * @param {Object} params
 * @return {Object} profile
 */
Subscriber.prototype.deleteAllSessions = function (subscriberId, callback) {
  'use strict';
  var q = async.queue(function (data, callbackQueue) {
      Core.query.redisSession.session.delete(data, callbackQueue);
    }, 1);
  q.drain = function () {
    if (callback !== undefined) {
      callback();
    }
  };
  Core.query.mongodbSession.session.getSessionsOfSubscriber({ 'subscriberId': subscriberId }, function (err, sessions) {
    if (sessions !== null && sessions.length > 0) {
      for (var key in sessions) {
        q.push({ wyclubToken: sessions[key]._id }, function () {});
      }
    } else {
      if (callback !== undefined) {
        callback();
      }
    }
  });
};

/**
 * # Description
 * Read subscriber according to the subscriberId
 *
 * @param {Object} params
 * @return {Object} profile
 */
Subscriber.prototype.read = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.subscriber.read({ _id: params.subscriberId }, function (err, subscriber) {
    if (err !== null) {
      callback(err);
    } else {
      if (subscriber && subscriber._id) {
        callback(null, subscriber);
      } else {
        callback('NO_SUBSCRIBER', null);
      }
    }
  });
};

/**
 * # Description
 * Read subscriber according to the subscriberId
 *
 * @param {Object} params
 * @return {Object} profile
 */
Subscriber.prototype.readSessionRecorder = function (subscriberId, callback) {
  'use strict';
  if (subscriberId !== null && subscriberId !== undefined) {
    Core.query.mongodbSession.session.getSessionsOfSubscriber({
      'subscriberId': subscriberId,
      'status': 1
    }, function (err, lstSessionSub) {
      if (err !== null) {
        callback(err, null);
      } else {
        if (lstSessionSub.length > 0) {
          var sessionRecorder = [];
          async.each(lstSessionSub, function (sessionSub, cb) {
            Core.repository.session.readInQuery({ 'wyclubToken': sessionSub._id }, function (err, session) {
              if (err !== null) {
                cb(err, null);
              } else {
                if (session.application.type === 'recorder') {
                  sessionRecorder.push(session);
                }
                cb();
              }
            });
          }, function (err) {
            if (err !== null) {
              callback(err, null);
            } else {
              callback(null, sessionRecorder);
            }
          });
        } else {
          callback('SESSIONS_EMPTY', null);
        }
      }
    });
  } else {
    callback('SUBSCRIBERS_EMPTY', null);
  }
};

/**
 * # Description
 * Read public subscriber according to the email/password
 *
 * @param {Object} params
 * @return {Object} profile
 */
Subscriber.prototype.readPublic = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.subscriber.readPublic(params.subscriberId === undefined ? {
    email: params.email,
    password: params.password
  } : { _id: params.subscriberId }, function (err, subscriber) {
    Core.log(subscriber);
    if (err !== null) {
      callback(err);
    } else {
      if (subscriber && subscriber._id) {
        callback(null, subscriber);
      } else {
        callback('NO_SUBSCRIBER', null);
      }
    }
  });
};

/**
 * # Description
 * Add profile to subscriber corresponds to the subscriberId
 *
 * @param {Object} params
 * @return {Object} profile
 */
Subscriber.prototype.addProfile = function (params, callback) {
  'use strict';
  if (params.label !== undefined && params.subscriberId) {
    var newParams = {};
    newParams._id = tools.generatePublicKey(32);
    newParams.label = params.label;
    newParams.birthdate = params.birthdate;
    newParams.position = params.position;
    newParams.password = params.password;
    newParams.subscriberId = params.subscriberId;
    Core.query.mongodbStatic.subscriber.createProfile(newParams, function (err, profile) {
      callback(err, profile);
    });
    this.deleteAllSessions(params.subscriberId);
  } else {
    callback('NO_SUBSCRIBER', null);
  }
};

/**
 * # Description
 * Add device to subscriber corresponds to the subscriberId
 *
 * @param {Object} params
 * @return {Object} device
 */
Subscriber.prototype.addDevice = function (params, callback) {
  'use strict';
  if (params.uuid !== undefined && params.subscriberId) {
    var newParams = {};
    newParams._id = tools.generatePublicKey(32);
    newParams.label = params.label;
    newParams.uuid = params.uuid;
    newParams.type = params.type;
    newParams.status = params.status;
    newParams.subscriberId = params.subscriberId;
    Core.query.mongodbStatic.subscriber.createDevice(newParams, function (err, device) {
      callback(err, device);
    });
    this.deleteAllSessions(params.subscriberId);
  } else {
    callback('NO_SUBSCRIBER', null);
  }
};

/**
 * # Description
 * Add device instance to a subscriber
 *
 * @param {Object} params
 * @return {Object} device
 */
Subscriber.prototype.addDeviceInstance = function (params, callback) {
  'use strict';
  var self = this;
  if (params.subscriberId !== undefined) {
    var newParams = {};
    newParams._id = tools.generatePublicKey(32);
    newParams.applicationId = params.applicationId;
    newParams.deviceId = params.deviceId;
    newParams.subscriberId = params.subscriberId;
    Core.query.mongodbStatic.subscriber.createDeviceInstance(newParams, function (err, deviceInstance) {
      self.deleteAllSessions(params.subscriberId, function () {
        callback(err, deviceInstance);
      });
    });
  } else {
    callback('NO_SUBSCRIBER', null);
  }
};

/**
 * # Description
 * Return devices corresponds to the query
 *
 * @param {Object} params
 * @return {Object} profiles
 */
Subscriber.prototype.readDevices = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.subscriber.readQuery({ _id: params.subscriberId }, function (err, subscriber) {
    if (subscriber !== null && err === null && subscriber.hasOwnProperty('devices')) {
      callback(err, subscriber.devices);
    } else if (subscriber !== null && !subscriber.hasOwnProperty('devices')) {
      callback('DEVICES_EMPTY', null);
    } else {
      callback(err, null);
    }
  });
};

/*
 * # Description
 * Return device instances 
 *
 * @param {Object} params
 * @return {Object} profiles
 */
Subscriber.prototype.readDeviceInstances = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.subscriber.readQuery({ _id: params.subscriberId }, function (err, subscriber) {
    if (subscriber !== null && err === null && subscriber.hasOwnProperty('deviceInstances')) {
      callback(err, subscriber.deviceInstances);
    } else if (subscriber !== null && !subscriber.hasOwnProperty('deviceInstances')) {
      callback('DEVICE_INSTANCES_EMPTY', null);
    } else {
      callback(err, null);
    }
  });
};

/**
 * # Description
 * Return profiles corresponds to the query
 *
 * @param {Object} params
 * @return {Object} profiles
 */
Subscriber.prototype.readProfiles = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.subscriber.readQuery({ _id: params.subscriberId }, function (err, subscriber) {
    if (subscriber !== null && err === null && subscriber.hasOwnProperty('profiles')) {
      callback(err, subscriber.profiles);
    } else if (subscriber !== null && !subscriber.hasOwnProperty('profiles')) {
      callback('PROFILES_EMPTY', null);
    } else {
      callback(err, null);
    }
  });
};

/**
 * # Description
 * Update profile to subscriber corresponds to the subscriberId
 *
 * @param {Object} params
 * @return {Object} profile
 */
Subscriber.prototype.updateProfile = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.subscriber.updateProfile(params, function (err, profile) {
    if (err === null && profile === null) {
      callback('NO_PROFILE', null);
    } else {
      callback(err, profile);
    }
  });
  this.deleteAllSessions(params.subscriberId);
};

/**
 * # Description
 * Update device to subscriber corresponds to the subscriberId
 *
 * @param {Object} params
 * @return {Object} device
 */
Subscriber.prototype.updateDevice = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.subscriber.updateDevice(params, function (err, device) {
    if (err === null && device === null) {
      callback('NO_DEVICE', null);
    } else {
      callback(err, device);
    }
  });
  this.deleteAllSessions(params.subscriberId);
};

/**
 * # Description
 * Custom read for subscriber
 *
 * @param {Object} params
 * @return {Object} subscriber
 */
Subscriber.prototype.readCustom = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.subscriber.readQuery(params, function (err, subscribers) {
    if (err !== null) {
      callback(err, null);
    } else {
      if (subscribers) {
        callback(null, subscribers);
      } else {
        callback('NO_SUBSCRIBER', null);
      }
    }
  });
};

/*
 * # Description
 * Delete a  device instance
 * 
 * @param {Object} params
 * @return {Object} profiles
 */
Subscriber.prototype.deleteDeviceInstances = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.subscriber.deleteDeviceInstance(params, function (err, subscriber) {
    if (err !== null) {
      callback(err, null);
    } else {
      callback(err, subscriber);
    }
  });
  this.deleteAllSessions(params.subscriberId);
};

module.exports = new Subscriber();