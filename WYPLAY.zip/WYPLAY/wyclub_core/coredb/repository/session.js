/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* jshint -W079, -W098 */

/* Session Repo */
var tools = require('../../lib/tools.js');
var underscore = require('underscore');
var subscriberRepo = require('./subscriber.js');
var Repository = require('../../lib/repository');
var Session = function () {
};

Session.prototype = Object.create(Repository.prototype);

/**
 * Check if a session object is valid.
 *
 * @param {Object} session
 * @returns {Boolean}
 */
Session.prototype.checkSessionObject = function (session) {
  'use strict';
  return session !== undefined && session !== null && session._id !== undefined && session._id !== null;
};

/**
 * Get session from cache or rebuild object from staticDB
 *
 */
Session.prototype.readInQuery = function (params, callback) {
  'use strict';
  var self = this;
  if (Object.keys(params).length === 1 && params.wyclubToken) {
    Core.query.redisSession.session.readSession(params, function (err, session) {
      if (err !== null) {
        callback(err);
      } else {
        if (self.checkSessionObject(session)) {
          callback(null, session);
        } else {
          Core.query.mongodbSession.session.read({ _id: params.wyclubToken }, function (err, session) {
            if (err === null && session !== null) {
              if (session.applicationId !== undefined) {
                Core.query.mongodbStatic.application.read({ _id: session.applicationId }, function (err, application) {
                  if (application !== null && err === null) {
                    session.application = application;
                    self.writeSessionInCache(session, null, callback);
                  } else {
                    callback('NO_APPLICATION', null);
                  }
                });
              } else {
                self.writeSessionInCache(session, null, callback);
              }
            } else {
              callback('NO_SESSION', null);
            }
          });
        }
      }
    });
  } else if (Object.keys(params).length >= 1) {
    if (params.wyclubToken) {
      params._id = params.wyclubToken;
      delete params.wyclubToken;
    }
    Core.query.mongodbSession.session.readCustom(params, function (err, sessions) {
      if (err === null && sessions !== null) {
        async.eachSeries(sessions, function (session, cb) {
          if (session.applicationId !== undefined) {
            Core.query.mongodbStatic.application.read({ _id: session.applicationId }, function (err, application) {
              if (application !== null && err === null) {
                session.application = application;
                self.writeSessionInCache(session, null, cb);
              } else {
                cb('NO_APPLICATION', null);
              }
            });
          } else {
            self.writeSessionInCache(session, null, cb);
          }
        }, function (err) {
          if (sessions.length === 0) {
            sessions = null;
            err = 'NO_SESSION';
          }
          callback(err, sessions);
        });
      } else {
        callback('NO_SESSION', null);
      }
    });
  } else {
    callback('NO_SESSION', null);
  }
};

/**
 * Write in cache the new session
 *
 */
Session.prototype.writeSessionInCache = function (session, subscriber, callback) {
  'use strict';
  var self = this;
  if (typeof subscriber === 'function' && callback === undefined) {
    callback = subscriber;
    subscriber = null;
  }
  if (session !== null && session !== undefined && !tools.isEmpty(session) && typeof session !== 'function') {
    if (session.subscriberId !== undefined) {
      if (subscriber === null || tools.isEmpty(subscriber)) {
        Core.query.mongodbStatic.subscriber.read({ _id: session.subscriberId }, function (err, subscriber) {
          if (err === null && subscriber !== null) {
            if (session.applicationId !== undefined && session.application === undefined) {
              Core.query.mongodbStatic.application.read({ _id: session.applicationId }, function (err, application) {
                if (application !== null && err === null) {
                  session.application = application;
                  self.generateSubscriberForSessionAndWriteInCache(subscriber, session, callback);
                } else {
                  callback('NO_APPLICATION', null);
                }
              });
            } else {
              self.generateSubscriberForSessionAndWriteInCache(subscriber, session, callback);
            }
          } else {
            callback('NO_SUBSCRIBER', null);
          }
        });
      } else {
        self.generateSubscriberForSessionAndWriteInCache(subscriber, session, callback);
      }
    } else if (session.applicationId !== undefined && session.application === undefined) {
      Core.query.mongodbStatic.application.read({ _id: session.applicationId }, function (err, application) {
        if (application !== null && err === null) {
          session.application = application;
          self.generateSubscriberForSessionAndWriteInCache(subscriber, session, callback);
        } else {
          callback('NO_APPLICATION', null);
        }
      });
    } else {
      callback(null, session);
    }
  } else {
    if (typeof session === 'function' && callback === undefined) {
      callback = session;
    }
    if (callback !== undefined) {
      callback('NO_SESSION', null);
    }
  }
};
/**
 * Format session object and write it in cache
 *
 */
Session.prototype.generateSubscriberForSessionAndWriteInCache = function (subscriber, session, callback) {
  'use strict';
  if (session !== null) {
    if (subscriber !== undefined && subscriber !== null) {
      session.subscriber = subscriber;
    }
    if (session.profileId !== undefined) {
      var profile = underscore.where(subscriber.profiles, { _id: session.profileId })[0];
      if (profile !== undefined) {
        session.profile = profile;
      }
    }
    if (session.deviceId !== undefined) {
      var device = underscore.where(subscriber.devices, { _id: session.deviceId })[0];
      if (device !== undefined) {
        session.device = device;
      }
    }
    if (session.deviceInstanceId !== undefined) {
      var deviceInstance = underscore.where(subscriber.deviceInstances, { _id: session.deviceInstanceId })[0];
      if (deviceInstance !== undefined) {
        session.deviceInstance = deviceInstance;
      }
    }
    delete session.profileId;
    delete session.subscriberId;
    delete session.applicationId;
    delete session.deviceId;
    delete session.deviceInstanceId;
    Core.query.redisSession.session.writeSession({
      wyclubToken: session._id,
      session: JSON.stringify(session)
    }, function (err) {
      callback(err, session);
    });
  } else {
    callback('NO_SESSION', null);
  }
};
/**
 * # Description
 * read the current session.
 *
 * @param {Object} params (contain wyclubToken)
 * @return {Object} session
 */
Session.prototype.read = function (params, callback) {
  'use strict';
  var self = this;
  self.readInQuery(params, function (err, session) {
    if (err !== null) {
      callback(err, null);
    } else {
      if (self.checkSessionObject(session)) {
        callback(null, session);
      } else {
        if (session[0]) {
          var test = true;
          session.forEach(function (sessionObj) {
            test = test && self.checkSessionObject(sessionObj);
          });
          if (test) {
            callback(null, session[0]);
          } else {
            callback('NO_SESSION', null);
          }
        }
      }
    }
  });
};

/**
 * # Description
 * create a session.
 *
 * @param {Object} params (contain applicationId, uuid)
 * @return {Object} session
 */
Session.prototype.readSubscriberWriteSession = function (application, session, err, subscriber, params, callback) {
  'use strict';
  var self = this;
  if (err !== null) {
    callback(err, null);
  } else if (subscriber !== null) {
    if (subscriber.devices.length > 0) {
      var device = underscore.where(subscriber.devices, { uuid: params.uuid });
      if (device.length > 0) {
        var deviceId = device[0]._id;
        var subDeviceInstance = underscore.where(subscriber.deviceInstances, {
          deviceId: deviceId,
          applicationId: params.applicationId
        });
        session.deviceId = deviceId;
        session.subscriberId = subscriber._id;
        session.applicationId = params.applicationId;
        if (subDeviceInstance.length === 0) {
          var paramsDeviceInstance = {
            subscriberId: subscriber._id,
            applicationId: params.applicationId,
            deviceId: deviceId
          };
          Core.repository.subscriber.addDeviceInstance(paramsDeviceInstance, function (err, deviceInstance) {
            session.deviceInstance = deviceInstance;
            if (subscriber.deviceInstances === undefined) {
              subscriber.deviceInstances = [];
            }
            subscriber.deviceInstances.push(deviceInstance);
            Core.query.mongodbSession.session.create(session, function (err, sessionDB) {
              session.application = application;
              self.writeSessionInCache(session, subscriber, function () {
                callback(err, sessionDB);
              });
            });
          });
        } else {
          session.deviceInstance = subDeviceInstance[0];
          Core.query.mongodbSession.session.create(session, function (err, sessionDB) {
            session.application = application;
            self.writeSessionInCache(session, subscriber, function () {
              callback(err, sessionDB);
            });
          });
        }
      } else {
        session.subscriberId = subscriber._id;
        session.applicationId = params.applicationId;
        if (params.label !== undefined && params.type !== undefined) {
          var deviceObject = {
            label: params.label,
            uuid: params.uuid,
            type: params.type,
            status: 1,
            subscriberId: params.subscriberId
          };
          subscriberRepo.addDevice(deviceObject, function (err, device) {
            session.deviceId = device._id;
            if (err !== null) {
              callback(err, null);
            } else {
              var deviceInstanceObject = {
                subscriberId: subscriber._id,
                applicationId: params.applicationId,
                deviceId: device._id
              };
              subscriberRepo.addDeviceInstance(deviceInstanceObject, function (err, deviceInstance) {
                session.deviceInstance = deviceInstance;
                if (subscriber.deviceInstances === undefined) {
                  subscriber.deviceInstances = [];
                }
                subscriber.deviceInstances.push(deviceInstance);
                if (subscriber.devices === undefined) {
                  subscriber.devices = [];
                }
                subscriber.devices.push(device);
                Core.query.mongodbSession.session.create(session, function (err, sessionDB) {
                  session.application = application;
                  self.writeSessionInCache(session, subscriber, function () {
                    callback(err, sessionDB);
                  });
                });
              });
            }
          });
        } else {
          callback('NO_DEVICE', null);
        }
      }
    } else {
      callback('NO_DEVICE', null);
    }
  } else {
    callback('NO_SUBSCRIBER', null);
  }
};

/**
 * # Description
 * create a session.
 *
 * @param {Object} params (contain applicationId, uuid)
 * @return {Object} session
 */
Session.prototype.create = function (params, callback) {
  'use strict';
  var self = this;
  Core.query.mongodbStatic.application.read({ _id: params.applicationId }, function (err, application) {
    if (err !== null) {
      callback(err, null);
    } else {
      if (application !== undefined && application !== null && application._id !== undefined &&
        application._id !== null) {
        var session = {};
        session.status = 1;
        session._id = tools.generatePublicKey(32);
        session.created = new Date();
        session.updated = new Date();
        if (params.uuid !== undefined && params.subscriberId === undefined) {
          Core.query.mongodbStatic.subscriber.readQuery({ 'devices.uuid': params.uuid }, function (err, subscriber) {
            self.readSubscriberWriteSession(application, session, err, subscriber, params, callback);
          });
        } else if (params.subscriberId !== undefined && params.uuid !== undefined) {
          Core.query.mongodbStatic.subscriber.read({ _id: params.subscriberId }, function (err, subscriber) {
            self.readSubscriberWriteSession(application, session, err, subscriber, params, callback);
          });
        } else {
          session.applicationId = params.applicationId;
          Core.query.mongodbSession.session.create(session, function (err, sessionDB) {
            session.application = application;
            self.writeSessionInCache(session, null, function (err) {
              callback(err, sessionDB);
            });
          });
        }
      } else {
        callback('NO_APPLICATION', null);
      }
    }
  });
};

/**
 * # Description
 * update the current profile of a session.
 *
 * @param {Object} params (contain profileId and password)
 * @return {Object} session
 */
Session.prototype.updateProfile = function (session, params, callback) {
  'use strict';
  var self = this;
  var i = 0;
  if (session.subscriber !== undefined) {
    while (i < session.subscriber.profiles.length && session.subscriber.profiles[i]._id !== params.profileId) {
      i++;
    }
    if (session.subscriber.profiles[i] && session.subscriber.profiles[i]._id === params.profileId) {
      var verif = 0;
      if (params.password !== undefined && params.password !== null &&
        session.subscriber.profiles[i].password !== undefined && session.subscriber.profiles[i].password !== null) {
        if (session.subscriber.profiles[i].password === params.password) {
          verif = 1;
        }
      } else {
        verif = 1;
      }
      if (verif === 1) {
        session.profile = session.subscriber.profiles[i];
        self.redisSessionToMongo(session, function (err, mongoSession) {
          Core.query.mongodbSession.session.update({ session: mongoSession }, function (err, sessionDB) {
            Core.query.redisSession.session.deleteSession({
              wyclubToken: session._id,
              session: JSON.stringify(session)
            }, function (err) {
              Core.query.redisSession.session.writeSession({
                wyclubToken: session._id,
                session: JSON.stringify(session)
              }, function (err) {
              });
              callback(null, session);
            });
          });
        });
      } else {
        callback('BAD_PASSWORD', null);
      }
    } else {
      callback('NO_PROFILE', null);
    }
  } else {
    callback('NO_SUBSCRIBER', null);
  }
};

/**
 * # Description
 * read the current session twin sisters.
 *
 * @param {Object} params (contain wyclubToken)
 * @return [{Object}] session
 */
Session.prototype.readTwinSisterSessions = function (params, callback) {
  'use strict';
  Core.query.mongodbSession.session.readTwinSisterSessions({ session: params }, function (err, sessions) {
    if (err !== null) {
      callback(err);
    } else {
      if (sessions !== undefined && sessions !== null && sessions.length !== undefined && sessions.length !== 0 &&
        sessions[0]._id !== undefined && sessions[0]._id !== null) {
        callback(null, sessions);
      } else {
        callback('NO_SESSION', []);
      }
    }
  });
};

/**
 * # Description
 * read the current session Half sisters.
 *
 * @param {Object} params (contain wyclubToken)
 * @return [{Object}] session
 */
Session.prototype.readHalfSisterSessions = function (params, callback) {
  'use strict';
  Core.query.mongodbSession.session.readHalfSisterSessions(params, function (err, sessions) {
    if (err !== null) {
      callback(err);
    } else {
      if (sessions !== undefined && sessions !== null && sessions.length !== undefined && sessions.length !== 0 &&
        sessions[0]._id !== undefined && sessions[0]._id !== null) {
        callback(null, sessions);
      } else {
        callback('NO_SESSION', []);
      }
    }
  });
};

/**
 * # Description
 * read the current session siamese sisters.
 *
 * @param {Object} params (contain wyclubToken)
 * @return [{Object}] session
 */
Session.prototype.readSiamezeSessions = function (params, callback) {
  'use strict';
  Core.query.mongodbSession.session.readSiameseSessions(params, function (err, sessions) {
    if (err !== null) {
      callback(err, null);
    } else {
      if (sessions !== undefined && sessions !== null && sessions.length !== undefined && sessions.length !== 0 &&
        sessions[0]._id !== undefined && sessions[0]._id !== null) {
        callback(null, sessions);
      } else {
        callback('NO_SESSION', []);
      }
    }
  });
};

Session.prototype.deleteSiamezeSessions = function (params, callback) {
  'use strict';
  Core.query.mongodbSession.session.deleteSiamezeSessions(params, function (err, sessions) {
    if (err !== null) {
      callback(err, null);
    } else {
      if (sessions !== undefined && sessions !== null && sessions.length !== undefined && sessions.length !== 0 &&
        sessions[0]._id !== undefined && sessions[0]._id !== null) {
        callback(null, sessions);
      } else {
        callback('NO_SESSION', []);
      }
    }
  });
};

/**
 * # Description
 * read the current session tags.
 *
 * @param {Object} params (contain wyclubToken)
 * @return [{Object}] tags
 */
Session.prototype.readTags = function (params, callback) {
  'use strict';
  Core.query.redisSession.session.readTags({ wyclubToken: params.wyclubToken }, function (err, tags) {
    if (err !== null) {
      callback(err);
    } else {
      if (tags !== undefined && tags !== null) {
        callback(null, tags);
      } else {
        callback('TAGS_EMPTY', null);
      }
    }
  });
};

/**
 * # Description
 * Check if a session is tagged with a specific tag.
 *
 * @param {Object} params (contain wyclubToken, tag)
 * @return [{Boolean}]
 */
Session.prototype.hasTag = function (params, callback) {
  'use strict';

  this.readTags(params, function (err, result) {
    if (err) {
      callback(err, tags);
    } else {
      var tags = JSON.parse(result);
      callback(null, require('underscore').contains(tags.tag, params.tag));
    }
  });
};

/**
 * # Description
 * set the current session tags.
 *
 * @param {Object} params (contain wyclubToken, tags)
 * @return [{Object}] tags
 */
Session.prototype.setTags = function (params, callback) {
  'use strict';
  if (params.wyclubToken !== undefined) {
    Core.query.redisSession.session.setTags({
      wyclubToken: params.wyclubToken,
      tags: params.tags
    }, function (err, tags) {
      if (err !== null) {
        callback(err);
      } else {
        if (tags !== undefined && tags !== null) {
          callback(null, tags);
        } else {
          callback('NO_SESSION', []);
        }
      }
    });
  } else {
    callback('NO_SESSION', null);
  }
};

/**
 * # Description
 * add tags to the current session.
 *
 * @param {Object} params (contain wyclubToken, tags)
 * @return [{Object}] tags
 */
Session.prototype.addTags = function (params, callback) {
  'use strict';
  if (params.wyclubToken !== undefined) {
    //TODO: dafuq is that ? check with jausset
    if(params.tags && !params.tags.tag){
      params.tags = {tag: params.tags};
    }

    Core.query.redisSession.session.addTags({
      wyclubToken: params.wyclubToken,
      tags: params.tags
    }, function (err, tags) {
      if (err !== null) {
        callback(err);
      } else {
        if (tags !== undefined && tags !== null) {
          callback(null, tags);
        } else {
          callback('NO_SESSION', []);
        }
      }
    });
  } else {
    callback('NO_SESSION', null);
  }
};

/**
 * # Description
 * update the current device of a session.
 *
 * @param {Object} params (contain wyclubToken & deviceId)
 * @return {Object} session
 */
Session.prototype.updateDevice = function (session, deviceId, callback) {
  'use strict';
  var self = this;
  if (session.subscriber !== undefined && session.subscriber !== null) {
    var i = 0;
    while (i < session.subscriber.devices.length && session.subscriber.devices[i]._id !== deviceId) {
      i++;
    }
    if (session.subscriber.devices[i] && session.subscriber.devices[i]._id === deviceId) {
      session.device = session.subscriber.devices[i];
      self.redisSessionToMongo(session, function (err, mongoSession) {
        Core.query.mongodbSession.session.update({ session: mongoSession }, function (err, sessionDB) {
          Core.query.redisSession.session.deleteSession({
            wyclubToken: session._id,
            session: JSON.stringify(session)
          }, function (err) {
            Core.query.redisSession.session.writeSession({
              wyclubToken: session._id,
              session: JSON.stringify(session)
            }, function (err) {
            });
            callback(null, session);
          });
        });
      });
    } else {
      callback('NO_DEVICE', null);
    }
  } else {
    callback('NO_SUBSCRIBER', null);
  }
};

/**
 * # Description
 * update the current device instance of a session.
 *
 * @param {Object} params (contain wyclubToken & deviceInstanceId)
 * @return {Object} session
 */
Session.prototype.updateDeviceInstance = function (session, deviceInstanceId, callback) {
  'use strict';
  var self = this;
  if (session.subscriber !== undefined && session.subscriber !== null) {
    var i = 0;
    while (i < session.subscriber.deviceInstances.length &&
      session.subscriber.deviceInstances[i]._id !== deviceInstanceId) {
      i++;
    }
    if (session.subscriber.deviceInstances[i] && session.subscriber.deviceInstances[i]._id === deviceInstanceId) {
      session.deviceInstance = session.subscriber.deviceInstances[i];
      self.redisSessionToMongo(session, function (err, mongoSession) {
        Core.query.mongodbSession.session.update({ session: mongoSession }, function (err, sessionDB) {
          Core.query.redisSession.session.writeSession({
            wyclubToken: session._id,
            session: JSON.stringify(session)
          }, function (err) {
            callback(null, session);
          });
        });
      });
    } else {
      callback('NO_DEVICE_INSTANCE', null);
    }
  } else {
    callback('NO_SUBSCRIBER', null);
  }
};

/**
 * # Description
 * format session to a mongo format
 *
 * @param {Object} redis session
 * @param {Object mongo session
 */
Session.prototype.redisSessionToMongo = function (session, callback) {
  'use strict';
  if (session._id !== undefined) {
    var mongoSession = {
      _id: session._id,
      status: 1
    };
    if (session.application !== undefined) {
      mongoSession.applicationId = session.application._id;
    }
    if (session.subscriber !== undefined) {
      mongoSession.subscriberId = session.subscriber._id;
    }
    if (session.profile !== undefined) {
      mongoSession.profileId = session.profile._id;
    }
    if (session.device !== undefined) {
      mongoSession.deviceId = session.device._id;
    }
    callback(null, mongoSession);
  } else {
    callback('NO_SESSION', null);
  }
};

Session.prototype.update = function (params, callback) {
  'use strict';
  if (params.session !== undefined) {
    Core.query.mongodbSession.session.update({ session: params.session }, function (err, sessionDB) {
      callback(err, sessionDB);
    });
  } else {
    callback('NO_SESSION', null);
  }
};

/**
 * # Description
 * delete the current session.
 *
 * @param {Object} params (contain wyclubToken)
 * @return {Object} session
 */
Session.prototype.delete = function (params, callback) {
  'use strict';
  var self = this;
  Core.query.mongodbSession.session.delete({ _id: params.wyclubToken }, function (err, session) {
    if (err !== null) {
      callback(err);
    } else {
      if (self.checkSessionObject(session)) {
        Core.query.redisSession.session.delete(params, function (err, success) {
          callback(null, session);
        });
      } else {
        callback('NO_SESSION', []);
      }
    }
  });
};

/**
 * # Description
 * get an access token for session.
 *
 * @param {Object} params (contain accessToken)
 * @return {Object} session
 */
Session.prototype.readAccessToken = function (params, callback) {
  'use strict';
  Core.query.redisSession.session.readAccessToken({ accessToken: params.accessToken }, function (err, wyclubToken) {
    if (err !== null) {
      callback(err);
    } else {
      if (wyclubToken !== undefined && wyclubToken !== null) {
        callback(null, wyclubToken);
      } else {
        callback('NO_SESSION', []);
      }
    }
  });
};

/**
 * # Description
 * create an access token for session.
 *
 * @param {Object} params (contain wyclubToken)
 * @return {Object} session
 */
Session.prototype.createAccessToken = function (params, callback) {
  'use strict';
  if (params.wyclubToken !== undefined) {
    Core.query.redisSession.session.createAccessToken({
      wyclubToken: params.wyclubToken,
      accessToken: tools.generatePublicKey(32)
    }, function (err, sessionTokenId) {
      if (err !== null) {
        callback(err);
      } else {
        if (sessionTokenId !== undefined && sessionTokenId !== null) {
          callback(null, sessionTokenId);
        } else {
          callback('NO_SESSION', []);
        }
      }
    });
  } else {
    callback('NO_SESSION', null);
  }
};

/**
 * # Description
 * create an half sister to the current session.
 *
 * @param {Object} params (contain wyclubToken, applicationId)
 * @return [{Object}] session
 */
Session.prototype.createHalfSisterSession = function (params, callback) {
  'use strict';
  var self = this;
  var session = params.session;
  if (self.checkSessionObject(session)) {
    Core.query.mongodbStatic.application.read({ _id: params.applicationId }, function (err, application) {
      if (err !== null) {
        callback(err);
      } else {
        if (application !== undefined && application !== null && application._id !== undefined &&
          application._id !== null) {
          session._id = tools.generatePublicKey(32);
          session.applicationId = application._id;
          session.deviceId = session.device._id;
          session.subscriberId = session.subscriber._id;
          session.profileId = session.profile._id;
          var sessionRedis = tools.clone(session);
          delete session.application;
          delete session.device;
          delete session.subscriber;
          delete session.profile;
          Core.query.mongodbSession.session.create(session, function (err, halfSisterSession) {
            self.writeSessionInCache(sessionRedis, null, function () {
              callback(err, halfSisterSession);
            });
          });
        } else {
          callback('NO_APPLICATION', null);
        }
      }
    });
  } else {
    callback('NO_SESSION', []);
  }
};

/**
 * # Description
 * update the current content of the current session.
 *
 * @param {Object} params (contain wyclubToken, content, origin)
 * @return [{Object}] session
 */
Session.prototype.updateCurrentContent = function (params, callback) {
  'use strict';
  if (params.wyclubToken !== undefined && params.content !== undefined) {
    Core.query.redisSession.session.setCurrentContent({
      wyclubToken: params.wyclubToken,
      content: params.content,
      origin: params.origin,
      info: params.info
    }, function (err, currentContent) {
      callback(err, currentContent);
    });
  } else {
    callback('NO_SESSION', null);
  }
};

/**
 * # Description
 * read the current content of the current session.
 *
 * @param {Object} params (contain wyclubToken, content, origin)
 * @return [{Object}] session
 */
Session.prototype.readCurrentContent = function (params, callback) {
  'use strict';
  Core.query.redisSession.session.readCurrentContent({ wyclubToken: params.wyclubToken }, function (err, currentContent) {
    callback(err, currentContent);
  });
};

/**
 * # Description
 * Clean collection
 *
 */
Session.prototype.clean = function (callback) {
  'use strict';
  Core.query.mongodbSession.session.clean(callback);
};

module.exports = new Session();
