/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* global async:true*/
/* jshint -W079, -W083, -W106 */

/* Business Repo */
var tools = require('../../lib/tools.js');
async = require('async');
var Repository = require('../../lib/repository');

var Business = function () {
};

Business.prototype = Object.create(Repository.prototype);
Business.prototype.createPackage = function (params, callback) {
  'use strict';
  params._id = tools.generatePublicKey(32);
  params.type = 'package';
  Core.query.mongodbStatic.business.create(params, function (err, document) {
    if (err !== null) {
      callback(err);
    } else {
      callback(null, document);
    }
  });
};

Business.prototype.readPackageCustom = function (params, callback) {
  'use strict';
  var self = this;
  Core.query.mongodbStatic.business.readCustom(params, function (err, packages) {
    if (err !== null) {
      callback('NO_BUSINESS_PACKAGE');
    } else if (packages !== undefined && packages.length > 0) {
      var q = async.queue(self.readAndCreateBusinessObject, 1), countQueue = 0;
      var countNoQueue = 0;
      q.drain = function () {
        self.cleanBusinessObjectAndResponse(packages, callback);
      };
      for (var packageKey in packages) {
        if (packages[packageKey].tags &&
            packages[packageKey].tags.length > 0 || packages[packageKey].assets &&
            packages[packageKey].assets.length > 0 || packages[packageKey].services &&
            packages[packageKey].services.length > 0) {
          for (var packageServiceKey in packages[packageKey].services) {
            countQueue++;
            q.push({
              assets: packages,
              assetKey: packageKey,
              assetDataKey: packageServiceKey,
              type: 'service',
              collection: 'business'
            });
          }
          for (var packageAssetKey in packages[packageKey].assets) {
            countQueue++;
            q.push({
              assets: packages,
              assetKey: packageKey,
              assetDataKey: packageAssetKey,
              type: 'asset',
              collection: 'business'
            });
          }
          for (var packageTagKey in packages[packageKey].tags) {
            countQueue++;
            q.push({
              assets: packages,
              assetKey: packageKey,
              assetDataKey: packageTagKey,
              type: 'tag',
              collection: 'tag'
            });
          }
        } else {
          countNoQueue++;
        }
      }
      if (countQueue === 0 && countNoQueue > 0) {
        self.cleanBusinessObjectAndResponse(packages, callback);
      }
    } else {
      callback('NO_BUSINESS_PACKAGE');
    }
  }, 'package');
};

Business.prototype.readServiceCustom = function (params, callback) {
  'use strict';
  var self = this;
  Core.query.mongodbStatic.business.readCustom(params, function (err, services) {
    if (err !== null) {
      callback('NO_BUSINESS_SERVICE');
    } else if (services !== undefined && services.length > 0) {
      var q = async.queue(function (data, callback) {
          Core.query.mongodbStatic.application.read(
                { publicId: data.services[data.serviceKey].applicationId },
                function (err, application) {
                  if (err === null && application !== null) {
                    data.services[data.serviceKey].application = application;
                  }
                  callback();
                }, 1);
        }), countQueue = 0;
      var countNoQueue = 0;
      for (var serviceKey in services) {
        q.push({
          services: services,
          serviceKey: serviceKey
        }, function () {});
      }
      var q2 = async.queue(self.readAndCreateBusinessObject, 1);
      q.drain = function () {
        for (var serviceKey in services) {
          if (services[serviceKey].tags &&
              services[serviceKey].tags.length > 0 || services[serviceKey].assets &&
              services[serviceKey].assets.length > 0 || services[serviceKey].packages &&
              services[serviceKey].packages.length > 0) {
            for (var serviceAssetKey in services[serviceKey].assets) {
              countQueue++;
              q2.push({
                assets: services,
                assetKey: serviceKey,
                assetDataKey: serviceAssetKey,
                type: 'asset',
                collection: 'business'
              });
            }
            for (var servicePackageKey in services[serviceKey].packages) {
              countQueue++;
              q2.push({
                assets: services,
                assetKey: serviceKey,
                assetDataKey: servicePackageKey,
                type: 'package',
                collection: 'business'
              });
            }
            for (var serviceTagKey in services[serviceKey].tags) {
              countQueue++;
              q2.push({
                assets: services,
                assetKey: serviceKey,
                assetDataKey: serviceTagKey,
                type: 'tag',
                collection: 'tag'
              });
            }
          } else {
            countNoQueue++;
          }
        }
        if (countQueue === 0 && countNoQueue > 0) {
          self.cleanBusinessObjectAndResponse(services, callback);
        }
      };
      q2.drain = function () {
        self.cleanBusinessObjectAndResponse(services, callback);
      };
    } else {
      callback('NO_BUSINESS_PACKAGE');
    }
  }, 'service');
};

Business.prototype.readAndCreateBusinessObject = function (data, callback) {
  'use strict';
  var test = data.type + 's';
  Core.query.mongodbStatic[data.collection].readCustom(
              { _id: data.assets[data.assetKey][test][data.assetDataKey] },
              function (err, object) {
                if (data.assets[data.assetKey][data.type] === undefined) {
                  data.assets[data.assetKey][data.type] = [];
                }
                if (err === null) {
                  data.assets[data.assetKey][data.type].push(object[0]);
                }
                callback(data.type);
              }, data.type);
};

Business.prototype.cleanBusinessObjectAndResponse = function (data, callback) {
  'use strict';
  for (var dataKey in data) {
    delete data[dataKey].services;
    for (var dataServiceKey in data[dataKey].service) {
      delete data[dataKey].service[dataServiceKey].packages;
      delete data[dataKey].service[dataServiceKey].services;
      delete data[dataKey].service[dataServiceKey].assets;
      delete data[dataKey].service[dataServiceKey].tags;
    }
    delete data[dataKey].packages;
    for (var dataPackageKey in data[dataKey].package) {
      delete data[dataKey].package[dataPackageKey].packages;
      delete data[dataKey].package[dataPackageKey].services;
      delete data[dataKey].package[dataPackageKey].assets;
      delete data[dataKey].package[dataPackageKey].tags;
    }
    delete data[dataKey].assets;
    for (var dataAssetKey in data[dataKey].asset) {
      delete data[dataKey].asset[dataAssetKey].packages;
      delete data[dataKey].asset[dataAssetKey].services;
      delete data[dataKey].asset[dataAssetKey].assets;
      delete data[dataKey].asset[dataAssetKey].tags;
    }
    delete data[dataKey].tags;
  }
  callback(null, data);
};

Business.prototype.readAssetCustom = function (params, callback) {
  'use strict';
  var self = this;
  Core.query.mongodbStatic.business.readCustom(params, function (err, assets) {
    if (err !== null) {
      callback('NO_BUSINESS_ASSET');
    } else if (assets !== undefined && assets.length > 0) {
      var q = async.queue(self.readAndCreateBusinessObject, 1), countQueue = 0;
      var countNoQueue = 0;
      q.drain = function () {
        self.cleanBusinessObjectAndResponse(assets, callback);
      };
      for (var assetKey in assets) {
        if (assets[assetKey].tags &&
            assets[assetKey].tags.length > 0 || assets[assetKey].packages &&
            assets[assetKey].packages.length > 1 || assets[assetKey].services &&
            assets[assetKey].services.length > 0) {
          for (var assetServiceKey in assets[assetKey].services) {
            countQueue++;
            q.push({
              assets: assets,
              assetKey: assetKey,
              assetDataKey: assetServiceKey,
              type: 'service',
              collection: 'business'
            });
          }
          for (var assetPackageKey in assets[assetKey].packages) {
            countQueue++;
            q.push({
              assets: assets,
              assetKey: assetKey,
              assetDataKey: assetPackageKey,
              type: 'package',
              collection: 'business'
            });
          }
          for (var assetTagKey in assets[assetKey].tags) {
            countQueue++;
            q.push({
              assets: assets,
              assetKey: assetKey,
              assetDataKey: assetTagKey,
              type: 'tag',
              collection: 'tag'
            });
          }
        } else {
          countNoQueue++;
        }
      }
      if (countQueue === 0 && countNoQueue > 0) {
        self.cleanBusinessObjectAndResponse(assets, callback);
      }
    } else {
      callback('NO_BUSINESS_ASSET');
    }
  }, 'asset');
};

Business.prototype.updatePackage = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.business.update({ document: params }, 'package', function (err, document) {
    if (err !== null) {
      callback(err);
    } else {
      if (!document || document.length === 0) {
        callback('NO_BUSINESS_PACKAGE');
      } else {
        callback(null, document);
      }
    }
  });
};

Business.prototype.createService = function (params, callback) {
  'use strict';
  params._id = tools.generatePublicKey(32);
  params.type = 'service';
  //todo faire une verif sur les packages
  Core.query.mongodbStatic.business.create(params, function (err, document) {
    if (err !== null) {
      callback(err);
    } else {
      callback(null, document);
    }
  });
};

Business.prototype.delete = function (params, type, finalcallback) {
  'use strict';
  var arrays = type + 's';
  Core.query.mongodbStatic.business.delete(params, type, function (err, numberOfRemovedDocs) {
    if (err !== null) {
      finalcallback(err);
    } else {
      if (!numberOfRemovedDocs || numberOfRemovedDocs === 0) {
        finalcallback('NO_BUSINESS_ASSET');
      } else {
        var obj = {};
        obj[arrays] = { $in: [params._id] };
        Core.query.mongodbStatic.business.readCustom(obj, function (err, documents) {
          var q = async.queue(function (data, callback) {
              Core.query.mongodbStatic.business.update({ document: data }, undefined, callback);
            }, 1);
          q.drain = function () {
            finalcallback(null, numberOfRemovedDocs);
          };
          if (documents && documents.length) {
            for (var i = 0; i < documents.length; i++) {
              var newObjects = [];
              for (var j = 0; j < documents[i][arrays].length; j++) {
                if (documents[i][arrays][j] !== params._id) {
                  newObjects.push(documents[i][arrays][j]);
                }
              }
              documents[i][arrays] = newObjects;
              q.push(documents[i]);
            }
          } else {
            finalcallback(null, 1);
          }
        });
      }
    }
  });
};

Business.prototype.updateService = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.business.update({ document: params }, 'service', function (err, document) {
    if (err !== null) {
      callback(err);
    } else {
      if (!document || document.length === 0) {
        callback('NO_BUSINESS_SERVICE');
      } else {
        callback(null, document);
      }
    }
  });
};

Business.prototype.createAsset = function (params, callback) {
  'use strict';
  params._id = tools.generatePublicKey(32);
  params.type = 'asset';
  Core.query.mongodbStatic.business.create(params, function (err, document) {
    if (err !== null) {
      callback(err);
    } else {
      callback(null, document);
    }
  });
};

Business.prototype.updateAsset = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.business.update({ document: params }, 'asset', function (err, document) {
    if (err !== null) {
      callback(err);
    } else {
      if (!document || document.length === 0) {
        callback('NO_BUSINESS_ASSET');
      } else {
        callback(null, document);
      }
    }
  });
};

Business.prototype.linkPackageToService = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.business.link(params.package_id, params.service_id, function (err, result) {
    if (err !== null) {
      callback(err);
    } else {
      callback(null, result);
    }
  });
};

Business.prototype.unlinkPackageToService = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.business.unlink(params.service_id, params.package_id, function (err, result) {
    if (err !== null) {
      callback(err);
    } else {
      callback(null, result);
    }
  });
};

Business.prototype.linkPackageToAsset = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.business.link(params.package_id, params.asset_id, function (err, result) {
    if (err !== null) {
      callback(err);
    } else {
      callback(null, result);
    }
  });
};

Business.prototype.unlinkPackageToAsset = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.business.unlink(params.package_id, params.asset_id, function (err, result) {
    if (err !== null) {
      callback(err);
    } else {
      callback(null, result);
    }
  });
};

Business.prototype.linkServiceToAsset = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.business.link(params.service_id, params.asset_id, function (err, result) {
    if (err !== null) {
      callback(err);
    } else {
      callback(null, result);
    }
  });
};

Business.prototype.unlinkServiceToAsset = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.business.unlink(params.service_id, params.asset_id, function (err, result) {
    if (err !== null) {
      callback(err);
    } else {
      callback(null, result);
    }
  });
};

Business.prototype.linkApplicationToService = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.business.linkApplicationToService(params, function (err, result) {
    if (err !== null) {
      callback(err);
    } else {
      if (result) {
        callback(null, result);
      } else {
        callback('NO_APPLICATION');
      }
    }
  });
};

Business.prototype.unlinkApplicationToService = function (params, callback) {
  'use strict';
  Core.query.mongodbStatic.business.unlinkApplicationToService(params, function (err, result) {
    if (err !== null) {
      callback(err);
    } else {
      if (result) {
        callback(null, result);
      } else {
        callback('NO_APPLICATION');
      }
    }
  });
};

/**
 * # Description
 * Clean collection
 *
 */
Business.prototype.clean = function (callback) {
  'use strict';
  Core.query.mongodbStatic.business.clean(callback);
};

module.exports = new Business();
