/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* Application Repo with publicId */

var Repository = require('../../lib/repository');
var boUser = function () {
  'use strict';
  this.setDefaultCollection('boUser');
};

boUser.prototype = Object.create(Repository.prototype);


boUser.prototype.addGroup = function (params, callback) {
  'use strict';

  this.customUpdate({_id: params._id}, {'$addToSet': {
    group: {'$each': params.group}
  }}, callback);
};


boUser.prototype.deleteGroup = function (params, callback) {
  'use strict';

  Core.query.mongodbStatic.boUser.customUpdate({_id: params._id}, {'$pullAll': {
    group: params.group
  }}, callback);
}


boUser.prototype.encryptPassword = function (password) {
  'use strict';

  var bcrypt = require('bcrypt');
  var salt = bcrypt.genSaltSync(10);
  return bcrypt.hashSync(password, salt);
}


boUser.prototype.checkParams = function (params) {
  'use strict';

  var checkedParams = {};
  for (var i in params) {
    switch (i) {
      case '_id':
        if (params[i]) {
          checkedParams[i] = params[i];
        } else {
          return '_id can\'t be empty';
        }
        break;
      case 'login':
        if (params[i]) {
          checkedParams[i] = params[i];
        } else {
          return 'Login can\'t be empty';
        }
        break;
      case 'passwd':
        if (params[i]) {
          checkedParams[i] = this.encryptPassword(params[i]);
        } else {
          return 'Password can\'t be empty';
        }
        break;
    }
  }
  return checkedParams;
}
module.exports = new boUser();
