/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

// Application Queries

/** @namespace err.errmsg */
var Mongodb = require('../../../lib/mongodbQuery');
var Application = function () {
  'use strict';
  this.setDefaultCollection('application');
};
Application.prototype = Object.create(Mongodb.prototype);

/**
 * # Description
 * Return all application corresponds to the publicId
 *
 * @param {Object} params (contains publicId)
 * @param {Function} callback function, return applications Array
 * @return undefined
 */
Application.prototype.readPublic = function (params, callback) {
  'use strict';
  var self = this;
  this.staticClient.getCollection(this.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.find({ publicId: params.publicId }).toArray(function (err, applications) {
        if (err !== null) {
          callback('DB_ERROR');
          self.staticClient.close();
        } else {
          callback(null, applications);
          self.staticClient.close();
        }
      });
    }
  });
  return undefined;
};

module.exports = new Application();