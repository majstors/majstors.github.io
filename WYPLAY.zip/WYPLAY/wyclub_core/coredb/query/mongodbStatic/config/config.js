//
// Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//
var config = {
  db: {
    create: {
      business: 'create',
      application: 'none',
      rule: 'create',
      webservice: 'create',
      deviceType: 'create',
      subscriber: 'none',
      tag: 'none',
      boUser: 'create',
      boGroup: 'create'
    },
    clean: {
      business: 'restore',
      application: 'none',
      rule: 'restore',
      webservice: 'restore',
      deviceType: 'restore',
      subscriber: 'none',
      tag: 'none',
      boUser: 'restore',
      boGroup: 'restore'
    },
    indexes: {
      boUser: [
        {
          name: 'loginUnique',
          index: {
            login: 1
          },
          params: { unique: 1}
        }
      ],
      boGroup: [
        {
          name: 'nameUnique',
          index: {
            name: 1
          },
          params: { unique: 1}
        }
      ]
    }
  }
};

module.exports = config;