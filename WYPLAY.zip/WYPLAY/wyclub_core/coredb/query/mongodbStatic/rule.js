/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* Rule Queries */

var Mongodb = require('../../../lib/mongodbQuery');
var Rule = function () {
  'use strict';
  this.setDefaultCollection('rule');
  this.setUpdateReturnDocument(true);
};
Rule.prototype = Object.create(Mongodb.prototype);

/**
 * # Description
 * Check if a rule exists, given its _id.
 *
 * @param {Object} params contains _id
 * @param {Function} callback function
 * @return undefined
 *
 **/
Rule.prototype.exists = function (params, callback) {
  'use strict';
  var self = this;
  this.staticClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback('NO_RULE');
    } else {
      collection.find({
        '_id': params._id,
        'status': 1
      }, { limit: 1 }, function (err, cursor) {
        if (err !== null) {
          callback('NO_RULE');
        } else {
          if (cursor) {
            callback(null, true);
          } else {
            callback(null, false);
          }
        }
        self.staticClient.close();
      });
    }
  });
  return undefined;
};

/**
 * # Description
 * Return all rules corresponds to or/and label,type
 *
 * @param {Object} params (contains or/and label,type)
 * @param {Function} callback return rules array
 * @return undefined
 *
 */
Rule.prototype.readCustom = function (params, callback) {
  'use strict';
  var self = this;
  this.staticClient.getCollection(self.collection, function (err, collection) {
    var i, where, attribs, currentAttrib;
    if (err !== null) {
      callback(err);
    } else {
      where = {};
      attribs = Object.keys(params);
      i = attribs.length - 1;
      for (i; i >= 0; i--) {
        currentAttrib = attribs[i];
        if (currentAttrib === 'label' || currentAttrib === 'type' || currentAttrib === 'webservices') {
          where[currentAttrib] = params[currentAttrib];
        }
      }
      collection.find(where).toArray(function (err, rules) {
        if (err !== null) {
          callback('error');
          self.staticClient.close();
        } else {
          callback(null, rules);
          self.staticClient.close();
        }
      });
    }
  });
};

/**
 * # Description
 * Create rule
 *
 * @param {Object} params (contains label, type, sourceCode)
 * @param {Function} callback return rule object
 * @return undefined
 */
Rule.prototype.create = function (params, callback) {
  'use strict';
  Mongodb.prototype.create.call(this, params, function (err, document) {
    if (err !== null) {
      callback(err);
    } else {
      callback(null, document[0]);
    }
  });
};

module.exports = new Rule();