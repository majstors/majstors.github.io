/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

// Subscriber Queries

/* jshint -W098 */
//TODO Fix unused var

var Mongodb = require('../../../lib/mongodbQuery');
var Subscriber = function () {
  'use strict';
  this.setDefaultCollection('subscriber');
};
Subscriber.prototype = Object.create(Mongodb.prototype);

/**
 * # Description
 * Return one Subscriber corresponds to the _id
 *
 * @param {Object} params (contains _id )
 * @param {Function} callback function, return subscriber Object
 * @return undefined
 */
Subscriber.prototype.read = function (params, callback) {
  Mongodb.prototype.read.call(this, {_id: params._id}, callback);
};

/**
 * # Description
 * Return one Subscriber corresponds to the params
 *
 * @param {Object} params (contains _id )
 * @param {Function} callback function, return subscriber Object
 * @return undefined
 */
Subscriber.prototype.readPublic = function (params, callback) {
  Mongodb.prototype.read.call(this, params, callback);
};

/**
 * # Description
 * Return one Subscriber corresponds to the query
 *
 * @param {Object} params
 * @param {Function} callback function, return subscriber Object
 * @return undefined
 */
Subscriber.prototype.readQuery = function (where, callback) {
  'use strict';
  var self = this;
  this.staticClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.findOne(where, function (err, subscriber) {
        if (err !== null) {
          callback(err);
          self.staticClient.close();
        } else {
          if (subscriber === null) {
            callback('NO_SUBSCRIBER', null);
            self.staticClient.close();
          } else {
            callback(null, subscriber);
            self.staticClient.close();
          }
        }
      });
    }
  });
  return undefined;
};

/**
 * # Description
 * Add profile to subscriber corresponds to the subscriberId
 *
 * @param {Object} params
 * @param {Function} callback function, return profile Object
 * @return undefined
 */
Subscriber.prototype.createProfile = function (params, callback) {
  'use strict';
  var self = this;
  var where = { _id: params.subscriberId };
  this.staticClient.getCollection(self.collection, function (err, collection, db) {
    collection.findOne(where, function (err, subscriber) {
      if (subscriber !== null) {
        if (subscriber.profiles === undefined) {
          subscriber.profiles = [];
        }
        delete params.subscriberId;
        subscriber.profiles.push(params);
        collection.findAndModify(where, [], subscriber, {
          w: 1,
          new: true
        }, function (err) {
          callback(err, params);
        });
      } else {
        callback(err, null);
      }
    });
  });
  return undefined;
};

/**
 * # Description
 * Add device to subscriber corresponds to the subscriberId
 *
 * @param {Object} params
 * @param {Function} callback function, return device Object
 * @return undefined
 */
Subscriber.prototype.createDevice = function (params, callback) {
  'use strict';
  var self = this;
  var where = { _id: params.subscriberId };
  this.staticClient.getCollection(self.collection, function (err, collection, db) {
    collection.findOne(where, function (err, subscriber) {
      if (subscriber !== null) {
        if (subscriber.devices === undefined) {
          subscriber.devices = [];
        }
        delete params.subscriberId;
        subscriber.devices.push(params);
        collection.findAndModify(where, [], subscriber, {
          w: 1,
          new: true
        }, function (err, modifiedSubscriber) {
          callback(err, params);
        });
      } else {
        callback('NO_SUBSCRIBER', null);
      }
    });
  });
  return undefined;
};

/**
 * # Description
 * Add device instance to a subscriber
 *
 * @param {Object} params
 * @return {Object} device
 */
Subscriber.prototype.createDeviceInstance = function (params, callback) {
  'use strict';
  var self = this;
  var where = { _id: params.subscriberId };
  this.staticClient.getCollection(self.collection, function (err, collection, db) {
    collection.findOne(where, function (err, subscriber) {
      if (subscriber !== null) {
        if (subscriber.deviceInstances === undefined) {
          subscriber.deviceInstances = [];
        }
        delete params.subscriberId;
        subscriber.deviceInstances.push(params);
        collection.findAndModify(where, [], subscriber, {
          w: 1,
          new: true
        }, function (err, modifiedSubscriber) {
          callback(err, params);
        });
      } else {
        callback('NO_SUBSCRIBER', null);
      }
    });
  });
};

/**
 * # Description
 * Update profile to subscriber corresponds to the subscriberId
 *
 * @param {Object} params
 * @param {Function} callback function, return profile Object
 * @return undefined
 */
Subscriber.prototype.updateProfile = function (params, callback) {
  'use strict';
  var self = this;
  if (params.subscriberId !== undefined) {
    if (params._id !== undefined) {
      var where = { _id: params.subscriberId };
      this.staticClient.getCollection(self.collection, function (err, collection, db) {
        collection.findOne(where, function (err, subscriber) {
          if (subscriber !== null) {
            delete params.subscriberId;
            for (var keyProfiles in subscriber.profiles) {
              if (subscriber.profiles[keyProfiles]._id === params._id) {
                for (var keyParams in params) {
                  subscriber.profiles[keyProfiles][keyParams] = params[keyParams];
                }
                break;
              }
            }
            collection.findAndModify(where, [], subscriber, {
              w: 1,
              new: true
            }, function (err, modifiedSubscriber) {
              callback(err, params);
            });
          } else {
            callback('NO_SUBSCRIBER', null);
          }
        });
      });
    } else {
      callback('NO_PROFILE', null);
    }
  } else {
    callback('NO_SUBSCRIBER', null);
  }
  return undefined;
};

/**
 * # Description
 * Update device to subscriber corresponds to the subscriberId
 *
 * @param {Object} params
 * @param {Function} callback function, return device Object
 * @return undefined
 */
Subscriber.prototype.updateDevice = function (params, callback) {
  'use strict';
  var self = this;
  if (params.subscriberId !== undefined) {
    if (params._id !== undefined) {
      var where = { _id: params.subscriberId };
      this.staticClient.getCollection(self.collection, function (err, collection, db) {
        collection.findOne(where, function (err, subscriber) {
          if (subscriber !== null) {
            delete params.subscriberId;
            for (var keyDevices in subscriber.devices) {
              if (subscriber.devices[keyDevices]._id === params._id) {
                for (var keyParams in params) {
                  subscriber.devices[keyDevices][keyParams] = params[keyParams];
                }
                break;
              }
            }
            collection.findAndModify(where, [], subscriber, {
              w: 1,
              new: true
            }, function (err, modifiedSubscriber) {
              callback(err, params);
            });
          } else {
            callback('NO_SUBSCRIBER', null);
          }
        });
      });
    } else {
      callback('NO_DEVICE', null);
    }
  } else {
    callback('NO_SUBSCRIBER', null);
  }
  return undefined;
};

/**
 * # Description
 * Unactive all subscribers
 * Used in import
 */
Subscriber.prototype.unactivateAll = function (params, callback) {
  'use strict';
  var self = this;
  this.staticClient.getCollection(self.collection, function (err, collection) {
    collection.update({}, { '$set': { status: 0 } }, {
      w: 1,
      multi: true
    }, function (err, data) {
      callback(err, data);
    });
  });
  return undefined;
};

/**
 * # Description
 * Remove a device instance from a sub
 */
Subscriber.prototype.deleteDeviceInstance = function (params, callback) {
  'use strict';
  var self = this;
  this.staticClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.update({ '_id': params.subscriberId }, {
        '$pull': {
          'deviceInstances': {
            'deviceId': params.deviceId,
            'applicationId': params.applicationId
          }
        }
      }, { 'w': 1 }, function (err, document) {
        if (err !== null) {
          callback(err);
          self.staticClient.close();
        } else {
          callback(null, document);
          self.staticClient.close();
        }
      });
    }
  });
};

module.exports = new Subscriber();