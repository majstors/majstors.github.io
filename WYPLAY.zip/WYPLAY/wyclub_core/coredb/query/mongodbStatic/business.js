/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* global tools:true*/

// MongoDb Business Queries

var Mongodb = require('../../../lib/mongodbQuery');
var tools = require('../../../lib/tools.js');
var Business = function () {
  'use strict';
  this.setDefaultCollection('business');
};
Business.prototype = Object.create(Mongodb.prototype);

/**
 * # Description
 * Read the given business type.
 *
 * @param {Object} params (contains _id)
 * @return {Object} asset
 */
Business.prototype.read = function (params, type, callback) {
  Mongodb.prototype.read.call(this, {_id: params._id, type: type}, callback);
}

/**
 * # Description
 * Read the given business type.
 *
 * @param {Object} params (contains _id)
 * @return {Object} package
 */
Business.prototype.readCustom = function (params, callback, type) {
  'use strict';
  var self = this;
  this.staticClient.getCollection('business', function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      if (type !== undefined) {
        params.type = type;
      }
      collection.find(params).toArray(function (err, document) {
        if (err !== null) {
          callback(err);
          self.staticClient.close();
        } else {
          callback(null, document);
          self.staticClient.close();
        }
      });
    }
  });
};

/**
 * # Description
 * Update the given business type.
 *
 * @param {Object} params (contains doc)
 * @return {Object} asset
 */
Business.prototype.update = function (params, type, callback) {
  'use strict';
  var self = this;
  this.staticClient.getCollection('business', function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      var docWithoutId = tools.clone(params.document);
      delete docWithoutId._id;
      docWithoutId = tools.deleteUndefined(docWithoutId);
      var object = { _id: params.document._id };
      if (type !== undefined) {
        docWithoutId.type = type;
        object.type = type;
      }
      collection.findAndModify(object, [], { '$set': docWithoutId }, {
        w: 1,
        new: true
      }, function (err, updatedDoc) {
        if (err !== null) {
          callback(err);
          self.staticClient.close();
        } else {
          callback(null, updatedDoc);
          self.staticClient.close();
        }
      });
    }
  });
};

Business.prototype.delete = function (params, type, callback) {
  'use strict';
  if (typeof type === 'function') {
    Mongodb.prototype.delete.call(this, params, type);
  } else {
    Mongodb.prototype.delete.call(this, params, callback);
  }
}

/**
 * # Description
 * Link a given service from a service.
 *
 * @param {Object} params (contains service_id and service_id)
 * @return {Object}
 */
Business.prototype.link = function (id1, id2, callback) {
  'use strict';
  var self = this;
  this.staticClient.getCollection('business', function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.findOne({ _id: id1 }, function (err, document1) {
        collection.findOne({ _id: id2 }, function (err, document2) {
          if (document1 !== null && document2 !== null) {
            var array1 = document1.type + 's', array2 = document2.type + 's';
            if (!document1[array2]) {
              document1[array2] = [];
            }
            if (document1[array2].indexOf(id2) === -1) {
              document1[array2].push(id2);
            }
            if (!document2[array1]) {
              document2[array1] = [];
            }
            if (document2[array1].indexOf(id1) === -1) {
              document2[array1].push(id1);
            }
            delete document1._id;
            delete document2._id;
            collection.update({ _id: id1 }, { $set: document1 },
              //TODO fix param unused
              function (err, result) { // jshint ignore:line
                collection.update({ _id: id2 }, { $set: document2 }, function (err, result) {
                  callback(null, result);
                  self.staticClient.close();
                });
              });
          } else {
            callback('NO_BUSINESS_OBJECT');
          }
        });
      });
    }
  });
};

/**
 * # Description
 * Unlink a given service from a service.
 *
 * @param {Object} params (contains service_id and service_id)
 * @return {Object}
 */
Business.prototype.unlink = function (id1, id2, callback) {
  'use strict';
  var self = this;
  this.staticClient.getCollection('business', function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.findOne({ _id: id1 }, function (err, document1) {
        collection.findOne({ _id: id2 }, function (err, document2) {
          var array1 = document1.type + 's', array2 = document2.type + 's';
          var index;
          if (document1[array2]) {
            index = document1[array2].indexOf(id2);
            document1[array2].splice(index, 1);
          }
          if (document2[array1]) {
            index = document2[array1].indexOf(id1);
            document2[array1].splice(index, 1);
          }
          delete document1._id;
          delete document2._id;
          collection.update({ _id: id1 }, { $set: document1 },
            //TODO fix param unused
            function (err, result) { // jshint ignore:line
              collection.update({ _id: id2 }, { $set: document2 }, function (err, result) {
                callback(null, result);
                self.staticClient.close();
              });
            });
        });
      });
    }
  });
};

/**
 * # Description
 * Link a given aplication to a service.
 *
 * @param {Object} params (contains service_id and package_id)
 * @return {Object}
 */
Business.prototype.linkApplicationToService = function (params, callback) {
  'use strict';
  var self = this;
  this.staticClient.getCollection('business', function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      //TODO Change variable in camelCase
      collection.findAndModify(
        { _id: params.service_id }, // jshint ignore:line
        [],
        { $set: { applicationId: params.application_id } }, // jshint ignore:line
        { w: 1, new: true},
        function (err, result) {
          if (err !== null) {
            callback(err);
            self.staticClient.close();
          } else {
            callback(null, result);
            self.staticClient.close();
          }
        });
    }
  });
};

/**
 * # Description
 * Unlink a given aplication from a service.
 *
 * @param {Object} params (contains service_id and package_id)
 * @return {Object}
 */
Business.prototype.unlinkApplicationToService = function (params, callback) {
  'use strict';
  var self = this;
  this.staticClient.getCollection('business', function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.findAndModify(
        //TODO Change variable in camelCase
        { _id: params.service_id }, // jshint ignore:line
        [],
        { $set: { applicationId: null } },
        { w: 1, new: true },
        function (err, result) {
          if (err !== null) {
            callback(err);
            self.staticClient.close();
          } else {
            callback(null, result);
            self.staticClient.close();
          }
        });
    }
  });
};

module.exports = new Business();