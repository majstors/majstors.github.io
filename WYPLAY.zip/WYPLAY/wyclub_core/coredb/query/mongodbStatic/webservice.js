/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* global tools:true*/

// Web Service Queries

var Mongodb = require('../../../lib/mongodbQuery');
var tools = require('../../../lib/tools');
var Webservice = function () {
  'use strict';
  this.setDefaultCollection('webservice');
};
Webservice.prototype = Object.create(Mongodb.prototype);

/**
 * # Description
 * Return all webservices corresponds to or/and name,url,protocol,path,port,method,types,applicationId
 *
 * @param {Object} params (contains or/and name,url,protocol,path,port,method,types,applicationId)
 * @return {Array} webservices
 */
Webservice.prototype.readCustom = function (params, callback) {
  'use strict';
  var self = this;
  this.staticClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      var where = params;
      collection.find(where).toArray(function (err, webservices) {
        if (err !== null) {
          callback('error');
          self.staticClient.close();
        } else {
          callback(null, webservices);
          self.staticClient.close();
        }
      });
    }
  });
};

/**
 * # Description
 * Create webservice
 *
 * @param {Object} params (contains applicationId, name, url, protocol, path, {Integer} port, method, types, rules)
 * @return {Object} webservice
 */
Webservice.prototype.create = function (params, callback) {
  'use strict';
  var self = this;
  this.staticClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      var clonedParams = tools.clone(params);
      delete clonedParams._id;
      collection.find(clonedParams, { 'limit': 1 }).count(true, function (err, count) {
        if (Boolean(count)) {
          callback('DUPLICATE_ENTRY');
          self.staticClient.close();
        } else {
          collection.insert(params, {}, function (err, webservice) {
            if (err !== null || !webservice) {
              callback('error');
              self.staticClient.close();
            } else {
              callback(null, webservice[0]);
              self.staticClient.close();
            }
          });
        }
      });
    }
  });
};

/**
 * # Description
 * Update webservice
 *
 * @param {Object} params (contains applicationId, name)
 * @param {Object} params optionnal (url, protocol, path, {Integer} port, method, types, rules)
 * @return {Object} webservice
 */
Webservice.prototype.update = function (params, callback) {
  'use strict';
  var self = this;
  this.staticClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      var up = {};
      var attribs = Object.keys(params);
      for (var i = attribs.length - 1; i >= 0; i--) {
        var currentAttrib = attribs[i];
        if (currentAttrib === 'name' ||
          currentAttrib === 'url' ||
          currentAttrib === 'protocol' ||
          currentAttrib === 'path' ||
          currentAttrib === 'port' ||
          currentAttrib === 'method' ||
          currentAttrib === 'types' ||
          currentAttrib === 'rules') {
          up[currentAttrib] = params[currentAttrib];
        }
      }
      collection.findAndModify({
        name: params.name,
        applicationId: params.applicationId
      }, {}, { $set: up }, { new: true }, function (err, webservice) {
        if (err !== null) {
          callback('error');
          self.staticClient.close();
        } else {
          callback(null, webservice);
          self.staticClient.close();
        }
      });
    }
  });
};

/**
 * # Description
 * Link a rule to a webservice.
 *
 *    @param {Object} params (contains webserviceId, ruleId)
 *  @return {Object}
 *
 */
Webservice.prototype.linkRule = function (params, callback) {
  'use strict';
  var self = this;
  this.staticClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.findOne({ _id: params.webserviceId }, function (err, document) {
        if (err !== null) {
          callback('error');
          self.staticClient.close();
        } else {
          if (document && document._id !== undefined) {
            if (!document.rules || document.rules.length === 0) {
              document.rules = [params.ruleId];
            } else {
              document.rules.push(params.ruleId);
            }
            collection.update({ _id: document._id }, document, {}, function (err) {
              if (err !== null && err !== undefined) {
                callback(err);
                self.staticClient.close();
              } else {
                callback(null, {
                  ruleId: params.ruleId,
                  webserviceId: document._id
                });
                self.staticClient.close();
              }
            });
          } else {
            callback('NO_WEBSERVICE', null);
            self.staticClient.close();
          }
        }
      });
    }
  });
};

/**
 * # Description
 * Unlink a rule from a webservice.
 *
 *    @param {Object} params (contains webserviceId, ruleId)
 *    @return {Object}
 *
 */
Webservice.prototype.unlinkRule = function (params, callback) {
  'use strict';
  var self = this;
  this.staticClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.findOne({ _id: params.webserviceId }, function (err, document) {
        if (err !== null) {
          callback('error');
          self.staticClient.close();
        } else {
          if (document !== undefined && document !== null && document._id !== undefined) {
            if (document.rules.length !== 0) {
              var newRulesArray = [];
              for (var rule in document.rules) {
                if (document.rules[rule] !== params.ruleId) {
                  newRulesArray.push(document.rules[rule]);
                }
              }
              document.rules = newRulesArray;
              collection.update({ _id: document._id }, document, { w: 1 }, function (err) {
                if (err !== null) {
                  callback(err);
                } else {
                  callback(null, {
                    ruleId: params.ruleId,
                    webserviceId: document._id
                  });
                }
              });
            } else {
              callback('NO_WEBSERVICE');
            }
          } else {
            callback('NO_WEBSERVICE');
          }
        }
        self.staticClient.close();
      });
    }
  });
};

module.exports = new Webservice();