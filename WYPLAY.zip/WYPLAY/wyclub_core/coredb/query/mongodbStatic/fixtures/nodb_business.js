/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
*/

/* jshint -W106*/
/* global tools:true*/

var business = {
  nonExistingService1: {
    _id: tools.generatePublicKey(32),
    label: 'non exist',
    businessId: '_404',
    state: 'activated',
    applicationId: null,
    tags: ["dFaMuoEBmGVW46ljSOKtRj8xStD2zgH0"],
    assets: [],
    packages: []
  },
  nonExistingPackage1: {
    _id: tools.generatePublicKey(32),
    label: 'non exist',
    businessId: '_404',
    state: 'activated',
    tags: ["dFaMuoEBmGVW46ljSOKtRj8xStD2zgH0"],
    assets: [],
    services: []
  },
  toCreatePackage1: {
    _id: tools.generatePublicKey(32),
    label: 'created1',
    businessId: '_555',
    state: 'activated',
    tags: ["dFaMuoEBmGVW46ljSOKtRj8xStD2zgH0"],
    assets: [],
    services: []
  },
  toCreatePackage2: {
    _id: tools.generatePublicKey(32),
    label: 'created2',
    businessId: '_556',
    state: 'activated',
    assets: [],
    services: []
  },
  toCreateService1: {
    _id: tools.generatePublicKey(32),
    label: 'created1',
    businessId: '_555',
    state: 'activated',
    tags: ["dFaMuoEBmGVW46ljSOKtRj8xStD2zgH0"],
    assets: [],
    services: []
  },
  toCreateService2: {
    _id: tools.generatePublicKey(32),
    label: 'created2',
    businessId: '_556',
    state: 'activated',
    assets: [],
    services: []
  },
  toCreateAsset1: {
    _id: tools.generatePublicKey(32),
    label: 'created1',
    businessId: '_556',
    state: 'activated',
    packages: [],
    tags: ["dFaMuoEBmGVW46ljSOKtRj8xStD2zgH0"],
    services: []
  },
  toCreateAsset2: {
    _id: tools.generatePublicKey(32),
    label: 'created2',
    businessId: '_557',
    state: 'activated',
    packages: [],
    services: []
  },
  nonExistingAsset1: {
    _id: tools.generatePublicKey(32),
    label: 'non exist',
    businessId: '_404',
    state: 'activated',
    tags: ["dFaMuoEBmGVW46ljSOKtRj8xStD2zgH0"],
    assets: [],
    services: []
  }
};

module.exports = business;