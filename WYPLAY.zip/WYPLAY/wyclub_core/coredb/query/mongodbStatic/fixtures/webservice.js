/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* jshint -W106*/
/* global tools:true*/

var webservice = {
  webservice_1: {
    _id: 'firstWebservice',
    name: 'core2:application.service:get',
    url: '',
    protocol: 'https',
    path: '/:wyclubToken/application.service.json',
    port: 3103,
    method: 'get',
    types: 'fixture',
    applicationId: 'kGvUuwnBlTNnQPi09kx8eQyiUN5zgM4w'
  },
  webservice_2: {
    _id: tools.generatePublicKey(32),
    name: 'core2:application.service:post',
    url: '',
    protocol: 'https',
    path: '/:wyclubToken/application.service.json',
    port: 3103,
    method: 'post',
    types: 'fixture',
    applicationId: 'kGvUuwnBlTNnQPi09kx8eQyiUN5zgM4w'
  },
  webservice_3: {
    _id: tools.generatePublicKey(32),
    name: 'Core:application.service:post',
    url: '',
    protocol: 'https',
    path: '/:wyclubToken/application.service.json',
    port: 3103,
    method: 'post',
    types: 'fixture',
    applicationId: 'kGvUuwnBlTNnQPi09kx8eQyiUN5zgM4w'
  },
  webservice_4: {
    _id: tools.generatePublicKey(32),
    name: 'npvr:sendMeEvent:post',
    url: '',
    protocol: 'https',
    path: '/:wyclubToken/application.service.json',
    port: 3103,
    method: 'post',
    types: 'fixture',
    applicationId: 'kGvUuwnBlTNnQPi09kx8eQyiUN5zgM4w'
  },
  webservice_noRule: {
    _id: tools.generatePublicKey(32),
    name: 'core2:application.service:delete',
    url: '',
    protocol: 'https',
    path: '/:wyclubToken/application.service.json',
    port: 3103,
    method: 'delete',
    types: 'fixture',
    applicationId: 'kGvUuwnBlTNnQPi09kx8eQyiUN5zgM4w'
  }
};

module.exports = webservice;