/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* jshint -W106*/
/* global tools:true*/

var webservice = {
  invalid_webservice_1: {
    _id: tools.generatePublicKey(32),
    name: 'core:application.service:get',
    url: '',
    protocol: 'https',
    path: '/:wyclubToken/application.service.json',
    port: 3103,
    method: 'get',
    servicetype: 'core',
    applicationId: 'e41e58aa28b0732692982cb70152eb1a',
    rules: [
      '706af90b3f98cce1187cea3a1c19a857',
      '059517fe17b7e6aff728bcc77cd1f54a'
    ]
  }
};

module.exports = webservice;