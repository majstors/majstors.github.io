/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
*/

/* jshint -W106*/
/* global tools:true*/

var business = {
  business_service_1: {
    _id: tools.generatePublicKey(32),
    label: 'service1',
    businessId: '01',
    state: 'activated',
    applicationId: null,
    type: 'service',
    tags: [
      "dFaMuoEBmGVW4dljSOctRj8qStD2zgH0",
      "pFaMuoEBmGVW46ljSOKtRj8xStD2zgH0"
    ],
    assets: [],
    packages: []
  },
  business_service_2: {
    _id: tools.generatePublicKey(32),
    label: 'service2',
    businessId: '02',
    state: 'activated',
    type: 'service',
    applicationId: null,
    tags: ["dFaMuoEBmGVW4dljSOctRj8qStD2zgH0"],
    assets: [],
    packages: []
  },
  business_service_3: {
    _id: tools.generatePublicKey(32),
    label: 'service3',
    businessId: '03',
    state: 'activated',
    applicationId: null,
    type: 'service',
    tags: ["dFaMuoEBmGVW4dljSOctRj8qStD2zgH0"],
    assets: [],
    packages: []
  },
  business_service_toDelete: {
    _id: tools.generatePublicKey(32),
    label: 'serviceDelete',
    businessId: '05',
    state: 'activated',
    applicationId: null,
    type: 'service',
    tags: ["dFaMuoEBmGVW4dljSOctRj8qStD2zgH0"],
    assets: [],
    packages: []
  },
  business_service_4: {
    _id: tools.generatePublicKey(32),
    label: 'service4',
    businessId: '04',
    state: 'activated',
    applicationId: null,
    type: 'service',
    tags: ["dFaMuoEBmGVW4dljSOctRj8qStD2zgH0"],
    assets: [],
    packages: []
  },
  business_package_1: {
    _id: tools.generatePublicKey(32),
    label: 'package1',
    businessId: '01',
    state: 'activated',
    tags: [],
    type: 'package',
    assets: [],
    services: []
  },
  business_package_2: {
    _id: tools.generatePublicKey(32),
    label: 'package2',
    businessId: '02',
    state: 'activated',
    tags: ["dFaMuoEBmGVW4dljSOctRj8qStD2zgH0"],
    assets: [],
    type: 'package',
    services: []
  },
  business_package_3: {
    _id: tools.generatePublicKey(32),
    label: 'package3',
    businessId: '03',
    state: 'activated',
    tags: [
      "dFaMuoEBmGVW4dljSOctRj8qStD2zgH0",
      "pFaMuoEBmGVW46ljSOKtRj8xStD2zgH0"
    ],
    type: 'package',
    assets: [],
    services: []
  },
  business_package_ToUpdate: {
    _id: tools.generatePublicKey(32),
    label: 'package4',
    businessId: '04',
    state: 'activated',
    tags: [
      "dFaMuoEBmGVW4dljSOctRj8qStD2zgH0",
      "pFaMuoEBmGVW46ljSOKtRj8xStD2zgH0"
    ],
    assets: [],
    type: 'package',
    services: []
  },
  business_package_ToDelete: {
    _id: tools.generatePublicKey(32),
    label: 'package5',
    businessId: '05',
    state: 'activated',
    type: 'package',
    tags: ["pFaMuoEBmGVW46ljSOKtRj8xStD2zgH0"],
    assets: [],
    services: []
  },
  business_asset_1: {
    _id: tools.generatePublicKey(32),
    label: 'asset1',
    businessId: '01',
    type: 'asset',
    state: 'activated',
    tags: [
      "dFaMuoEBmGVW4dljSOctRj8qStD2zgH0",
      "pFaMuoEBmGVW46ljSOKtRj8xStD2zgH0"
    ],
    packages: [],
    services: []
  },
  business_asset_2: {
    _id: tools.generatePublicKey(32),
    label: 'asset2',
    businessId: '02',
    state: 'activated',
    type: 'asset',
    tags: ["dFaMuoEBmGVW4dljSOctRj8qStD2zgH0"],
    packages: [],
    services: []
  },
  business_asset_3: {
    _id: tools.generatePublicKey(32),
    label: 'asset3',
    businessId: '03',
    type: 'asset',
    state: 'activated',
    tags: [],
    packages: [],
    services: []
  },
  business_asset_4: {
    _id: tools.generatePublicKey(32),
    label: 'asset4',
    businessId: '04',
    type: 'asset',
    state: 'activated',
    tags: ["dFaMuoEBmGVW4dljSOctRj8qStD2zgH0"],
    packages: [],
    services: []
  },
  business_asset_fightClub: {
    _id: tools.generatePublicKey(32),
    label: 'fight club',
    businessId: 'VOD4',
    type: 'asset',
    state: 'activated',
    tags: [],
    packages: [],
    services: []
  },
  business_asset_batman: {
    _id: tools.generatePublicKey(32),
    label: 'batman',
    businessId: 'VOD3',
    type: 'asset',
    state: 'activated',
    tags: [],
    packages: [],
    services: []
  },
  business_asset_skyfall: {
    _id: tools.generatePublicKey(32),
    label: 'skyfall',
    type: 'asset',
    businessId: 'SVOD3',
    state: 'activated',
    tags: [],
    packages: [],
    services: []
  },
  business_asset_toUpdate: {
    _id: tools.generatePublicKey(32),
    label: 'update',
    type: 'asset',
    businessId: '_558',
    state: 'activated',
    packages: [],
    services: [],
    tags: ["dFaMuoEBmGVW4dljSOctRj8qStD2zgH0"]
  },
  business_asset_toDelete: {
    _id: tools.generatePublicKey(32),
    label: 'delete',
    businessId: '_559',
    state: 'activated',
    type: 'asset',
    packages: [],
    services: [],
    tags: []
  }
};

business.business_package_2.services = [
  business.business_service_1._id,
  business.business_service_2._id,
  business.business_service_4._id
];
business.business_service_1.packages = [business.business_package_1._id];
business.business_service_2.packages = [business.business_package_1._id];
business.business_service_toDelete.packages = [business.business_package_1._id];
business.business_service_2.assets = [
  business.business_asset_1._id,
  business.business_asset_2._id
];
business.business_package_2.assets = [
  business.business_asset_1._id,
  business.business_asset_3._id
];
business.business_asset_1.packages = [business.business_package_2._id];
business.business_asset_3.packages = [business.business_package_2._id];
business.business_asset_1.services = [business.business_service_2._id];
business.business_asset_2.services = [business.business_service_2._id];
business.business_asset_fightClub.tags = ["pFaMuoEBmGVW46ljSOKtRj8xStD2zgH0"];
business.business_asset_batman.tags = ["pFaMuoEBmGVW46ljSOKtRj8xStD2zgH0"];
business.business_asset_skyfall.tags = [
  "pFaMuoEBmGVW46ljSOKtRj8xStD2zgH0",
  "dFaMuoEBmGVW4dljSOctRj8qStD2zgH0"
];
business.business_service_1.applicationId = 'XHPiMdpchfugjthdjitfH6WgJVJP6r1Z';
business.business_service_4.applicationId = 'XHPiMdpchfugjthdjitfH6WgJVJP6r1B';

module.exports = business;