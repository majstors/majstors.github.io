/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* jshint -W106*/
/* global tools:true*/

var rule = {
  rule_1: {
    _id: tools.generatePublicKey(32),
    type: 'sync',
    label: 'no if age < 18',
    sourcecode: 'ruleCallback(null,true);',
    rules: []
  },
  rule_2: {
    _id: tools.generatePublicKey(32),
    type: 'sync',
    label: 'no if age < 18',
    sourcecode: 'ruleCallback(null,true);'
  },
  rule_deleteSiamezeSessions: {
    _id: tools.generatePublicKey(32),
    type: 'async',
    label: 'deleteSiamezeSessions',
    sourcecode: 'var wyclubToken = null;\n' +
    'if(req && req.params && req.params.wyclubToken){\n' +
    '   wyclubToken = req.params.wyclubToken;\n' +
    '}\n' +
    'sessionContext.read(req, function(err,currentSession){\n' +
    '   Core.repository.session.deleteSiamezeSessions({session: currentSession},function(err,data){\n' +
    '       if(err !== null){\n' +
    '           ruleCallback(null, false)\n' +
    '       } else {\n' +
    '           ruleCallback(null, true);\n' +
    '       }\n' +
    '   });\n' +
    '});',
    rules: [{_id:tools.generatePublicKey(32), webservice: 'core:session:post' }]
  },
  rule_newConnection: {
    _id: tools.generatePublicKey(32),
    type: 'async',
    label: 'newConnection',
    sourcecode: 'var myEvent = {};\n' +
    'myEvent.eventName = req.body.eventName;\n' +
    'myEvent.eventValue = req.body.eventValue;\n' +
    'if(myEvent.eventValue && myEvent.eventName && myEvent.eventName == "newConnection"){\n' +
    '   var wyclubToken = null;\n' +
    '   if(req && req.params && req.params.wyclubToken){\n' +
    '       wyclubToken = req.params.wyclubToken;\n' +
    '   }\n' +
    '   sessionContext.read(req, function(err,currentSession){\n' +
    '       if(err !== null){\n' +
    '           ruleCallback(null, false);\n' +
    '       } else {\n' +
    '           if(currentSession &&' +
    '             currentSession.application &&' +
    '             currentSession.application._id &&' +
    '             currentSession.application._id == "simpleui123456789123456789123456" &&' +
    '             currentSession.profile &&' +
    '             system.getAgeFromDate(currentSession.profile.birthdate) < 18){\n' +
    '               Core.repository.session.readTwinSisterSessions(currentSession, function(err,otherSessions){\n' +
    '                   if(err !== null || !otherSessions || otherSessions.length <= 0){\n' +
    '                       ruleCallback(null, false);\n' +
    '                   } else {\n' +
    '                       async.eachSeries(otherSessions,function(mySess,callback){\n' +
    '                           Core.repository.session.read({wyclubToken: mySess._id}, function(err,mySess){\n' +
    '                               if(mySess &&' +
    '                                 mySess.application &&' +
    '                                 mySess.application._id &&' +
    '                                 mySess.profile &&' +
    '                                 mySess.profile._id !== currentSession.profile._id){\n' +
    '                                Core.eventBroker.publishChannel(mySess.application._id,' +
    '                                 {' +
    '                                  \'session\': mySess._id,' +
    '                                  \'event\': myEvent,' +
    '                                  \'otherInformations\': {' +
    '                                    \'profileName\': currentSession.profile.label' +
    '                                  }' +
    '                                 });\n' +
    '                                callback();\n' +
    '                               } else {\n' +
    '                                   callback();\n' +
    '                               }\n' +
    '                           }); \n' +
    '                       }, function(err){\n' +
    '                           ruleCallback(null, true);\n' +
    '                       })\n' +
    '                   }\n' +
    '               });\n' +
    '           } else {\n' +
    '               ruleCallback(null, true);\n' +
    '           }\n' +
    '       }\n' +
    '   });\n' +
    '} else {\n' +
    '   ruleCallback(null, true);\n' +
    '}',
    rules: [{_id:tools.generatePublicKey(32), webservice: 'core:event:post' }]
  },
  rule_addNotification: {
    _id: tools.generatePublicKey(32),
    type: 'async',
    label: 'addNotification',
    sourcecode: 'var myEvent = {};\n' +
    'myEvent.eventName = req.body.eventName;\n' +
    'myEvent.eventValue = req.body.eventValue;\n' +
    'if(myEvent.eventValue && myEvent.eventName && myEvent.eventName == "addNotification"){\n' +
    '	var wyclubToken = null;\n' +
    '	if(req && req.params && req.params.wyclubToken){\n' +
    '		wyclubToken = req.params.wyclubToken;\n' +
    '	}\n' +
    '	sessionContext.read(req, function(err,currentSession){\n' +
    '		if(err !== null){\n' +
    '			ruleCallback(null, false);\n' +
    '		} else {\n' +
    '			if(currentSession &&' +
    '       currentSession.application &&' +
    '       currentSession.application._id &&' +
    '       currentSession.application._id == "simpleui123456789123456789123456"){\n' +
    '				Core.repository.session.readHalfSisterSessions(currentSession, function(err,otherSessions){\n' +
    '					if(err == \'NO_SESSION\'){\n' +
    '						err = null;\n' +
    '					}\n' +
    '					otherSessions.push(currentSession);\n' +
    '					if(err !== null || !otherSessions || otherSessions.length <= 0){\n' +
    '						ruleCallback(null, false);\n' +
    '					} else {\n' +
    '						async.eachSeries(otherSessions,function(mySess,callback){\n' +
    '							Core.repository.session.read({wyclubToken: mySess._id}, function(err,mySess){\n' +
    '								if(mySess &&' +
    '                 mySess.application &&' +
    '                 mySess.application._id &&' +
    '                 mySess.profile &&' +
    '                 mySess.profile._id == currentSession.profile._id){\n' +
    '									console.log(\'eventLaunch\'.red);' +
    '                 Core.eventBroker.publishChannel(mySess.application._id,' +
    '                   {' +
    '                     \'session\': mySess._id,' +
    '                     \'event\': myEvent,' +
    '                     \'otherInformations\': {}' +
    '                   }' +
    '                 );\n' +
    '									callback();\n' +
    '								} else {\n' +
    '									callback();\n' +
    '								}\n' +
    '							});\n' +
    '						}, function(err){\n' +
    '							ruleCallback(null, true);\n' +
    '						})\n' +
    '					}\n' +
    '				});\n' +
    '			} else {\n' +
    '				ruleCallback(null, true);\n' +
    '			}\n' +
    '		}\n' +
    '	});	\n' +
    '} else {\n' +
    '	ruleCallback(null, true);\n' +
    '}',
    rules: [{_id:tools.generatePublicKey(32), webservice: 'core:event:post' }]
  },
  rule_updateCurrentContent: {
    _id: tools.generatePublicKey(32),
    type: 'sync',
    label: 'updateCurrentContent',
    sourcecode: 'var wyclubToken = null;\n' +
    'if(req && req.params && req.params.wyclubToken){\n' +
    '   wyclubToken = req.params.wyclubToken;\n' +
    '}\n' +
    'sessionContext.read(req, function(err,currentSession){\n' +
    '   if(err !== null){\n' +
    '       ruleCallback(err, true);\n' +
    '   } else {\n' +
    '       if(currentSession && currentSession._id){\n' +
    '           var currentContent = req.body.currentContent;\n' +
    '            if(typeof currentContent == "string"){\n' +
    '                try {\n' +
    '                    currentContent = JSON.parse(currentContent);\n' +
    '                } catch (err) {\n' +
    '                    currentContent = undefined;\n' +
    '                }\n' +
    '            }\n' +
    '           if(currentContent !== null && currentContent !== undefined)\n' +
    '            {\n' +
    '               Core.repository.session.updateCurrentContent({' +
    '                 wyclubToken: currentSession._id,' +
    '                 content: currentContent.content,' +
    '                 origin: currentContent.origin' +
    '               },function(err,data){\n' +
    '               if(data.content == currentContent.content && data.origin == currentContent.origin)\n' +
    '                    {\n' +
    '                        ruleCallback(null,true);\n' +
    '                    } else {\n' +
    '                        Core.log("current content insertion has failed.".red);\n' +
    '                        ruleCallback("current content insertion has failed.",true);\n' +
    '                    }\n' +
    '               });\n' +
    '            } else {\n' +
    '               ruleCallback(null, true);\n' +
    '            }\n' +
    '       } else {\n' +
    '           ruleCallback(null, true);\n' +
    '       }\n' +
    '   }\n' +
    '});\n',
    rules: [{_id:tools.generatePublicKey(32), webservice: 'core:event:post' }]
  },
  rule_settingChange: {
    _id: tools.generatePublicKey(32),
    type: 'async',
    label: 'settingChange',
    sourcecode: 'var myEvent = {}; \n' +
    'myEvent.eventName = req.body.eventName; \n' +
    'myEvent.eventValue = req.body.eventValue; \n' +
    'if(myEvent.eventValue && myEvent.eventName && myEvent.eventName == "settingChange"){ \n' +
    '	var wyclubToken = null; \n' +
    '	if(req && req.params && req.params.wyclubToken){ \n' +
    '		wyclubToken = req.params.wyclubToken; \n' +
    '	} \n' +
    '	sessionContext.read(req, function(err,currentSession){ \n' +
    '		if(err !== null){ \n' +
    '			ruleCallback(null, false); \n' +
    '		} else { \n' +
    '			if(currentSession &&' +
    '       currentSession.application &&' +
    '       currentSession.application._id &&' +
    '       currentSession.application._id == "simpleui123456789123456789123456"){ \n' +
    '				Core.repository.session.readHalfSisterSessions(currentSession, function(err,otherSessions){ \n' +
    '					if(err == \'NO_SESSION\'){ \n' +
    '						err = null; \n' +
    '					} \n' +
    '					otherSessions.push(currentSession);\n' +
    '					if(err !== null || !otherSessions || otherSessions.length <= 0){ \n' +
    '						ruleCallback(null, false); \n' +
    '					} else { \n' +
    '						async.eachSeries(otherSessions,function(mySess,callback){ \n' +
    '							Core.repository.session.read({wyclubToken: mySess._id}, function(err, mySess){\n' +
    '								if(mySess && mySess.application && mySess.application._id){ \n' +
    '									Core.eventBroker.publishChannel(mySess.application._id,' +
    '                   {\'session\': mySess._id, \'event\': myEvent,\'otherInformations\': {}}' +
    '                 );\n' +
    '									callback();\n' +
    '								} else { \n' +
    '									callback(); \n' +
    '								} \n' +
    '							});\n' +
    '						}, function(err){ \n' +
    '							ruleCallback(null, true); \n' +
    '						}) \n' +
    '					} \n' +
    '				}); \n' +
    '			} else { \n' +
    '				ruleCallback(null, true); \n' +
    '			} \n' +
    '		} \n' +
    '	});	 \n' +
    '} else { \n' +
    '	ruleCallback(null, true); \n' +
    '}',
    rules: [{_id:tools.generatePublicKey(32), webservice: 'core:event:post' }]
  },
  rule_deviceLabelChange: {
    _id: tools.generatePublicKey(32),
    type: 'async',
    label: 'deviceLabelChange',
    sourcecode: 'var myEvent = {};\n' +
    'myEvent.eventName = req.body.eventName;\n' +
    'myEvent.eventValue = req.body.eventValue;\n' +
    'if(myEvent.eventValue && myEvent.eventName && myEvent.eventName == "deviceLabelChange"){\n' +
    '	var wyclubToken = null;\n' +
    '	if(req && req.params && req.params.wyclubToken){\n' +
    '		wyclubToken = req.params.wyclubToken;\n' +
    '	}\n' +
    '	sessionContext.read(req, function(err,currentSession){\n' +
    '		if(err !== null){\n' +
    '			ruleCallback(null, false);\n' +
    '		} else {\n' +
    '			if(currentSession &&' +
    '       currentSession.application &&' +
    '       currentSession.application._id &&' +
    '       currentSession.application._id == "simpleui123456789123456789123456"){\n' +
    '				Core.repository.session.readHalfSisterSessions({session: currentSession}, function(err,otherSessions){\n' +
    '					if(err == \'NO_SESSION\'){\n' +
    '						err = null;\n' +
    '					}\n' +
    '					otherSessions.push(currentSession);\n' +
    '					if(err !== null || !otherSessions || otherSessions.length <= 0){\n' +
    '						ruleCallback(null, false);\n' +
    '					} else {\n' +
    '						async.eachSeries(otherSessions,function(mySess,callback){\n' +
    '							Core.repository.session.read({wyclubToken: mySess._id}, function(err,mySess){\n' +
    '								if(mySess &&' +
    '                 mySess.application &&' +
    '                 mySess.application._id &&' +
    '                 mySess.profile &&' +
    '                 mySess.profile._id == currentSession.profile._id){\n' +
    '									Core.eventBroker.publishChannel(mySess.application._id,' +
    '                 {' +
    '                  \'session\': mySess._id,' +
    '                  \'event\': myEvent,' +
    '                  \'otherInformations\': {}' +
    '                 });\n' +
    '									callback();\n' +
    '								} else {\n' +
    '									callback();\n' +
    '								}\n' +
    '							}); \n' +
    '						}, function(err){\n' +
    '							ruleCallback(null, true);\n' +
    '						})\n' +
    '					}\n' +
    '				});\n' +
    '			} else {\n' +
    '				ruleCallback(null, true);\n' +
    '			}\n' +
    '		}\n' +
    '	});	\n' +
    '} else {\n' +
    '	ruleCallback(null, true);\n' +
    '}',
    rules: [{_id:tools.generatePublicKey(32), webservice: 'core:event:post' }]
  },
  rule_swipeNotif: {
    _id: tools.generatePublicKey(32),
    type: 'async',
    label: 'swipeNotif',
    sourcecode: 'var myEvent = {};\n' +
    'myEvent.eventName = req.body.eventName;\n' +
    'myEvent.eventValue = req.body.eventValue;\n' +
    'if(myEvent.eventValue && myEvent.eventName && myEvent.eventName == "swipeNotif"){\n' +
    '    Core.log("Swipe Notif".yellow);\n' +
    '    var wyclubToken = null;\n' +
    '    if(req && req.params && req.params.wyclubToken){\n' +
    '        wyclubToken = req.params.wyclubToken;\n' +
    '    }\n' +
    '    sessionContext.read(req, function(err,currentSession){\n' +
    '        if(err !== null){\n' +
    '            ruleCallback(null, false);\n' +
    '        } else {\n' +
    '            if(currentSession &&' +
    '             currentSession.application &&' +
    '             currentSession.application._id &&' +
    '             currentSession.application._id == "simpleui123456789123456789123456") {\n' +
    '                Core.repository.session.readTwinSisterSessions(currentSession, function(err,otherSessions){\n' +
    '                   console.log(otherSessions);' +
    '                   if(err !== null || !otherSessions || otherSessions.length <= 0){\n' +
    '                        ruleCallback(null, false);\n' +
    '                    } else {\n' +
    '                        async.eachSeries(otherSessions,function(mySess,callback){\n' +
    '                            if(mySess && mySess.applicationId){\n' +
    '                                var swipe = JSON.parse(myEvent.eventValue);\n' +
    '                                if(typeof swipe == \'object\') {\n' +
    '                                    if(swipe.hasOwnProperty(mySess._id)) {\n' +
    '                                        var myEventSend = {\n' +
    '                                            eventName: myEvent.eventName,\n' +
    '                                            eventValue: JSON.stringify({"swipeNum": swipe[mySess._id] })\n' +
    '                                        };\n' +
    '                                        //TODO: change that to next comm after readtwinsister action\n' +
    '                                        Core.eventBroker.publishChannel(mySess.applicationId, {\n' +
    '                                            \'session\': mySess._id, \n' +
    '                                            \'event\': myEventSend,\n' +
    '                                            \'otherInformations\': {}\n' +
    '                                        });\n' +
    '                                        /*\n' +
    '                                        Core.eventBroker.publishChannel(mySess.application._id, {\n' +
    '                                            \'session\': mySess._id, \n' +
    '                                            \'event\': myEvent,\n' +
    '                                            \'otherInformations\': {}\n' +
    '                                        });\n' +
    '                                        */\n' +
    '                                        callback();\n' +
    '                                    }\n' +
    '                                } \n' +
    '                            }\n' +
    '                            callback();\n' +
    '                        }, function(err){\n' +
    '                            ruleCallback(null, true);\n' +
    '                        })\n' +
    '                    }\n' +
    '                });\n' +
    '            } else {\n' +
    '                ruleCallback(null, true);\n' +
    '            }\n' +
    '        }\n' +
    '    }); \n' +
    '} else {\n' +
    '    ruleCallback(null, true);\n' +
    '}',
    rules: [{_id:tools.generatePublicKey(32), webservice: 'core:event:post' }]
  },
  rule_vod_reading: {
    _id: tools.generatePublicKey(32),
    type: 'async',
    label: 'vod_reading',
    sourcecode: 'var myEvent = {};\n' +
    'myEvent.eventName = req.body.eventName;\n' +
    'myEvent.eventValue = req.body.eventValue;\n' +
    'if(myEvent.eventValue && myEvent.eventName && myEvent.eventName == "VOD_reading"){\n' +
    '	var wyclubToken = null;\n' +
    '	if(req && req.params && req.params.wyclubToken){\n' +
    '		wyclubToken = req.params.wyclubToken;\n' +
    '	}\n' +
    '	sessionContext.read(req, function(err,currentSession){\n' +
    '		if(err !== null){\n' +
    '			ruleCallback(null, false);\n' +
    '		} else {\n' +
    '			if(currentSession &&' +
    '       currentSession.application &&' +
    '       currentSession.application._id &&' +
    '       currentSession.application._id == "simpleui123456789123456789123456" &&' +
    '       currentSession.profile &&' +
    '       system.getAgeFromDate(currentSession.profile.birthdate) < 18){\n' +
    '				Core.repository.session.readCurrentContent({wyclubToken: currentSession._id}, function(err,data){\n' +
    '					var params = {businessId: data.content};\n' +
    '					Core.repository.business.readAssetCustom(params, function(err,asset){\n' +
    '						if(err !== null){\n' +
    '							ruleCallback(null, true);\n' +
    '						} else {\n' +
    '							if(asset[0] && asset[0].tag){\n' +
    '								var isAdult = false;\n' +
    '								async.eachSeries(asset[0].tag, function(tag, cb){\n' +
    '									if(tag.label == "ADULT"){\n' +
    '										isAdult = true;\n' +
    '									}\n' +
    '									cb(null);\n' +
    '								}, function(err){\n' +
    '									if(isAdult){\n' +
    '										Core.eventBroker.publishChannel(currentSession.application._id,' +
    '                   {' +
    '                    \'session\': currentSession._id,' +
    '                    \'event\': {eventName:"stopAsset",' +
    '                    eventValue: {reason: "That asset is not for children!"}' +
    '                   },' +
    '                   \'otherInformations\': {}});\n' +
    '										Core.repository.session.readTwinSisterSessions(currentSession,' +
    '                   function(err,otherSessions){\n' +
    '											if(err !== null || !otherSessions || otherSessions.length <= 0){\n' +
    '												ruleCallback(null, false);\n' +
    '											} else {\n' +
    '												async.eachSeries(otherSessions,function(mySess,callback){ \n' +
    '														Core.repository.session.read({wyclubToken: mySess._id}, function(err,mySess){\n' +
    '															if(mySess &&' +
    '                               mySess.application &&' +
    '                               mySess.application._id &&' +
    '                               mySess.profile &&' +
    '                               mySess.profile._id !== currentSession.profile._id){\n' +
    '																Core.eventBroker.publishChannel(mySess.application._id,' +
    '                               {' +
    '                                \'session\': mySess._id,' +
    '                                \'event\': myEvent,' +
    '                                \'otherInformations\': {' +
    '                                  \'profileName\': currentSession.profile.label,' +
    '                                  \'initialSession\':currentSession._id' +
    '                                }' +
    '                               });' +
    '                               callback();\n' +
    '														} else {\n' +
    '															callback();\n' +
    '														}\n' +
    '														});\n' +
    '												}, function(err){\n' +
    '													ruleCallback(null, true);\n' +
    '												})\n' +
    '											}\n' +
    '										});\n' +
    '									} else {\n' +
    '										ruleCallback(null, true);\n' +
    '									}\n' +
    '								});\n' +
    '							} else {\n' +
    '								ruleCallback(null,true);\n' +
    '							}\n' +
    '						}\n' +
    '					});\n' +
    '				});\n' +
    '			} else {\n' +
    '				ruleCallback(null, true);\n' +
    '			}\n' +
    '		}\n' +
    '	});	\n' +
    '} else {\n' +
    '	ruleCallback(null, true);\n' +
    '}',
    rules: [{_id:tools.generatePublicKey(32), webservice: 'core:event:post' }]
  },
  rule_unlockVideo: {
    _id: tools.generatePublicKey(32),
    type: 'async',
    label: 'unlockVideo',
    sourcecode: 'var myEvent = {};\n' +
    'myEvent.eventName = req.body.eventName;\n' +
    'myEvent.eventValue = req.body.eventValue;\n' +
    'if(myEvent.eventValue && myEvent.eventName && myEvent.eventName == "unlockVideo"){\n' +
    '	var wyclubToken = null;\n' +
    '	if(req && req.params && req.params.wyclubToken){\n' +
    '		wyclubToken = req.params.wyclubToken;\n' +
    '	}\n' +
    '	sessionContext.read(req, function(err,currentSession){\n' +
    '		if(err !== null){\n' +
    '			ruleCallback(null, false);\n' +
    '		} else {\n' +
    '			if(currentSession &&' +
    '       currentSession.application &&' +
    '       currentSession.application._id &&' +
    '       currentSession.application._id == "simpleui123456789123456789123456" &&' +
    '       currentSession.profile &&' +
    '       system.getAgeFromDate(currentSession.profile.birthdate) > 18){\n' +
    '				myEvent.eventValue = JSON.parse(myEvent.eventValue);\n' +
    '				var where = {wyclubToken: myEvent.eventValue.targetedSession}; \n' +
    '				Core.repository.session.read(where, function(err,targetedSession){\n' +
    '					if(targetedSession &&' +
    '           targetedSession._id &&' +
    '           targetedSession.application &&' +
    '           targetedSession.application._id){\n' +
    '						Core.eventBroker.publishChannel(targetedSession.application._id,' +
    '           {' +
    '            \'session\': targetedSession._id,' +
    '            \'event\': {' +
    '              eventName:"unlockVideo",' +
    '              eventValue: {' +
    '                profileName: myEvent.eventValue.profileName' +
    '                }' +
    '              },' +
    '            \'otherInformations\': {}' +
    '           });\n' +
    '						ruleCallback(null, true);\n' +
    '					} else {\n' +
    '						ruleCallback(null, false);\n' +
    '					}\n' +
    '				});\n' +
    '			} else {\n' +
    '				ruleCallback(null, false);\n' +
    '			}\n' +
    '		}\n' +
    '	});	\n' +
    '} else {\n' +
    '	ruleCallback(null, true);\n' +
    '}',
    rules: [{_id:tools.generatePublicKey(32), webservice: 'core:event:post' }]
  },
  rule_swipeTo: {
    _id: tools.generatePublicKey(32),
    type: 'sync',
    label: 'swipeTo',
    sourcecode: 'var myEvent = {};\n' +
    'myEvent.eventName = req.body.eventName;\n' +
    'myEvent.eventValue = req.body.eventValue;\n' +
    'if (myEvent.eventValue && myEvent.eventName && myEvent.eventName === \'swipeTo\') {\n' +
    '  Core.log(\'Swipe To\'.yellow);\n' +
    '  var wyclubToken = null;\n' +
    '  if (req && req.params && req.params.wyclubToken) {\n' +
    '    wyclubToken = req.params.wyclubToken;\n' +
    '  }\n' +
    '  sessionContext.read(req, function (err, currentSession) {\n' +
    '    if (err !== null) {\n' +
    '      ruleCallback(err, false);\n' +
    '    } else {\n' +
    '      if (currentSession &&' +
    '         currentSession.application &&' +
    '         currentSession.application._id &&' +
    '         currentSession.application._id === \'simpleui123456789123456789123456\') {\n' +
    '        var swipe = JSON.parse(myEvent.eventValue);\n' +
    '        if (typeof swipe === \'object\') {\n' +
    '          Core.repository.session.read({ wyclubToken: swipe.sessionTarget }, function (err, swipeToSession) {\n' +
    '            if (err !== null) {\n' +
    '              ruleCallback(err, false);\n' +
    '            } else {\n' +
    '              var mySession = system.clone(currentSession);\n' +
    '              Core.repository.session.createHalfSisterSession({\n' +
    '                applicationId: swipeToSession.application._id,\n' +
    '                session: mySession\n' +
    '              }, function (err, halfSisterSess) {\n' +
    '                if (err !== null) {\n' +
    '                  ruleCallback(err, false);\n' +
    '                } else {\n' +
    '                  swipeToSession.status = 0;\n' +
    '                  Core.repository.session.update({ session: swipeToSession },' +
    '                    function (err, swipeToSessionDisable) {\n' +
    '                    if (err !== null) {\n' +
    '                      ruleCallback(err, false);\n' +
    '                    }\n' +
    '                  });\n' +
    '                  halfSisterSess.deviceId = swipeToSession.device._id;\n' +
    '                  Core.repository.session.update({ session: halfSisterSess }, function (err, swipedSession) {\n' +
    '                    swipe.newSession = halfSisterSess._id;\n' +
    '                    myEvent.eventValue = JSON.stringify(swipe);\n' +
    '                    Core.eventBroker.publishChannel(swipeToSession.application._id, {\n' +
    '                      \'session\': swipeToSession._id,\n' +
    '                      \'event\': myEvent,\n' +
    '                      \'otherInformations\': {}\n' +
    '                    });\n' +
    '                    for (var i = 0; i < currentSession.subscriber.profiles.length; i++) {\n' +
    '                      if (currentSession.subscriber.profiles[i].label === \'Family\') {\n' +
    '                        currentSession.profile = currentSession.subscriber.profiles[i];\n' +
    '                        i = currentSession.subscriber.profiles.length;\n' +
    '                      }\n' +
    '                    }\n' +
    '                    var eventOriginSession = system.clone(myEvent);\n' +
    '                    if (currentSession.profile.label === \'Family\') {\n' +
    '                      eventOriginSession.eventValue = JSON.stringify({' +
    '                       \'myProfile\': currentSession.profile._id ' +
    '                      });\n' +
    '                      Core.eventBroker.publishChannel(currentSession.application._id, {\n' +
    '                        \'session\': wyclubToken,\n' +
    '                        \'event\': eventOriginSession,\n' +
    '                        \'otherInformations\': {}\n' +
    '                      });\n' +
    '                    } else {\n' +
    '                      ruleCallback(\'No Profile Family for this sub\', false);\n' +
    '                    }\n' +
    '                  });\n' +
    '                }\n' +
    '              });\n' +
    '            }\n' +
    '          });\n' +
    '        } else {\n' +
    '          ruleCallback(null, false);\n' +
    '        }\n' +
    '      } else {\n' +
    '        ruleCallback(null, true);\n' +
    '      }\n' +
    '    }\n' +
    '  });\n' +
    '} else {\n' +
    '  ruleCallback(null, true);\n' +
    '}',
    rules: [{_id:tools.generatePublicKey(32), webservice: 'core:event:post' }]
  },
  rule_swipeFrom: {
    _id: tools.generatePublicKey(32),
    type: 'sync',
    label: 'swipeFrom',
    sourcecode: 'var myEvent = {};\n' +
    'myEvent = {};\n' +
    'myEvent.eventName = req.body.eventName;\n' +
    'myEvent.eventValue = req.body.eventValue;\n' +
    'if(myEvent.eventValue && myEvent.eventName && myEvent.eventName == "swipeFrom"){\n' +
    '  //Core.log("Swipe From".yellow);\n' +
    '  var wyclubToken = null;\n' +
    '  if(req && req.params && req.params.wyclubToken){\n' +
    '      wyclubToken = req.params.wyclubToken;\n' +
    '  }\n' +
    '  sessionContext.read(req, function(err,currentSession){\n' +
    '    if(err !== null){\n' +
    '        ruleCallback(err, false);\n' +
    '    } else {\n' +
    '      if(currentSession &&' +
    '       currentSession.application &&' +
    '       currentSession.application._id &&' +
    '       currentSession.application._id == "simpleui123456789123456789123456"){\n' +
    '        var swipe = JSON.parse(myEvent.eventValue);\n' +
    '        if(typeof swipe == \'object\') {\n' +
    '          Core.repository.session.read({wyclubToken: swipe.sessionOrigin},' +
    '            function(err,swipeFromSession){\n' +
    '              if(err !== null){\n' +
    '                  ruleCallback(err,false);\n' +
    '              } else {\n' +
    '                  swipeFromSession.status = 0;\n' +
    '                  Core.repository.session.update({session: swipeFromSession},' +
    '                    function(err, swipeFromSessionDisable){\n' +
    '                      if(err !== null){\n' +
    '                          ruleCallback(err,false);\n' +
    '                      } else {\n' +
    '                          var mySession = system.clone(currentSession);\n' +
    '                          Core.repository.session.createHalfSisterSession(' +
    '                             {' +
    '                               applicationId:swipeFromSession.application._id,' +
    '                               session: mySession' +
    '                             },' +
    '                             function(err,halfSisterSess){\n' +
    '                              if(err !== null) {\n' +
    '                                  ruleCallback(err,false);\n' +
    '                              } else {\n' +
    '                                  halfSisterSess.device = swipeFromSession.device;\n' +
    '                                  Core.repository.session.update({session: halfSisterSess},' +
    '                                   function(err, swipedSession){\n' +
    '                                      swipe.newSession = halfSisterSess._id;\n' +
    '                                      swipe.myProfile = currentSession.profile._id;\n' +
    '                                      myEvent.eventValue = JSON.stringify(swipe);\n' +
    '                                      Core.eventBroker.publishChannel(' +
    '                                       swipeFromSession.application._id,' +
    '                                       {' +
    '                                        \'session\': swipeFromSession._id,' +
    '                                        \'event\': myEvent,' +
    '                                        \'otherInformations\': {}' +
    '                                       }' +
    '                                      );\n' +
    '                                      for( var i = 0; i < currentSession.subscriber.profiles.length; i++){\n' +
    '                                          if(currentSession.subscriber.profiles[i].label == "Family"){\n' +
    '                                              currentSession.profile = currentSession.subscriber.profiles[i];\n' +
    '                                              i = currentSession.subscriber.profiles.length;\n' +
    '                                          }\n' +
    '                                      }\n' +
    '                                      var eventOriginSession = system.clone(myEvent);\n' +
    '                                      if(currentSession.profile.label == "Family"){\n' +
    '                                        eventOriginSession.eventValue = JSON.stringify(' +
    '                                          {"myProfile":currentSession.profile._id}' +
    '                                        );\n' +
    '                                        Core.eventBroker.publishChannel(currentSession.application._id,' +
    '                                         {' +
    '                                           \'session\': wyclubToken,' +
    '                                           \'event\': eventOriginSession,' +
    '                                           \'otherInformations\': {}' +
    '                                         });\n' +
    '                                        ruleCallback();\n' +
    '                                      } else {\n' +
    '                                          ruleCallback("No Profile Family for this sub",false);\n' +
    '                                      }\n' +
    '                                  });\n' +
    '                              }\n' +
    '                          });\n' +
    '                      }\n' +
    '                  });\n' +
    '              }\n' +
    '          });\n' +
    '        } else {\n' +
    '            ruleCallback(null,false);\n' +
    '        }\n' +
    '      } else {\n' +
    '          ruleCallback(null, true);\n' +
    '      }\n' +
    '    }\n' +
    '  });\n' +
    '} else {\n' +
    ' ruleCallback(null, true);\n' +
    '}',
    rules: [{_id:tools.generatePublicKey(32), webservice: 'core:event:post' }]
  },
  rule_recoverContent: {
    _id: tools.generatePublicKey(32),
    type: 'sync',
    label: 'recoverContent',
    sourcecode: 'var myEvent = {};\n' +
    'myEvent.eventName = req.body.eventName;\n' +
    'myEvent.eventValue = req.body.eventValue;\n' +
    'if(myEvent.eventValue && myEvent.eventName && myEvent.eventName == "recoverContent"){\n' +
    '    Core.log("Recover content".yellow);\n' +
    '    var wyclubToken = null;\n' +
    '    if(req && req.params && req.params.wyclubToken){\n' +
    '        wyclubToken = req.params.wyclubToken;\n' +
    '    }\n' +
    '    sessionContext.read(req, function(err,currentSession){\n' +
    '        if(err !== null){\n' +
    '            ruleCallback(err, false);\n' +
    '        } else {\n' +
    '            if(currentSession &&' +
    '             currentSession.application &&' +
    '             currentSession.application._id &&' +
    '             currentSession.application._id == "simpleui123456789123456789123456"){\n' +
    '                var swipe = JSON.parse(myEvent.eventValue);\n' +
    '                if(typeof swipe == "object") {\n' +
    '                    Core.repository.session.read({wyclubToken: swipe.sessionTarget},function(err,targetSess){\n' +
    '                        if(err !== null) {\n' +
    '                            ruleCallback(err,false);\n' +
    '                        } else {\n' +
    '                            Core.eventBroker.publishChannel(targetSess.application._id,' +
    '                             {\'session\': targetSess._id, \'event\': myEvent,\'otherInformations\': {}});\n' +
    '                            ruleCallback();\n' +
    '                        }\n' +
    '                    });\n' +
    '                }\n' +
    '            } else {\n' +
    '                ruleCallback(null, true);\n' +
    '            }\n' +
    '        }\n' +
    '    });\n' +
    '} else {\n' +
    '    ruleCallback(null, true);\n' +
    '}',
    rules: [{_id:tools.generatePublicKey(32), webservice: 'core:event:post' }]
  },
  rule_maxNumberOfDevices: {
    _id: '7KGq0kPZusxPkr3q6zOdZ6Sc81MMo7dw',
    type: 'sync',
    label: 'maxNumberOfDevices',
    description: 'Max number of device : {{x}}',
    schema: {
      type: 'object',
      properties: {
        x: {
          type: 'number',
          required: true
        }
      }
    },
    sourcecode: 'var uuid = null;\n' +
    'var subscriberId = null;\n' +
    'var applicationId = null;\n' +
    'var x = {{x}};\n' +
    'if(req && req.body && req.body.uuid){\n' +
    '  uuid = req.body.uuid;\n' +
    '}\n' +
    'if(req && req.body && req.body.subscriberId){\n' +
    '  subscriberId = req.body.subscriberId;\n' +
    '}\n' +
    'if(req && req.body && req.params.applicationId){\n' +
    '  applicationId = req.params.applicationId;\n' +
    '}\n' +
    'if(uuid !== null && subscriberId !== null && applicationId !== null) {\n' +
    '   Core.repository.subscriber.read({subscriberId: subscriberId}, function(err, subscriber){\n' +
    '     if(err !== null){\n' +
    '       ruleCallback(err, true);\n' +
    '     } else {\n' +
    '           if(subscriber !== undefined && subscriber.deviceInstances !== undefined) {\n' +
    '               var device = underscore.where(subscriber.devices, {\'uuid\':uuid});\n ' +
    '               if (device.length > 0) {\n' +
    '                   var deviceId = device[0]._id;\n' +
    '                   var deviceInstanceExists = underscore.where(subscriber.deviceInstances,' +
    '                   {applicationId: applicationId, deviceId: deviceId}).length;\n' +
    '                   if (deviceInstanceExists === 0) {\n' +
    '                       var deviceInstance = underscore.where(subscriber.deviceInstances,' +
    '                       {applicationId: applicationId});\n' +
    '                       if(deviceInstance.length >= x) {\n' +
    '                         ruleCallback(\'Max devices for this subscriber\', false);\n' +
    '                       } else {\n' +
    '                         ruleCallback(null, true);\n' +
    '                       }\n' +
    '                   } else {\n' +
    '                     ruleCallback(null, true);\n' +
    '                   }\n' +
    '               } else { \n' +
    '                   var deviceInstance = underscore.where(subscriber.deviceInstances,' +
    '                  {applicationId: applicationId});\n' +
    '                   if(deviceInstance.length >= x) {\n' +
    '                       ruleCallback(\'Max devices for this subscriber\', false);\n' +
    '                   } else {\n' +
    '                       ruleCallback(null, true);\n' +
    '                   }\n' +
    '               }\n' +
    '            } else {\n' +
    '               ruleCallback(null, true);\n' +
    '            }\n' +
    '      }\n' +
    '   });\n' +
    '} else if(uuid !== null && applicationId !== null) {\n' +
    '   Core.repository.subscriber.readCustom({\'devices.uuid\': uuid}, function(err, subscriber){\n' +
    '     if(err !== null){\n' +
    '       ruleCallback(err, true);\n' +
    '     } else {\n' +
    '           if(subscriber !== undefined && subscriber.deviceInstances !== undefined) {\n' +
    '               var device = underscore.where(subscriber.devices, {\'uuid\':uuid});\n ' +
    '               var deviceId = device[0]._id;\n' +
    '                   var deviceInstanceExists = underscore.where(subscriber.deviceInstances,' +
    '                   {applicationId: applicationId, deviceId: deviceId}).length;\n' +
    '                   if (deviceInstanceExists === 0) {\n' +
    '                       var deviceInstance = underscore.where(subscriber.deviceInstances,' +
    '                       {applicationId: applicationId});\n' +
    '                       if(deviceInstance.length >= x) {\n' +
    '                         ruleCallback(\'Max devices for this subscriber\', false);\n' +
    '                       } else {\n' +
    '                         ruleCallback(null, true);\n' +
    '                       }\n' +
    '                   } else {\n' +
    '                     ruleCallback(null, true);\n' +
    '                   }\n' +
    '            } else {\n' +
    '               ruleCallback(null, true);\n' +
    '            }\n' +
    '      }\n' +
    '   });\n' +
    '} else {\n' +
    '   ruleCallback(null, true);\n' +
    '}\n',
    rules: [{
      values: { x: 4 },
      webservice: 'core:session:post',
      _id:'123456789'
    }]
  },
  rule_maxNumberOfSessions: {
    _id: 'u0MKTeLbsNYd0AUAsF4vFhTJiq1mRcNL',
    type: 'sync',
    label: 'maxNumberOfSessions',
    schema: {
      type: 'object',
      properties: {
        x: {
          type: 'number',
          required: true
        }
      }
    },
    sourcecode: 'var uuId = null;' +
    'var subscriberId = null;' +
    'var applicationId = null;' +
    'var x = {{x}};\n' +
    'if(req && req.body && req.body.subscriberId){\n' +
    '   subscriberId = req.body.subscriberId;\n' +
    '}\n' +
    'if(req && req.params && req.params.applicationId){\n' +
    '   applicationId = req.params.applicationId;\n' +
    '}\n' +
    'if(req && req.body && req.body.uuid){\n' +
    '   uuId = req.body.uuid;\n' +
    '}\n' +
    'if(applicationId !== undefined &&' +
    ' applicationId !== null &&' +
    ' applicationId === \'simpleui123456789123456789123456\') {\n' +
    'if (uuId !== null && subscriberId === null) {\n' +
    '\tCore.query.mongodbStatic.subscriber.readQuery({\'devices.uuid\': uuId}, function(err, subscriber) {\n' +
    '       if(err === null) {\n' +
    '           subscriberId = subscriber._id;\n' +
    '       }\n' +
    '       if(subscriberId !== undefined &&' +
    '         applicationId !== undefined &&' +
    '         subscriberId !== null &&' +
    '         applicationId !== null) {' + '\t' +
    '         Core.query.mongodbSession.session.readCustom({status: 1, applicationId: applicationId,' +
    '           subscriberId: subscriberId}, function(err, session) {\n' +
    '               if(err !== null) {' +
    '                 ruleCallback(null, true);\n' +
    '               } else {\n' +
    '                   if(session.length >= x) {\n' +
    '                       ruleCallback(\'Max session\', false);\n' +
    '                   } else {\n' +
    '                       ruleCallback(null, true);\n' +
    '                   }\n' +
    '               }\n' +
    '           });\n' +
    '       } else {' +
    '         ruleCallback(null, true);\n' +
    '       }\n' +
    '   });\n' +
    '} else if (uuId !== null && subscriberId !== null) {\n' +
    '   if(subscriberId !== undefined &&' +
    '     applicationId !== undefined &&' +
    '     subscriberId !== null &&' +
    '     applicationId !== null) {' +
    '     Core.query.mongodbSession.session.readCustom({status: 1, applicationId: applicationId,' +
    '       subscriberId: subscriberId}, function(err, session) {\n' +
    '           if(err !== null) {' +
    '             ruleCallback(null, true);\n' +
    '           } else {\n' +
    '               if(session.length >= x) {\n' +
    '                   ruleCallback(\'Max session\', false);\n' +
    '               } else {\n' +
    '                   ruleCallback(null, true);\n' +
    '               }\n' +
    '           }\n' +
    '       });\n' +
    '   } else {' + '       ruleCallback(null, true);\n' +
    '   }\n' +
    '} else {' + '   ruleCallback(null, true);' + '}\n' +
    '} else {\n' +
    '   ruleCallback(null, true);\n' +
    '}\n',
    rules: [{
      webservice: 'core:session:post',
      _id:tools.generatePublicKey(32),
      values: { x: 50 }
    }]
  },
  rule_setTagToTest: {
    _id: tools.generatePublicKey(32),
    type: 'sync',
    label: 'setTagToTest',
    schema: {
      type: 'object',
      properties: {
        x: {
          type: 'string',
          required: true
        }
      }
    },
    sourcecode: '' + 'var wyclubToken = null;\n' +
    'if(req && req.params && req.params.wyclubToken){\n' +
    '   wyclubToken = req.params.wyclubToken;\n' +
    '}\n' +
    'sessionContext.read(req, function(err, currentSession){\n' +
    '   if(err !== null){\n' +
    '       ruleCallback(err, true);\n' +
    '   } else {\n' +
    '       if(currentSession && currentSession._id){\n' +
    '           Core.repository.session.setTags(' +
    '             {wyclubToken: currentSession._id, tags:\xa0{tag: [\'{{x}}\']}}, function(){}' +
    '           );\n' +
    '       }\n' +
    '       ruleCallback(null, true);\n' +
    '   }\n' +
    '});\n',
    rules: []
  },
  rule_contactSession: {
    _id: 'aaaaaaaaaaaaaaaaaaaaaaa',
    type: 'async',
    label: 'contactSession',
    sourcecode: 'var myEvent = {};\n' +
    'myEvent.eventName = req.body.eventName;\n' +
    'myEvent.eventValue = req.body.eventValue;\n' +
    'try {\n' +
    '    myEvent.eventValue = JSON.parse(myEvent.eventValue);\n' +
    '} catch(error){\n' +
    '    //ruleCallback(null, false);\n' +
    '}\n' +
    'if(myEvent.eventValue && myEvent.eventName && myEvent.eventName == "contactSession"){\n' +
    '    console.log(Core.colors.green("contactSession"));\n' +
    '	sessionContext.read(req, function(err,currentSession){\n' +
    '        console.log("session source trouv\xe9e".yellow, currentSession);\n' +
    '		if(err !== null){\n' +
    '            console.log("error".red, err);\n' +
    '			ruleCallback(null, false);\n' +
    '		} else {\n' +
    '            console.log(Core.colors.green("no error"));\n' +
    '            var _ = require(\'underscore\');\n' +
    '            if(_.isArray(myEvent.eventValue.targetedSession) &&' +
    '             myEvent.eventValue.targetedSession.length > 0){\n' +
    '                async.eachSeries(myEvent.eventValue.targetedSession, function(session, cb){\n' +
    '                    var where = {};\n' +
    '                    if(currentSession.subscriber){\n' +
    '                        where.subscriberId = currentSession.subscriber._id;\n' +
    '                    }\n' +
    '                    where.wyclubToken = session;\n' +
    '                    Core.repository.session.read(where, function(err,targetedSessions){\n' +
    '                        if(err){\n' +
    '                            console.log("error".red, err);\n' +
    '                            cb(null, false);\n' +
    '                        } else {\n' +
    '                            console.log(Core.colors.green("no error"));\n' +
    '                            if(targetedSessions && !targetedSessions[0]){\n' +
    '                                targetedSessions = [targetedSessions];\n' +
    '                            }\n' +
    '                            async.eachSeries(targetedSessions, function(targetedSession, cb){\n' +
    '                                console.log("session target trouv\xe9e".yellow, targetedSession);\n' +
    '                                var sessionOk = true;\n' +
    '                                if(myEvent.eventValue.where && myEvent.eventValue.where.tags){\n' +
    '                                }\n' +
    '                                if(sessionOk){\n' +
    '                                    console.log("event launched".yellow);\n' +
    '                                    Core.eventBroker.publishChannel(targetedSession.application._id,' +
    '                                     {' +
    '                                       \'session\': targetedSession._id,' +
    '                                       \'event\': myEvent.eventValue.message,' +
    '                                       \'otherInformations\': {}' +
    '                                     });\n' +
    '                                }\n' +
    '                                cb(null);\n' +
    '                            }, function(){\n' +
    '                                cb(null, true);\n' +
    '                            });\n' +
    '                        }\n' +
    '                    });\n' +
    '                }, function(err){\n' +
    '                    ruleCallback(err, true);\n' +
    '                });\n' +
    '            } else {\n' +
    '                var where = {};\n' +
    '                if(currentSession.subscriber){\n' +
    '                    where.subscriberId = currentSession.subscriber._id;\n' +
    '                }\n' +
    '                console.log(myEvent);\n' +
    '                if(myEvent.eventValue.targetedSession){\n' +
    '                    where.wyclubToken = myEvent.eventValue.targetedSession;\n' +
    '                } else if (myEvent.eventValue.where) {\n' +
    '                    if(myEvent.eventValue.where.sameProfile){\n' +
    '                        where.profileId = currentSession.profile._id;\n' +
    '                    }\n' +
    '                    if(myEvent.eventValue.where.sameDevice){\n' +
    '                        where.deviceId = currentSession.device._id;\n' +
    '                    }\n' +
    '                }\n' +
    '                console.log("selector".yellow, where);\n' +
    '                Core.repository.session.read(where, function(err,targetedSessions){\n' +
    '                    if(err){\n' +
    '                        console.log("error".red, err);\n' +
    '                        ruleCallback(null, false);\n' +
    '                    } else {\n' +
    '                        console.log("no error".green);\n' +
    '                        if(targetedSessions && !targetedSessions[0]){\n' +
    '                            targetedSessions = [targetedSessions];\n' +
    '                        }\n' +
    '                        async.eachSeries(targetedSessions, function(targetedSession, cb){\n' +
    '                            console.log("session target trouv\xe9e".yellow, targetedSession);\n' +
    '                            var sessionOk = true;\n' +
    '                            if(myEvent.eventValue.where && myEvent.eventValue.where.tags){\n' +
    '                            }\n' +
    '                            if(sessionOk){\n' +
    '                                console.log("event launched".yellow);\n' +
    '                                Core.eventBroker.publishChannel(targetedSession.application._id,' +
    '                                 {' +
    '                                   \'session\': targetedSession._id,' +
    '                                   \'event\': myEvent.eventValue.message,' +
    '                                   \'otherInformations\': {}' +
    '                                 });\n' +
    '                            }\n' +
    '                            cb(null);\n' +
    '                        }, function(){\n' +
    '                            ruleCallback(null, true);\n' +
    '                        });\n' +
    '                    }\n' +
    '                });\n' +
    '            }\n' +
    '		}\n' +
    '	});	\n' +
    '} else {\n' +
    '	ruleCallback(null, true);\n' +
    '}',
    rules: [{_id:tools.generatePublicKey(32), webservice: 'core:event:post' }]
  },
  rule_EPG_profile: {
    _id: tools.generatePublicKey(32),
    type: 'sync',
    label: 'epgProfile',
    schema: {
      type: 'object',
      properties: {
        bouquet_activated: {
          type: 'boolean',
          required: true
        },
        bouquet_operator: {
          type: 'string',
          required: true
        },
        bouquet_value: {
          type: 'string',
          required: true
        }
      }
    },
    sourcecode: '' + 'var wyclubToken = null;\n' +
    'if(req && req.params && req.params.wyclubToken){\n' +
    '   wyclubToken = req.params.wyclubToken;\n' +
    '}\n' +
    'sessionContext.read(req, function(err, currentSession){\n' +
    '   if(err !== null){\n' +
    '       ruleCallback(err, true);\n' +
    '   } else {\n' +
    '       if(currentSession && currentSession._id){\n' +
    '           Core.repository.session.setTags(' +
    '             {wyclubToken: currentSession._id, tags:\xa0{tag: [\'{{x}}\']}}, function(){}' +
    '           );\n' +
    '       }\n' +
    '       ruleCallback(null, true);\n' +
    '   }\n' +
    '});\n',
    rules: []
  }
};

module.exports = rule;