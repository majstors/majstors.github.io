/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

var config = {
  db: {
    create: { session: 'none' },
    clean: { session: 'none' },
    indexes: {
      session: [{
        name: '_id+status',
        index: {
          _id: 1,
          status: 1
        },
        params: {}
      }]
    }
  }
};

module.exports = config;