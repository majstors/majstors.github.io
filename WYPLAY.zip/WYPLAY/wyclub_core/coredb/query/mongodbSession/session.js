/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* global tools:true*/

/**
 * MongoDB Session Queries
 *
 * */

var Mongodb = require('../../../lib/mongodbQuery');
var tools = require('../../../lib/tools');
var Session = function () {
  'use strict';
  this.setDefaultCollection('session');
};
Session.prototype = Object.create(Mongodb.prototype);

Session.prototype.exists = function (params, callback) {
  'use strict';
  var self = this;
  self.sessionClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      var where = {
          '_id': params._id,
          'status': 1
        };
      collection.find(where, { 'limit': 1 }).count(true, function (err, count) {
        if (err !== null) {
          callback(err);
        } else {
          callback(null, Boolean(count));
        }
        self.sessionClient.close();
      });
    }
  });
};

Session.prototype.getSessionsOfSubscriber = function (params, callback) {
  'use strict';
  var self = this;
  this.sessionClient.getCollection(self.collection, function (err, collection) {
    collection.find(params).toArray(function (err, sessions) {
      if (err !== null) {
        callback(err);
      } else {
        callback(null, sessions);
      }
    });
  });
};

/**
 * # Description
 * read the current session.
 *
 * @param {Object} params (contain wyclubToken)
 * @return {Object} session
 */
Session.prototype.read = function (params, callback) {
  'use strict';
  var self = this;
  self.sessionClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.findOne({
        _id: params._id,
        status: 1
      }, function (err, sessionDoc) {
        callback(err, sessionDoc);
        self.sessionClient.close();
      });
    }
  });
};

/**
 * # Description
 * read sessions by custom fields.
 *
 * @param {Object} params ()
 * @return {Object} session
 */
Session.prototype.readCustom = function (params, callback) {
  'use strict';
  var self = this;
  self.sessionClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.find(params).toArray(function (err, device) {
        if (err !== null) {
          callback(err);
          self.sessionClient.close();
        } else {
          callback(null, device);
          self.sessionClient.close();
        }
      });
    }
  });
};

/**
 * # Description
 * read the current session.
 *
 * @param {Object} params (contain wyclubToken)
 * @return {Object} session
 */
Session.prototype.readField = function (params, callback) {
  'use strict';
  var self = this;
  self.sessionClient.getCollection(self.collection, function (err, collection) {
    collection.findOne({
      _id: params._id,
      'status': 1
    }, function (err, sessionDoc) {
      callback(err, sessionDoc);
      self.sessionClient.close();
    });
  });
};

/**
 * # Description
 * create a session.
 *
 * @param {Object} params (contain session)
 * @return {Object} session
 */
Session.prototype.create = function (params, callback) {
  'use strict';
  var self = this;
  self.sessionClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.insert(params, { w: 1 }, function (err, sessionDB) {
        if (sessionDB !== null && sessionDB !== undefined && sessionDB[0] !== undefined) {
          callback(err, sessionDB[0]);
        } else {
          callback(err);
        }  //self.sessionClient.close();
      });
    }
  });
};

/**
 * # Description
 * update a session.
 *
 * @param {Object} params (contain session)
 * @return {Object} session
 */
Session.prototype.update = function (params, callback) {
  'use strict';
  var self = this;
  self.sessionClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      if (params.session !== undefined) {
        var sessionWithoutId = tools.clone(params.session);
        delete sessionWithoutId._id;
        collection.findAndModify({ _id: params.session._id }, [], { '$set': sessionWithoutId }, {
          new: true,
          w: 1
        }, function (err, sessionDB) {
          if (sessionDB !== null && sessionDB !== undefined) {
            callback(err, sessionDB);
          } else {
            callback(err);
          }
          self.sessionClient.close();
        });
      } else {
        callback('NO_SESSION', null);
      }
    }
  });
};

/**
 * # Description
 * delete a session.
 *
 * @param {Object} params (contain session)
 * @return {Object} session
 */
Session.prototype.delete = function (params, callback) {
  'use strict';
  var self = this;
  self.sessionClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.findOne({ _id: params._id }, function (err, sessionDB) {
        if (err !== null) {
          callback(err);
        } else {
          if (sessionDB === null) {
            callback(err);
          } else {
            collection.remove({ _id: params._id }, { w: 1 }, function (err, nbDeleted) {
              if (err !== null) {
                callback(err);
              } else {
                if (nbDeleted > 0) {
                  callback(null, sessionDB);
                } else {
                  callback(err);
                }
              }
            });
          }
        }
        self.sessionClient.close();
      });
    }
  });
};

/**
 * # Description
 * read the current session twin sisters.
 *
 * @param {Object} params (contain wyclubToken)
 * @return {Object} session
 */
Session.prototype.readTwinSisterSessions = function (params, callback) {
  'use strict';
  var self = this;
  self.sessionClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      var sessionDB = params.session;
      if (sessionDB !== null &&
        sessionDB !== undefined &&
        sessionDB.application !== undefined &&
        sessionDB.application._id !== undefined) {
        var applicationId = sessionDB.application._id;
        var subscriberId = null;
        if (sessionDB.subscriber !== undefined &&
          sessionDB.subscriber !== null &&
          sessionDB.subscriber._id !== undefined) {
          subscriberId = sessionDB.subscriber._id;
        }
        collection.find({
          _id: { '$ne': sessionDB._id },
          'status': 1,
          'applicationId': applicationId,
          'subscriberId': subscriberId
        }).toArray(function (err, twinSisterSessions) {
          callback(err, twinSisterSessions);
          self.sessionClient.close();
        });
      } else {
        callback(null, []);
        self.sessionClient.close();
      }
    }
  });
};

/**
 * # Description
 * read the current session half sisters.
 *
 * @param {Object} params (contain wyclubToken)
 * @return {Object} session
 */
Session.prototype.readHalfSisterSessions = function (sessionDB, callback) {
  'use strict';
  var self = this;
  self.sessionClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      if (sessionDB !== null && sessionDB !== undefined && sessionDB.subscriber !== undefined) {
        var profileId = null;
        if (sessionDB.profile !== undefined) {
          profileId = sessionDB.profile._id;
        }
        var subscriberId = null;
        if (sessionDB.subscriber !== undefined) {
          subscriberId = sessionDB.subscriber._id;
        }

        collection.find({
          _id: { '$ne': sessionDB._id },
          'status': 1,
          'profileId': profileId,
          'subscriberId': subscriberId
        }).toArray(function (err, halfSisterSessions) {
          callback(err, halfSisterSessions);
          self.sessionClient.close();
        });
      } else {
        callback(null, []);
        self.sessionClient.close();
      }
    }
  });
};

/**
 * # Description
 * read the current session siameze sisters.
 *
 * @param {Object} params (contain wyclubToken)
 * @return {Object} session
 */
Session.prototype.readSiameseSessions = function (sessionDB, callback) {
  'use strict';
  var self = this;
  self.sessionClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      if (sessionDB !== null &&
        sessionDB !== undefined &&
        sessionDB.application !== undefined &&
        sessionDB.application._id !== undefined) {
        var applicationId = sessionDB.application._id;
        var profileId = null;
        if (sessionDB.profile !== undefined &&
          sessionDB.profile !== null &&
          sessionDB.profile._id !== undefined) {
          profileId = sessionDB.profile._id;
        }
        var subscriberId = null;
        if (sessionDB.subscriber !== undefined &&
          sessionDB.subscriber !== null &&
          sessionDB.subscriber._id !== undefined) {
          subscriberId = sessionDB.subscriber._id;
        }
        collection.find({
          _id: { '$ne': sessionDB._id },
          'status': 1,
          'applicationId': applicationId,
          'profileId': profileId,
          'subscriberId': subscriberId
        }).toArray(function (err, siameseSessions) {
          callback(err, siameseSessions);
          self.sessionClient.close();
        });
      } else {
        callback(null, []);
        self.sessionClient.close();
      }
    }
  });
};

/**
 * # Description
 * read the current session siameze sisters.
 *
 * @param {Object} params (contain wyclubToken)
 * @return {Object} session
 */
Session.prototype.deleteSiamezeSessions = function (params, callback) {
  'use strict';
  var self = this;
  self.sessionClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err, null);
    } else {
      var sessionDB = params;
      if (sessionDB !== null &&
        sessionDB !== undefined &&
        sessionDB.application !== undefined &&
        sessionDB.application._id !== undefined) {
        var applicationId = sessionDB.application._id;
        var profileId = null;
        if (sessionDB.profile !== undefined &&
          sessionDB.profile !== null &&
          sessionDB.profile._id !== undefined) {
          profileId = sessionDB.profile._id;
        }
        var subscriberId = null;
        if (sessionDB.subscriber !== undefined &&
          sessionDB.subscriber !== null &&
          sessionDB.subscriber._id !== undefined) {
          subscriberId = sessionDB.subscriber._id;
        }
        collection.remove({
          _id: { '$ne': params._id },
          'status': 1,
          'applicationId': applicationId,
          'profileId': profileId,
          'subscriberId': subscriberId
        }, { w: 1 }, function (err, siameseSessions) {
          callback(err, siameseSessions);
          self.sessionClient.close();
        });
      } else {
        callback(null, []);
        self.sessionClient.close();
      }
    }
  });
};

Session.prototype.clean = function (callback) {
  'use strict';
  var self = this;
  self.sessionClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.remove({}, { w: 1 }, function (err, document) {
        if (err !== null) {
          callback(err);
          self.sessionClient.close();
        } else {
          callback(null, document);
          self.sessionClient.close();
        }
      });
    }
  });
};

Session.prototype.restore = function (callback) {
  'use strict';
  var self = this;
  self.sessionClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err, false);
    } else {
      collection.drop(function (err) {
        if (err !== null && err.errmsg !== 'ns not found') {
          callback(err, false);
          self.sessionClient.close();
        } else {
          self.sessionClient.getDatabase(function (err, db) {
            if (err !== null) {
              callback(err, false);
            } else {
              db.createCollection(self.collection, function (err) {
                if (err !== null) {
                  self.sessionClient.close();
                  callback(err, false);
                } else {
                  self.sessionClient.close();
                  callback(err, true);
                }
              });
            }
          });
        }
      });
    }
  });
};

module.exports = new Session();