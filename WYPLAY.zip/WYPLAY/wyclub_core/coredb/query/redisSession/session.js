/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

//redis query for sessions

var Redis = require('../../../lib/redisQuery');
var Session = function () {
};
Session.prototype = Object.create(Redis.prototype);

/**
 *  Redis
 *  =====
 *  setCurrentContent
 *  readCurrentContent
 *
 */
/**
 * # Description
 * Output the requested CurrentContent
 *
 * @param String wyclubToken
 * @return {Object} current content
 *
 */
Session.prototype.readCurrentContent = function (params, callback) {
  'use strict';
  this.sessionClient.hget('sessionCurrentContent', params.wyclubToken, function (err, currentContent) {
    if (currentContent !== undefined && currentContent !== null) {
      callback(err, JSON.parse(currentContent));
    } else {
      callback('NO_CURRENT_CONTENT', null);
    }
  });
};

/**
 * # Description
 * Output the requested CurrentContent
 *
 * @param String wyclubToken
 * @return {Object} current content
 *
 */
Session.prototype.setCurrentContent = function (params, callback) {
  'use strict';
  var contentObject = {
    content: params.content,
    origin: params.origin,
    info: params.info
  };
  this.sessionClient.hset('sessionCurrentContent', params.wyclubToken, JSON.stringify(contentObject), function (err, result) {
    //TODO après update this.sessionClient.retourne 0 et non 1
    if (result === 1) {
      callback(null, contentObject);
    } else {
      callback(err, contentObject);
    }
  });
};

/**
 * # Description
 * Output the tags of a session
 *
 * @param String wyclubToken
 * @return {Object} current tags
 *
 */
Session.prototype.readTags = function (params, callback) {
  'use strict';
  this.sessionClient.hget('sessionTag', params.wyclubToken, function (err, tags) {
    callback(err, tags);
  });
};

/**
 * # Description
 * set the tags of a session
 *
 * @param String wyclubToken, tags
 * @return {Object} current tags
 *
 */
Session.prototype.setTags = function (params, callback) {
  'use strict';
  this.sessionClient.hset('sessionTag', params.wyclubToken, JSON.stringify(params.tags), function (err, result) {
    callback(err, result);
  });
};

/**
 * # Description
 * add tags to a session
 *
 * @param String wyclubToken, tags
 * @return {Object} current tags
 *
 */
Session.prototype.addTags = function (params, callback) {
  'use strict';
  var underscore = require('underscore');
  var self = this;
  this.sessionClient.hget('sessionTag', params.wyclubToken, function (err, tags) {
    if (err) {
      callback(err);
    } else {
      if (!tags) {
        tags = {tag: []};
      } else {
        tags = JSON.parse(tags);
      }
      tags.tag = underscore.union(tags.tag, params.tags.tag);
      self.sessionClient.hset('sessionTag', params.wyclubToken, JSON.stringify(tags), function (err, result) {
        callback(err, result);
      });
    }
  });
};

/**
 * # Description
 * Output the session binded with an access token
 *
 * @param {object} contain accessToken
 * @return String session id
 *
 */
Session.prototype.readAccessToken = function (params, callback) {
  'use strict';
  this.sessionClient.hget('sessionAccessToken', params.accessToken, function (err, result) {
    callback(err, result);
  });
};

/**
 * # Description
 * set the tags of a session
 *
 * @param {object} contain wyclubToken, accessToken
 * @return String accessToken
 *
 */
Session.prototype.createAccessToken = function (params, callback) {
  'use strict';
  this.sessionClient.hset('sessionAccessToken', params.accessToken, params.wyclubToken, function (err, result) {
    if (result === 1) {
      callback(null, params.accessToken);
    } else {
      callback(err, result);
    }
  });
};

/**
 * # Description
 * clean sessionAccessToken
 *
 * @param String id, label
 * @return {Object} tag
 *
 */
Session.prototype.clean = function (callback) {
  'use strict';
  var self = this;
  this.sessionClient.del('session', function (err) {
    if (err !== null) {
      callback('error');
    } else {
      self.sessionClient.del('sessionTag', function (err) {
        if (err !== null) {
          callback('error');
        } else {
          self.sessionClient.del('sessionCurrentContent', function (err) {
            if (err !== null) {
              callback('error');
            } else {
              self.sessionClient.del('sessionAccessToken', function (err, result) {
                if (err !== null) {
                  callback('error');
                } else {
                  callback(null, result);
                }
              });
            }
          });
        }
      });
    }
  });
}

/**
 * # Description
 * Cache a session to Redis
 *
 * @param {object} contain wyclubToken
 * @return String accessToken
 *
 */
Session.prototype.writeSession = function (params, callback) {
  'use strict';
  this.sessionClient.hset('session', params.wyclubToken, params.session, function (err, result) {
    if (result === 1) {
      callback(null, params.wyclubToken);
    } else {
      callback(err, result);
    }
  });
};

/**
 * # Description
 * Delete a sesssion in Redis cache
 *
 * @param {object} contain wyclubToken
 * @return null or err
 *
 */
Session.prototype.deleteSession = function (params, callback) {
  'use strict';
  this.sessionClient.hdel('session', params.wyclubToken, function (err) {
    if (err) {
      callback(err);
    } else {
      callback(null);
    }
  });
};

/**
 * # Description
 * Read a sesssion in Redis cache
 *
 * @param {object} contain wyclubToken
 * @return String accessToken
 *
 */
Session.prototype.readSession = function (params, callback) {
  'use strict';

  this.sessionClient.hget('session', params.wyclubToken, function (err, result) {
    if (err) {
      callback(err);
    } else {
      if (result && result !== "undefined") {
        callback(null, JSON.parse(result));
      } else {
        callback(null, result);
      }
    }
  });
};

/**
 * # Description
 * Session exists in Redis cache
 *
 * @param {object} contain wyclubToken
 * @return Bool
 *
 */
Session.prototype.existsSession = function (params, callback) {
  'use strict';
  this.sessionClient.hexists('session', params.wyclubToken, function (err, result) {
    if (err) {
      callback(err);
    } else {
      if (result === 1) {
        callback(null, true);
      } else {
        callback(null, false);
      }
    }
  });
};
/**
 * # Description
 * Delete session from cache
 *
 * @param {object} contain wyclubToken
 * @return Bool
 *
 */
Session.prototype.delete = function (params, callback) {
  'use strict';
  this.sessionClient.del('session', params.wyclubToken, function (err, result) {
    if (err) {
      callback(err);
    } else {
      if (result === 1) {
        callback(null, true);
      } else {
        callback(null, false);
      }
    }
  });
};
module.exports = new Session();