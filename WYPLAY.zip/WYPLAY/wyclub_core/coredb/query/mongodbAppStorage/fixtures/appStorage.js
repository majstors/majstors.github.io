/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
*/

/* jshint -W106*/
/* global tools:true*/

var appStorage = {
  appStorage_subProfilePremiumAndapp1: {
    _id: tools.generatePublicKey(32),
    key: 'notification',
    value: {},
    optimisticLock: 1401701384253,
    subscriberId: 'XHPiMFOgAD0KzimPeitfH6WgJVJP6r1Z',
    profileId: 'xXx2K0zCsbYbOPRhLZHqa0g83h5uSmlh',
    applicationId: 'XHPiMdpchfugjthdjitfH6WgJVJP6r1Z'
  },
  appStorage_AS2subProfilePremiumAndapp1: {
    _id: tools.generatePublicKey(32),
    key: 'connect',
    value: { eventName: 'newConnect' },
    optimisticLock: new Date().getTime(),
    subscriberId: 'XHPiMFOgAD0KzimPeitfH6WgJVJP6r1Z',
    profileId: 'xXx2K0zCsbYbOPRhLZHqa0g83h5uSmlh',
    applicationId: 'XHPiMdpchfugjthdjitfH6WgJVJP6r1Z'
  },
  appStorage_forUpdate: {
    _id: tools.generatePublicKey(32),
    key: 'forUpdate',
    value: {},
    optimisticLock: 1401701384253,
    subscriberId: 'XHPiMFOgAD0KzimPeitfH6WgJVJP6r1Z',
    profileId: 'xXx2K0zCsbYbOPRhLZHqa0g83h5uSmlh',
    applicationId: 'XHPiMdpchfugjthdjitfH6WgJVJP6r1Z'
  },
  appStorage_forUpdate2: {
    _id: tools.generatePublicKey(32),
    key: 'forUpdate2',
    value: {},
    optimisticLock: new Date().getTime(),
    subscriberId: 'XHPiMFOgAD0KzimPeitfH6WgJVJP6r1Z',
    profileId: 'xXx2K0zCsbYbOPRhLZHqa0g83h5uSmlh',
    applicationId: 'XHPiMdpchfugjthdjitfH6WgJVJP6r1Z'
  },
  appStorage_forDel: {
    _id: tools.generatePublicKey(32),
    key: 'forDel',
    value: {},
    optimisticLock: new Date().getTime(),
    subscriberId: 'XHPiMFOgAD0KzimPeitfH6WgJVJP6r1Z',
    profileId: 'xXx2K0zCsbYbOPRhLZHqa0g83h5uSmlh',
    applicationId: 'XHPiMdpchfugjthdjitfH6WgJVJP6r1Z'
  },
  appStorage_forDel2: {
    _id: tools.generatePublicKey(32),
    key: 'forDel2',
    value: {},
    optimisticLock: 1401701384253,
    subscriberId: 'XHPiMFOgAD0KzimPeitfH6WgJVJP6r1Z',
    profileId: 'xXx2K0zCsbYbOPRhLZHqa0g83h5uSmlh',
    applicationId: 'XHPiMdpchfugjthdjitfH6WgJVJP6r1Z'
  },
  appStorage_forDel3: {
    _id: tools.generatePublicKey(32),
    key: 'forDel3',
    value: {},
    optimisticLock: new Date().getTime(),
    subscriberId: 'XHPiMFOgAD0KzimPeitfH6WgJVJP6r1Z',
    profileId: 'xXx2K0zCsbYbOPRhLZHqa0g83h5uSmlh',
    applicationId: 'XHPiMdpchfugjthdjitfH6WgJVJP6r1Z'
  }
};

module.exports = appStorage;