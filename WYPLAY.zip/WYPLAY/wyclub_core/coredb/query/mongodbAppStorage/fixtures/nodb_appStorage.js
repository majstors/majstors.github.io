/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
*/

/* jshint -W106*/
/* global tools:true*/

var nodb_appStorage = {
  appStorage_subProfilePremiumAndapp1: {
    _id: tools.generatePublicKey(32),
    key: 'nodbInsert',
    value: { insert: 'value' },
    optimisticLock: new Date().getTime(),
    subscriberId: 'XHPiMFOgAD0KzimPeitfH6WgJVJP6r1Z',
    profileId: 'xXx2K0zCsbYbOPRhLZHqa0g83h5uSmlh',
    applicationId: 'XHPiMdpchfugjthdjitfH6WgJVJP6r1Z'
  },
  appStorage_subNoPremiumAndNoPasswordApp2: {
    _id: tools.generatePublicKey(32),
    key: 'nodb',
    value: {},
    optimisticLock: new Date().getTime(),
    subscriberId:'qqVTdlR9cXZT7MIpBS7fv8hXlcsEiyyG',
    profileId: 'RjkwdtbQ5hoqlA754cRQ4yXnmH7fCOBX',
    applicationId: 'XHPiMdpchfugjthdjitfH6WgJVJP6r1A'
  },
  appStorage_forUpdate: {
    _id: tools.generatePublicKey(32),
    key: fx.mongodbAppStorage.appStorage.appStorage_forUpdate.key,
    value: { eventName: 'forUpdate' },
    optimisticLock: new Date().getTime(),
    subscriberId: 'XHPiMFOgAD0KzimPeitfH6WgJVJP6r1Z',
    profileId: 'xXx2K0zCsbYbOPRhLZHqa0g83h5uSmlh',
    applicationId: 'XHPiMdpchfugjthdjitfH6WgJVJP6r1Z'
  },
  appStorage_forUpdate2: {
    _id: tools.generatePublicKey(32),
    key: fx.mongodbAppStorage.appStorage.appStorage_forUpdate.key,
    value: { eventName: 'forUpdate2' },
    optimisticLock: new Date().getTime(),
    subscriberId: 'XHPiMFOgAD0KzimPeitfH6WgJVJP6r1Z',
    profileId: 'xXx2K0zCsbYbOPRhLZHqa0g83h5uSmlh',
    applicationId: 'XHPiMdpchfugjthdjitfH6WgJVJP6r1Z'
  },
  appStorage_forDel: {
    _id: tools.generatePublicKey(32),
    key: 'nodbForDel',
    value: { eventName: 'nodbForDel' },
    optimisticLock: new Date().getTime(),
    subscriberId: 'XHPiMFOgAD0KzimPeitfH6WgJVJP6r1Z',
    profileId: 'xXx2K0zCsbYbOPRhLZHqa0g83h5uSmlh',
    applicationId: 'XHPiMdpchfugjthdjitfH6WgJVJP6r1Z'
  }
};

module.exports = nodb_appStorage;