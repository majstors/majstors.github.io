/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/**
 * MongoDB Application Storage Queries
 *
 * */

var Mongodb = require('../../../lib/mongodbQuery');
var AppStorage = function () {
  'use strict';
  this.setDefaultCollection('appStorage');
};
AppStorage.prototype = Object.create(Mongodb.prototype);

AppStorage.prototype.create = function (params, callback) {
  'use strict';
  var self = this;
  this.appStorageClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.insert(params, { w: 1 }, function (err, record) {
        if (err !== null) {
          callback(err);
          self.appStorageClient.close();
        } else {
          if (record.length !== undefined) {
            record = record[0];
          }
          callback(null, record);
          self.appStorageClient.close();
        }
      });
    }
  });
};

AppStorage.prototype.read = function (params, callback) {
  'use strict';
  var self = this;
  this.appStorageClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.findOne(params, {}, function (err, item) {
        if (err !== null) {
          callback(err);
          self.appStorageClient.close();
        } else {
          callback(null, item);
          self.appStorageClient.close();
        }
      });
    }
  });
};

AppStorage.prototype.readAll = function (params, callback) {
  'use strict';
  var self = this;
  this.appStorageClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.find(params, {}).toArray(function (err, item) {
        if (err !== null) {
          callback(err);
          self.appStorageClient.close();
        } else {
          callback(null, item);
          self.appStorageClient.close();
        }
      });
    }
  });
};

AppStorage.prototype.update = function (params, callback) {
  'use strict';
  var self = this;
  this.appStorageClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      var where = {
          key: params.key,
          subscriberId: params.subscriberId,
          profileId: params.profileId,
          applicationId: params.applicationId
        };
      var update = {
          value: params.value,
          optimisticLock: params.optimisticLock
        };
      collection.findAndModify(where, [], { '$set': update }, {
        w: 1,
        new: true
      }, function (err, item) {
        if (err !== null) {
          callback(err);
          self.appStorageClient.close();
        } else {
          callback(null, item);
          self.appStorageClient.close();
        }
      });
    }
  });
};

AppStorage.prototype.delete = function (params, callback) {
  'use strict';
  var self = this;
  this.appStorageClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.remove(params, { w: 1 }, function (err, numberOfRemovedDocs) {
        if (err !== null) {
          callback(err);
          self.appStorageClient.close();
        } else {
          callback(null, numberOfRemovedDocs);
          self.appStorageClient.close();
        }
      });
    }
  });
};

AppStorage.prototype.clean = function (callback) {
  'use strict';
  var self = this;
  this.appStorageClient.getCollection(self.collection, function (err, collection) {
    if (err !== null) {
      callback(err);
    } else {
      collection.remove({}, { w: 1 }, function (err, document) {
        if (err !== null) {
          callback(err);
          self.appStorageClient.close();
        } else {
          callback(null, document);
          self.appStorageClient.close();
        }
      });
    }
  });
};

module.exports = new AppStorage();