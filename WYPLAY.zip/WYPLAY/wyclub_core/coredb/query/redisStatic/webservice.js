/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

// Redis Webservice Queries

var Redis = require('../../../lib/redisQuery');
var Webservice = function () {
  this.setDefaultCollection('Core');
};
Webservice.prototype = Object.create(Redis.prototype);

/**
 * # Description
 * Output the requested public service
 *
 * @param {Object} params (contains applicationName,serviceName)
 * @return {Object} service
 *
 */
Webservice.prototype.create = function (params, callback) {
  'use strict';
  if (params.label === undefined) {
    params.label = 'Core';
  }
  this.staticClient.hset(params.label, params.name, JSON.stringify(params.webService), function (err, service) {
    if (err !== null) {
      callback(err);
    } else {
      callback(null, service);
    }
  });
};

Webservice.prototype.readPublic = function (params, callback) {
  'use strict';
  this.staticClient.hget(params.applicationName, params.serviceName, function (err, service) {
    if (err !== null) {
      callback(err);
    } else {
      callback(null, JSON.parse(service));
    }
  });
};

/**
 * # Description
 * Output all the public services
 *
 * @param {Object} params (applicationName)
 * @return {Object} service
 *
 */
Webservice.prototype.readAllPublic = function (params, callback) {
  'use strict';
  this.staticClient.hgetall(params.applicationName, function (err, services) {
    if (err !== null) {
      callback(err);
    } else {
      callback(null, services);
    }
  });
};

module.exports = new Webservice();