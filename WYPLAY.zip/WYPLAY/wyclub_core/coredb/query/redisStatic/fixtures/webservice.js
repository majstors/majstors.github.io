/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* jshint -W106*/

var webservice = {
  webservice_1: {
    webService: fx.mongodbStatic.webservice.webservice_3,
    label: fx.mongodbStatic.webservice.webservice_3.name.split(':')[0],
    name: fx.mongodbStatic.webservice.webservice_3.name
  },
  webservice_2: {
    webService: fx.mongodbStatic.webservice.webservice_4,
    label: fx.mongodbStatic.webservice.webservice_4.name.split(':')[0],
    name: fx.mongodbStatic.webservice.webservice_4.name.split(':')[1]
  }
};

module.exports = webservice;