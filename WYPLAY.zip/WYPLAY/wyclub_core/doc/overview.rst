***********
WyClub Core
***********

Introduction
============
The Core is the central component of the WyClub.

It is used to handle all sessions: subscriber, administrative and application.


API Documentation
=================
.. toctree::
   :maxdepth: 1
   :glob:

   api/*
   api/statuscodes/*
