Core = {'install': true};
require('../app/config/params.js');
var fs = require('fs-extra');
var url = require('url');
var child_process = require('child_process');
var params = Core.params;

if (!params) {
  return;
}

if (params.assembly.repo) {
  console.log('== Start initialisation of assembly module ==');
  var npm = child_process.spawn('npm', ['install', params.assembly.repo]);
  npm.stdout.on('data', function (data) {
    console.log(data.toString());
  });
  npm.stderr.on('data', function (data) {
    console.log(data.toString());
  });
  npm.on('exit', function (code) {
    console.log('== End initialisation of assembly modulee ==');
  });
} else {
  child_process.exec('rm -rf ' + Core.root + 'node_modules/' + params.assembly.name);
  child_process.exec('rm -rf ' + root + 'node_modules/wyclub_' + params.assembly.name);
}