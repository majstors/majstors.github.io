/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */
var async = require('async');
var path = require('path');
var rulesLib = require('../../lib/rule.js');
var tools = require('../../lib/tools.js');
var sessionContext = require('../../lib/sessionContext');
var helmet = require("helmet");
var httpTools = require('../../lib/httpTools');

Error.stackTraceLimit = Infinity;

/*process.on('uncaughtException', function (err) {
  Error.stackTraceLimit = Infinity;
  console.log(err.stack);
});*/

var initRedis = function (name, type, callback) {
  var redis = require('redis');
  Core.log('Connecting to redis session...', 'connectDB');
  Core[name] = redis.createClient(Core.params[type].port, Core.params[type].host);
  if (Core.params[type].password !== undefined) {
    Core[name].auth(Core.params[type].password, function () {
      Core.log('Connected to redis logs.', 'connectDB');
    });
  } else {
    Core.log('Connected to redis logs.', 'connectDB');
  }
  callback();
};

var initMongo = function (callback) {
  var Connection = require('../../lib/mongoDb');
  Core.db = { 'mongo': {} };
  async.eachSeries(Core.params.mongo.databases, function (database, cb) {
    Core.db.mongo[database.name] = new Connection(database, function (err) {
      cb(err);
    });
    if (!callback) {
      cb();
    }
  }, function () {
    if (callback) {
      callback();
    }
  });
};

var initEnv = function (express, callback) {
  Core.configure(function () {
    var rules = require('../../lib/rule.js');
    Core.set('port', process.env.PORT || Core.params.portServer);
    Core.use(express.favicon());
    if (Core.params.debug === true && Core.isTestServer !== true) {
      Core.use(express.logger('dev'));
    }
    Core.use(express.bodyParser());

    Core.use(function (error, req, res, next) {
      //Catch json error
      if (error) {
        var err = httpTools.getError({code: 'BAD_REQUEST', params: {reqType:'JSON'}});
        httpTools.setResponse(req, err, res, 200, 'JSON');
      }else {
        next();
      }
    });
    Core.use(express.static(path.join(__dirname, '/../../generated/swagger')));
    Core.use(express.methodOverride());
    Core.use(sessionContext.store);
    Core.use(rules.executeRules);
    Core.use(Core.logger.getService);
    Core.use(Core.router);

    // Remove default x-powered-by response header
    Core.disable("x-powered-by");

    // Prevent opening page in frame or iframe to protect from clickjacking
    Core.use(helmet.xframe());

    // Prevents browser from caching and storing page
    Core.use(helmet.nocache());

    // Allow loading resources only from white-listed domains
    Core.use(helmet.csp());

    // Forces browser to only use the Content-Type set in the response header instead of sniffing or guessing it
    Core.use(helmet.nosniff());

    //Enable Express csrf protection
    Core.use(express.csrf());
  });
  Core.configure('development', function () {
    //Core.use(express.errorHandler());
  });
  callback();
};

/**
 * Config environment
 */
module.exports = function (express, callback) {
  if (!callback) {
    initRedis('redisLogs', 'redisLogs', function () {});
    initRedis('redisSession', 'redisSession', function () {});
    initRedis('redisStatic', 'redisStatic', function () {});
    initRedis('redis', 'redis', function () {});
    initRedis('redisPublisher', 'redisPubSub', function () {});
    initRedis('redisSubscriber', 'redisPubSub', function () {});
    initMongo(false);
    initEnv(express, function () {});
  } else {
    async.waterfall([
      function (callback) {
        initRedis('redisLogs', 'redisLogs', function () {
          callback(null);
        });
      },
      function (callback) {
        initRedis('redisSession', 'redisSession', function () {
          callback(null);
        });
      },
      function (callback) {
        initRedis('redisStatic', 'redisStatic', function () {
          callback(null);
        });
      },
      function (callback) {
        initRedis('redis', 'redis', function () {
          callback(null);
        });
      },
      function (callback) {
        initRedis('redisPublisher', 'redisPubSub', function () {
          callback(null);
        });
      },
      function (callback) {
        initRedis('redisSubscriber', 'redisPubSub', function () {
          callback(null);
        });
      },
      function (callback) {
        initMongo(function () {
          callback(null);
        });
      },
      function (callback) {
        initEnv(express, function () {
          callback(null);
        });
      },
      function (callback) {
        //event broker config
        if (typeof ignoreEventBroker !== 'undefined') {
          ignoreEventBroker = true;
        } else {
          ignoreEventBroker = false;
        }

        if (!Core.isTestServer && !ignoreEventBroker) {
          Core.eventBroker = require('wyclub_event-broker');
          Core.eventBroker.createContext(Core.params.eventBroker, function (err) {
            var randomChannel = tools.generatePublicKey(10);

            if (err) {
              callback({ 'event-broker': err });
            } else {
              Core.eventBroker.subscribeChannel(randomChannel, function (err, message) {
                if (message && message.test === 'ok') {
                  //server is ok, start now
                  callback(null);
                } else {
                  callback('eventBrokerError');
                }
              }, function() {
                Core.eventBroker.publishChannel(randomChannel, { test: 'ok' });
              });
            }
          });
        } else {
          callback(null);
        }
      }
    ], function (err, result) {
      if (err) {
        console.log('init error:');
        console.log(err);
        process.exit(999);
      } else {
        // Subscriber to rule channel
        rulesLib.subToRedis();
        callback();
      }
    });
  }
};
