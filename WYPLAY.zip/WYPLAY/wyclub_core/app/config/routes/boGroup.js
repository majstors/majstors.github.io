/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * BO User routing directive
 */
module.exports = function() {
  Core.get('/:wyclubToken/boGroup.json', Core.controller.boGroup.read);
  Core.post('/:wyclubToken/boGroup.json', Core.controller.boGroup.create);
  Core.put('/:wyclubToken/boGroup.json', Core.controller.boGroup.update);
  Core.delete('/:wyclubToken/boGroup.json', Core.controller.boGroup.delete);
  Core.get('/:wyclubToken/boGroup/list.json', Core.controller.boGroup.readAll);
};