/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * Session routing directive
 */
module.exports = function() {
  Core.get('/:wyclubToken/businesspackage.json', Core.controller.business.readPackage);
  Core.get('/:wyclubToken/businessservice.json', Core.controller.business.readService);
  Core.get('/:wyclubToken/businessasset.json', Core.controller.business.readAsset);

  Core.put('/:wyclubToken/businesspackage.json', Core.controller.business.updatePackage);
  Core.put('/:wyclubToken/businessservice.json', Core.controller.business.updateService);
  Core.put('/:wyclubToken/businessasset.json', Core.controller.business.updateAsset);

  Core.delete('/:wyclubToken/businesspackage.json', Core.controller.business.deletePackage);
  Core.delete('/:wyclubToken/businessservice.json', Core.controller.business.deleteService);
  Core.delete('/:wyclubToken/businessasset.json', Core.controller.business.deleteAsset);
  Core.delete('/:wyclubToken/businesslinkpackageservice.json', Core.controller.business.unlinkPackageToService);
  Core.delete('/:wyclubToken/businesslinkapplicationservice.json', Core.controller.business.unlinkServiceToApplication);
  Core.delete('/:wyclubToken/businesslinkassetservice.json', Core.controller.business.unlinkServiceToAsset);
  Core.delete('/:wyclubToken/businesslinkpackageasset.json', Core.controller.business.unlinkPackageToAsset);

  Core.post('/:wyclubToken/businesspackage.json', Core.controller.business.createPackage);
  Core.post('/:wyclubToken/businessservice.json', Core.controller.business.createService);
  Core.post('/:wyclubToken/businessasset.json', Core.controller.business.createAsset);
  Core.post('/:wyclubToken/businesslinkapplicationservice.json', Core.controller.business.linkServiceToApplication);

  Core.post('/:wyclubToken/businesslinkpackageservice.json', Core.controller.business.linkPackageToService);
  Core.post('/:wyclubToken/businesslinkpackageasset.json', Core.controller.business.linkPackageToAsset);
  Core.post('/:wyclubToken/businesslinkassetservice.json', Core.controller.business.linkServiceToAsset);
};
