/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * Session routing directive
 */
module.exports = function() {

  Core.get('/:wyclubToken/session/sub.json', Core.controller.session.readSubscriber);
  Core.get('/:wyclubToken/session/sub/profile.json', Core.controller.session.readSubscriberProfile);
  Core.get('/:wyclubToken/session/sub/device.json', Core.controller.session.readSubscriberDevices);
  Core.get('/:wyclubToken/session/twinSister.json', Core.controller.session.readTwinSister);
  Core.get('/:wyclubToken/session/profile.json', Core.controller.session.readProfile);
  Core.get('/:wyclubToken/session/tag.json', Core.controller.session.readTag);
  Core.get('/:wyclubToken/session/accesstoken.json', Core.controller.session.readAccessToken);
  Core.get('/:wyclubToken/session/currentcontent.json', Core.controller.session.readCurrentContent);
  Core.get('/:wyclubToken/session/device.json', Core.controller.session.readDevice);
  Core.get('/:wyclubToken/session/alldevices.json', Core.controller.session.readAllDevices);

  Core.post('/:applicationId/session.json', Core.controller.session.create);
  Core.post('/:applicationId/halfsistersession.json', Core.controller.session.createHalfSister);
  Core.post('/:wyclubToken/session/currentcontent.json', Core.controller.session.createCurrentContent);
  Core.post('/:wyclubToken/session/device.json', Core.controller.session.createDevice);

  Core.put('/:wyclubToken/session/profile.json', Core.controller.session.updateProfile);
  Core.put('/:wyclubToken/session/device.json', Core.controller.session.updateDevice);

  Core.delete('/:wyclubToken/session.json', Core.controller.session.delete);
  Core.delete('/:wyclubToken/session/device.json', Core.controller.session.deleteDevice);
};
