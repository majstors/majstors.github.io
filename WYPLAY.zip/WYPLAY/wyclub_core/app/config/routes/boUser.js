/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

/**
 * BO User routing directive
 */
module.exports = function() {
  Core.get('/:wyclubToken/boUser.json', Core.controller.boUser.read);
  Core.post('/:wyclubToken/boUser.json', Core.controller.boUser.create);
  Core.put('/:wyclubToken/boUser.json', Core.controller.boUser.update);
  Core.delete('/:wyclubToken/boUser.json', Core.controller.boUser.delete);
  Core.get('/:wyclubToken/boUser/list.json', Core.controller.boUser.readAll);
  Core.post('/:wyclubToken/boUser/group.json', Core.controller.boUser.addGroup);
  Core.delete('/:wyclubToken/boUser/group.json', Core.controller.boUser.deleteGroup);
  Core.post('/:applicationId/boUser/login.json', Core.controller.boUser.login);
};