/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

module.exports = {
  logVerbosity: {
    connectDB: false
  },
  portServer: 3000,
  checkParam: true,
  protocolServer: 'http',
  clustering: false,
  debug: true,
  logsInRedis: false,
  eventBroker: {
    protocol: 'amqp',
    user: 'admin',
    password: 'wyclub',
    ip: '127.0.0.1'
  },
  fixturesPriority: {
    db: [
      'mongodbStatic',
      'mongodbSession',
      'mongodbAppStorage',
      'redisStatic',
      'redisSession'
    ],
    mongodbStatic: [
      'tag',
      'application',
      'deviceType',
      'subscriber',
      'business',
      'rule'
    ],
    mongodbAppStorage: ['appStorage']
  },
  mongo: {
    servers: {
      local: {
        'hosts': ['127.0.0.1'],
        'port': 27017,
        'user': undefined,
        'password': undefined,
        'authdb': undefined,
        'options': {
          'auto_reconnect': true,
          'poolSize': 5,
          'socketOptions': {}
        }
      }
    },
    logCollection: 'logs',
    importCollection: 'import',
    databases: [
      {
        'name': 'logs',
        'dbName': 'logs',
        'server': 'local',
        options: { 'w': 0 }
      },
      {
        'name': 'appstorage',
        'dbName': 'appStorage',
        'server': 'local',
        'options': { 'w': 1 }
      },
      {
        'name': 'session',
        'dbName': 'session',
        'server': 'local',
        'options': { 'w': 1 }
      },
      {
        'name': 'static',
        'dbName': 'static',
        'server': 'local',
        'options': { 'w': 1 }
      }
    ]
  },
  redis: {
    host: '127.0.0.1',
    port: '6379',
    password: undefined
  },
  redisPubSub: {
    host: '127.0.0.1',
    port: '6379',
    password: undefined
  },
  redisStatic: {
    host: '127.0.0.1',
    port: '6379',
    password: undefined
  },
  redisSession: {
    host: '127.0.0.1',
    port: '6379',
    password: undefined
  },
  redisLogs: {
    host: '127.0.0.1',
    port: '6379',
    password: undefined
  }
};
