/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

module.exports = {
  logVerbosity: {
    connectDB: false,
    fixtures: false
  },
  portServer: 3000,
  checkParam: true,
  protocolServer: 'http',
  clustering: false,
  debug: true,
  logsInRedis: false,
  eventBroker: {
    protocol: 'amqp',
    user: 'admin',
    password: 'wyclub',
    ip: process.env.RABBITMQ_PORT_5672_TCP_ADDR
  },
  fixturesPriority: {
    db: [
      'mongodbStatic',
      'mongodbSession',
      'mongodbAppStorage',
      'redisStatic',
      'redisSession'
    ],
    mongodbStatic: [
      'tag',
      'application',
      'deviceType',
      'subscriber',
      'business',
      'rule'
    ],
    mongodbAppStorage: ['appStorage']
  },
  mongo: {
    servers: {
      local: {
        'hosts': [process.env.MONGODB_PORT_27017_TCP_ADDR],
        'port': 27017,
        'user': 'core',
        'password': 'core',
        'authdb': 'core',
        'options': {
          'auto_reconnect': true,
          'poolSize': 5,
          'socketOptions': {}
        }
      }
    },
    logCollection: 'logs',
    importCollection: 'import',
    databases: [
      {
        'name': 'logs',
        'dbName': 'logs',
        'server': 'local',
        options: { 'w': 0 }
      },
      {
        'name': 'appstorage',
        'dbName': 'appStorage',
        'server': 'local',
        'options': { 'w': 1 }
      },
      {
        'name': 'session',
        'dbName': 'session',
        'server': 'local',
        'options': { 'w': 1 }
      },
      {
        'name': 'static',
        'dbName': 'static',
        'server': 'local',
        'options': { 'w': 1 }
      }
    ]
  },
  redis: {
    host: process.env.REDIS_PORT_6379_TCP_ADDR,
    port: '6379',
    password: undefined
  },
  redisPubSub: {
    host: process.env.REDIS_PORT_6379_TCP_ADDR,
    port: '6379',
    password: undefined
  },
  redisStatic: {
    host: process.env.REDIS_PORT_6379_TCP_ADDR,
    port: '6379',
    password: undefined
  },
  redisSession: {
    host: process.env.REDIS_PORT_6379_TCP_ADDR,
    port: '6379',
    password: undefined
  },
  redisLogs: {
    host: process.env.REDIS_PORT_6379_TCP_ADDR,
    port: '6379',
    password: undefined
  }
};