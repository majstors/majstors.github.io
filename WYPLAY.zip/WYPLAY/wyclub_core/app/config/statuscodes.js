/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/**
 * Error status Codes
 */
module.exports = {
  'DEFAULT': {
    code: 999,
    content: 'An unexpected error occured.'
  },
  'BAD_REQUEST': {
    code: 1,
    content: 'Invalid %reqType% request, check your header.'
  },
  'DB_NO_CONNECTION': {
    code: 2,
    content: 'Could not connect to database.'
  },
  'DB_ERROR': {
    code: 3,
    content: 'Unexpected database error.'
  },
  'NO_SESSION': {
    code: 4,
    content: 'Your session isn\'t valid.'
  },
  'INVALID_REQ_PARAM': {
    code: 5,
    content: 'Invalid request parameter: %param%'
  },
  'MISSING_REQ_PARAM': {
    code: 6,
    content: 'Missing request parameter(s): %param%'
  },
  'NO_SUPERADMIN': {
    code: 7,
    content: 'Session is not a superadmin session'
  },
  'NO_SUBSCRIBER': {
    code: 100,
    content: 'The specified subscriber does not exist.'
  },
  'NO_PROFILE': {
    code: 101,
    content: 'The specified profile does not exist.'
  },
  'NO_DEVICE': {
    code: 102,
    content: 'The specified device does not exist.'
  },
  'NO_DEVICE_INSTANCE': {
    code: 112,
    content: 'The specified device instance does not exist.'
  },
  'NO_WEBSERVICE': {
    code: 103,
    content: 'The specified web service does not exist.'
  },
  'NO_BUSINESS_SERVICE': {
    code: 104,
    content: 'The specified business service does not exist.'
  },
  'NO_BUSINESS_PACKAGE': {
    code: 105,
    content: 'The specified business package does not exist.'
  },
  'NO_BUSINESS_OBJECT': {
    code: 112,
    content: 'The specified business object does not exist.'
  },
  'NO_BUSINESS_ASSET': {
    code: 106,
    content: 'The specified business asset does not exist.'
  },
  'NO_APPLICATION': {
    code: 107,
    content: 'The specified application does not exist.'
  },
  'NO_APPLICATION_DATA': {
    code: 108,
    content: 'The specified application data does not exist.'
  },
  'NO_TAG': {
    code: 109,
    content: 'The specified tag does not exist.'
  },
  'NO_RULE': {
    code: 110,
    content: 'The specified rule does not exist.'
  },
  'NO_CURRENT_CONTENT': {
    code: 111,
    content: 'The specified current content does not exist.'
  },
  'NO_BOUSER': {
    code: 112,
    content: 'The specified user does not exist.'
  },
  'NO_BOGROUP': {
    code: 113,
    content: 'The specified group does not exist.'
  },
  'BAD_BO_LOGIN': {
    code: 114,
    content: 'Bad login/password'
  },
  'SUBSCRIBERS_EMPTY': {
    code: 200,
    content: 'Could not find any subscribers.'
  },
  'PROFILES_EMPTY': {
    code: 201,
    content: 'Could not find any profiles.'
  },
  'DEVICES_EMPTY': {
    code: 202,
    content: 'Could not find any devices.'
  },
  'DEVICE_INSTANCES_EMPTY': {
    code: 213,
    content: 'Could not find any device instances.'
  },
  'WEBSERVICES_EMPTY': {
    code: 203,
    content: 'Could not find any web services.'
  },
  'APPLICATIONS_EMPTY': {
    code: 207,
    content: 'Could not find any applications.'
  },
  'TAGS_EMPTY': {
    code: 209,
    content: 'Could not find any tags.'
  },
  'RULES_EMPTY': {
    code: 210,
    content: 'Could not find any rules.'
  },
  'OPTIMISTICLOCK_EMPTY': {
    code: 211,
    content: 'OptimisticLock doesn\'t match.'
  },
  'BAD_PASSWORD': {
    code: 212,
    content: 'Bad password'
  },
  'SESSIONS_EMPTY': {
    code: 214,
    content: 'Could not find any sessions.'
  },
  'DUPLICATE_ENTRY': {
    code: 300,
    content: 'Duplicate entry'
  },
  'JSON_SCHEMA_ERROR': {
    code: 400,
    content: 'Json schema error'
  },
  'NO_RULES_VALUES': {
    code: 401,
    content: 'This rule doesn\'t have values'
  },
  'RULES_ALREADY_EXIST': {
    code: 402,
    content: 'This rule already exist on this webservice'
  },
  'UPDATE_SCHEMA_BUT_PROTORULE_HAVE_RULES': {
    code: 403,
    content: 'Can\'t update protorule schema because already have rules'
  },
  'NO_UPDATE_RULES': {
    code: 404,
    content: 'Can\'t update rules via a protorule'
  },
  'SUBRULEID_NEEDED_FOR_PROTORULE': {
    code: 666,
    content: 'You need a subRuleId to update/delete a protorule'
  }
};