/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/**
 * Database config
 */
var fs = require('fs-extra');
var path = require('path');
var params = {
  prod: {},
  qualif: {},
  dev: {}
};

if (typeof(Core) === 'undefined') {
  Core = {};
}
if (!Core.root) {
  Core.root = __dirname + '/../../';
}
if (Core.isTestServer !== true) {
  if (fs.existsSync(__dirname + '/params.dev.js') && require(__dirname + '/params.dev.js') !== undefined) {
    params.dev = require(__dirname + '/params.dev.js');
    Core.env = 'dev';
  } else if (fs.existsSync(__dirname + '/params.qualif.js')) {
    params.qualif = require(__dirname + '/params.qualif.js');
    Core.env = 'qualif';
  } else {
    params.prod = require(__dirname + '/params.prod.js');
    Core.env = 'prod';
  }
} else {
  if (fs.existsSync(__dirname + '/params.test.js') && require(__dirname + '/params.test.js') !== undefined) {
    params.dev = require(__dirname + '/params.test.js');
    Core.env = 'dev';
  } else {
    Core.canBeLaunch = 'You have no ' + Core.colors.red(__dirname + '/params.test.js')
      + ' file, create it before launching tests';
  }
}
Core.params = params[Core.env];

// Read wyclub modules
var modules = fs.readdirSync(__dirname + '/modules');
modules.forEach(function (module) {
  'use strict';

  // Keep js files only
  if (module.indexOf('.js') > 0) {
    var moduleParams = require(__dirname + '/modules/' + module);
    // If module is used as a node module, try to read branch to use on the file name
    if (moduleParams.repo) {
      var branch = module.split('#');
      if (branch.length === 2) {
        branch = branch[1].replace('.js', '');
        moduleParams.repo = moduleParams.repo.replace(/#[a-z0-9]+/i, '#' + branch);
      }
    }
    Core.params[moduleParams.name] = moduleParams;
  }
});

if (!Core.install) {
  if (!Core.params.assembly) {
    throw 'Assembly directory doesn\'t exist';
  }
  // Require package.json to check if module exists
  require(Core.params.assembly.dir + "/package.json");
}

Core.log = function (str, logType) {
  if (Core && Core.params && Core.params.logVerbosity && logType) {
    if (Core.params.logVerbosity[logType] !== false) {
      console.log(str);
    }
  }
};

module.exports = Core.params;