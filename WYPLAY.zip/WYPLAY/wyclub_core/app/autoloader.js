/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

'use strict';

module.exports = function(where, cb) {
  var fs = require('fs');
  var path = require('path');
  var async = require('async');
  async.series([
    function(callback) {
      fs.readdir(path.join(__dirname, '../coredb/repository'), function(error, repositories) {
        if (repositories !== undefined && repositories !== null) {
          var lengthRepositories = repositories.length;
          var i = 0;
          Object.keys(repositories).forEach(function(repository) {
            var repositoryName = repositories[repository].replace('.js', '');
            var repositoryPath = path.join(module.parent.filename, where, '../coredb/repository', repositories[repository]);
            Core.repository[repositoryName] = require(repositoryPath);
            i++;
            if (i === lengthRepositories) {
              callback(null, 'repositories');
            }
          });
        } else {
          callback(null, 'repositories');
        }
      });
    },
    function(callback) {
      fs.readdir(path.join(__dirname, '../coredb/query'), function(error, queries) {
        if (queries !== undefined && queries !== null) {
          var i = 0;
          for (var query in queries) {
            i++;
            var queriesQueryName = queries[query];
            Core.query[queriesQueryName] = {};
            var queriesQuery = fs.readdirSync(path.join(__dirname, '../coredb/query', queries[query]));
            for (var queryQuery in queriesQuery) {
              if (queriesQuery[queryQuery].substring(queriesQuery[queryQuery].length - 3, queriesQuery[queryQuery].length) === '.js') {
                var queryName = queriesQuery[queryQuery].replace('.js', '');
                var queryPath = path.join(module.parent.filename, where, '../coredb/query', queries[query], queriesQuery[queryQuery]);
                Core.query[queriesQueryName][queryName] = require(queryPath);
              }
            }
          }
          callback(null, 'queries');
        } else {
          callback(null, 'repositories');
        }
      });
    },
    function(callback) {
      fs.readdir(path.join(__dirname, '../controller'), function(error, controllers) {
        var lengthController = controllers.length;
        var i = 0;
        Object.keys(controllers).forEach(function(controller) {
          var controllerName = controllers[controller].replace('.js', '');
          var controllerPath = path.join(module.parent.filename, where, '../controller', controllers[controller]);
          Core.controller[controllerName] = require(controllerPath);
          i++;
          if (i === lengthController) {
            callback(null, 'controllers');
          }
        });
      });
    },
    function(callback) {
      fs.readdir(path.join(__dirname, 'authorization'), function(error, authorizations) {
        if (typeof authorization !== 'undefined') {
          var lengthAuthorization = authorizations.length;
          var i = 0;
          if (lengthAuthorization > 0)
            Object.keys(authorizations).forEach(function(authorization) {
              var authorizationName = authorizations[authorization].replace('.js', '');
              var authorizationPath = path.join(module.parent.filename, where, '../app/authorization', authorizations[authorization]);
              Core.authorization[authorizationName] = require(authorizationPath);
              i++;
              if (i === lengthAuthorization) {
                callback(null, 'authorizations');
              }
            });
          else {
            callback(null, 'authorizations');
          }
        } else {
          callback(null, 'authorizations');
        }
      });
    }
  ],
  // optional callback
  function(err, results) {
    fs.readdir(path.join(__dirname, 'config/routes'), function(error, routes) {
      var lengthRoute = routes.length;
      var i = 0;
      Object.keys(routes).forEach(function(route) {
        var routeName = routes[route].replace('.js', '');
        Core.route[routeName] = path.join(module.parent.filename, where, 'config/routes', routes[route]);
        require(path.join(module.parent.filename, where, '../app/config/routes', routeName))();
        i++;
        if (i === lengthRoute) {
          cb();
        }
      });
    });
  });
};
