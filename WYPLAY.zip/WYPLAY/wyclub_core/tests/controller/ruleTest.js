#!/usr/bin/env node
/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* jshint -W106 */

var fx = {};
var path = require('path');
var assert = require('assert');

var loadFixtures = function (params, cb) {
  'use strict';

  require(path.join(__dirname + '../../../app/bin/loadFixtures'))(params, function (err, data) {
    if (err) {
      throw err;
    }
    fx = data;
    cb(err, data);
  });
};

var reporter = require(__dirname + '/../../lib/vows/lib/reporters/xunitDotMatrix.js');

var isTestServer = false;
var nocolor = false;
for (var key in process.argv) {
  if (process.argv[key] === 'isTestServer=true') {
    isTestServer = true;
  }
  if (process.argv[key] === 'nocolor=true') {
    nocolor = true;
  }
}

loadFixtures({isTestServer: isTestServer}, function () {
  'use strict';

  var vows = require('vows');
  var apiTest = require('../apiTest');
  var underscore = require('underscore');
  var enabledSession = 'Cal9SSQdjjiQ2MiCCZVLlkF730RpyKXK';
  var sessionEnabledWithoutTag = 'I546AgCTu3uPaN56Q9UkffNLU5JfUHta';
  var disabledSession = 'session_disabled_ZVLlkF730RpyKXK';
  var webserviceValid = fx.mongodbStatic.webservice.webservice_2;
  var webserviceValid1 = fx.mongodbStatic.webservice.webservice_1;
  var tagTest = "test_oEBmGVW46ljSOKtRj8xStD2zgH0";
  var tagTest2 = "test2_EBmGVW46ljSOKtRj8xStD2zgH0";
  var ruleMaxNumberOfDevices = fx.mongodbStatic.rule.rule_maxNumberOfDevices;
  var setTagToTest = fx.mongodbStatic.rule.rule_setTagToTest;
  var rule1 = fx.mongodbStatic.rule.rule_1;
  var rule2 = fx.mongodbStatic.rule.rule_newConnection;
  var tmpRuleId = null;
  var tmpRuleId2 = null;
  vows.describe('API HTTPS - Rule Controller').addBatch({
    'ruleCreate - create rule with valid data': {
      topic: function () {
        var self =  this;
        apiTest.post('/' + enabledSession._id + '/rule.json', {
          '_id': ruleMaxNumberOfDevices._id,
          'webservice': webserviceValid1.name,
          'values': {'x': 3}
        }, function(resp){
          tmpRuleId2 = resp.body.content.rules[1]._id;
          self.callback(resp);
        });
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Valid club response': apiTest.response.assertValidResponse(),
      'Rule have new value and new webservice': function (response, data) { //jshint ignore:line
        assert.equal(response.body.content.rules.length, 2);
      }
    }
  }).addBatch({
    'ruleCreate - create rule with invalid session': {
      topic: function () {
        apiTest.post('/' + disabledSession._id + '/rule.json', {
          '_id': ruleMaxNumberOfDevices._id,
          'webservice': webserviceValid1.name,
          'values': {'x': 3}
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(4)
    }
  }).addBatch({
    'ruleCreate - create rule with valid bad rules id': {
      topic: function () {
        apiTest.post('/' + enabledSession._id + '/rule.json', {
          '_id': '41984',
          'webservice': webserviceValid.name,
          'values': {'x': 3}
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(110)
    }
  }).addBatch({
    'ruleCreate - create rule with bad webservice': {
      topic: function () {
        apiTest.post('/' + enabledSession._id + '/rule.json', {
          '_id': ruleMaxNumberOfDevices._id,
          'webservice': 'test',
          'values': {'x': 3}
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(103)
    }
  }).addBatch({
    'ruleCreate - create rule with empty values but webservice has schema': {
      topic: function () {
        apiTest.post('/' + enabledSession._id + '/rule.json', {
          '_id': ruleMaxNumberOfDevices._id,
          'webservice': webserviceValid.name,
          'values': {}
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(400)
    }
  }).addBatch({
    'ruleCreate - create rule with values but webservice doesn\'t have schema': {
      topic: function () {
        apiTest.post('/' + enabledSession._id + '/rule.json', {
          '_id': rule1._id,
          'webservice': webserviceValid.name,
          'values': {'x': 3}
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(401)
    }
  }).addBatch({
    'ruleCreate - create rule with empty values and webservice doesn\'t have schema': {
      topic: function () {
        apiTest.post('/' + enabledSession._id + '/rule.json', {
          '_id': rule2._id,
          'webservice': webserviceValid.name,
          'values': {}
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Valid club response': apiTest.response.assertValidResponse(),
      'Rule have new value and new webservice': function (response, data) { //jshint ignore:line
        assert.equal(response.body.content.rules.length, 2);
      }
    }
  }).addBatch({
    'ruleCreate - create rule with no values key': {
      topic: function () {
        apiTest.post('/' + enabledSession._id + '/rule.json', {
          '_id': rule1._id,
          'webservice': webserviceValid.name
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(5)
    }
  }).addBatch({
    'ruleCreate - create rule with no webservice key': {
      topic: function () {
        apiTest.post('/' + enabledSession._id + '/rule.json', {
          '_id': rule1._id,
          'values': {}
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(5)
    }
  }).addBatch({
    'ruleCreate - create rule with no values id': {
      topic: function () {
        apiTest.post('/' + enabledSession._id + '/rule.json', {
          'webservice': webserviceValid.name,
          'values': {}
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(5)
    }
  }).addBatch({
    'ruleCreate - create rule with valid data but bad values schema': {
      topic: function () {
        apiTest.post('/' + enabledSession._id + '/rule.json', {
          '_id': ruleMaxNumberOfDevices._id,
          'webservice': webserviceValid.name,
          'values': {'x': 'jnioe'}
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(400)
    }
  }).addBatch({
    'ruleCreate - create rule with valid data but bad values schema': {
      topic: function () {
        apiTest.post('/' + enabledSession._id + '/rule.json', {
          '_id': ruleMaxNumberOfDevices._id,
          'webservice': webserviceValid.name,
          'values': {'y': 3}
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(400)
    }
  }).addBatch({
    'ruleUpdate - create rule with valid data': {
      topic: function () {
        var self = this;
        apiTest.post('/' + enabledSession._id + '/rule.json', {
          '_id': setTagToTest._id,
          'webservice': 'core:session:sub:profile:get',
          'values': {'x': tagTest._id}
        }, function (response) {
          tmpRuleId = response.body.content.rules[0]._id;
          // Use timeout to give time to the core to load new rules (call one core -> publish on redis -> update all core..)
          setTimeout(function () {
            apiTest.get('/' + enabledSession._id + '/session/sub/profile.json', {}, function () {
              apiTest.get('/' + enabledSession._id + '/session/tag.json', {}, function (response, err) {
                apiTest.del('/' + enabledSession._id + '/rule.json', {
                  '_id': setTagToTest._id,
                  'webservice': 'core:session:sub:profile:get'
                }, function () {
                  self.callback(response, err);
                });
              });
            })
          }, 1000);
        });
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Valid club response': apiTest.response.assertValidResponse(),
      'Rule have new value and new webservice': function (response, data) { //jshint ignore:line
        assert.equal(response.body.content.tag[0], tagTest.label);
      }
    }
  }).addBatch({
    'ruleUpdate - update protorule without subruleIda': {
      topic: function () {
        var self = this;
        apiTest.post('/' + enabledSession._id + '/rule.json', {
          '_id': setTagToTest._id,
          'webservice': 'core:session:sub:profile:get',
          'values': {'x': tagTest._id}
        }, function () {
          apiTest.put('/' + enabledSession._id + '/rule.json', {
            '_id': setTagToTest._id,
            'webservice': 'core:session:sub:profile:get',
            'values': {'x': tagTest2._id}
          }, function (response, err) {
            self.callback(response, err);
          });
        });
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(666)
    }
  }).addBatch({
    'ruleUpdate - update protorule with valid data': {
      topic: function () {
        var self = this;
        apiTest.post('/' + enabledSession._id + '/rule.json', {
          '_id': setTagToTest._id,
          'webservice': 'core:session:sub:profile:get',
          'values': {'x': tagTest._id}
        }, function () {
          var sentBody = {
            '_id': setTagToTest._id,
            'webservice': 'core:session:sub:profile:get',
            'values': {'x': tagTest2._id},
            'subRuleId': tmpRuleId
          };
          apiTest.put('/' + enabledSession._id + '/rule.json', sentBody, function (err) {
            // Use timeout to give time to the core to load new rules (call one core -> publish on redis -> update all core..)
            setTimeout(function () {
              apiTest.get('/' + enabledSession._id + '/session/sub/profile.json', {}, function () {
                apiTest.get('/' + enabledSession._id + '/session/tag.json', {}, function (response, err) {
                  apiTest.del('/' + enabledSession._id + '/rule.json', {
                    '_id': setTagToTest._id,
                    'webservice': 'core:session:sub:profile:get'
                  }, function () {
                    self.callback(response, err);
                  });
                });
              });
            }, 1000);
          });
        });
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Valid club response': apiTest.response.assertValidResponse(),
      'Rule have new value and new webservice': function (response, data) { //jshint ignore:line
        assert.equal(response.body.content.tag[0], tagTest2.label);
      }
    }
  }).addBatch({
    'ruleCreate - create a rules that already exist': {
      topic: function () {
        var self = this;
        apiTest.post('/' + sessionEnabledWithoutTag._id + '/rule.json', {
          '_id': setTagToTest._id,
          'webservice': 'core:session:sub:profile:get',
          'values': {'x': tagTest2._id}
        }, function (resp) {
          apiTest.del('/' + sessionEnabledWithoutTag._id + '/rule.json', {
            '_id': setTagToTest._id,
            'subRuleId': tmpRuleId,
            'webservice': 'core:session:sub:profile:get'
          }, function (resp) {
            apiTest.get('/' + sessionEnabledWithoutTag._id + '/session/sub/profile.json', {}, function () {
              setTimeout( function() {
                apiTest.get('/' + sessionEnabledWithoutTag._id + '/session/tag.json', {}, function (resp) {
                  self.callback(resp);
                });
              },1000);
            });
          });
        });
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(209)//old:209
    }
  }).addBatch({
    'ruleCreate - create rule with valid data': {
      topic: function () {
        var self = this;
        apiTest.post('/' + enabledSession._id + '/rule.json', {
          '_id': ruleMaxNumberOfDevices._id,
          'webservice': webserviceValid1.name,
          'values': {'x': 3}
        }, function(resp){
          self.callback(resp);
        });
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(402)
    }
  }).addBatch({
    'ruleUpdate - update rule with valid data': {
      topic: function () {
        var self = this;
        apiTest.put('/' + enabledSession._id + '/rule.json', {
          '_id': ruleMaxNumberOfDevices._id,
          'webservice': webserviceValid1.name,
          'values': {'x': 10},
          'subRuleId': tmpRuleId2
        }, function () {
          apiTest.get('/' + enabledSession._id + '/rule.json?ruleId=' + ruleMaxNumberOfDevices._id, {}, self.callback);
        });
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Valid club response': apiTest.response.assertValidResponse(),
      'Rule have new value and new webservice': function (response, data) { //jshint ignore:line
        var rulesForThatWebservice = underscore.where(response.body.content.rules,
          {webservice: webserviceValid1.name});
        assert.equal(rulesForThatWebservice[0].values.x, 10);
      }
    }
  }).addBatch({
    'ruleUpdate - update rule with valid data': {
      topic: function () {
        var self = this;
        apiTest.put('/' + enabledSession._id + '/rule.json', {
          '_id': ruleMaxNumberOfDevices._id,
          'webservice': webserviceValid1.name,
          'values': {'x': 10}
        }, function () {
          apiTest.get('/' + enabledSession._id + '/rule.json?ruleId=' + ruleMaxNumberOfDevices._id, {}, self.callback);
        });
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Valid club response': apiTest.response.assertValidResponse(),
      'Rule have new value and new webservice': function (response, data) { //jshint ignore:line
        assert.equal(underscore.where(response.body.content.rules,
          {webservice: webserviceValid1.name})[0].values.x, 10);
      }
    }
  }).addBatch({
    'ruleUpdate - update rule with bad rules id': {
      topic: function () {
        apiTest.put('/' + enabledSession._id + '/rule.json', {
          '_id': '123',
          'webservice': webserviceValid1.name,
          'values': {'x': 10}
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(110)
    }
  }).addBatch({
    'ruleUpdate - update rule with bad webservice': {
      topic: function () {
        apiTest.put('/' + enabledSession._id + '/rule.json', {
          '_id': ruleMaxNumberOfDevices._id,
          'webservice': 'test',
          'values': {'x': 10}
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(103)
    }
  }).addBatch({
    'ruleUpdate - update rule with empty values but webservice has schema': {
      topic: function () {
        var self = this;
        var tmpBody= {
          '_id': ruleMaxNumberOfDevices._id,
          'webservice': webserviceValid1.name,
          'subRuleId': tmpRuleId2,
          'values': {}
        };
        apiTest.put('/' + enabledSession._id + '/rule.json', tmpBody, function(resp){
          self.callback(resp);
        });
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(400)
    }
  }).addBatch({
    'ruleUpdate - update rule with values but webservice doesn\'t have schema': {
      topic: function () {
        var self = this;
        apiTest.put('/' + enabledSession._id + '/rule.json', {
          '_id': rule1._id,
          'webservice': webserviceValid.name,
          'values': {'x': 3}
        }, function(resp) {
          self.callback(resp);
        });
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(400)
    }
  }).addBatch({
    'ruleUpdate - update rule with no values key': {
      topic: function () {
        apiTest.put('/' + enabledSession._id + '/rule.json', {
          '_id': rule1._id,
          'webservice': webserviceValid.name
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(5)
    }
  }).addBatch({
    'ruleUpdate - create rule with no webservice key': {
      topic: function () {
        apiTest.put('/' + enabledSession._id + '/rule.json', {
          '_id': rule1._id,
          'values': {}
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(5)
    }
  }).addBatch({
    'ruleUpdate - create rule with no values id': {
      topic: function () {
        apiTest.put('/' + enabledSession._id + '/rule.json', {
          'webservice': webserviceValid.name,
          'values': {}
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(5)
    }
  }).addBatch({
    'ruleUpdate - create rule with valid data but bad values schema': {
      topic: function () {
        var self=this;
        apiTest.put('/' + enabledSession._id + '/rule.json', {
          '_id': ruleMaxNumberOfDevices._id,
          'webservice': webserviceValid1.name,
          'subRuleId': tmpRuleId2,
          'values': {'x': 'jnioe'}
        }, function(resp){
          self.callback(resp);
        });
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(400)
    }
  }).addBatch({
    'ruleUpdate - create rule with valid data but bad values schema': {
      topic: function () {
        var self = this;
        apiTest.put('/' + enabledSession._id + '/rule.json', {
          '_id': ruleMaxNumberOfDevices._id,
          'webservice': webserviceValid1.name,
          'subRuleId': tmpRuleId2,
          'values': {'y': 3}
        }, function(resp){
          self.callback(resp);
        });
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(400)
    }
  }).addBatch({
    'ruleDelete - delete rule with valid data': {
      topic: function () {
        var self = this;
        apiTest.del('/' + enabledSession._id + '/rule.json', {
          '_id': ruleMaxNumberOfDevices._id,
          'webservice': webserviceValid1.name,
          'subRuleId': tmpRuleId2
        }, function (resp) {
          apiTest.get('/' + enabledSession._id + '/rule.json?ruleId=' + ruleMaxNumberOfDevices._id, {}, self.callback);
        });
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Valid club response': apiTest.response.assertValidResponse(),
      'Rule have new value and new webservice': function (response, data) { //jshint ignore:line
        assert.equal(underscore.where(response.body.content.rules, {webservice: webserviceValid1.name}).length, 0);
      }
    }
  }).addBatch({
    'ruleDelete - delete rule with bad rules id': {
      topic: function () {
        apiTest.del('/' + enabledSession._id + '/rule.json', {
          '_id': '123',
          'webservice': webserviceValid1.name,
          'values': {'x': 10}
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(110)
    }
  }).addBatch({
    'ruleDelete - delete rule with bad webservice': {
      topic: function () {
        var self = this;
        apiTest.del('/' + enabledSession._id + '/rule.json', {
          '_id': ruleMaxNumberOfDevices._id,
          'webservice': 'test',
          'values': {'x': 10}
        }, function(resp){
          self.callback(resp);
        });
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(110)
    }
  }).addBatch({
    'ruleDelete - delete rule with no webservice key': {
      topic: function () {
        apiTest.del('/' + enabledSession._id + '/rule.json', {
          '_id': rule1._id,
          'values': {}
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(5)
    }
  }).addBatch({
    'ProtoRuleGet - create Protorule with valid data': {
      topic: function () {
        apiTest.get('/' + enabledSession._id + '/rule.json?ruleId=' + ruleMaxNumberOfDevices._id, {}, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Valid club response': apiTest.response.assertValidResponse(),
      'Rule have new value and new webservice': function (response, data) { //jshint ignore:line
        assert.equal(response.body.content.rules.length, 1);
      },
      'object in response have label': apiTest.body.have('label'),
      'object in response have rules': apiTest.body.have('rules'),
      'object in response have id': apiTest.body.have('_id'),
      'object in response have sourcecode': apiTest.body.have('sourcecode'),
      'object in response have schema': apiTest.body.have('schema')
    }
  }).addBatch({
    'ProtoRuleGet - create Protorule without ruleId': {
      topic: function () {
        apiTest.get('/' + enabledSession._id + '/rule.json', {}, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Valid club response': apiTest.response.assertValidResponse(),
      'object in response have label': apiTest.body.allHave('label'),
      'object in response have id': apiTest.body.allHave('_id'),
      'object in response have sourcecode': apiTest.body.allHave('sourcecode')
    }
  }).addBatch({
    'ProtoRuleGet - create Protorule with bad ruleId': {
      topic: function () {
        apiTest.get('/' + enabledSession._id + '/rule.json?ruleId=123', {}, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(110)
    }
  }).addBatch({
    'ProtoRuleGet - create Protorule with good webserviceName': {
      topic: function () {
        apiTest.get('/' + enabledSession._id + '/rule.json?webserviceName=core:event:post', {}, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Valid club response': apiTest.response.assertValidResponse(),
      'object in response have label': apiTest.body.allHave('label'),
      'object in response have id': apiTest.body.allHave('_id'),
      'object in response have sourcecode': apiTest.body.allHave('sourcecode'),
      'body have 14 element': apiTest.body.count(14)
    }
  })/* Test to remove all rules on a protorules. Todo later...
  .addBatch({
    'ProtoRuleUpdate - update rules of protorule ': {
      topic: function () {
        apiTest.put('/' + enabledSession._id + '/protorule.json', {
          _id: ruleMaxNumberOfDevices._id,
          rules: []
        }, this.callback);
      },
      'JSON response': function (response, err) { //jshint ignore:line
        assert.equal(response.body.content.rules.length, 1);
      }
    }
  })*/.addBatch({
    'ProtoRuleUpdate - update label Protorule ': {
      topic: function () {
        apiTest.put('/' + enabledSession._id + '/protorule.json', {
          _id: ruleMaxNumberOfDevices._id,
          label: 'toto'
        }, this.callback);
      },
      'JSON response': function (response, err) { //jshint ignore:line
        assert.equal(response.body.content.label, 'toto');
      }
    }
  }).addBatch({
    'ProtoRuleUpdate - update sourcecode Protorule ': {
      topic: function () {
        var self = this;

        apiTest.post('/' + enabledSession._id + '/rule.json', {
          '_id': setTagToTest._id,
          'webservice': 'core:session:sub:profile:get',
          'values': {'x': tagTest._id}
        }, function () {
          apiTest.post('/' + enabledSession._id + '/tag.json', {
            'label': 'toto' + tagTest.label
          }, function (response) {
            var code = setTagToTest.sourcecode.replace('{{x}}', response.body.content._id);
            apiTest.put('/' + enabledSession._id + '/protorule.json', {
              _id: setTagToTest._id,
              sourcecode: code
            }, function () {
              // Use timeout to give time to the core to load new rules (call one core -> publish on redis -> update all core..)
              setTimeout(function () {
                apiTest.get('/' + enabledSession._id + '/session/sub/profile.json', {}, function () {
                  apiTest.get('/' + enabledSession._id + '/session/tag.json', {}, function (responseProfile) {
                    apiTest.del('/' + enabledSession._id + '/rule.json', {
                      '_id': setTagToTest._id,
                      'webservice': 'core:session:sub:profile:get'
                    }, function () {
                      self.callback(responseProfile);
                    });
                  });
                });
              }, 1000);
            });

          });
        });
      },
      'Error code': function (response, err) { //jshint ignore:line
        assert.equal(response.body.code, 0);
        assert.equal(response.body.content.tag[0], 'toto' + tagTest.label);
      }
    }
  }).addBatch({
    'ProtoRuleUpdate - update Protorule with schema but have many rules': {
      topic: function () {
        apiTest.put('/' + enabledSession._id + '/protorule.json', {
          _id: ruleMaxNumberOfDevices._id,
          schema: {
            'type': 'object',
            'properties': {
              'x': {
                'type': 'string',
                'required': true
              }
            }
          }
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(403)
    }
  }).addBatch({
    'ProtoRuleUpdate - update Protorule with schema and haven\'t rules': {
      topic: function () {
        apiTest.put('/' + enabledSession._id + '/protorule.json', {
          _id: rule1._id,
          schema: {
            'type': 'object',
            'properties': {
              'x': {
                'type': 'string',
                'required': true
              }
            }
          }
        }, this.callback);
      },
      'JSON response': function (response, err) { //jshint ignore:line
        assert.equal(response.body.content.schema.type, 'object');
        assert.equal(response.body.content.schema.properties.x.type, 'string');
      }
    }
  }).addBatch({
    'ProtoRuleUpdate - update Protorule with type but have many rules': {
      topic: function () {
        apiTest.put('/' + enabledSession._id + '/protorule.json', {
          _id: ruleMaxNumberOfDevices._id,
          type: 'async'
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(403)
    }
  }).addBatch({
    'ProtoRuleUpdate - update Protorule with type and haven\'t rules': {
      topic: function () {
        apiTest.put('/' + enabledSession._id + '/protorule.json', {
          _id: rule1._id,
          type: 'async'
        }, this.callback);
      },
      'JSON response': function (response, err) { //jshint ignore:line
        assert.equal(response.body.content.type, 'async');
      }
    }
  }).addBatch({
    'ProtoRuleUpdate - update Protorule with type and schema but have many rules': {
      topic: function () {
        apiTest.put('/' + enabledSession._id + '/protorule.json', {
          _id: ruleMaxNumberOfDevices._id,
          type: 'async',
          schema: {}
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(403)
    }
  }).addBatch({
    'ProtoRuleUpdate - update Protorule with schema and type and haven\'t rules': {
      topic: function () {
        apiTest.put('/' + enabledSession._id + '/protorule.json', {
          _id: rule1._id,
          type: 'async',
          schema: {
            'type': 'object',
            'properties': {
              'x': {
                'type': 'string',
                'required': true
              }
            }
          }
        }, this.callback);
      },
      'JSON response': function (response, err) { //jshint ignore:line
        assert.equal(response.body.content.type, 'async');
        assert.equal(response.body.content.schema.type, 'object');
        assert.equal(response.body.content.schema.properties.x.type, 'string');
      }
    }
  }).addBatch({
    'ProtoRuleCreate - create new Protorule ': {
      topic: function () {
        apiTest.post('/' + enabledSession._id + '/protorule.json', {
          _id: ruleMaxNumberOfDevices._id,
          label: 'Test',
          type: 'async',
          sourcecode: 'ruleCallback(null,true);',
          schema: {
            'type': 'object',
            'properties': {
              'x': {
                'type': 'string',
                'required': true
              }
            }
          }
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Valid club response': apiTest.response.assertValidResponse(),
      'object in response have label': apiTest.body.have('label'),
      'object in response have id': apiTest.body.have('_id'),
      'object in response have sourcecode': apiTest.body.have('sourcecode'),
      'object in response have type': apiTest.body.have('type'),
      'object in response have schema': apiTest.body.have('schema')
    }
  }).addBatch({
    'ProtoRuleCreate - create new Protorule without label ': {
      topic: function () {
        apiTest.post('/' + enabledSession._id + '/protorule.json', {
          _id: ruleMaxNumberOfDevices._id,
          type: 'async',
          sourcecode: 'ruleCallback(null,true);',
          schema: {
            'type': 'object',
            'properties': {
              'x': {
                'type': 'string',
                'required': true
              }
            }
          }
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(5)
    }
  }).addBatch({
    'ProtoRuleCreate - create new Protorule without sourcecode ': {
      topic: function () {
        apiTest.post('/' + enabledSession._id + '/protorule.json', {
          _id: ruleMaxNumberOfDevices._id,
          type: 'async',
          label: 'Test',
          schema: {
            'type': 'object',
            'properties': {
              'x': {
                'type': 'string',
                'required': true
              }
            }
          }
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(5)
    }
  }).addBatch({
    'ProtoRuleCreate - create new Protorule with empty sourcecode ': {
      topic: function () {
        apiTest.post('/' + enabledSession._id + '/protorule.json', {
          _id: ruleMaxNumberOfDevices._id,
          type: 'async',
          label: 'Test',
          schema: {
            'type': 'object',
            'properties': {
              'x': {
                'type': 'string',
                'required': true
              }
            }
          },
          sourcecode: ''
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(5)
    }
  }).addBatch({
    'ProtoRuleCreate - create new Protorule with empty label ': {
      topic: function () {
        apiTest.post('/' + enabledSession._id + '/protorule.json', {
          _id: ruleMaxNumberOfDevices._id,
          type: 'async',
          label: '',
          schema: {
            'type': 'object',
            'properties': {
              'x': {
                'type': 'string',
                'required': true
              }
            }
          },
          sourcecode: 'ruleCallback(null,true);'
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(5)
    }
  }).addBatch({
    'ProtoRuleCreate - create new Protorule with empty type ': {
      topic: function () {
        apiTest.post('/' + enabledSession._id + '/protorule.json', {
          _id: ruleMaxNumberOfDevices._id,
          type: '',
          label: 'Test',
          schema: {
            'type': 'object',
            'properties': {
              'x': {
                'type': 'string',
                'required': true
              }
            }
          },
          sourcecode: 'ruleCallback(null,true);'
        }, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(5)
    }
  }).addBatch({
    'ProtoRuleDelete - delete Protorule': {
      topic: function () {
        apiTest.del('/' + enabledSession._id + '/protorule.json', {_id: ruleMaxNumberOfDevices._id}, this.callback);
      },
      '1 rule has been deleted': function (response, err) { //jshint ignore:line
        assert.equal(response.body.content.deleted, 1);
      }
    }
  }).addBatch({
    'ProtoRuleDelete - delete Protorule with bad id': {
      topic: function () {
        apiTest.del('/' + enabledSession._id + '/protorule.json', {_id: 'hipzerhizpe'}, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(110)
    }
  }).addBatch({
    'ProtoRuleDelete - delete Protorule with no id': {
      topic: function () {
        apiTest.del('/' + enabledSession._id + '/protorule.json', {}, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(5)
    }
  }).addBatch({
    'ProtoRuleDelete - delete Protorule width session': {
      topic: function () {
        apiTest.del('/' + disabledSession._id + '/protorule.json', {_id: ruleMaxNumberOfDevices._id}, this.callback);
      },
      'JSON response': apiTest.response.assertValidJson(),
      'Error code': apiTest.response.errorCode(4)
    }
  }).run({
    reporter: new reporter({
      directory: __dirname + '/../results',
      filename: 'controllerRuleTest.xml',
      nocolor: nocolor
    })
  }, function () {
    process.exit();
  });
});