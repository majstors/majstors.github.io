/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

var assert = require('assert');
var http = require('http');

var apiTest = {
  general: function(method, url, data, cb) {
    'use strict';

    var req = http.request({
      host: 'localhost',
      port: Core.params.portServer,
      method: method,
      path: url,
      rejectUnauthorized: false,
      headers: {'Content-Type': 'application/json'}
    }, function(res) {
      var completeChunk = '';
      res.on('data', function(chunk) {
        completeChunk += chunk;
      });
      res.on('end', function() {
        res.body = JSON.parse(completeChunk);
        //console.log(res.body);
        cb(res);
      });
    });
    if (JSON.stringify(data) !== '{}') {
      req.write(JSON.stringify(data), null, 4);
    } else if (JSON.stringify(data) === '{}' && (method === 'POST' || method === 'PUT' || method === 'DELETE')) {
      req.write('{}');
    }
    req.end();
  },
  get: function(url, data, cb) {
    'use strict';
    apiTest.general('GET', url, data, cb);
  },
  post: function(url, data, cb) {
    'use strict';
    apiTest.general('POST', url, data, cb);
  },
  put: function(url, data, cb) {
    'use strict';
    apiTest.general('PUT', url, data, cb);
  },
  del: function(url, data, cb) {
    'use strict';
    apiTest.general('DELETE', url, data, cb);
  },
  header: {
    assertStatus: function(code) {
      'use strict';
      return function(res, b, c) { //jshint ignore:line
        assert.equal(res.statusCode, code);
      };
    }
  },
  body: {
    content: function(key, value) {
      'use strict';
      return function(res, b, c) { //jshint ignore:line
        assert.equal(res.body.content[key], value);
      };
    },
    innerContent: function(key1, key2, value) {
      'use strict';
      return function(res, b, c) { //jshint ignore:line
        if (res.body.content[key1] !== undefined) {
          assert.equal(res.body.content[key1][key2], value);
        } else {
          assert.ok(res.body.content[key1] !== undefined);
        }
      };
    },
    isNull: function() {
      'use strict';
      return function(res, b, c) { //jshint ignore:line
        assert.isNull(res.body.content);
      };
    },
    have: function(value) {
      'use strict';
      return function(res, b, c) { //jshint ignore:line
        assert.include(res.body.content, value);
      };
    },
    count: function(value) {
      'use strict';
      return function(res, b, c) { //jshint ignore:line
        assert.lengthOf(res.body.content, value);
      };
    },
    allHave: function(value) {
      'use strict';
      return function(res, b, c) { //jshint ignore:line
        Object.keys(res.body.content).forEach(function(key) {
          assert.include(res.body.content[key], value);
        });
      };
    },
    objectCount: function(value) {
      'use strict';
      return function(res, b, c) { //jshint ignore:line
        Object.keys(res.body.content).forEach(function(key) {
          assert.lengthOf(res.body.content[key], value);
        });
      };
    }
  },
  jsonTest: {
    assertValidJSON: function() {
      'use strict';
      return function(res, b) { //jshint ignore:line
        assert.ok(typeof res.body === 'object');
      };
    },
    assertJSONHead: function() {
      'use strict';
      return function(res, b, c) { //jshint ignore:line
        assert.equal(res.headers['content-type'], 'application/json');
      };
    }
  },
  response: {
    assertValidJson: function() {
      'use strict';
      return function(res, b, c) { //jshint ignore:line
        assert.ok(typeof res.body === 'object');
        assert.equal(res.headers['content-type'], 'application/json');
        assert.equal(res.statusCode, 200);
      };
    },
    assertValidResponse: function() {
      'use strict';
      return function(res, b, c) { //jshint ignore:line
        assert.equal(res.body.code, 0);
      };
    },
    errorCode: function(errorCode) {
      'use strict';
      return function(res, b, c) { //jshint ignore:line
        assert.lengthOf(res.body, 2);
        assert.include(res.body, 'code');
        assert.equal(res.body.code, errorCode);
        assert.include(res.body, 'content');
      };
    }
  }
};

module.exports = apiTest;