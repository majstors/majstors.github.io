#!/usr/bin/env node
/*
 * Copyright (C) 2013-2014 Wyplay, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Wyplay and is confidential in nature.
 * 
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Wyplay.
 */

/* global fx:true, async:true, tools:true  */
/* jshint -W098, -W106 */

var assert = require('assert');
var vows = require('vows');
var async = require('async');
var tools = require('../../lib/tools');
var fx = {};
var path = require('path');
var loadFixtures = function (params, cb) {
    'use strict';
    require(path.join(__dirname + '../../../app/bin/loadFixtures'))(params, function (err, data) {
      if (err) {
        throw err;
      }
      fx = data;
      cb(err, data);
    });
  };
var  reporter = require(__dirname + '/../../lib/vows/lib/reporters/xunitDotMatrix.js');
var isTestServer = false;
var nocolor = false;
for (var key in process.argv) {
  if (process.argv[key] === 'isTestServer=true') {
    isTestServer = true;
  }
  if (process.argv[key] === 'nocolor=true') {
    nocolor = true;
  }
}
loadFixtures({ isTestServer: isTestServer }, function () {
  'use strict';
  var rule1 = fx.mongodbStatic.rule.rule_1;
  var rule2 = fx.mongodbStatic.rule.rule_2;
  /*
     * read Rules test
     */
  async.series([
    function (callback) {
      vows.describe('Read rule').addBatch({
        'with good params': {
          topic: function () {
            Core.repository.rule.read({ _id: rule1._id }, this.callback);
          },
          'is good service': function (err, rule) {
            assert.isNull(err);
            assert.equal(JSON.stringify(rule1), JSON.stringify(rule));
          }
        }
      }).addBatch({
        'with empty params': {
          topic: function () {
            Core.repository.rule.read({}, this.callback);
          },
          'is bad service': function (err, rule) {
            assert.isNull(rule);
            assert.equal(err, 'NO_RULE');
          }
        }
      }).addBatch({
        'with bad key params': {
          topic: function () {
            Core.repository.rule.read({ _i: rule1._id }, this.callback);
          },
          'is bad service': function (err, rule) {
            assert.isNull(rule);
            assert.equal(err, 'NO_RULE');
          }
        }
      }).addBatch({
        'with bad params': {
          topic: function () {
            Core.repository.rule.read({ _id: 'Toto' }, this.callback);
          },
          'is bad service': function (err, rule) {
            assert.isNull(rule);
            assert.equal(err, 'NO_RULE');
          }
        }
      }).run({
        reporter: new reporter({
          directory: __dirname + '/../results',
          filename: 'repositoryRuleTest-1.xml',
          nocolor: nocolor
        })
      }, function () {
        callback(null, true);
      });
    },
    function (callback) {
      vows.describe('Read custom rule').addBatch({
        'with good params': {
          topic: function () {
            Core.repository.rule.readCustom({ type: rule1.type }, this.callback);
          },
          'is good service': function (err, rule) {
            assert.isNull(err);
            assert.typeOf(rule, 'array');
            assert.equal(rule.length, 12);
          }
        }
      }).addBatch({
        'with bad params': {
          topic: function () {
            Core.repository.rule.readCustom({ type: 'test' }, this.callback);
          },
          'is good service': function (err, rule) {
            assert.isNull(err);
            assert.typeOf(rule, 'array');
            assert.equal(rule.length, 0);
          }
        }
      }).addBatch({
        'with empty params': {
          topic: function () {
            Core.repository.rule.readCustom({}, this.callback);
          },
          'is good service': function (err, rule) {
            assert.isNull(err);
            assert.typeOf(rule, 'array');
            assert.equal(rule.length, Object.keys(fx.mongodbStatic.rule).length);
          }
        }
      }).addBatch({
        'with bad key params': {
          topic: function () {
            Core.repository.rule.readCustom({ te: rule1.type }, this.callback);
          },
          'is good service': function (err, rule) {
            assert.isNull(err);
            assert.typeOf(rule, 'array');
            assert.equal(rule.length, Object.keys(fx.mongodbStatic.rule).length);
          }
        }
      }).run({
        reporter: new reporter({
          directory: __dirname + '/../results',
          filename: 'repositoryRuleTest-2.xml',
          nocolor: nocolor
        })
      }, function () {
        callback(null, true);
      });
    },
    function (callback) {
      vows.describe('Read all rules').addBatch({
        'with good params': {
          topic: function () {
            Core.repository.rule.readAll(null, this.callback);
          },
          'is good service': function (err, rules) {
            assert.isNull(err);
            assert.typeOf(rules, 'array');
            assert.equal(rules.length, Object.keys(fx.mongodbStatic.rule).length);
          }
        }
      }).run({
        reporter: new reporter({
          directory: __dirname + '/../results',
          filename: 'repositoryRuleTest-3.xml',
          nocolor: nocolor
        })
      }, function () {
        callback(null, true);
      });
    },
    function (callback) {
      vows.describe('Create rule').addBatch({
        'with good params': {
          topic: function () {
            Core.repository.rule.create({
              label: 'Test',
              type: 'Test',
              sourcecode: 'Test'
            }, this.callback);
          },
          'is good service': function (err, rule) {
            assert.isNull(err);
            assert.equal(rule.label, 'Test');
            assert.equal(rule.type, 'Test');
            assert.equal(rule.sourcecode, 'Test');
            assert.typeOf(rule._id, 'string');
          }
        }
      }).run({
        reporter: new reporter({
          directory: __dirname + '/../results',
          filename: 'repositoryRuleTest-4.xml',
          nocolor: nocolor
        })
      }, function () {
        callback(null, true);
      });
    },
    function (callback) {
      vows.describe('Update rule').addBatch({
        'with good params': {
          topic: function () {
            Core.repository.rule.update({
              _id: rule1._id,
              type: 'Test'
            }, this.callback);
          },
          'is good service': function (err, rule) {
            var ruleAssert = tools.clone(rule1);
            ruleAssert.type = 'Test';
            assert.isNull(err);
            assert.equal(JSON.stringify(ruleAssert), JSON.stringify(rule));
          }
        }
      }).addBatch({
        'with empty params': {
          topic: function () {
            Core.repository.rule.update({}, this.callback);
          },
          'is good service': function (err, rule) {
            assert.isNull(err);
            assert.isNull(rule);
          }
        }
      }).addBatch({
        'with bad params': {
          topic: function () {
            Core.repository.rule.update({
              _id: 'TestUpdate',
              type: 'sync'
            }, this.callback);
          },
          'is good service': function (err, rule) {
            assert.isNull(err);
            assert.isNull(rule);
          }
        }
      }).addBatch({
        'with bad keys params': {
          topic: function () {
            Core.repository.rule.update({
              _d: rule1._id,
              type: 'TestUpdate'
            }, this.callback);
          },
          'is good service': function (err, rule) {
            assert.isNull(err);
            assert.isNull(rule);
          }
        }
      }).run({
        reporter: new reporter({
          directory: __dirname + '/../results',
          filename: 'repositoryRuleTest-5.xml',
          nocolor: nocolor
        })
      }, function () {
        callback(null, true);
      });
    },
    function (callback) {
      vows.describe('Delete rule').addBatch({
        'with good params': {
          topic: function () {
            var self = this;
            Core.repository.rule.delete({ _id: rule1._id }, function (err, rules) {
              Core.repository.rule.read({ _id: rule1._id }, self.callback);
            });
          },
          'is good service': function (err, rule) {
            assert.isNull(rule);
            assert.equal(err, 'NO_RULE');
          }
        }
      }).addBatch({
        'with bad params': {
          topic: function () {
            Core.repository.rule.delete({ _id: 'testDelete' }, this.callback);
          },
          'is good service': function (err, rule) {
            assert.isNull(err);
            assert.equal(rule, 0);
          }
        }
      }).addBatch({
        'with good params': {
          topic: function () {
            Core.repository.rule.delete({ _id: rule2._id }, this.callback);
          },
          'is good service': function (err, rule) {
            assert.isNull(err);
            assert.equal(rule, 1);
          }
        }
      }).addBatch({
        'with bad key params': {
          topic: function () {
            Core.repository.rule.delete({ _i: rule2._id }, this.callback);
          },
          'is good service': function (err, rule) {
            assert.isNull(err);
            assert.equal(rule, 0);
          }
        }
      }).addBatch({
        'with empty params': {
          topic: function () {
            Core.repository.rule.delete({}, this.callback);
          },
          'is good service': function (err, rule) {
            assert.isNull(err);
            assert.equal(rule, 0);
          }
        }
      }).run({
        reporter: new reporter({
          directory: __dirname + '/../results',
          filename: 'repositoryRuleTest-6.xml',
          nocolor: nocolor
        })
      }, function () {
        callback(null, true);
      });
    }
  ], function () {
    process.exit();
  });
});
