<?php

$fh_lang = array(
  1  => 'Janvier',
  2  => 'F�vrier',
  3  => 'Mars',
  4  => 'Avril',
  5  => 'Mai',
  6  => 'Juin',
  7  => 'Juillet',
  8  => 'Ao�t',
  9  => 'Septembre',
  10 => 'Octobre',
  11 => 'Novembre',
  12 => 'D�cembre',
  13 => 'La date indiqu�e n\'est pas valable!',
  14 => 'La valeur donn�e est non-valable!',
  15 => 'Les mots de garde ne sont pas la m�me chose!',
  16 => 'Ces terrains sont obligatoires!',
  17 => 'Le mot de garde doit �tre au moins %d signes long!',
  18 => 'Le mot de garde comprend les signes non-valables!',
  19 => 'Ce terrain remplit uniquement si vous voulez transf�rer la valeur existante (<a href="%path%%filename%" target="_blank">%filename%</a>)<br />',
  20 => 'Le suivant extensive a uniquement �t� autoris�: %s.',
  21 => 'Le geuploade fichier existe d�j�!',
  22 => 'Ce terrain est obligatoire!',
  23 => 'La hauteur de fichier maximale de %s kb a �t� d�pass�e!',
  24 => 'Il y a quelque chose erreur est all�e, essaye de nouveau!',
  25 => '<small>Ces terrains remplissent uniquement si vous voulez modifier votre vieux mot de garde</small>',
  26 => 'Submit',
  27 => 'Reset',
  28 => 'Annulent',
  29 => 'Disponible',
  30 => 'S�lectionn�s',
  31 => 'Le geuploade fichier a un type de fichier non-valable!',
  32 => 'Le format de la plaquette peut les dimensions %d x %d avoir maximalement ! Le geuploade fichier a les dimensions %d x %d.',
  33 => 'Parce que un terrain est non- bien rempli, vous devez de nouveau s�lectionner le fichier <b>%filename%</b> pour envoyer le!<br />',
  34 => 'S�lectionner un item afin de d�placer vers le %s le terrain ou doublement le clic pour d�placer tous items',
  35 => 'Ce champ doit �tre unique. La valeur "%s" allready existe dans la base de donn�es!'
);

?>
  