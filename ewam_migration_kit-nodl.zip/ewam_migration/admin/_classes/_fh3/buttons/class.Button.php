<?php

/**
* class Button 
*
* Create a button on the given form
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/04 13:08:55 $
*
*/
class Button {
    var $_oForm;
    var $_sName;
    var $_sExtra;
    var $_sCaption;
    var $_iTabIndex;

    /**
     * Button::Button()
     *
     * Public Constructor: create a new Button object
     *
     * @param object $form: the form where the button is located on
     * @param string $name: the name of the button
     * @return void
     */
    function Button(&$oForm, $sName) {
        // set the button name and caption
        $this->_oForm    =& $oForm;
        $this->_sName    =& $sName;            
    }    
    
    /**
     * Field::setTabIndex()
     *
     * Public: set the tabindex of the field
     *
     * @param int $iIndex
     * @return void
     */
    function setTabIndex( $iIndex ) {
        $this->_iTabIndex = $iIndex;
    }

    
    /**
     * Button::setCaption()
     *
     * Public: Set the caption of the button
     *
     * @param string $caption: The caption of the button
     * @return void
     */
    function setCaption($sCaption) {
        $this->_sCaption = $sCaption;
    }
    
    /**
     * Button::getButton()
     *
     * Public: Return the HTML of the button
     *
     * @return string: the button
     */
    function getButton() {
        return 
        '<input '.
        'type="button" '.
        'name="'.$this->_sName.'" '.
        'id="'.$this->_sName.'" '.
        'value="'.$this->_sCaption.'" '.
        (isset($this->_sExtra) ? $this->_sExtra.' ':'').
        (isset($this->_iTabIndex) ? ' tabindex="'.$this->_iTabIndex.'" ' : '').
        '/>';        
    }
    
    /**
     * Button::setExtra()
     *
     * Public: set extra tag information, like CSS or Javascript
     *
     * @param string $extra: the CSS, JS or other extra tag info
     * @return void
     */
    function setExtra($sExtra) {
        $this->_sExtra = $sExtra;
    }
}


?>