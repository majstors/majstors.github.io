<?php 

/**
* class fhMailer
*
* Mail the form data and uploaded files...
*
* Created by: T. Heimans
* Revision: $Date: 2005/04/30 09:51:02 $
*/
class fhMailer {    
    var $_headers;
    var $_boundary;
    var $_attachments;
    var $_mailData;

    /**
     * fhMailer::fhMailer()
     *
     * Constructor: set the mail data (to, subject, etc)
     *
     * @param array $mailData
     * @return 
     */
    function fhMailer( $mailData ) {
        $this->_mailData   = $mailData;
        $this->_attachments = array();
        $this->_boundary = '_formhandler_mail_boundary_';
        $this->_headers = array(
          'From'         => 'FormHandler <info@formhandler.nl',
          'MIME-Version' => '1.0',
          'Content-Type' => "multipart/mixed; boundary=\"$this->_boundary\""
        );
    }

    /**
     * fhMailer::_getHeader()
     *
     * Convert the values in the header array into the correct format.
     *
     * @param String $headers: possible headers set by the user
     * @return string
     */
    function _getHeader( $headers ) {
        
        $items = explode("\n", $headers);
        foreach( $items as $line ) {
            if( !empty($line) && strpos($line, ':') !== false ) {
                list( $name, $value ) = explode(':', $line, 1);
                $this->_headers[$name] = $value;
            }
        }
        $unique = array();
        
        $result = '';
        foreach($this->_headers as $key => $value) {
            $id = strtolower( trim( $key) );
            if(!in_array( $id, $unique )) {
                $result .= "$key: $value\n";
                $unique[] = $id;
            }
        }

        return $result;
    }

    /**
     * fhMailer::attachFile()
     *
     * Attach a file to the message.
     *
     * @param String $sFile: The path to the file
     * @return boolean
     */
    function attachFile( $sFile )  {       
        
        if(!($fd = fopen($sFile, 'rb'))) {
            return false;
        }
        
        $data = fread($fd, filesize($sFile));
        fclose($fd);
        
        // get the mime type op the file
        if( function_exists('mime_content_type') ) {
            $sType = mime_content_type( $sFile );
        } else {
            // get the extension and get the type from the 
            $fp = explode( '.', basename($sFile) );
            $sExtension = strtolower( $fp[ count($fp) -1 ] );
            
            $aMimeData = unserialize( FH_MIME_DATA );
            
            if(isset($aMimeData[$sExtension])) {
                $sType = $aMimeData[$sExtension][0];
            } else {
                trigger_error(
                  "Error, could not retrieve mime type of file $sFile.\n".
                  "Please contact the FormHandler Crew and include the file you have uploaded.\n",
                  E_USER_WARNING
                );
                return false;
            }  
        }
        
        $sFname = basename( $sFile );       

        // Convert to base64 becuase mail attachments are not binary safe.
        $data = chunk_split(base64_encode($data));
    
        $this->_attachments[$sFile]  = "\n--" . $this->_boundary . "\n";
        $this->_attachments[$sFile] .= "Content-Type: $sType; name=\"$sFname\"\n";
        $this->_attachments[$sFile] .= "Content-Transfer-Encoding: base64\n";
        $this->_attachments[$sFile] .= "Content-Disposition: attachment; " .
                                         "filename=\"$sFname\"\n\n";
        $this->_attachments[$sFile] .= $data;

        return true;
    }

    /**
     * fhMailer::sendMail()
     *
     * Send the headers and body using php's built in mail.
     *
     * @param array $aFormData: array with all the form's fields and there values
     * @return void
     */
    function sendMail( $aFormData ) {// $to = "root@localhost", $subject = "Default Subject") {
        
        // walk the form data and generate the message
        $sMessage = '';
        foreach( $aFormData as $sField => $mValue ) {
            $sMessage .= $sField . ': ';
            // is the value a array (like checkboxes)
            if( is_array($mValue) ) {
                // sum the items
                if(sizeof( $mValue) > 1) {                          
                    $sMessage .= "\n";
                    foreach ( $mValue as $sItem ) {
                        $sMessage .= " - ".$sItem."\n";
                    }
                } else {
                    $sMessage .= $mValue[0]."\n";
                }
            } else {
                $sMessage .= $mValue ."\n";
            }
            $sMessage .= "\n";
        }
        
        // Set the content type to text/plain for the text message.
        // 7bit encoding is simple ASCII characters, this is default.
        $body  = "\n--" . $this->_boundary . "\n";
        $body .= "Content-Type: text/plain\n";
        $body .= "Content-Transfer-Encoding: 7bit\n\n";
        $body .= $sMessage;
        
        foreach($this->_attachments as $tblck) {
            $body .= $tblck;
        }
        
        $body .= "\n--$this->_boundary--";
        
        foreach( $this->_mailData as $aItems ) {
            list( $to, $subject, $sHeaders ) = $aItems;
            
            mail($to, $subject, $body, $this->_getHeader($sHeaders));
        }        
    }
}
?>