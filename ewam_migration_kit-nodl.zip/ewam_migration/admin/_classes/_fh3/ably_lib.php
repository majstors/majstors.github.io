<?php

function ably_options($O) {
	global $DBCON;

	if (is_array($O)) return $O;

	$C = explode(":",$O);
	$P = explode(",",$C[1]);
	$R = array();

	switch ($C[0]) {
		case "RANGE":
			for ($i=$P[0];$i<$P[1];$i++) $R[]=$i;
			break;

		case "LIST":
			$R = $P;
			break;

		case "REL":
			$P = explode("->", $C[1]);
			$tP = $DBCON->select_to_array($P[0],"{$P[0]}.{$P[1]} as KeyField,{$P[2]} as ValueField","ORDER BY $P[2]");
			if (isset( $P[3] )) $R[] = $P[3];
			foreach ($tP as $K=>$V) {
				$R[$V["KeyField"]] = $V["ValueField"];
			}
			break;


		case "Q":
			$tP = $DBCON->query_to_array($C[1]);
			//		print $C[1];
			foreach ($tP as $K=>$V) {
				$R[$V["KeyField"]] = $V["ValueField"];
			}
			break;
		case "QQ":
			$tP = $DBCON->query_to_array($C[1]);
			foreach ($tP as $K=>$V) {
				$R[$V["Field"]] = $V["Field"];
			}
			break;

		case "_Q":
			$R = array("","--- select from this list or upload ---");
			$tP = $DBCON->query_to_array($C[1]);
			//		print $C[1];
			foreach ($tP as $K=>$V) {
				$R[$V["KeyField"]] = $V["ValueField"];
			}
			break;
			
		case "_DIR":
			$R = array(""=>"--- select from this list or upload ---");

			$R = array_merge($R, options_dir_list(urldecode($C[1]),true));

//			print_a($R);
			
			break;

		case "VALLIST":
			foreach ($P as $K=>$V) { $R[$V]=$V; }
			break;
		default:
			break;


		default:
			break;
	}

	return $R;

}

function options_dir_list($D, $LetterBegin=false) {

//	print $D;
	
	$options=array();

	if (!file_exists($D)) { return $options; }

	$handle = opendir($D);
	while ($file = readdir($handle)) {
		if ($file != "." AND $file != "" AND $file != ".." AND !is_dir($D . $file)) {
			if ($LetterBegin && substr($file,0,1)!="_"  && substr($file,0,1)!="!" && substr($file,0,1)!=".") {
				$options[$file]=$file;
			}
		}
	}
	closedir($handle);
	
//	print_a ($options);
	
	return $options;
}


function optionsAreKeys($O) {
	$R = array();
	foreach ($O as $K=>$V) {
		$R[$V] = $V;
	}
	return $R;
}

?>