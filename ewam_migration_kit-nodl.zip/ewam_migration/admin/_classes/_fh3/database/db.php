<?php

/**
* class fh_db
*
* Abstract database class
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/17 07:24:40 $
*/
class fh_db {
    var $_db;          // string: contains the database name
    var $_table;       // string: contains the table name
    var $_keys;        // array: contains the primary keys
    var $_isConnected; // boolean: do we have a connection ?
    var $_quoteNumbers;// boolean: do we have to quote numbers?
    
    /**
     * fh_db::fh_db()
     *
     * Public abstract constructor: store the db and table name and 
     * make sure that we have some pr.keys to work with
     *
     * @param string $db: the database we are using
     * @param string $table: the table we are using
     * @param mixed $keys: one ore more keys used with the table
     * @return void
     */
    function fh_db( $db, $table, $keys = null ) {
        $this->_db           = $db;
        $this->_table        = $table;   
        $this->_isConnected  = false;
        $this->_quoteNumbers = false; 
               
        
        // make sure that we have a pr. key
        if( is_string( $keys ) ) {
            $this->_keys = array( $keys );
        } else if( is_array( $keys ) ) {
            $this->_keys = $keys;
        } else if( !is_null($keys)) {
            trigger_error(
              'Unknown type given as key: '.$keys,
              E_USER_WARNING
            );
        }   
    } 
    
    /**
     * fh_db::getPrKey()
     *
     * Public: return the keys used in the table
     *
     * @return array
     */
    function getPrKey() {
        if( is_null($this->_keys) || is_array($this->_keys) && sizeof($this->_keys) <= 0 ) {
            $this->setPrKey( $this->fetchKeys() );
        }  
                
        return $this->_keys;
    }
    
    /**
     * fh_db::isConnected()
     *
     * Public: return if we have a connection or not
     *
     * @return boolean
     */
    function isConnected() {
        return $this->_isConnected;
    }
    
    /**
     * fh_db::setPrKey()
     *
     * Public: function to set the primary keys 
     *
     * @param mixed $key
     * @return void
     */
    function setPrKey( $key ) {
        if( func_num_args() > 1 ) {
            $a = func_get_args();
            foreach( $a as $key ) {
                $this->setPrKey( $key );
            }
        } else {
            if( is_string( $key ) && !empty( $key ) ) {
                $this->_keys = array( $key );
            } else if( is_array( $key ) ) {
                $this->_keys = array_merge($this->_keys, $key);
            } else {
                trigger_error(
                  'Error, unknown value for key: '.$key,
                  E_USER_WARNING
                );  
            }            
        }
        return;
    }
    
    /**
     * fh_db::_loadData()
     *
     * Public: return the data of the given record
     *
     * @param mixed $record: string or array with the record we are editing
     * @return array of false on failure
     */
    function loadData( $record ) {        
        
        // make sure that this is an array
        if(!is_array($record)) $record = array( $record );
        
        $query = 'SELECT * FROM `'.$this->_table.'` '.$this->_getWhereClause( $record );
        
        $this->query( $query );
        
        return $this->getRecord();
    }
    
    /**
     * fh_db::saveData()
     *
     * Public: save the data given by FormHandler
     *
     * @param array $data: the data we have to save into the database (data from the form)
     * @param array $sqlFields: array of the field names with data are SQL functions
     * @param boolean $edit: was the form an edit field or not ? (Update or insert the data?)
     * @param boolean $id: if the form was a edit form, what record was edited?
     * @return array: the id of the record which was edited / updated
     */
    function saveData( $data, $sqlFields = array(), $edit = false, $id = null) {
        
        $query = $this->_getQuery( $data, $sqlFields, $edit, $id);
        
        // die( $query ); # debug
        
        // execute the query
        $this->query( $query );
        
        return $edit ? $id : $this->getInsertId();
    }
    
    
    /**
     * fh_db::_getQuery()
     *
     * Private: create a query from the data of the form
     *
     * @param array $data: the data we have to save into the database (data from the form)
     * @param array $sqlFields: array of the field names with data are SQL functions
     * @param boolean $edit: was the form an edit field or not ? (Update or insert the data?)
     * @param boolean $id: if the form was a edit form, what record was edited?
     * @return string: the query which is generated
     */
    function _getQuery( $data, $sqlFields = array(), $edit = false, $id = null ) {
        // get the column names of the table
        if(method_exists( $this, 'getFieldNames')) {
            $fields = $this->getFieldNames();
        } else {    	            
            $this->query('SELECT * FROM `'.$this->_table.'`');
            $row    = $this->getRecord();
            $fields = array_keys( $row );
        }
        
        // walk the data from the form
        foreach($data as $field => $value) {
        	
        	// not in field list? remove the data (we dont need it)
            if(!in_array($field, $fields)) {
                unset( $data[$field] );
            } else {
                // is the value an array? Implode it!
            	if(is_array($value)) $value = implode(', ', $value);
            	
            	// remove spaces etc
	            $value = trim($value);
	            
	            // is the value of the field a SQL field? Then don't quote it!
                if(! in_array($field, $sqlFields) ) {
                    $value = $this->escapeString( $value );
                    if( preg_match("/^-?([0-9]*\.?[0-9]+)$/", $value)) {
                        if( $this->_quoteNumbers ) {                         
                            $value = "'".$value."'";
                        }
                    } else {
                        $value = "'".$value."'";
                    }
                    $data[$field] = $value;
                }
            }
        }        
        
        // generate the query
        if(!$edit) {
            $query = 
            "INSERT INTO `".$this->_table."` (`".
            implode('`, `', array_keys($data))."`) VALUES (".
            implode(', ', $data).")";            
        } else {
            $query = "UPDATE `".$this->_table."` SET ";
            foreach($data as $field => $value) {
                $query .= " `".$field."` = ".$value.", ";
            }            
            $query = substr($query, 0, -2) . $this->_getWhereClause( $id );
        }
        
        return $query;        
    }
    
    /**
     * fh_db::getTable()
     *
     * Public: return the default table
     *
     * @return string
     */
    function getTable() {
        return $this->_table;
    }
    
    // when the unique fields cannot be retrieved, this function will not be overwritten.
    function fetchUniqueFields() {
        return array();
    }
    
    function fetchKeys() {
        trigger_error(
          'Error, abstract function '.__FUNCTION__.' has not been overwritten by class '.get_class( $this ), 
          E_USER_WARNING
        );
    }
    
    function recordCount() {
        trigger_error(
          'Error, abstract function '.__FUNCTION__.' has not been overwritten by class '.get_class( $this ), 
          E_USER_WARNING
        );
    }
    
    function escapeString() {
        trigger_error(
          'Error, abstract function '.__FUNCTION__.' has not been overwritten by class '.get_class( $this ), 
          E_USER_WARNING
        );
    }
    
    function getRecord() {
        trigger_error(
          'Error, abstract function '.__FUNCTION__.' has not been overwritten by class '.get_class( $this ), 
          E_USER_WARNING
        );
    }
    
    function getInsertId() {
        trigger_error(
          'Error, abstract function '.__FUNCTION__.' has not been overwritten by class '.get_class( $this ), 
          E_USER_WARNING
        );
    }
    
    function query() {
        trigger_error(
          'Error, abstract function '.__FUNCTION__.' has not been overwritten by class '.get_class( $this ), 
          E_USER_WARNING
        );
    }
    
    /**
     * fh_db::getDbDate()
     *
     * Public abstract: return the date in a correct format used by the db
     *
     * @param string $date: the date in dd-mm-yyyy format
     * @return string
     */
    function getDbDate($date) {
        return $date;
    }
    
    /**
     * fh_db::_getWhereClause()
     *
     * Private: get the where clause used for the given table
     *
     * @param array $record: array with record identifiers used in the where clause
     * @return string: the where clause
     */
    function _getWhereClause( $record, $glue = '=' ) { 
        $keys = $this->getPrKey();
        
        $size1 = sizeof( $record );
        $size2 = sizeof( $keys );
        
        $data = array();
        for($i = 0; $i < ($size1 < $size2 ? $size1 : $size2); $i++ ) {
            if(preg_match("/^-?([0-9]*\.?[0-9]+)$/", $record[$i]) ) {
                if( $this->_quoteNumbers ) {                         
                    $record[$i] = "'".$record[$i]."'";
                }
            } else {
                $record[$i] = "'".$record[$i]."'";
            }
            $data[] = ' `'.$keys[$i] .'` '.$glue.' '.$record[$i].' ';
        }
        return (sizeof($data) ? ' WHERE ' . implode(' AND ', $data) : '');
    }
}

?>