<?php

/**
* class fh_postgresql
*
* PostgreSQL class
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/02 18:19:40 $
*/
class fh_postgresql extends fh_db {
    var $_conn;     // connection handler
    var $_sql;      // SQL resource
    
     
    /**
     * fh_postgresql::connect()
     *
     * Public: Make a connection with the database and
     * select the database.
     *
     * @param string host: the host to connect to
     * @param string username: the username which should be used to login
     * @param string password: the password which should be used to login
     * @return void
     */
    function connect( $host = '', $username = '', $password = '' ) {    	
        // build connection string based on internal settings. 
        $connStr = ''; 
        if(!empty($host))       $connStr .= "host=" . $host. " ";
        if(!empty($this->_db))  $connStr .= "dbname=" . $this->_db . " ";
        if(!empty($username))   $connStr .= "user=" . $username . " ";
        if(!empty($password))   $connStr .= "password=" . $password . " ";
        $connStr = trim($connStr); 
        
        $connID = pg_connect($connStr); 
        if ( $connID ) { 
            $this->_conn = $connID; 
            $this->query("set datestyle='ISO'"); 
            $this->_isConnected = true;
            return $this->_conn; 
        } 
        
        // connection failed...
        return false; 
        
    }    
    
    /**
     * fh_postgresql::getDate()
     *
     * Public: returns the right date format for this database type
     *
     * @param string $date:  the date in dd-mm-yyyy format
     * @return string
     */
    function getDbDate($date) {
        list($d, $m, $y) = explode('-', $date);
        
        return "'$y-$m-$d'";
    }    
        
    /**
     * fh_postgresql::query()
     *
     * Public: Execute the query
     *
     * @param string $query: the query
     * @return resource 
     */
    function query( $query ) {        
        $this->_sql = pg_query($this->_conn, $query); 
        
        if(!$this->_sql) {
            trigger_error('Error in query! Error: '.$this->getError().' Query: '.$query );
        } 
                 
        return $this->_sql;  
    }  
    
    /**
     * fh_postgresql::_getQuery()
     *
     * Private: overwrite the original function getQuery because PostreSQL dont allows ` in the query
     *
     * @return string 
     */
    function _getQuery( $data, $sqlFields = array(), $edit = false, $id = null ) {        
        $query = fh_db::_getQuery( $data, $sqlFields, $edit, $id );
        return str_replace('`', '', $query);
    }    

    /**
     * fh_db::_loadData()
     *
     * Public overwrite: return the data of the given record
     *
     * @param mixed $record: string or array with the record we are editing
     * @return array of false on failure
     */
    function loadData( $record ) {        
        
        // make sure that this is an array
        if(!is_array($record)) $record = array( $record );
        
        $query = 'SELECT * FROM '.$this->_table.' '.str_replace('`', '', $this->_getWhereClause( $record ));
        
        $this->query( $query );
        return $this->getRecord();
    }   
    
    /**
     * fh_postgresql::getInsertId()
     *
     * Public: get the id of the last inserted record
     *
     * @return int
     */
    function getInsertId() {
        $k = $this->fetchKeys();
        $result = pg_exec($this->_conn, "SELECT last_value FROM ".$this->_table."_".$k[0]."_seq");
		if ($result) {
			$arr = @pg_fetch_row($result,0);
			pg_freeresult($result);
			if (isset($arr[0])) return $arr[0];
		}
		return false;

    }
    
    /**
     * fh_postgresql::getError()
     *
     * Public: return the last error
     *
     * @return string
     */
    function getError() {
        return $this->_sql ? pg_result_error($this->_sql) : pg_last_error();
    }
    
    /**
     * fh_postgresql::recordCount()
     *
     * Public: return the number of records found by the query
     *
     * @return int
     */
    function recordCount( $sql = null) {
        $sql = is_null($sql) ? $this->_sql : $sql;
        return pg_numrows( $sql ); 
    }     
    
    /**
     * fh_postgresql::getRecord()
     *
     * Public: fetch a record in assoc mode and return it
     *
     * @return: assoc array or false when there are no records left
     */
    function getRecord($sql = null) {
        $sql = is_null($sql) ? $this->_sql : $sql;
        return pg_fetch_assoc($this->_sql);
    }
    
    /**
     * fh_postgresql::getFieldNames()
     *
     * Public: return the field names of the table
     *
     * @param string $table: if a table is given, this one is used. otherwise the default is used
     * @return array
     */
    function getFieldNames( $table = null ) {
        $table = is_null($table) ? $this->_table : $table;        
        $tmp   = $this->_sql;
        
        $result = array();
        
        $this->query("
          SELECT 
            a.attname    AS name,
            t.typname    AS type,
            a.attlen     AS maxlength,
            a.atttypmod  AS mod,
            a.attnotnull AS notnull,
            a.atthasdef  AS hasdefault,
            a.attnum     AS num  
          FROM 
            pg_class c, 
            pg_attribute 
            a,pg_type t 
          WHERE 
            relkind = 'r' AND 
            c.relname='".$table."' AND 
            a.attnum > 0 AND 
            a.atttypid = t.oid AND 
            a.attrelid = c.oid 
          ORDER BY a.attnum"
        );
        
        while($row = $this->getRecord()) {
            $result[] = $row['name'];
        }
        
        $this->_sql = $tmp;
        
        return $result;
    }
        
    
    /**
     * fh_postgresql::escapeString()
     *
     * Public: escape the string we are going to save from dangerous characters
     *
     * @param string $string
     * @return string
     */
    function escapeString( $string ) {
        return mysql_escape_string( $string );
    }
    
    /**
     * fh_postgresql::fetchKeys()
     *
     * Public: fetch the keys from the table 
     *
     * @return array of the keys which are found
     */
    function fetchKeys( $table = null) {
        $table = is_null($table) ? $this->_table : $table;
        
        $tmp = $this->_sql;           
        
        $this->query("
          SELECT 
            ic.relname AS index_name, 
            a.attname AS column_name,
            i.indisunique AS unique_key, 
            i.indisprimary AS primary_key 
          FROM 
            pg_class bc, 
            pg_class ic, 
            pg_index i, 
            pg_attribute a 
          WHERE 
            bc.oid = i.indrelid AND 
            ic.oid = i.indexrelid AND 
            (i.indkey[0] = a.attnum OR 
             i.indkey[1] = a.attnum OR 
             i.indkey[2] = a.attnum OR 
             i.indkey[3] = a.attnum OR 
             i.indkey[4] = a.attnum OR 
             i.indkey[5] = a.attnum OR 
             i.indkey[6] = a.attnum OR 
             i.indkey[7] = a.attnum) AND 
            a.attrelid = bc.oid AND 
            bc.relname = '".$table."'"
        );
        
        $result = array();
        while($row = $this->getRecord()) {
            if($row['primary_key'] == 't' ) {
                $result[] = $row['column_name'];
            }
        }
        
        $this->_sql = $tmp;
        
        return $result;
    }
    
    /**
     * fh_postgresql::fetchUniqueFields()
     *
     * Public: fetch the unique keys from the table 
     *
     * @return array: keys which are found
     */
    function fetchUniqueFields( $table = null) {
        $table = is_null($table) ? $this->_table : $table;
        
        $tmp = $this->_sql;           
        
        $this->query("
          SELECT 
            ic.relname AS index_name, 
            a.attname AS column_name,
            i.indisunique AS unique_key, 
            i.indisprimary AS primary_key 
          FROM 
            pg_class bc, 
            pg_class ic, 
            pg_index i, 
            pg_attribute a 
          WHERE 
            bc.oid = i.indrelid AND 
            ic.oid = i.indexrelid AND 
            (i.indkey[0] = a.attnum OR 
             i.indkey[1] = a.attnum OR 
             i.indkey[2] = a.attnum OR 
             i.indkey[3] = a.attnum OR 
             i.indkey[4] = a.attnum OR 
             i.indkey[5] = a.attnum OR 
             i.indkey[6] = a.attnum OR 
             i.indkey[7] = a.attnum) AND 
            a.attrelid = bc.oid AND 
            bc.relname = '".$table."'"
        );
        
        $result = array();
        while($row = $this->getRecord()) {
            if($row['unique_key'] == 't') {
                $result[] = $row['column_name'];
            }
        }
        
        $this->_sql = $tmp;
        
        return $result;
    }
}

?>