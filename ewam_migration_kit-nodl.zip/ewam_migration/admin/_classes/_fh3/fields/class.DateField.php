<?php

/**
* class DateField
*
* Create a datefield
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/10 18:21:59 $
*/
class DateField extends Field {
    var $_sDisplay;  // string: how to display the fields (d-m-y) or other
    var $_oDay;      // SelectField: object of the day selectfield
    var $_oMonth;    // SelectField: object of the month selectfield
    var $_oYear;     // SelectField: object of the year selectfield
    var $_sInterval; // string: interval of the year
    var $_bRequired; // boolean: if the field is required or if we have to give the option to leave this field empty
    
    /**
     * DateField::DateField()
     *
     * Public constructor: create a new datefield object
     *
     * @param object &$oForm: the form where the datefield is located on
     * @param string $sName: the name of the datefield
     * @return
     */
    function DateField(&$oForm, $sName) {        
        
        // set the default date display
        $this->setDisplay( FH_DATEFIELD_DEFAULT_DISPLAY );
        
        // set the default interval
        $this->setInterval( FH_DATEFIELD_DEFAULT_DATE_INTERVAL );
        
        // set if the field is required
        $this->setRequired( FH_DATEFIELD_DEFAULT_REQUIRED );
        
        // the day, month and year fields
        $this->_oDay   =& new SelectField($oForm, $sName.'_day');
        $this->_oMonth =& new SelectField($oForm, $sName.'_month');
        $this->_oYear  =& new SelectField($oForm, $sName.'_year');
        
        $this->Field( $oForm, $sName );
    }
    
    /**
     * DateField::setRequired()
     *
     * Public: set if the datefield is required or if we have to give the user 
     * the option to select empty value
     *
     * @param boolean $bStatus: the status
     * @return void
     */
    function setRequired( $bStatus ) {
        $this->_bRequired = $bStatus;
    }
    
    /**
     * DateField::setDisplay()
     *
     * Public: set the display of the fields 
     * (use d,m and y for positioning, like "d-m-y", or "y-m-d" )
     *
     * @param string $sDisplay: how we have to display the datefield (day-month-year combination)
     * @return void
     */
    function setDisplay( $sDisplay ) {    	 
        $this->_sDisplay = str_replace('y', 'Y', strtolower( $sDisplay ));
    }
    
    /**
     * DateField::setInterval()
     *
     * Public: set the year range of the years 
     * The interval between the current year and the years to start/stop. 
     * Default the years are beginning at 90 yeas from the current. It is also possible to have years in the future. 
     * This is done like this: "90:10" (10 years in the future).    
     *
     * @param string/int $sInterval: the interval we should use
     * @return
     */
    function setInterval( $sInterval ) {
        $this->_sInterval = $sInterval;
    }
    
    /**
     * DateField::setExtra()
     *
     * Public: set some extra tag information of the fields
     *
     * @param string $sExtra: The extra information to inglude with the html tag
     * @return void
     */
    function setExtra( $sExtra ) {
    	$this->_oDay->setExtra   ( $sExtra );
    	$this->_oMonth->setExtra ( $sExtra );
    	$this->_oYear->setExtra  ( $sExtra );
    }
    
    /**
     * DateField::getValue()
     *
     * return the value of the field (in d-m-Y format!)
     *
     * @return string: the current value of the field
     */
    function getValue() { 
        $d = $this->_oDay->getValue();
        $m = $this->_oMonth->getValue();
        $y = $this->_oYear->getValue();
        
        if( !empty($d) && !empty($m) && !empty($y) && ($d != 0 || $m != 0 || $y != 0 ) ) { 
            return str_replace(
              array('d', 'm', 'y'),
              array($d, $m, $y),
              strtolower( $this->_sDisplay )
            );
        } else {
            return null;
        }
    }   
    
    /**
     * DateField::isValid()
     *
     * Check if the date is valid (eg not 31-02-2003)
     *
     * @return boolean: true if the field is correct, false if not
     */
    function isValid() {
    	// first of al check if the date is right when a valid date is submitted
    	// (but only when all fields are displayed (d m and y in the display string!)
    	if( strpos( $this->_sDisplay, 'd') !== false &&
    	    strpos( $this->_sDisplay, 'm') !== false &&
    	    strpos( $this->_sDisplay, 'Y') !== false &&    	    
            !checkdate( 
              $this->_oMonth->getValue(),
              $this->_oDay->getValue(), 
              $this->_oYear->getValue()
            )) 
        {                
            return $this->_oForm->_text( 13 );                        
        } 

    	// if validator given, check the value with the validator
    	if(isset($this->_sValidator) && !empty($this->_sValidator)) {
    		return Field::isValid();
    	} 
    	
    	return true;            
    } 
    
    /**
     * DateField::getField()
     *
     * return the field
     *
     * @return string: the field
     */
    function getField() {
        // set the date when the field is empty,
    	// its not an edit form, the form is not posted already and the field
    	// is required 
    	if( !$this->_oForm->isPosted() && !$this->_oForm->edit && $this->getValue() == null && $this->_bRequired ) {
    		// set the current date if wanted    
    		if( FH_DATEFIELD_SET_CUR_DATE ) {
    			$this->setValue( date('d-m-Y') );
    		} else {
    			$this->setValue( date('01-01-Y') );
    		}
    	}
    	
        $sInterval = $this->_sInterval;
        // get the year interval for the dates in the field
        if(strpos($sInterval, ':')) {
             list( $iStart, $iEnd ) = explode( ':', $sInterval, 2 );
        } elseif( is_string($sInterval) || is_integer($sInterval) && !empty($sInterval) ) {
            $iStart = $sInterval;
            $iEnd = 0;
        } else {
            $iStart = 90;
            $iEnd = 0;
        }        
        
        // get the days, months and years
        $aDays = array();
        if(!$this->_bRequired) {
            $aDays['00'] = '';
        }
        for($i = 1; $i <= 31; $i++) {
            $aDays[sprintf("%02d", $i)] = sprintf("%02d", $i);
        }
        
        $aMonths = array(
          '01' => $this->_oForm->_text( 1 ),
          '02' => $this->_oForm->_text( 2 ),
          '03' => $this->_oForm->_text( 3 ),
          '04' => $this->_oForm->_text( 4 ),
          '05' => $this->_oForm->_text( 5 ),
          '06' => $this->_oForm->_text( 6 ),
          '07' => $this->_oForm->_text( 7 ),
          '08' => $this->_oForm->_text( 8 ),
          '09' => $this->_oForm->_text( 9 ),
          '10' => $this->_oForm->_text( 10 ),
          '11' => $this->_oForm->_text( 11 ),
          '12' => $this->_oForm->_text( 12 ) 
        );
        if(!$this->_bRequired) {
            $aMonths['00'] = '';
            ksort($aMonths);
        }        
        
        $aYears = array();
        if(!$this->_bRequired) {
            $aYears['0000'] = '';
        }
        for($i = date('Y') - intval($iStart); $i <= date('Y') + intval($iEnd); $i++) {
            $aYears[$i] = $i;
        }
        
        $this->_oDay->setOptions   ( $aDays );
        $this->_oMonth->setOptions ( $aMonths );
        $this->_oYear->setOptions  ( $aYears );
        
        // make sure that the fields are not replacing other fields characters
        $sDisplay = str_replace(
          array('d','m','y'),
          array('%d%','%m%','%y%'),
          strtolower($this->_sDisplay)
        );  
        
        return str_replace(
          array('%d%','%m%','%y%'),
          array(
            ' '.$this->_oDay->getField().' ',
            ' '.$this->_oMonth->getField().' ',
            ' '.$this->_oYear->getField().' '
          ),
          $sDisplay          
        );  
    }
    
    /**
     * DateField::setValue()
     *
     * Set the value of the field. The value can be 3 things:
     * - "d-m-Y" like 02-04-2004
     * - "Y-m-d" like 2003-12-24
     * - Unix timestamp like 1104421612
     *
     * @param string $sValue: the time to set the current value
     * @return void
     */
    function setValue( $sValue ) {        
                           
        $aData = explode('-', $sValue);
        
        // 3 "-" found ? ?
        if(sizeof($aData) == 3) {
            // Y-m-d ?
            if(strlen($aData[0]) == 4) {
                $y = $aData[0];
                $m = $aData[1];
                $d = $aData[2];
            } 
            // d-m-Y
            else {                
                $y = $aData[2];
                $m = $aData[1];
                $d = $aData[0]; 
            }                   
            $this->_oDay->setValue( $d );
            $this->_oMonth->setValue( $m );
            $this->_oYear->setValue( $y );
             
        } elseif(strlen($aData[0]) >= 8 && Validator::IsDigit($aData[0]) ) {
            // the given value is a timestamp
            $this->_oDay->setValue( date("d", $aData[0]) );
            $this->_oMonth->setValue( date("m", $aData[0]) );
            $this->_oYear->setValue( date("Y", $aData[0]) );
        } else {
        	// if not three "-" are found, set the current time
            $f = trim( strtolower( preg_replace('/[^dmy]/i', '', $this->_sDisplay) ) );
            switch( $f ) {
            	case 'd':
            	  $d = $aData[0];
            	  break;
            	case 'm':
            	  $m = $aData[0];
            	  break;
            	case 'y':
            	  $y = $aData[0];
            	  break;
            	case 'dm':
            	  $m = $aData[1];
            	  $d = $aData[0];
            	  break;
            	case 'dy':
            	  $d = $aData[0];
            	  $y = $aData[1];
            	  break; 
            	case 'md': 
            	  $m = $aData[0];
            	  $d = $aData[1];
            	  break;
            	case 'my':  
            	  $m = $aData[0];
            	  $y = $aData[1];
            	  break;
            	case 'yd':
            	  $d = $aData[1];
            	  $y = $aData[0];
            	  break;
            	case 'ym':  
            	  $m = $aData[1];
            	  $y = $aData[0];
            	  break;
            }
            
            $this->_oDay->setValue  ( isset($d) ? $d : date('d') );
            $this->_oMonth->setValue( isset($m) ? $m : date('m') );
            $this->_oYear->setValue ( isset($y) ? $y : date('Y') );
        }
    }    
}

?>