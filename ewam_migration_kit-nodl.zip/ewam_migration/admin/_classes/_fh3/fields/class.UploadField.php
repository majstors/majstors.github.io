<?php

/**
* class UploadField
*
* File uploads handler class
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/22 17:36:56 $
*/
class UploadField extends Field {

    var $_aConfig;           // array: which contains the default upload config
    var $_bAlertOverwrite;   // boolean: display a message when the file allready exists
    var $_sFilename;         // string: filename of the file
    
    
    /**
     * UploadField::UploadField()
     *
     * Public constructor: Create a new UploadField object
     *
     * @param object &$oForm: The form where this field is located on
     * @param string $sName: The name of the field
     * @param array $aConfig: The config array
     * @return void
     */
    function UploadField( &$oForm, $sName, $aConfig ) {
        $this->_bAlertOverwrite = true;
        
        // check if there are spaces in the fieldname
        if(strpos($sName,' ') !== false) {
            trigger_error('Warning: There are spaces in the field name "'.$sName.'"!', E_USER_WARNING );
        }
        
        // set the config file
        $aDefault = unserialize( FH_DEFAULT_UPLOAD_CONFIG );
        $this->_aConfig = array_merge( $aDefault, $aConfig );   
        
        // add slash to the end of the pathname if it does not have allready
        $l = substr($this->_aConfig['path'], -1);
        if($l != '\\' && $l != '/') {     
            $this->_aConfig['path'] .= '/';
        }
        
        // if no size is given, get the max uploadsize
        if(empty($this->_aConfig['size'])) {
            $this->_aConfig['size'] = $this->_getMaxUploadSize();
        }
        
        $this->_oForm =& $oForm;  
        $this->_sName =& $sName;
        
        // get the value of the field
        if( $oForm->isPosted() ) 
        {            
            // make sure that the $_POST array is global
            if(!_global) global $_FILES;
            
            // get the value if it exists in the $_FILES array
            if( isset( $_FILES[$sName] ) ) {
                $this->_mValue = $_FILES[$sName];
                if( $this->isUploaded() ) {
                	$this->setValue( $this->_getFilename( ) );
                } else {
					// if this is an edit form and no value is given to the field, 
					// keep the existing value thats in the database
					if( $oForm->edit && isset( $oForm->_dbData[$sName] ) ) {
						$this->setValue( $oForm->_dbData[$sName] );
					}
				}
            }  
        // load database value if exists    
        } else if( $oForm->edit ) {
            if( isset( $oForm->_dbData[$sName] ) ) {
                $this->setValue( $oForm->_dbData[$sName] );
            }
        } 
        
        // if no file is uploaded and it is a edit form, dont overwrite the current value
        if(!$this->isUploaded() && $oForm->edit && $oForm->isPosted()) {
            $this->_oForm->_dontSave[] = $sName;    
        }
    }  
    
    /**
      * UploadField::setValue()
      *
      * Public: Set the value of the field (the filename of the uploaded file)
      *
      * @param string $sFilename: The filename of the value 
      * @return void
      */ 
    function setValue( $sFilename ) { 
        $this->_sFilename = $sFilename;
    }
    
    /**
     * UploadField::getSavePath()
     *
     * Public: return the path were we are going to save the file
     *
     * @return string: the path where the file is saved
     */
    function getSavePath() {
        return $this->_aConfig['path'];
    }        
    
    /**
     * UploadField::getValue()
     *
     * Public: return the current value
     *
     * @return string: the current file
     */
    function getValue() {
        return $this->_sFilename;
    }
    
    /**
     * UploadField::isUploaded()
     *
     * Public: Check if there is a file uploaded or not
     *
     * @return boolean
     */
    function isUploaded() {
        return ($this->_oForm->isPosted() && $this->_mValue['error'] != 4);
    }
    
    /**
     * UploadField::getField()
     *
     * Public: return the HTML of the field
     *
     * @return string: the html of the field
     */
    function getField() {
        static  $bSetJS = false;
        
        // alert the user if the image allready exists ?
        $sMsg = '';
        if($this->_bAlertOverwrite && !empty($this->_sFilename) && empty($this->_sError)) {
			
            // edit form and the field got a value ?
            if( $this->_oForm->edit && !empty($this->_sFilename) )
            //isset( $this->_oForm->_dbData[$this->_sName] ) )
            {
                // display "overwrite" message
            	$sMsg = str_replace(
            	  array('%path%', '%filename%'),
            	  array(
            	    str_replace($_SERVER['DOCUMENT_ROOT'], '', $this->_aConfig['path']), 
            	    (!empty($this->_mValue['name']) ? $this->_mValue['name'] :$this->_sFilename)
            	  ),
            	  $this->_oForm->_text( 19 )
            	);
            }
            // Correct ?
            else if( $this->_oForm->isPosted() && !$this->_oForm->isCorrect() )
            {
            	$sMsg = sprintf(FH_ERROR_MASK, str_replace('%filename%', $this->_sFilename, $this->_oForm->_text( 33 )) );
            }
        }
        
        // set the javascript upload checker if wanted
        $sJs = '';
        if(FH_UPLOAD_JS_CHECK && $this->_aConfig['type'] != '*') {
        	// needed javascript included yet ?
	        if(!$bSetJS) {
	            $bSetJS = true;
	            $sJs = "<script language='javascript' type='text/javascript' src='".FH_FHTML_DIR."js/extensionCheck.js' ></script>\n";
	        }
        
	        $aMatch = array();
            if(isset($this->_sExtra) && preg_match("/onchange([ ]*)=([ ]*)('|\")(.*)$/i", $this->_sExtra, $aMatch)) {
                // put the function into a onchange tag if set
                $sStr = str_replace($aMatch[3], ( ($aMatch[3]=="'") ? '"' : "'" ), "checkUpload(this, '".$this->_aConfig['type']."', '".$this->_oForm->_text( 20 )."');");
                $this->_sExtra = preg_replace("/onchange([ ]*)=([ ]*)('|\")(.*)$/i", "onchange=\\3$sStr\\4", $this->_sExtra);
            } else {
                $this->_sExtra = "onchange=\"checkUpload(this, '".$this->_aConfig['type']."', '".$this->_oForm->_text( 20 )."')\" ".$this->_sExtra;
            }
        }
            
        return 
        $sMsg . $sJs .         
        '<input '.
        'type="file" '.
        'name="'.$this->_sName.'" '.
        'id="'.$this->_sName.'" '.
        (isset($this->_iTabIndex) ? ' tabindex="'.$this->_iTabIndex.'" ' : '').
        (isset($this->_sExtra) ? $this->_sExtra.' ':'').        
        '/>';
    }
    
    /**
     * UploadField::setAlertOverwrite()
     *
     * Public: set if we have to alert when the file allready exists
     *
     * @param boolean $bStatus: The status to set
     * @return void
     */
    function setAlertOverwrite( $bStatus) {
        $this->_bAlertOverwrite = $bStatus;
    } 
    
    /**
     * UploadField::isValid()
     *
     * Public: Check if the value is valid
     *
     * @return bool: check if the value is valid
     */
    function isValid() {
        // is a own error handler used?
        if(isset($this->_sValidator) && !empty($this->_sValidator) ) {
            return Field::isValid();
        } 
        
        // easy name to work with (this is the $_FILES['xxx'] array )
        $aFile =& $this->_mValue; 
        
        // detect error type if php version is older then 4.2.0 (make the errors the same)
        if($aFile['tmp_name'] == 'none' && empty($aFile['name'])) {
            $aFile['error'] = 4;
        } elseif($aFile['tmp_name'] == 'none' && !empty($aFile['name'])) {
            $aFile['error'] = 2;
        } elseif(!isset($aFile['error'])) {
            $aFile['error'] = 0;
        }
        
        // alert when file exists ? (and is a file uploaded ?)
        if($this->_aConfig['exists'] == 'alert' && $aFile['error'] != 4) {
            // does the file exists ?
            if( file_exists( $this->_aConfig['path'] . $this->_getFilename(true) ) ) {
                $this->_sError = $this->_oForm->_text( 21 );
            }
        }
        
        //  check if the field is required
        if(is_bool($this->_aConfig['required']) && $this->_aConfig['required'] && $aFile['error'] == 4 && empty($this->_sFilename) ) {
            $this->_sError = $this->_oForm->_text( 22 );
        } elseif(strtolower(trim($this->_aConfig['required'])) == 'true' && $aFile['error'] == 4 && empty($this->_sFilename)) {
            $this->_sError = $this->_oForm->_text( 22 );
        }
            
        // if a file is uploaded...
        elseif($aFile['error'] != 4)  {
            // to to big?
            if( isset($aFile['error']) &&
                ($aFile['error'] == 1 ||
                 $aFile['error'] == 2 ||
                 $aFile['size'] > $this->_aConfig['size']))
            {
                $this->_sError = sprintf( $this->_oForm->_text( 23 ), round($this->_aConfig['size'] / 1024, 2) );
                return false;
            }
            
            // is the extension correct ?
            $sExt = $this->_getExtension( $this->_mValue['name'] );
            if($this->_aConfig['type'] != '*' && !in_array( $sExt , explode(' ', strtolower($this->_aConfig['type'])))) {
                $this->_sError = sprintf( $this->_oForm->_text( 20 ), $this->_aConfig['type']);
            }

            // does build in function exists ?
            // if so, get the type of the mime from that function (more secure)
            // otherwise, use the one from the browser
//            $sType = function_exists('mime_content_type') ? mime_content_type( $aFile['tmp_name'] ) : $aFile['type'];
			$sType = $aFile['type'];
            
            // mime data
            $aMimeData = unserialize( FH_MIME_DATA );
            
            // debug!
            //echo "Mime type of uploaded file: <b>$sType</b><br />\n";
            //echo "Extension known: <b>". (isset( $aMimeData[$sExt] ) ? "true":"false")."</b><br />\n";
            //if(isset( $aMimeData[$sExt] )) 
            //foreach( $aMimeData[$sExt] as $mime ) echo "Mime type expected: <b>$mime</b><br />\n";
            
            // mime content check of the file            
            
            if( !isset( $aMimeData[$sExt] ) /* ||  !in_array($sType, $aMimeData[$sExt] ) */ ) {
            	$this->_sError = $this->_oForm->_text( 31 );          	            		

            } else {
                       
                // is it an image and is a max width/height given? Get the proportions
                if(ereg('^image/', $sType) && 
                  !empty($this->_aConfig['height']) || 
                  !empty($this->_aConfig['width'])) 
                {
                    
                    list($iWidth, $iHeight) = getimagesize( $aFile['tmp_name'] );                        
                    if(( (int) $this->_aConfig['height'] > 0 && $iHeight > (int) $this->_aConfig['height'] ) ||
                       ( (int) $this->_aConfig['width']  > 0 && $iWidth  > (int) $this->_aConfig['width']))
                    {
                        $this->_sError = sprintf(
                          $this->_oForm->_text( 32 ),
                          (int) $this->_aConfig['width'],
                          (int) $this->_aConfig['height'],
                          $iWidth,
                          $iHeight
                        ); 
                    }   
                }
            }
              

            // if an error occured..
            if($aFile['error'] == 3) {
                $this->_sError = $this->_oForm->_text( 24 );
            }
        }
        
        // when no error ocoured, the file is valid
        return empty($this->_sError);
    } 
    
    /**
     * UploadField::doUpload()
     *
     * Public: Upload the file
     *
     * @return string | bool: the filename of the uploaded file, or false on an 
     */
    function doUpload() {
        // alias for the file data
        $aFile =& $this->_mValue;
            
        // is a file uploaded ?
        if( !is_null($aFile['error']) && $aFile['error'] != 4) {
            if(is_uploaded_file($aFile['tmp_name'])) {
				
                // make the dir if not exists
                if(!is_dir($this->_aConfig['path'])) {
                    if(!$this->_forceDir($this->_aConfig['path'], FH_DEFAULT_CHMOD)) {
                        trigger_error(
                          "Could not upload file to dir: ".$this->_aConfig['path'].". ".
                          "The dir does not exists and trying to make the dir failed...",
                          E_USER_WARNING
                        );
                        return false;
                    }
                }
				
                // the file like where going to upload it
                $sFilename = $this->_getFilename(false, true);
                $sUpload   = $this->_aConfig['path'].$sFilename;
				
                // uploading
                if(!move_uploaded_file($aFile['tmp_name'], $sUpload))
                {
                    trigger_error(
                      sprintf( 
                        'Unable to move uploaded file %s to location %s', 
                        $aFile['tmp_name'], 
                        $sUpload 
                      ),
                      E_USER_ERROR
                    );
                    return false;
                }
                @chmod( $this->_aConfig['path'], FH_DEFAULT_CHMOD );
				
                $this->_sFilename = $sFilename;
                
                return $sUpload;
            }
            else
            {
                trigger_error(
                  sprintf(
                    'Possible file upload attack: filename %s', 
                    $aFile['name']
                  ), 
                  E_USER_WARNING
                );
                return false;
            }
        }
        return false;
    }
    
    /******* PRIVATE! *************/
    
    /**
     * UploadField::_forceDir()
     *
     * Private: create the given dir
     *
     * @param [type] {parameters}
     * @return
     */
    function _forceDir( $sPath, $iMode) {
		if ( strlen( $sPath) == 0) {
			return 0;
	    }
		if ( strlen( $sPath) < 3) {
			return 1; // avoid 'xyz:\' problem.
	    }
	    elseif ( is_dir( $sPath )) {
			return 1; // avoid 'xyz:\' problem.
	    }
	    elseif   ( dirname( $sPath) == $sPath ) {
			return 1; // avoid 'xyz:\' problem.
	    }
	 
	    return ( $this->_forceDir( dirname($sPath), $sPath) and mkdir( $sPath, $iMode));
	}
    
    /**
     * UploadField::_getFilename()
     *
     * Private: get the filename like we are going to save it
     *
     * @param boolean $bIgnoreRename: Ignore the rename option ?
     * @return string: the filename 
     */
    function _getFilename( $bIgnoreRename = false ) {
        // easy name to work with
        $sFile = $this->_mValue['name'];        
        
        // get the extension of the uploaded file
        $sExt = $this->_getExtension( $sFile );
        
        // use the given filename if wanted
        if(!empty($this->_aConfig['name'])) {
            $sFile = $this->_aConfig['name'].'.'.$sExt;
        }
        
        // replace not wanted caracters
        $sFile = ereg_replace('[^a-z0-9._]', '',
            str_replace(
                array(' ', '%20', '.'.$sExt),
                array('_', '_', ''),
                StrToLower($sFile)
            )
        );
        
        // rename when wanted
        if(strtolower($this->_aConfig['exists']) == 'rename' && !$bIgnoreRename) {                         
            $sPath = $this->_aConfig['path'];

            $sCopy = '';
            $i = 1;
            while (
              // file exists or ...
              file_exists($sPath.$sFile.$sCopy.'.'.$sExt) || 
              // other uploadfield has registered this filename ...
              !$this->_oForm->_registerFileName( $sPath.$sFile.$sCopy.'.'.$sExt, $this->_sName)) 
            {
                // then get a new filename
                $sCopy = '('.$i++ .')';
            }
            return $sFile.$sCopy.'.'.$sExt;
        } else {
            return $sFile.'.'.$sExt;
        }
    }
    
    /**
     * UploadField::_getExtension()
     *
     * Private: retrieve the extension of the given filename
     *
     * @param string $sFilename: The filename where we have to retrieve the extension from
     * @return string: the extension
     */
    function _getExtension( $sFilename ) {
        $fp = explode( '.', $sFilename );
        return strtolower( $fp[ count($fp) -1 ] );
    }  
    
    /**
     * UploadField::_getMaxUploadSize()
     *
     * Private: get the max uploadsize
     *
     * @return integer: the max upload size
     */
    function _getMaxUploadSize() {
        static $iIniSize = false;

        if(!$iIniSize) {
            $iPost = intval($this->_iniSizeToBytes(ini_get('post_max_size')));
            $iUpl  = intval($this->_iniSizeToBytes(ini_get('upload_max_filesize')));
            $iIniSize = floor(($iPost < $iUpl) ? $iPost : $iUpl);
        }
        return $iIniSize;
    }  
    
    /**
     * UploadField::_iniSizeToBytes()
     *
     * Private: get the given size in bytes
     *
     * @param string $sIniSize: The size we have to make to bytes
     * @return integer: the size in bytes
     */
    function  _iniSizeToBytes( $sIniSize )
	{
		$aIniParts = array();
		if (!is_string($sIniSize)) {
			trigger_error("Argument A is not a string! dump: ".$sIniSize, E_USER_NOTICE);
			return false;
		}
		if (!preg_match ('/^(\d+)([bkm]*)$/i', $sIniSize, $aIniParts)) {
			trigger_error("Argument A is not a valid php.ini size! dump: ".$sIniSize, E_USER_NOTICE);
			return false;
		}

		$iSize = $aIniParts[1];
		$sUnit = strtolower($aIniParts[2]);

		switch($sUnit) {
			case 'm':
				return (int)($iSize * 1048576);
			case 'k':
				return (int)($iSize * 1024);
			case 'b':
			default:
				return (int)$iSize;
		}
	}
    
}

?>