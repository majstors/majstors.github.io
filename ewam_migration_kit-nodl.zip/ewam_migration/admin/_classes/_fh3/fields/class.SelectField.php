<?php

/**
* class SelectField
*
* Create a SelectField
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/04 13:08:55 $
*/
class SelectField extends Field 
{
    var $_aOptions;              // array: the options of the selectfield
    var $_bUseArrayKeyAsValue;   // boolean: if the keys of the array should be used as values
    var $_iSize;                 // integer: set the size of the field
    var $_bMultiple;             // boolean: can multiple items be selected or not?  
    
    /**
     * SelectField::SelectField()
     *
     * Public constructor: Create a selectfield object 
     *
     * @param object $oForm: The form where the field is located on
     * @param string $sName: The name of the form
     * @return void
     */
    function SelectField( &$oForm, $sName ) {
        // call the constructor of the Field class
        $this->Field( $oForm, $sName );
        
        $this->setSize( 1 );        
        $this->useArrayKeyAsValue( FH_DEFUALT_USEARRAYKEY );
        $this->setMultiple( false );
    }    
    
    /**
     * SelectField::getField()
     *
     * Public: return the HTML of the field
     *
     * @return string: the html
     */
    function getField() {
        // multiple selected items possible?
        $aSelected = array();
        if($this->_bMultiple) {
            if( isset( $this->_mValue) ) {
                if( !is_array( $this->_mValue ) ) {
                    $aItems = explode(',', $this->_mValue );
                    foreach( $aItems as $mItem ) {
                        $aSelected[] = trim( $mItem );
                    }
                } else {
                    $aSelected += $this->_mValue;
                }
            }
        } else if( isset($this->_mValue ) ) {
            $aSelected[] = $this->_mValue;
        }            
        
        // create the options list
        $sOptions = '';
        foreach ($this->_aOptions as $iKey => $sValue ) {
            if(!$this->_bUseArrayKeyAsValue) {
                $iKey = $sValue;
            }
            
            if( strpos($iKey, 'LABEL') ) {
                $sOptions .= "\t<optgroup label=\"". $sValue."\">\n";
            } else {
                $sOptions .= 
                "\t<option ".
                'value="'.$iKey.'"'.
                (in_array( $iKey, $aSelected ) ?' selected="selected"':'').
                '>'.$sValue."</option>\n";
            }
        }
        
        if(empty($sOptions)) {
        	$sOptions = "\t<option />\n\t";
        }
        
        return 
        '<select '.
        'name="'.$this->_sName. ( $this->_bMultiple ? '[]':'').'" '.
        'id="'.$this->_sName.'" '.
        'size="'.$this->_iSize.'"'.
        (isset($this->_sExtra) ? ' '.$this->_sExtra.' ' :'').
        ($this->_bMultiple ? ' multiple="multiple" ' : '' ).
        (isset($this->_iTabIndex) ? ' tabindex="'.$this->_iTabIndex.'" ' : '').
        ">\n".$sOptions.
        '</select>';
    }
    
    /**
     * SelectField::setOptions()
     *
     * Public: set the options of the field
     *
     * @param array $aOptions: the options for the field
     * @return void
     */
    function setOptions( $aOptions ) {
        $this->_aOptions = $aOptions;
    }
    
    /**
     * SelectField::setMultiple()
     *
     * Public: set if multiple items can be selected or not
     *
     * @param boolean $bMultiple
     * @return void
     */
    function setMultiple( $bMultiple ) {
        $this->_bMultiple = $bMultiple;
    }
    
    /**
     * SelectField::setSize()
     *
     * Public: set the size of the field
     *
     * @param integer $iSize: the new size
     * @return void
     */
    function setSize( $iSize ) {
        $this->_iSize = $iSize;
    }
    
    /**
     * SelectField::useArrayKeyAsValue()
     *
     * Public: Set if the array keys of the options has to be used as values for the field
     *
     * @param boolean $bMode: The mode
     * @return void
     */
    function useArrayKeyAsValue( $bMode ) {        
        $this->_bUseArrayKeyAsValue = $bMode;
    }
}

?>