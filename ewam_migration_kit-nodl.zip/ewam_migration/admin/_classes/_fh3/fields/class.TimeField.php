<?php


/**
* class TimeField
*
* Create a new TimeField class
*
* Created by: T. Heimans
* Revision: $Date: 2005/04/30 09:51:01 $
*/
class TimeField extends Field {
    var $_iFormat;   // integer: hour format: {12, 24}
    var $_oHour;     // SelectField: object of the hour selectfield
    var $_oMinute;   // SelectField: object of the minute selectfield
    var $_bRequired; // boolean: if the field is required or if we have to give the option to leave this field empty
    
    /**
     * TimeField::TimeField()
     *
     * Public constructor: create a new TimeField on the given form
     *
     * @param object $oForm: The form where the field is located on
     * @param string $sName: The name of the field
     * @return void
     */
    function TimeField( &$oForm, $sName ) {       
        
        // set the default hour format
        $this->setHourFormat( FH_TIMEFIELD_DEFAULT_HOUR_FORMAT );
        
        // set if the field is required
        $this->setRequired( FH_TIMEFIELD_DEFAULT_REQUIRED );
        
        // make the hour and minute fields
        $this->_oHour   =& new SelectField($oForm, $sName.'_hour');
        $this->_oMinute =& new SelectField($oForm, $sName.'_minute');
        
        $this->Field( $oForm, $sName );
        
        // posted or edit form? Then load the value of the time
        if( $oForm->isPosted() || $oForm->edit ) {
            $this->_mValue = $this->_oHour->getValue().':'.$this->_oMinute->getValue();
        } 
    }    
    
    /**
     * TimeField::setExtra()
     *
     * Public: set some extra tag information of the fields
     *
     * @param string $sExtra: The extra information to inglude with the html tag
     * @return void
     */
    function setExtra( $sExtra ) {
    	$this->_oHour->setExtra  ( $sExtra );
    	$this->_oMinute->setExtra( $sExtra );
    }
    
    /**
     * TimeField::setHourFormat()
     *
     * Public: set the hour format (eg. 12 or 24)
     *
     * @param integer $iFormat: The hour format
     * @return void
     */
    function setHourFormat( $iFormat ) {
        if($iFormat == 12 || $iFormat == 24) {
            $this->_iFormat = $iFormat;
        } else {
        	trigger_error("Invalid value as hour format! Only 12 or 24 are allowed!", E_USER_WARNING);
        }
    }
    
    /**
     * TimeField::setRequired()
     *
     * Public: set if the timefield is required or if we have to give the user 
     * the option to select an empty value
     *
     * @param boolean $bStatus: The status 
     * @return void
     */
    function setRequired( $bStatus ) {
        $this->_bRequired = $bStatus;
    }
    
    
    /**
     * TimeField::setValue()
     *
     * Public: set the value of the field
     *
     * @param string $sValue: The new value of the field 
     * @return void
     */
    function setValue( $sValue ) {
    	if(strpos($sValue,':') !== false) {
            list($sHour, $sMinute) = explode(':', $sValue);
            $this->_oHour->setValue   ( $sHour );
            $this->_oMinute->setValue ( $sMinute );
            $this->_mValue = $sValue;
        } 
    }
    
    /**
     * TimeField::getValue()
     *
     * Public: return the current value of the field
     *
     * @return string: the value of the field
     */
    function getValue() {
        if($this->_oHour->getValue() == '' && $this->_oMinute->getValue() == '') {
            return '';
        } else {
        	$this->_mValue = $this->_oHour->getValue().':'.$this->_oMinute->getValue();
            return $this->_mValue;
        }
    }   
    	   
    
    /**
     * TimeField::getField()
     *
     * Public: return the HTML of the field
     *
     * @return string: the html of the field
     */
    function getField() {
    	
    	// set the currect time if wanted
        if( !$this->_oForm->isPosted() && 
            !$this->_oForm->edit && 
            $this->_bRequired && 
            $this->getValue() == '' &&
            FH_TIMEFIELD_SET_CUR_TIME) 
        {
        	$h   = date('H');
        	$cur = date('i');
        	
        	// get the nearest value at the minutes...
        	for($i = 0; $i < $cur; $i += FH_TIMEFIELD_MINUTE_STEPS);
        	$i = abs( $cur - $i ) < abs( $cur - ($i - FH_TIMEFIELD_MINUTE_STEPS)) ? $i : ($i - FH_TIMEFIELD_MINUTE_STEPS);
        	if($i == '60') {
        		$i = '0';
        		$h++;
        		if($h == 24) {
        			$h = 0;
        		} 
        	}
        	
        	$this->setValue( $h.':'.$i );
        }
        
        $aHours = array();
        if(!$this->_bRequired) {
            $aHours[''] = '';
        }
        for($i = 0; $i <= ($this->_iFormat-1); $i++ ) {
            $aHours[sprintf("%02d", $i)] = sprintf("%02d", $i);
        }
        
        $aMinutes = array();
        if(!$this->_bRequired) {
            $aMinutes[''] = '';
        }
        $i = 0;
        while($i <= 59) {
            $aMinutes[sprintf("%02d", $i)] = sprintf("%02d", $i);
            $i += FH_TIMEFIELD_MINUTE_STEPS;
        }
        
        $this->_oHour->setOptions  ( $aHours );
        $this->_oMinute->setOptions( $aMinutes );
        
        return 
          $this->_oHour->getField() . "<b> : </b>" .
          $this->_oMinute->getField();
    }
}

?>