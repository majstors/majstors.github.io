<?php

/**
* class ListField
*
* Create a listfield on the given form
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/01 18:52:21 $
*/
class ListField extends Field  
{
    var $_aOptions;             // Array: the options of the selectfield 
    var $_oHidden;              // HiddenField: the fielf where the value is saved in
    var $_oOn;                  // SelectField: the field where the items are displayed which are "on"
    var $_oOff;                 // SelectField: the field where the items are displayed which are "off"
    var $_sOnTitle;             // String: the title used for the on section
    var $_sOffTitle;            // String: the title used for the off section
    var $_bUseArrayKeyAsValue;  // Boolean: if the keys of the array should be used as values
    
    /**
     * ListField::ListField()
     *
     * Public constructor: Create a new ListField
     *
     * @param object &$oForm: The form where this field is located on
     * @param string $sName: The name of the field
     * @param array  $aOptions: The options of the field     
     * @return void
     */
    function ListField(&$oForm, $sName, $aOptions) {
    	$this->_mValue = array();
    	
    	// set the options
        $this->_aOptions = $aOptions;
    	
        $this->Field( $oForm, $sName, $aOptions );
        
        // make the fields of the listfield
        $this->_oHidden =& new HiddenField($oForm, $sName);        
        $this->_oOn     =& new SelectField($oForm, $sName.'_ListOn');
        $this->_oOff    =& new SelectField($oForm, $sName.'_ListOff');
        $this->_oOn->setMultiple ( true );
        $this->_oOff->setMultiple( true );
        
        // set some default values
        $this->useArrayKeyAsValue ( FH_DEFUALT_USEARRAYKEY );
        $this->setSize	   		  ( FH_DEFAULT_LISTFIELD_SIZE );
        $this->setOffTitle 		  ( $oForm->_text( 29 ) );
        $this->setOnTitle  		  ( $oForm->_text( 30 ) );
    }
    
    /**
     * ListField::setValue()
     *
     * Public Set the value of the field
     *
     * @param array | string $aValue: The new value of the field
     * @return void
     */
    function setValue( $aValue ) {    
    	    	
    	// make an array from the value
        if(!is_array($aValue)) {
            $aValue = explode(',', $aValue);
            foreach($aValue as $iKey => $sValue) {
            	$sValue = trim($sValue);
            	
            	// dont save an empty value when it does not exists in the 
            	// options array!
            	if( !empty($sValue) ||            		      		
            	   (in_array( $sValue, $this->_aOptions ) ||
            	    array_key_exists( $sValue, $this->_aOptions )))
            	{   
            		$aValue[$iKey] = $sValue;
            	} else {
            		unset($aValue[$iKey]);
            	}
            }
        }
        
        $this->_mValue = $aValue;
    }
    
    /**
     * ListField::setExtra()
     *
     * Public: set some extra tag information of the fields
     *
     * @param string $sExtra: The extra information to inglude with the html tag
     * @return void
     */
    function setExtra( $sExtra ) {
    	$this->_oOff->setExtra ( $sExtra );
    	$this->_oOn->setExtra  ( $sExtra );
    	// $this->_oHidden->setExtra( $sExtra ); # needed ?
    }    	
    
    /**
     * ListField::setOnTitle()
     *
     * Public: Set the title of the ON selection of the field
     *
     * @param strint $sTitle: The title
     * @return void
     */
    function setOnTitle($sTitle) {
        $this->_sOnTitle = $sTitle;
    }
    
    /**
     * ListField::setOffTitle()
     *
     * Public: Set the title of the OFF selection of the field
     *
     * @param string $sTitle: The title
     * @return void
     */
    function setOffTitle($sTitle) {
        $this->_sOffTitle = $sTitle;
    }
    
    /**
     * ListField::getField()
     *
     * Public: Return the HTML of the field 
     *
     * @return string: The html
     */
    function getField() {
        static $bSetJS = false;
        
        // set the value for the hidden field
        if( !empty( $this->_mValue )) {
            $this->_oHidden->setValue( implode(', ', $this->_mValue) );      
        }
        
        // get the selected and unselected values
        $aSelected   = array();
        $aUnselected = array();
        foreach($this->_aOptions as $iIndex => $sValue) {
            $sKey = (!$this->_bUseArrayKeyAsValue) ? $sValue : $iIndex;
              
            if(in_array($sKey, $this->_mValue)) {
                $aSelected[$iIndex] = $sValue;
            } else {
                $aUnselected[$iIndex] = $sValue;
            }             
        }
        
        $this->_oOn->setOptions ( $aSelected );
        $this->_oOff->setOptions( $aUnselected );
        
        // needed javascript included yet ?
        if(!$bSetJS) {
            $bSetJS = true;
            $sJs = "<script language='javascript' type='text/javascript' src='".FH_FHTML_DIR."js/listfield.js' ></script>\n";
        } else {
            $sJs = '';
        }        
        
        return 
        $sJs . $this->_oHidden->getField()."\n".
        "  <table border='0' cellspacing='0' cellpadding='0'>\n".
        "    <tr>\n".
        "      <td align='center'><b>".$this->_sOnTitle."</b></td>\n".
        "      <td align='center'></td>\n".
        "      <td align='center'><b>".$this->_sOffTitle."</b></td>\n".
        "    </tr>\n".
        "    <tr>\n".
        "      <td rowspan='2' align='right'>\n".
        "        ".$this->_oOn->getField()."\n".
        "      </td>\n".
        "      <td width='30' align='center' valign='bottom'>\n".
        "        <input type='button' value=' &gt; ' onclick=\"changeValue('".$this->_sName."', false)\" ".
        "ondblclick=\"moveAll('".$this->_sName."', false)\" title='".sprintf( $this->_oForm->_text( 34 ), $this->_sOnTitle )."' />\n".
        "      </td>\n".
        "      <td rowspan='2'>\n".
        "        ".$this->_oOff->getField()."\n".
        "      </td>\n".
        "    </tr>\n".
        "    <tr>\n".
        "      <td align='center' valign='top'>\n".
        "        <input type='button' value=' &lt; ' onclick=\"changeValue('".$this->_sName."', true)\" ".
        "ondblclick=\"moveAll('".$this->_sName."', true)\" title='".sprintf( $this->_oForm->_text( 34 ), $this->_sOffTitle )."' />\n".
        "      </td>\n".
        "    </tr>\n".
        "  </table>\n";
    }
    
    /**
     * ListField::setSize()
     *
     * Public: Set the size (height) of the field (default 4)
     *
     * @param integer $iSize: The size
     * @return void
     */
    function setSize( $iSize ) {
        $this->_oOn->setSize ( $iSize );
        $this->_oOff->setSize( $iSize );
    }
    
    /**
     * ListField::useArrayKeyAsValue()
     *
     * Public: Set if the array keys of the options has to be used as values for the field
     *
     * @param boolean $bMode: The mode
     * @return void
     */
    function useArrayKeyAsValue( $bMode ) {
        $this->_bUseArrayKeyAsValue = $bMode;
        $this->_oOn->useArrayKeyAsValue  ( $bMode );
        $this->_oOff->useArrayKeyAsValue ( $bMode );
    }
}

?>