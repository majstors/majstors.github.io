<?php

/**
* class TextArea
*
* Create a textarea
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/04 13:08:55 $
*/
class TextParts extends Field {
    
   
    /**
     * TextParts::TextParts()
     *
     * Public constructor: create a new textarea
     *
     * @param object &$oForm: The form where this field is located on
     * @param string $sName: The name of the field
     * @return void
     */
    function TextParts( &$oform, $sName ) {
        // call the constructor of the Field class
        $this->Field( $oform, $sName );
    }
    
    
    /**
     * TextArea::getField()
     *
     * Public: return the HTML of the field
     *
     * @return string: the html of the field
     */
    function getField() {
        return 
        '<textarea '.
        'name="'.$this->_sName.'" '.
        'id="'.$this->_sName.'" '.
        (isset($this->_sExtra) ? ' '.$this->_sExtra :'').'>'.        
        (isset($this->_mValue) ? htmlspecialchars($this->_mValue) : '').
        '---</textarea>';
    }
}

?>