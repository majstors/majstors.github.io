                    <div id="article_intro">
                        <h2><?php echo $M->aIntroPage['title']; ?></h2>
                        <img src="/img/articles/panel_jegricka.jpg"/>
                        <p>
                            <?php echo $M->truncateHTML($M->aIntroPage['content'], 200); ?>
                        </p>
                        <a href="/<?php echo "{$M->sLang}/{$M->aIntroPage['page_url']}"; ?>" class="more_about"/><?php echo $M->getTextBox('READMORE'); ?> &gt;</a>
                    </div>
                    <div id="phase_intro">
                        <h2><?php echo $M->aMenu[$M->aAnalisysPageID]['title']; ?></h2>
                        <ul id="phase_list" style="list-style: none">
                            <li id="phase_item_1" style="list-style: none">
                                <a href="#"><?php echo $M->getTextBox('PHASE'); ?> 1</a>
                                <p class="pdflink"><a href="/downloads/report_phase_I.pdf"><span><?php echo $M->getTextBox('DOWNLOADPDF'); ?></span></a></p>
                            </li>
                            <li id="phase_item_2" style="list-style: none">
                                <a href="#"><?php echo $M->getTextBox('PHASE'); ?> 2</a>
                                <p class="pdflink"><a href="/downloads/report_phase_II.pdf"><span><?php echo $M->getTextBox('DOWNLOADPDF'); ?></span></a></p>
                            </li>
                        </ul>
                    </div>