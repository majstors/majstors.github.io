﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN" "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>eWAM - <?php echo $M->aPage['title']; ?></title>
        <meta name="title" content="eWAM" />        
        <meta name="description" content="eWAM" />
        <link rel="stylesheet" href="/css/reset.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="/css/style.css?ac=<?php echo md5(time()); ?>" type="text/css" media="screen" />
        <link rel="stylesheet" href="/css/menu7.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="/css/bjqs.css" type="text/css" media="screen" />
    </head>
    <body class="">
        <div id="topbar">
            <div class="pw">
                <div id="topbar_title">
                    <?php echo $M->getTextBox('HEADLINE'); ?>
                </div>
                <div id="functions_nav">
                    <ul>
                        <?php foreach ($M->aLangs as $K => $V): ?>
                            <li><a href="/<?php echo $V['page_url']; ?>"><?php echo strtoupper($V['title']); ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
        <div id="logobar">
            <div class="pw">
                <div id="logo_left"><a href="http://www.hu-srb-ipa.com"><img src="/img/hun_srb_logo_<?php echo strtolower($M->sLang); ?>.png"/></a></div>
                <div id="logo_center">
                    <a href="#"><img src="/img/ewam_logo.png"/></a><br/>
                    Ref. br. HUSRB/1203/121/237                    
                </div>
                <div id="logo_right"><a href="http://europa.eu/"><img src="/img/eu_logo_<?php echo strtolower($M->sLang); ?>.png"/></a></div>
            </div>
        </div>
        <div id="menu_bar">
            <div class="pw">
                <div id="home_link" style="float: left"><a href="/<?php echo "{$M->sLang}"; ?>"><img src="/img/icons/home.png"/></a></div>
                <div id="menu7" style="float: left">
                    <ul class="menu-top">
                        <?php foreach ($M->aMenu as $K => $V): ?>
                            <li>
                                <?php
                                $sAttrURL = ($V['layout'] != 'folder') ?
                                        "href=\"/{$M->sLang}/{$V['page_url']}\"" :
                                        "href=\"#\" onclick=\"return false;\"";
                                ?>
                                <a <?php echo $sAttrURL; ?> class="menu-button<?php echo ( isset($V['subpages']) ) ? ' menu-drop' : ''; ?>"><span class="menu-label"><?php echo $V['title']; ?></span></a>
                                <?php if (isset($V['subpages'])): ?>
                                    <div class="menu-dropdown menu-dropdown1">
                                        <ul class="menu-sub">

                                            <?php foreach ($V['subpages'] as $K1 => $V1): ?>
                                                <li><a href="/<?php echo "{$M->sLang}/{$V1['page_url']}"; ?>" class="menu-subbutton"><span class="menu-label"><?php echo $V1['shorten_title']; ?></span></a>
                                                    <?php if (false && $V1['shorten_title'] == 'Flajeri'): ?>
                                                        <div class="menu-dropdown menu-dropdown3">
                                                            <ul class="menu-sub">
                                                                <li><a href="#" class="menu-subbutton"><span class="menu-label">Test</span></a></li>
                                                            </ul>
                                                        </div>
                                                    <?php endif; ?>
                                                </li>
                                            <?php endforeach; ?>

                                        </ul>
                                    </div>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>  

            </div>
        </div>
        <div id="slider_bar">
            <!--
            <div class="pw" id="slider_container">
                <img src="/img/slider/jegricka_1.jpg"/>
                <div id="slider_over"><img src="/img/dobri_susedi.png"/></div>
            </div>
            -->

            <div id="slider_container" class="pw">
                <ul class="bjqs">
                    <li><img src="/img/slider/jegricka_1.jpg"/></li>
                    <li><img src="/img/slider/jegricka_2.jpg"/></li>
                    <li><img src="/img/slider/jegricka_3.jpg"/></li>
                    <li><img src="/img/slider/jegricka_4.jpg"/></li>
                    <li><img src="/img/slider/kurcsa_1.jpg"/></li>                    
                    <li><img src="/img/slider/kurcsa_2.jpg"/></li>                    
                    <li><img src="/img/slider/kurcsa_3.jpg"/></li>
                </ul>
                <div id="slider_over"><img src="/img/dobri_susedi_<?php echo strtolower($M->sLang); ?>.png"/></div>
            </div>


        </div>
        <div id="content_bar">
            <div class="pw">