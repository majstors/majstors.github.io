<?php include_once(TEMPLATES_DIR . '/components/header.php'); ?>
<div id="content_container" class="simple_page_container">
    <h1><?php echo $M->aPage['title']; ?></h2>
    <?php echo $M->aPage['content']; ?>
</div>
<div id="side_bar">
    <?php include_once(TEMPLATES_DIR . "/components/partners.php"); ?>
</div>
<br clear="all"/>
<?php include_once(TEMPLATES_DIR . '/components/footer.php'); ?>