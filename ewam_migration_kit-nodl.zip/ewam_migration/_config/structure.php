<?php

$C = array(
    
    'sr' => array(
        'ewam' => array(
            'title'=>'eWAM',
            'subpages' => array(
                'opsti-cilj' => array(
                    'title'=>'opšti cilj',
                ),
                'specificni-ciljevi' => array(
                    'title'=>'specifični ciljevi',
                ),
                'projektne-aktivnosti' => array(
                    'title'=>'Projektne aktivnosti',
                ),
                'ciljne-grupe' => array(
                    'title'=>'Ciljne grupe',
                ),
                'projektni-tim' => array(
                    'title'=>'Projektni tim',
                ),
            )
        ),
        'analiza-i-monitoring' => array(
            'title'=>'Analiza i monitoring',
            'subpages' => array(
                'faza-1' => array(
                    'title'=>'I faza pre izmuljivanja',
                ),
                'faza-2' => array(
                    'title'=>'II faza - tokom izmuljivanja',
                ),
                'faza-3' => array(
                    'title'=>'III faza - nakon izmuljivanja	',
                ),
            )
        ),
        'radovi-izmuljenja' => array(
            'title'=>'Radovi izmuljenja',
            'subpages' => array(
                'aktivnosti' => array(
                    'title'=>'Aktivnosti',
                ),
                'izvestaji' => array(
                    'title'=>'Izveštaji',
                ),
            )
        ),
        'rezultati' => array(
            'title'=>'Rezultati',
            'subpages' => array(
                'izvestaji' => array(
                    'title'=>'Izveštaji',
                ),
             ),
        ),
        'preuzimanje' => array(
            'title'=>'Preuzimanje',
            'subpages' => array(
                'flajeri' => array(
                    'title'=>'Flajeri',
                ),
                'brosura' => array(
                    'title'=>'Brošura',
                ),
            ),
        ),
        'partneri' => array(
            'title'=>'Partneri',
            'subpages' => array(
                'vode-vojvodine' => array(
                    'title'=>'JVP "Vode Vojvodine" Novi Sad',
                ),
                'fond-evropski-poslovi' => array(
                    'title'=>'Fond "Evropski poslovi" AP Vojvodine',
                ),
                'ATI-VIZIG' => array(
                    'title'=>'ATI VIZIG',
                ),
            ),
        ),
        'arhiva' => array(
            'title'=>'Arhiva',
        ),
        'kontakt' => array(
            'title'=>'Kontakt',
        ),        
    ),
    
    'en' => array(
        
    ),
    
    'hu' => array(
        
    ),    
    
)



?>
