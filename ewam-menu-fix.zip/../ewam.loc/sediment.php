<?php
include('admin/_ably_config.php');
include('ably/model.php');

if (!isset($_GET['id'])) die('Invalid parameter ID');

    print '<table class="CSSTableGenerator"><tr>';

    print "<th>Parametar</th>\n";
    print "<th>Jedinica mere</th>\n";
    print "<th>Metoda</th>\n";
    print "<th>Izmerena vr.</th>\n";
    print "<th>Korigovana vr.</th>\n";
    print "<th>Klasifikacija</th>\n";
    print "</tr>\n";


$M = new Model(false);

$iDBFaza = $_GET['faza'];
$aData = $M->getSedimentTable($_GET['id']);

foreach($aData as $K=>$V) {
    
    print "<tr>\n";
    print "<td>" . htmlspecialchars($V['parametar']) . "</td>\n";
    print "<td>" . htmlspecialchars($V['jedinica_mere']) . "</td>\n";
    print "<td>" . htmlspecialchars($V['metoda']) . "</td>\n";
    print "<td>" . htmlspecialchars($V['izmerena_vrednost']) . "</td>\n";
    print "<td>" . htmlspecialchars($V['korigovana_vrednost']) . "</td>\n";
    print "<td>" . htmlspecialchars($V['klasifikacija']) . "</td>\n";
    print "</tr>\n";
    
}

print '</table>';

?>