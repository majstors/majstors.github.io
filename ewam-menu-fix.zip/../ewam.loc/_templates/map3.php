<?php include_once(TEMPLATES_DIR . '/components/header.php'); ?>
<div id="content_container">
    <h1><?php echo $M->aPage['title']; ?></h2>
        <div id="map"></div>

        <h1>Podaci</h1>

        <div id="tabs">
            <ul>
                <li><a href="#tab-1">Barchart sedimen.</a></li>
                <li><a href="#tab-2">Uzorci sedimen.</a></li>
                <li><a href="#tab-3">Uzorci vode</a></li>
                <li><a href="#tab-4">Param. sedimenata</a></li>
                <li><a href="#tab-5">Param. vode</a></li>
            </ul>
            <div id="tab-1">
                Parametar:<br/>
                <select name="parametar" id="parametar" style="border: 1px solid black">
                    <option name="">--izaberi parametar--</option>
                    <?php foreach ($M->getSedimentPars() as $K => $V): ?>
                        <option value="<?php echo $K; ?>"><?php echo $V; ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="button" value="Prikaz po lokacijama" id="show_graph"/>
                <hr>

            </div>
            <div id="tab-2">
                <select name="parametar" id="id_mesto_sediment" style="border: 1px solid black">
                    <option name="">--izaberi lokaciju--</option>
                    <?php foreach ($M->getSedimentMesto() as $K => $V): ?>
                        <option value="<?php echo $V['mesto']; ?>"><?php echo $V['mesto']; ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="button" value="Prikaz vrednosti parametara za lokaciju" id="show_sediment"/>
                <hr>
                <div id="contaner_tab-2" style="padding: 0"></div>
            </div>
            <div id="tab-3">
                <select name="parametar" id="id_mesto_voda" style="border: 1px solid black">
                    <option name="">--izaberi lokaciju--</option>
                    <?php foreach ($M->getVodaMesto() as $K => $V): ?>
                        <option value="<?php echo $V['mesto']; ?>"><?php echo $V['mesto']; ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="button" value="Prikaz vrednosti parametara za lokaciju" id="show_voda"/>
                <hr>
                <div id="contaner_tab-3" style="padding: 0"></div>
            </div>
            <div id="tab-4">
                <?php showParamSedimenata(); ?>
            </div>
            <div id="tab-5">
                <?php showParamVode(); ?>
            </div>

        </div>

        <div id="chart_div" style="width: 645px; height: 400px;">

        </div>


        <script type="text/javascript" src="https://www.google.com/jsapi"></script>
        <script type="text/javascript">
            var iDBFaza = <?php echo $iDBFaza; ?>;
            google.load("visualization", "1", {packages: ["corechart"]});
            google.setOnLoadCallback(init);

            function init() {
                $('#show_graph').click(function(e) {
                    iPID = $('#parametar').val();
                    $.ajax({
                        url: "/chart.php?faza=" + iDBFaza + "&id=" + iPID,
                        context: document.body
                    }).done(function(data) {
                        D = $.parseJSON(data);
                        drawChart(D.data, D.title);
                    });
                });

                $('#show_voda').click(function(e) {
                    iPID = $('#id_mesto_voda').val();
                    $.ajax({
                        url: "/voda.php?faza=" + iDBFaza + "&id=" + iPID,
                        context: document.body
                    }).done(function(data) {
                        $('#contaner_tab-3').html(data);
                        $('#contaner_tab-3').show();
                    });
                });

                $('#show_sediment').click(function(e) {
                    iPID = $('#id_mesto_sediment').val();
                    $.ajax({
                        url: "/sediment.php?faza=" + iDBFaza + "&id=" + iPID,
                        context: document.body
                    }).done(function(data) {
                        $('#contaner_tab-2').html(data);
                        $('#contaner_tab-2').show();
                    });
                });

            }


            function drawChart(aPars, sTitle) {

                /*
                 P = new Array();
                 
                 for(Q in pars) {
                 P[Q] = new Array(pars[Q]);
                 }
                 */


                var data = google.visualization.arrayToDataTable(aPars);

                /*
                 [
                 ['Lokacija', 'Mesto'],
                 ['2004',  1000],
                 ['2005',  1170],
                 ['2006',  660],
                 ['2007',  1030]
                 ]
                 */

                var options = {
                    title: sTitle
                            //hAxis: {title: 'Lokacija', titleTextStyle: {color: 'red'}}
                };

                var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
                chart.draw(data, options);
            }
        </script>





















        <script type="text/javascript">

            bDrawMap = true;

            window.onload = function() {

                $(function() {
                    $('#map').gMap({
                        latitude: 45.4536972,
                        longitude: 19.77863503,
                        zoom: 13,
                        controls: false,
                        scrollwheel: true,
                        maptype: 'TERRAIN',
                        markers: [
<?php
$aJSLocs = array();
foreach ($aLocations as $K => $V) {
    $aJSLocs[] = "
                                                   {
                                                            latitude: {$V['gps_x_float']},
                                                            longitude: {$V['gps_y_float']} ,
                                                            icon: {
                                                                image: \"/img/pointers/darkblue0{$V['name']}.png\",
                                                                iconsize: [27, 27],
                                                                iconanchor: [13, 27]
                                                            }
                                                    }
    ";
}
echo implode(', ', $aJSLocs);
?>

                        ]
                    });
                });

            }

        </script>


</div>
<div id="side_bar">
    <?php include_once(TEMPLATES_DIR . "/components/partners.php"); ?>
</div>
<br clear="all"/>
<?php include_once(TEMPLATES_DIR . '/components/footer.php'); ?>



<?php

function showParamSedimenata() {

    global $DBCON;

    print '<table class="CSSTableGenerator"><tr>';
    print "<th>Grupa parametara</th>\n";
    print "<th>Parametar</th>\n";
    print "<th>Jedinica mere</th>\n";
    print "<th>metoda</th>\n";
    print "<th>MDL</th>\n";
    print "<th>PQL</th>\n";
    print "</tr>\n";

    $aData = $DBCON->select_to_array('parametri_sedimenti', '*', 'WHERE 1=1');

    foreach ($aData as $K => $V) {
        print "<tr>\n";
        print "<td>" . htmlspecialchars($V['grupa_parametara']) . "</td>\n";
        print "<td>" . htmlspecialchars($V['parametar']) . "</td>\n";
        print "<td>" . htmlspecialchars($V['jedinica_mere']) . "</td>\n";
        print "<td>" . htmlspecialchars($V['metoda']) . "</td>\n";
        print "<td>" . htmlspecialchars($V['MDL']) . "</td>\n";
        print "<td>" . htmlspecialchars($V['PQL']) . "</td>\n";
        print "</tr>\n";
    }

    print '</table>';
}

function showParamVode() {
    global $DBCON;

    print '<table class="CSSTableGenerator"><tr>';
    print "<th>Grupa parametara</th>\n";
    print "<th>Parametar</th>\n";
    print "<th>Jedinica mere</th>\n";
    print "<th>metoda</th>\n";
    print "<th>MDL</th>\n";
    print "<th>PQL</th>\n";
    print "</tr>\n";

    $aData = $DBCON->select_to_array('parametri_voda', '*', 'WHERE 1=1');

    foreach ($aData as $K => $V) {
        print "<tr>\n";
        print "<td>" . htmlspecialchars($V['grupa_parametara']) . "</td>\n";
        print "<td>" . htmlspecialchars($V['parametar']) . "</td>\n";
        print "<td>" . htmlspecialchars($V['jedinica_mere']) . "</td>\n";
        print "<td>" . htmlspecialchars($V['metoda']) . "</td>\n";
        print "<td>" . htmlspecialchars($V['MDL']) . "</td>\n";
        print "<td>" . htmlspecialchars($V['PQL']) . "</td>\n";
        print "</tr>\n";
    }

    print '</table>';
}
?>