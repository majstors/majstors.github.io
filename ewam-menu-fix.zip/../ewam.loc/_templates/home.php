<?php include_once(TEMPLATES_DIR . '/components/header.php'); ?>
<div id="content_container">
    <?php include_once(TEMPLATES_DIR . "/components/home.php"); ?>
</div>
<div id="side_bar">
    <?php include_once(TEMPLATES_DIR . "/components/partners.php"); ?>
</div>
<br clear="all"/>
<?php include_once(TEMPLATES_DIR . '/components/footer.php'); ?>            

