                                        
<ul class="menu-sub">

    <?php foreach ($V['subpages'] as $K1 => $V1): ?>
        <li><a href="/<?php echo "{$M->sLang}/{$V1['page_url']}"; ?>" class="menu-subbutton"><span class="menu-label"><?php echo $V1['shorten_title']; ?></span></a>
            <?php if (false && $V1['shorten_title'] == 'Flajeri'): ?>
                <div class="menu-dropdown menu-dropdown3">
                    <ul class="menu-sub">
                        <li><a href="#" class="menu-subbutton"><span class="menu-label">Test</span></a></li>
                    </ul>
                </div>
            <?php endif; ?>
        </li>
    <?php endforeach; ?>

</ul>
-->