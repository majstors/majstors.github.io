<?php //include_once(TEMPLATES_DIR . '/components/home_header.php'); ?>
<div id="article_intro_wide"> 
    <?php foreach ($M->aHomeNews as $K => $V): ?>
        <h2 style="margin-top: 20px;"><?php echo $V['title']; ?></h2>
        <p class="article_date" style="line-height: 12px;"><?php echo date('d.m.Y.', strtotime($V['pubdate'])); ?></p><br clear="all"/>
        <p style="text-align: justify;margin-top: 0">
            <?php if($V['first_image']): ?>
            <img src="<?php echo $V['first_image']; ?>" class="inline_image" style="margin-right: 15px;"/>
            <?php endif; ?>
            <?php echo $M->truncateHTML(strip_tags($V['content']), 400); ?>
        </p>
        <a href="/<?php echo "{$M->sLang}/{$V['page_url']}"; ?>" class="more_about"/><?php echo $M->getTextBox('READMORE'); ?> &gt;</a>
    <br clear="all"/>
<?php endforeach; ?>
</div>
<br clear="all"/>