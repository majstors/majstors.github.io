<?php

/**
* class fh_access
*
* Microsoft Access database class. 
* This class works only on Windows!
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/02 18:19:40 $
*/
class fh_access extends fh_db {
    var $_conn;     // connection handler
    var $_rs;       // recordset
    var $_select;   // boolean: was the last executed query an SELECT query ? (Used for getRecord() )
    var $_cursor;   // integer: what was the cursor position? (Used for recordCount)
    
    /**
     * fh_access::connect()
     *
     * Public: Make a connection with the database and
     * select the database.
     *
     * @param string host: the host to connect to
     * @param string username: the username which should be used to login
     * @param string password: the password which should be used to login
     * @return void
     */
    function connect( $host = '', $username = '', $password = '' ) {    	
    	// Make connection with the database and get the primairy keys
    	// if we dont have them allready 
        $this->_conn = new COM('ADODB.Connection')
          or die(
            'Error, could not create ADODB connection with COM. '.
            'This only works on windows systems!'
          );
          
        $this->_conn->Open(
          'Provider=Microsoft.Jet.OLEDB.4.0;'.
          'Data Source='.$this->_db.';'.
          'User Id='.$username.';'.
          'Password='.$password.';'          
        );  
        
        if( $this->getError() == '' )
        {
            $this->_isConnected = true;
            return true;
        } else {
            trigger_error( 
              'Error, could not make database connection with database '. $this->_db.
              '. Error: '.$this->getError() 
            );
            return false;
        }        
    } 
    
    /**
     * fh_access::getError()
     *
     * Public: return the last eror
     *
     * @return string
     */
    function getError() {
        $errc = $this->_conn->Errors;
		if ($errc->Count == 0) return '';
		$err = $errc->Item($errc->Count-1);
		return $err->Description;
    }
    
    /**
	 * fh_access::getFieldNames()
	 *
	 * Public: retrieve the field names used in the table
	 *
	 * @param string $table: table to retrieve the field names from
	 * @return array of field names
	 */
	function getFieldNames( $table = null ) {
	    $table = strtoupper( is_null($table) ? $this->_table : $table );	    
	    $rs    = $this->_conn->OpenSchema(4);
	    
		$tbl = $rs->Fields( 2 ); 
		$fld = $rs->Fields( 3 );
	    $idx = $rs->Fields( 6 );
	    
		$result = array();
		while(!$rs->EOF){
			if (strtoupper($tbl->Value) == $table) {				
				$result[$idx->Value-1] = $fld->Value;
			}	
			$rs->MoveNext();
		}
		$rs->Close();
		
		ksort( $result );
		return $result;		
	}
	
	/**
     * fh_access::fetchKeys()
     *
     * Public: fetch the keys from the table and save
     * them in the private member _keys
     * (Get the first colum name)
     *
     * @return array: name of the first field
     */
    function fetchKeys( $table = null) {
        $table = strtoupper( is_null($table) ? $this->_table : $table );
        
        // open schema adSchemaPrimaryKeys
        $rs = $this->_conn->OpenSchema( 28 );
	    
        //
		$tbl  = $rs->Fields( 2 ); 
		$fld  = $rs->Fields( 3 );
		$idx  = $rs->Fields( 6 );
		$type = $rs->Fields( 7 );
		
		$result = array();
		while(!$rs->EOF){
			if (strtoupper($tbl->Value) == $table && strtolower($type->Value) == 'primarykey') {
				$result[$idx->Value-1] = $fld->Value;
			}	
			$rs->MoveNext();
		}
		$rs->Close();
		
		ksort( $result );
		return $result;		
    }
    
    /**
     * fh_access::getDate()
     *
     * Public: returns the right date format for this database type
     *
     * @param string $date:  the date in dd-mm-yyyy format
     * @return string
     */
    function getDbDate($date) {
        return " # $date # ";
    }    
        
    /**
     * fh_access::query()
     *
     * Public: Execute the query
     *
     * @param string $query:the query
     * @return record set 
     */
    function query( $query ) {
        // is it a select query ?
        $this->_select = (strtoupper(substr(trim($query), 0, 6)) == 'SELECT');
        $this->_cursor = 0;                  
        
        // execute the query
        $this->_rs = $this->_conn->Execute( $query ) 
          or die('Error in query. Error: '.$this->getError().'. Query: '.$query); 
             
        // request numer of columns (otherwise delete wont work :-S )         
        if(!$this->_select) {
            $this->_rs->Fields->Count;
        }            
                 
        return $this->_rs;  
    }    
    
    /**
     * fh_access::getInsertId()
     *
     * Public: get the id of the last inserted record
     *
     * @return int
     */
    function getInsertId() {
        $keys = $this->getPrKey();
        $k    = each( $keys );
        $rs   = $this->query( 
          'SELECT MAX('.$k[1].') AS id FROM '.$this->_table
        );
        reset( $this->_keys );
        $result = (!$rs->EOF)  ? $rs->Fields[0]->Value : -1;        
        $rs->Close();  
        $rs->Release();             
        return $result;
    }    
    
    /**
     * fh_access::recordCount()
     *
     * Public: return the number of records found by the query
     *
     * @return int
     */
    function recordCount() {
        // was the last query a select query ?
        if(!$this->_select) {
            trigger_error('Last executed query was not a SELECT query!', E_USER_WARNING);
            return 0;
        } 
        
        $rs =& $this->_rs;
        
        // go to the first record
        if( !$rs->BOF ) $rs->MoveFirst();
        
        // count the records
        $result = 0;
        while(!$rs->EOF) {
            $result++;
            $rs->MoveNext();
        }
        
        // go back to the record we where before calling this function
        if( !$rs->BOF ) $rs->MoveFirst();
        for($i = 0; $i < $this->_cursor; $i++ ) {
            $rs->MoveNext();
        }
        
        return $result;
    }     
    
    /**
     * fh_access::getRecord()
     *
     * Public: fetch a record in assoc mode and return it
     *
     * @return: assoc array or false when there are no records left
     */
    function getRecord() {
        $rs =& $this->_rs;
        
        // any records left to handle? 
        if(!$this->_select) {
            trigger_error('Last executed query was not a SELECT query!', E_USER_WARNING);
            return false;
        } else if( $rs->EOF) {
            $rs->Close();
            $rs->Release();
            return false;
        } else {
            $result = array();
            for( $i = 0; $i < $rs->Fields->Count; $i++ ) {
                $type  = $rs->Fields[$i]->Type;
                $value = $rs->Fields[$i]->Value;
                switch( $type ) {
                  case 1: // null value
    				$value = false;
    				break;
    			  case 6: // currency is not supported properly;
    				echo '<br /><b>'.$rs->Fields[$i]->Name.': currency type not supported by PHP</b><br />';
    				$value = (float) $value;
    				break;	
    		      case 7: // adDate
    				$value = date('Y-m-d H:i',(integer)$rs->Fields[$i]->Value);
    				break;
                  case 133:// A date value (yyyymmdd) 
    				$value = substr($value,0,4).'-'.substr($value,4,2).'-'.substr($value,6,2);
    				break;
    			}
    			
                $result[ $rs->Fields[$i]->Name ] = trim( $value );
            }
            $rs->MoveNext();
            $this->_cursor++;
            
            return $result;
        }         
    }
    
    /**
     * fh_access::escapeString()
     *
     * Public: escape the string we are going to save from dangerous characters
     *
     * @param string $string
     * @return string
     */
    function escapeString( $string ) {
        return str_replace("'", "''", $string);
    }
    
    /**
     * fh_access::fetchUniqueFields()
     *
     * Public: fetch the unique fields from the table
     *
     * @param string $table
     * @return array
     */
    function fetchUniqueFields( $table = null ) {
        // Access does not know unique fields... but primary key fields are also unique...
        return $this->fetchKeys();     
    }
    
    /*
    function displaySchemas() {    
	    
	    for( $x = 1; $x <= 38; $x++ ) {
	        
	        echo "SCHEMA $x\n";
    	    echo "<table border='1'>\n";
    	    
    	    for( $i = 0; $i <= 50; $i++ ) {
    	       $rs = @$this->_conn->OpenSchema( $x );
    	       
    	       echo 
    	       "  <tr>\n".
    	       "    <td>".$i ."</td>\n";
    	       
    	       if($rs) {
            	   $record = @$rs->Fields ( $i );
            	   if($record) {
                	   while( !$rs->EOF ) {
                	       echo "    <td>".($record->Value==''?'&nbsp;':$record->Value)."</td>\n";
                	       flush();
                	       $rs->MoveNext();
                	   }
            	   } else {
            	       break;
            	   }
            	   $rs->Close();
            	   $rs->Release();
    	       } else {
    	           echo "<td>Error.. $x failure</td>\n";
    	           break;
    	       }
        	   echo "  </tr>";
    	    }
    	    echo "</table> <br />";
	    }
		
	    return;
	}
	*/
	
}

/*
	adSchemaCatalogs	= 1,
	adSchemaCharacterSets	= 2,
	adSchemaCollations	= 3,
	adSchemaColumns	= 4,
	adSchemaCheckConstraints	= 5,
	adSchemaConstraintColumnUsage	= 6,
	adSchemaConstraintTableUsage	= 7,
	adSchemaKeyColumnUsage	= 8,
	adSchemaReferentialContraints	= 9,
	adSchemaTableConstraints	= 10,
	adSchemaColumnsDomainUsage	= 11,
	adSchemaIndexes	= 12,
	adSchemaColumnPrivileges	= 13,
	adSchemaTablePrivileges	= 14,
	adSchemaUsagePrivileges	= 15,
	adSchemaProcedures	= 16,
	adSchemaSchemata	= 17,
	adSchemaSQLLanguages	= 18,
	adSchemaStatistics	= 19,
	adSchemaTables	= 20,
	adSchemaTranslations	= 21,
	adSchemaProviderTypes	= 22,
	adSchemaViews	= 23,
	adSchemaViewColumnUsage	= 24,
	adSchemaViewTableUsage	= 25,
	adSchemaProcedureParameters	= 26,
	adSchemaForeignKeys	= 27,
	adSchemaPrimaryKeys	= 28,
	adSchemaProcedureColumns	= 29,
	adSchemaDBInfoKeywords	= 30,
	adSchemaDBInfoLiterals	= 31,
	adSchemaCubes	= 32,
	adSchemaDimensions	= 33,
	adSchemaHierarchies	= 34,
	adSchemaLevels	= 35,
	adSchemaMeasures	= 36,
	adSchemaProperties	= 37,
	adSchemaMembers	= 38

*/


?>