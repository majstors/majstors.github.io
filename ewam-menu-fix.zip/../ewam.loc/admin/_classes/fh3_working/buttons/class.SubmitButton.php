<?php

/**
* class SubmitButton 
*
* Create a submitbutton on the given form
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/04 13:08:55 $
*
*/
class SubmitButton extends Button  {
    var $_bDisableOnSubmit;  // boolean
    
    /**
     * SubmitButton::SubmitButton()
     *
     * Public Constructor: The constructor to create a new Submitbutton object.
     *
     * @param [type] {parameters}
     * @return
     */
    function SubmitButton(&$oForm, $sName) {
        $this->Button( $oForm, $sName );
        
        $this->disableOnSubmit( FH_DEFAULT_DISABLE_SUBMIT_BTN );
        
        // set the default submit caption
        $this->setCaption( $oForm->_text( 26 ) );
    }
    
    /**
     * SubmitButton::disableOnSubmit()
     *
     * Public: Set if the submitbutton has to be disabled after pressing it
     * (avoid dubble post!)
     *
     * @param boolean status
     * @return void
     */
    function disableOnSubmit( $bStatus ) {
        $this->_bDisableOnSubmit = (bool) $bStatus;
    }
         
    /**
     * SubmitButton::getButton()
     *
     * Public: Returns the button
     *
     * @return string: the HTML of the button
     */
    function getButton() {
         
        // set the javascript disable dubble submit option if wanted
        if($this->_bDisableOnSubmit) {            
            if(isset($this->_sExtra) && preg_match("/onclick([ ]*)=([ ]*)('|\")(.*)$/i", $this->_sExtra)) {
                // put the function into a onchange tag if set
                $this->_sExtra = preg_replace("/onclick([ ]*)=([ ]*)('|\")(.*)$/i", "onclick=\\3this.form.submit();this.disabled=true;\\4", $this->_sExtra);
            } else {
                $this->_sExtra = "onclick=\"this.form.submit();this.disabled=true;\" ".(isset($this->_sExtra) ? $this->_sExtra : '');
            }            
        }
        
        return 
        '<input '.
        'type="submit" '.
        'value="'.$this->_sCaption.'" '.
        'name="'.$this->_sName.'" '.
        'id="'.$this->_sName.'" '.
        (isset($this->_sExtra) ? $this->_sExtra.' ':'').
        (isset($this->_iTabIndex) ? ' tabindex="'.$this->_iTabIndex.'" ' : '').
        '/>';        
    }
    
}

?>