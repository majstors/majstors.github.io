<?php

/**
* class ResetButton 
*
* Create a resetbutton on the given form
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/04 13:08:55 $
*
*/
class ResetButton extends Button {
    
    /**
     * ResetButton::ResetButton()
     *
     * Public constructor: Create a new reset button object
     *
     * @param object $form: the form where the button is located on
     * @param string $name: the name of the button
     * @return void
     */
    function ResetButton(&$oForm, $sName) {
        $this->Button($oForm, $sName);
        
        $this->setCaption( $oForm->_text( 27 ) );        
    }
    
    /**
     * ResetButton::getButton()
     *
     * Public: return the HTMl of the button
     *
     * @return string: the html of the button
     */
    function getButton() {
        return 
        '<input '.
        'type="reset" '.
        'value="'.$this->_sCaption.'" '.
        'name="'.$this->_sName.'" '.
        'id="'.$this->_sName.'" '.
        (isset($this->_sExtra) ? $this->_sExtra.' ':'').
        (isset($this->_iTabIndex) ? ' tabindex="'.$this->_iTabIndex.'" ' : '').
        '/>';        
    }
     
}

?>