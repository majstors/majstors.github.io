<?php

define('FH_EXPOSE', false);
include_once ("class.FormHandler.php");

define('FH_DEFAULT_ROW_MASK', 
  "  <tr>\n".
  "    <td valign='top' align='right'>%title%</td>\n".
  "    <td valign='top'>:</td>\n".
  "    <td valign='top'>%field% %error%</td>\n".
  "  </tr>\n"
);


/**
 * FormHandler Extension
 *
 */
class MyFormHandler extends FormHandler {

	/**
	 * Returns a list of subfolders
	 *
	 * @param string $D
	 * @param boolean $LetterBegin
	 * @return array
	 */
	 
	  var $hiddenSection = false;
	 
	function options_dir_list($D, $LetterBegin=false) {

		$options=array();

		if (!file_exists($D)) { return $options; }

		$handle = opendir($D);
		while ($file = readdir($handle)) {
			if ($file != "." AND $file != "" AND $file != "..") {
				if ($LetterBegin && substr($file,0,1)!="_"  && substr($file,0,1)!="!" && substr($file,0,1)!=".") {
					$options[]=$file;
				}
			}
		}
		closedir($handle);
		return $options;
	}

	function ably_options($O) {
		$C = split(":",$O);
		$P = split(",",$C[1]);
		$R = array();

		switch ($C[0]) {
			case "RANGE":
			for ($i=$P[0];$i<$P[1];$i++) $R[$i]=$i;
			break;
			case "_RANGE":
			$R["-"]="-";
			for ($i=$P[0];$i<$P[1];$i++) $R[$i]=$i;
			break;
			case "LIST":
			$R = $P;
			break;
			case "VALLIST":
			foreach ($P as $K=>$V) { $R[$V]=$V; }
			break;			
			default:
			break;
		}
		
//		print_r($R);
		return $R;

	}
	
	function setFocus() {
		return null;	
	}

}

?>