<?php

/**
* class Field
*
* Public abstract: class to create a field.
* This class contains code which is used by all the other fields
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/04 13:08:55 $
*/
class Field {
    var $_oForm;         // object: the form where the field is located in
    var $_sName;         // string: name of the field
    var $_sValidator;    // string: callback function to validate the value of the field
    var $_mValue;        // mixed: the value of the field
    var $_sError;        // string: if the field is not valid, this var contains the error message
    var $_sExtra;        // string: extra data which should be added into the HTML tag (like CSS or JS) 
    var $_iTabIndex;     // int: tabindex or null when no tabindex is set


    /**
     * Field::Field()
     *
     * Public abstract constructor: Create a new field 
     *
     * @param object $oForm: The form where the field is located on
     * @param string $sName: The name of the field     
     * @return void
     */
    function Field( &$oForm, $sName ) {
        $this->_oForm = &$oForm;  
        $this->_sName = $sName;
        
        // check if there are spaces in the fieldname
        if(strpos($sName,' ') !== false) {
            trigger_error('Warning: There are spaces in the field name "'.$sName.'"!', E_USER_WARNING );
        } 
        
        // get the value of the field
        if($oForm->isPosted()) {   
                     
            // make sure that the $_POST array is global
            if(!_global) global $_POST;
            
            // get the value if it exists in the $_POST array
            if( isset( $_POST[$sName] ) ) {
                $this->setValue( 
                  get_magic_quotes_gpc() && is_string( $_POST[$sName] ) ? 
                    stripslashes($_POST[$sName]) : 
                    $_POST[$sName]
                );
            }  
        // load database value if exists    
        } else if($oForm->edit) {
            if( isset( $oForm->_dbData[$sName] ) ) {
                $this->setValue( $oForm->_dbData[$sName] );
            }
        } 
    }
    
    /**
     * Field::isValid()
     *
     * Public: Check if the value of the field is valid. If not,
     * set the error message and return false
     *
     * @return boolean: If the value of the field is valid
     */
    function isValid() {
        
        // is a validator set?
        if(isset($this->_sValidator) && $this->_sValidator != null) {
            // is the validator a user-spicified function?
            if( function_exists($this->_sValidator) ) {
                $error = call_user_func( $this->_sValidator, $this->getValue() );
            } else {
                $v =& new Validator();
                if(method_exists($v, $this->_sValidator)) {
                    // call the build in  validator function
                    $error = $v->{$this->_sValidator}( $this->getValue() );
                    
                } else {
                    trigger_error("Unknown validator: '".$this->_sValidator."' used in field '".$this->_sName."'");
                    $error = false;
                }
            }
                        
            // set the error message
            $this->_sError = 
              is_string($error) ? $error :
              (!$error ? $this->_oForm->_text( 14 ) :
			  (isset($this->_sError) ? $this->_sError : ''));
        } 
        
        return empty( $this->_sError );
    }
    
    /**
     * Field::setValidator()
     *
     * Public: set the validator which is used to validate the value of the field
     * This can also be an array. 
     * If you want to use a method to validate the value use it like this:
     * array(&$obj, 'NameOfTheMethod')
     *
     * @param string $sValidator: the name of the validator
     * @return
     */
    function setValidator( $sValidator ) {
        $this->_sValidator = $sValidator;
    }
    
    /**
     * Field::setTabIndex()
     *
     * Public: set the tabindex of the field
     *
     * @param int $iIndex
     * @return void
     */
    function setTabIndex( $iIndex ) {
        $this->_iTabIndex = $iIndex;
    }

    /**
     * Field::getValue()
     *
     * Public: return the value of the field
     *
     * @return mixed: the value of the field
     */
    function getValue() {
        return isset( $this->_mValue ) ? $this->_mValue : '';
    }
    
    /**
     * Field::getError()
     *
     * Public: return the error of the field (if the field-value is not valid)
     *
     * @return string: the error message
     */
    function getError() {
        return isset( $this->_sError) && strlen($this->_sError) > 0 ? sprintf( FH_ERROR_MASK ,$this->_sError): '';
    }
    
    /**
     * Field::setValue()
     *
     * Public: set the value of the field
     *
     * @param mixed $mValue: The new value for the field
     * @return void
     */
    function setValue( $mValue ) {
        $this->_mValue = $mValue; 
    }
    
    /**
     * Field::setExtra()
     *
     * Public: set some extra CSS, JS or something like that (to use in the html tag)
     *
     * @param strint $sExtra: the extra html to insert into the tag
     * @return void
     */
    function setExtra( $sExtra ) {
        $this->_sExtra = $sExtra;
    }
    
    /**
     * Field::getField()
     *
     * Public abstract: return the HTML of the field. 
     * This function HAS TO BE OVERWRITTEN by the child class!
     *
     * @return string: the html of the field
     */
    function getField() {
        trigger_error('Error, getField has not been overwritten!', E_USER_WARNING);
        return '';
    }
}

?>