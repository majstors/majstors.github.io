<?php

/**
* class Editor
*
* Create a Editor on the given form
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/10 18:21:59 $
*/
class Editor extends Field {
    var $_oEditor;    // FCKEditor: the object of the fck editor
    
    /**
     * Editor::Editor()
     *
     * Public constructor:  create a new Editor object
     *
     * @param object $oForm: The form where the field is located on
     * @return void
     */
    function Editor( &$oForm, $sName ) {
        
        $this->_oEditor = new FCKeditor( $sName );
        $this->_oEditor->BasePath = FH_FHTML_DIR . 'FCKeditor/';
        $this->_oEditor->Value	  = isset( $this->_mValue ) ? $this->_mValue : '';
        $this->setToolbar( 'Default' ); // Default or Basic

		$this->Field( $oForm, $sName );
        
        // set the language
        $this->_oEditor->Config['AutoDetectLanguage'] = false ;
        $this->_oEditor->Config['DefaultLanguage']    = $oForm->_lang;        
        
		// default height & width
        $this->setWidth ( 720 );
        $this->setHeight( 400 );
        
        // set the dir where the script is runned from
        $sSelfPath = $_SERVER['PHP_SELF'] ;
	    $sSelfPath = substr( $sSelfPath, 0, strrpos( $sSelfPath, '/' ) ) ;
	    
	    // set as default path the dir where the requested script is located
        $this->setServerPath( $sSelfPath );
        
        $this->setSkin( 'default' );
    }
    
    /**
     * Editor::setHeight()
     *
     * Public: set the height of the editor (in pixels!)
     *
     * @param integer $iHeight: the height
     * @return void
     */
    function setHeight( $iHeight ) {
        $this->_oEditor->Height = $iHeight;
    }
    
    /**
     * Editor::setValue()
     *
     * Public: Set the value of the field
     *
     * @param string $sValue: The html to set into the field
     * @return void
     */
    function setValue( $sValue ) {
    	$this->_mValue = $sValue;
    	$this->_oEditor->Value = $sValue;
    }
    
    /**
     * Editor::setWidth()
     *
     * Public: set the width of the editor  (in pixels!)
     *
     * @param integer $iWidth: the width
     * @return void
     */
    function setWidth( $iWidth) {
        $this->_oEditor->Width = $iWidth;
    }
    
    /**
     * Editor::setToolbar()
     *
     * Public: set the toolbar we should use for the editor
     *
     * @param string $sToolbar: The toolbar we should use
     * @return void
     */
    function setToolbar( $sToolbar ) {
        $this->_oEditor->ToolbarSet = $sToolbar;
    }
    
    /**
     * Editor::setServerPath()
     *
     * Public: set the server path used for browsing and uploading images
     *
     * @param string $sPath: The path
     * @return void
     */
    function setServerPath( $sPath ) {
        $char = substr(FH_FHTML_DIR, 0, 1);
        $pre  = ($char != '/' && $char != '\\' && strtolower(substr(FH_FHTML_DIR, 0, 4)) != 'http') ? str_replace('//', '/', dirname( $_SERVER['PHP_SELF'] ).'/') : '';
        
	    $sPath = urlencode( 
          $pre . FH_FHTML_DIR . 
          'FCKeditor/editor/filemanager/browser/default/browser.html?'.
          'Type=Image&Connector=connectors/php/connector.php&ServerPath='.$sPath.'&CurrentFolder=/'
          
        );
        $this->_oEditor->Config['ImageBrowserURL'] = $sPath;
    }
       
    /**
     * Editor::setSkin()
     *
     * Public: set the skin used for the FCKeditor
     *
     * @param string $skin
     * @return void
     */
    function setSkin( $sSkin ) {
        $char = substr(FH_FHTML_DIR, 0, 1);
        $pre  = ($char != '/' && $char != '\\' && strtolower(substr(FH_FHTML_DIR, 0, 4)) != 'http' ) ? str_replace('//', '/', dirname( $_SERVER['PHP_SELF'] ).'/') : '';
        
        $this->_oEditor->Config['SkinPath'] = $pre.FH_FHTML_DIR.'FCKeditor/editor/skins/'.$sSkin.'/';
    } 
    
    
    /**
     * Editor::getField()
     *
     * Public: Return the HTML of the field
     *
     * @return string: The HTML of the editor
     */
    function getField() {
        return $this->_oEditor->CreateHtml();
    }
    
}

?>