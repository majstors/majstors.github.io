<?php

/**
* class RadioButton 
*
* Create a RadioButton
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/04 13:08:55 $
*/
class RadioButton extends Field {
    var $_aOptions;              // string: the value with is selected 
    var $_bUseArrayKeyAsValue;  // boolean: if the keys of the array should be used as values
    var $_sGlue;                 // string: what kind of "glue" should be used to merge the fields 
     
    /**
     * RadioButton::RadioButton()
     *
     * Public constructor: Create a new radiobutton object
     *
     * @param object $oForm: The form where this field is located on
     * @param string $sName: The name of the field
     * @param array|string $aOptions: The options for the field
     * @return void
     */
    function RadioButton( &$oForm, $sName, $aOptions ) {
        // call the constructor of the Field class
        $this->Field($oForm, $sName);
        
        $this->_aOptions = $aOptions;
        
        $this->setGlue( FH_DEFAULT_GLUE );
        $this->useArrayKeyAsValue( FH_DEFUALT_USEARRAYKEY );
    }
    
    /**
     * RadioButton::useArrayKeyAsValue()
     *
     * Public: Set if the array keys of the options has to be used as values for the field
     *
     * @param boolean $bMode:  The mode
     * @return void
     */
    function useArrayKeyAsValue( $bMode ) {
        $this->_bUseArrayKeyAsValue = $bMode;
    }
    
    /**
     * RadioButton::setGlue()
     *
     * Public: set the glue used to glue multiple radiobuttons
     *
     * @param string sGlue: the glue
     * @return void
     */
    function setGlue( $sGlue ) {
        $this->_sGlue = $sGlue;
    }
    
    /**
     * RadioButton::getField()
     *
     * Public: return the HTML of the field
     *
     * @return string: the html of the field
     */
    function getField() {
        
        if(is_array($this->_aOptions)) {
            $sResult = '';
            $i = 0;
            foreach ($this->_aOptions as $iKey => $sValue) {
                
                if(!$this->_bUseArrayKeyAsValue) {
                    $iKey = $sValue;
                }
                
                $sResult .= $this->_getRadioButton($iKey, $sValue);
                
                // add the glue behind the field
                if(++$i < sizeof($this->_aOptions)) {
                    $sResult .= $this->_sGlue;
                }
            }
        } else {
            $sResult = $this->_getRadioButton($this->_aOptions, '' );
        }
        
        return $sResult;        
    }
    
    /**
     * RadioButton::_getRadioButton()
     *
     * Private: return the radiobutton with the given title and value
     *
     * @param string $sValue: the value for the checkbox
     * @param string $sTitle: the title for the checkbox
     * @return string: the HTML for the checkbox
     */
    function _getRadioButton($sValue, $sTitle) {
        static $counter = 1;
        
        $sValue = trim( $sValue );
        $sTitle = trim( $sTitle );
        
        return
        '<input '.
        'type="radio" '.
        'name="'.$this->_sName.'" '.
        'id="'.$this->_sName.'_'.$counter++.'" '.
        'value="'.htmlspecialchars($sValue).'" '.
        (isset($this->_mValue) && $sValue == $this->_mValue ? 'checked="checked" ':'').
        (isset($this->_iTabIndex) ? ' tabindex="'.$this->_iTabIndex.'" ' : '').
        (!empty($this->_sExtra) ? $this->_sExtra.' ':'').
        '/>'.
        ($sTitle ? 
        '<label for="'.$this->_sName.'_'.($counter-1).'">'.
        $sTitle.
        '</label>':'');
    }
        
    
}
?>