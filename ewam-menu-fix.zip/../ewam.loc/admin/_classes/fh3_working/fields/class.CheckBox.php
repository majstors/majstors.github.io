<?php

/**
* class CheckBox
*
* Create a checkbox on the given form object
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/04 13:08:55 $
*/
class CheckBox extends Field {
    var $_aOptions;              // array: contains all the options!
                                 // $this->_mValue contains the values which are selected!
    var $_bUseArrayKeyAsValue;   // boolean: if the keys of the array should be used as values
    var $_sGlue;                 // string: what kind of "glue" should be used to merge the checkboxes 
    
    /**
     * CheckBox::CheckBox()
     *
     * Public constructor: Create a new checkbox object
     *
     * @param object $oForm: The form where this field is located on
     * @param string $sName: The name of the field
     * @param array|string $aOptions: The options for the field
     * @return void
     */
    function CheckBox(&$oForm, $sName, $aOptions) {
        $this->_mValue = '';
        $sName = str_replace('[]','', $sName);
        
        $this->_aOptions = $aOptions;
        
        // call the constructor of the Field class
        $this->Field($oForm, $sName);
        
        $this->setGlue			 ( FH_DEFAULT_GLUE );
        $this->useArrayKeyAsValue( FH_DEFUALT_USEARRAYKEY );
    }
    
    /**
     * CheckBox::setValue()
     *
     * Public: set the value of the field
     *
     * @param string / array $mValue: the value to set 
     * @return void
     */
    function setValue( $aValue ) { 
    	    	
    	// make an array from the value
        if(!is_array($aValue) && is_array($this->_aOptions)) {
            $aValue = explode(',', $aValue);
            foreach($aValue as $iKey => $sValue) {
            	$sValue = trim($sValue);
            	
            	// dont save an empty value when it does not exists in the 
            	// options array!
            	if( !empty($sValue)  ||            		      		
            	   ((is_array($this->_aOptions) &&  
            	     ( in_array( $sValue, $this->_aOptions ) || 
            	       array_key_exists( $sValue, $this->_aOptions )
            	     )
            	   ) ||
            	   $sValue == $this->_aOptions ))
            	{   
            		$aValue[$iKey] = $sValue;
            	} else {
            		unset($aValue[$iKey]);
            	}
            }
        }
        
        $this->_mValue = $aValue;
    }
    

    /**
     * CheckBox::useArrayKeyAsValue()
     *
     * Public: Set if the array keys of the options has to be used as values for the field
     *
     * @param boolean $bMode:  The mode
     * @return void
     */
    function useArrayKeyAsValue( $bMode ) {
        $this->_bUseArrayKeyAsValue = $bMode;
    }
    
    /**
     * CheckBox::setGlue()
     *
     * Public: set the glue used to glue multiple checkboxes
     *
     * @param string sGlue: the glue
     * @return void
     */
    function setGlue( $sGlue ) {
        $this->_sGlue = $sGlue;
    }
    
    /**
     * CheckBox::getField()
     *
     * Public: return the HTML of the field
     *
     * @return string: the html of the field
     */
    function getField() {        
        
        if(is_array($this->_aOptions)) {
            $sResult = '';
            $i = 0;
            foreach( $this->_aOptions as $iKey => $sValue ) {
                
                if(!$this->_bUseArrayKeyAsValue) {
                    $iKey = $sValue;
                }
                
                $sResult .= $this->_getCheckBox( $iKey, $sValue );
                
                // add the glue behind the field
                if(++$i < sizeof( $this->_aOptions )) {
                    $sResult .= $this->_sGlue;
                }
            }
        } else {
            $sResult = $this->_getCheckBox( $this->_aOptions, '' );
        }
        
        return $sResult;        
    }
    
    /**
     * CheckBox::_getCheckBox()
     *
     * Private: return an option of the checkbox with the given value
     *
     * @param string $sValue: the value for the checkbox
     * @param string $sTitle: the title for the checkbox
     * @return string: the HTML for the checkbox
     */
    function _getCheckBox( $sValue, $sTitle ) {
        static $iCounter = 1;
        
        $sValue = trim( $sValue );
        $sTitle = trim( $sTitle );
        
        return
        '<input '.
        'type="checkbox" '.
        'name="'.$this->_sName.(is_array($this->_aOptions)?'[]':'').'" '.
        'id="'.$this->_sName.'_'.$iCounter++.'" '.
        'value="'.htmlspecialchars($sValue).'" '.
        (isset($this->_iTabIndex) ? ' tabindex="'.$this->_iTabIndex.'" ' : '').
        (
          (isset($this->_mValue) && ((is_array($this->_mValue) && in_array($sValue, $this->_mValue)) 
           || $sValue == $this->_mValue) )?
          'checked="checked" ':''
        ).
        (isset($this->_sExtra) ? $this->_sExtra.' ':'').
        '/>'.
        ($sTitle ? 
        '<label for="'.$this->_sName.'_'.($iCounter-1).'">'.
        $sTitle.
        '</label>':'');
    }
}

?>