<?php

define('ROOT', dirname(__FILE__) . '/');
define('TEMPLATES_DIR', ROOT . '_templates');

include('admin/_ably_config.php');
include('ably/model.php');
include('admin/_classes/class-htmldbtree.php');

//ROUTING
$aURL = parse_url( $_SERVER['REQUEST_URI'] );
$aPath = explode('/', $aURL['path']);
$sLang = 'sr';
if ($aPath[1]=='en') $sLang = 'en';
if ($aPath[1]=='hu') $sLang = 'hu';


//MODEL
$M = new Model( $aPath );


//CONTROLLERS

if( $M->aPage['layout'] == 'download' ) {
    
    //die($M->aPage['page_url']);
    
    header('Location: /downloads/' . $M->aPage['page_url'] );
}

if( $M->aPage['layout'] == 'map' ) {
    $iDBFaza = (int) $M->aPage['tags'];
   
    if ($iDBFaza==2) $M->aPage['layout'] = 'map2';
    if ($iDBFaza==3) $M->aPage['layout'] = 'map3';
    
    $aLocations = $M->getMapLocations();
}


//VIEW

//echo $M->aPage['layout'];

$sLayoutFile = TEMPLATES_DIR . "/{$M->aPage['layout']}.php";

if (file_exists($sLayoutFile)) {
    include($sLayoutFile);
} else {
    die("ABLY: Layout </b>{$M->aPage['layout']}</b> is not defined");
}





?>