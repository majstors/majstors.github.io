<?php

define('WF_RECIPIENT', 'contactus@figytech.com');

if (
        !isset($_GET['target'])
        || !is_numeric($_GET['target'])
        || !in_array($_GET['target'], array('1', '2'))
) {
    die('Invalid form target');
}

if ($_GET['target'] == '1') {
    if (checkFields(array('email', 'message'))) {
        echo 'Thank you for your inquiry.<br/>We\'ll contact you in a short time.';

        $i = @mail(
                WF_RECIPIENT, 'FIGYTECH: web contact form - inquiry', trim("
  e-mail: {$_POST['email']}
  ---------------------------------------
  {$_POST['message']}
  ---------------------------------------
  "), 'From: FIGYTECH web agent <webagent@figytech.com>' . "\r\n"
        );
    } else {
        echo 'FAIL';
    }
}

if ($_GET['target'] == '2') {
    if (checkFields(array('email', 'message'))) {
        echo 'Thank you for your inquiry. We\'ll contact you in a short time.';

        $i = @mail(
                WF_RECIPIENT, 'FIGYTECH: web contact form - inquiry', trim("
     Name: {$_POST['name']}
  Company: {$_POST['company']}
   E-mail: {$_POST['email']}
      WWW: {$_POST['wadr']}
  ---------------------------------------
  {$_POST['message']}
  ---------------------------------------
  "), 'From: FIGYTECH web agent <webagent@figytech.com>' . "\r\n"
        );
    } else {
        echo 'FAIL';
    }
}

function checkFields($aNames) {

    $bOK = TRUE;
  
    
    foreach ($aNames as $K) {
        
        if (key_exists($K, $_POST)) {
            $_POST[$K] = trim($_POST[$K]);
            if ($_POST[$K] == '')
                $bOK = FALSE;
        } else {
            $bOK = FALSE;
        }
    }

    if (key_exists('url', $_POST)) {
        if ($_POST['url'] != '')
            $bOK = FALSE;
    } else {
        $bOK = FALSE;

    }
    return $bOK;
}


?>