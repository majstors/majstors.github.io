<?php

/**
* class ImageButton 
*
* Create a image button on the given form
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/04 13:08:55 $
*
*/
class ImageButton extends Button {
	
	var $_bDisableOnSubmit;
    var $_sImage;
    

    /**
     * ImageButton::ImageButton()
     *
     * Public constructor: Create a new ImageButton object
     *
     * @param object $form: the form where the image button is located on     
     * @param string $name: the name of the button
     * @param string $image: the image we have to use as button
     * @return void
     */
    function ImageButton(&$oForm, $sName, $sImage) {        
        $this->Button($oForm, $sName);
        
        $this->disableOnSubmit( FH_DEFAULT_DISABLE_SUBMIT_BTN );
        
        // set the image we use
        $this->_sImage =& $sImage;
    }   
    
    /**
     * ImageButton::disableOnSubmit()
     *
     * Public: Set if the imagebutton has to be disabled after pressing it
     * (avoid dubble post!)
     *
     * @param boolean status
     * @return void
     */
    function disableOnSubmit( $bStatus ) {
        $this->_bDisableOnSubmit = (bool) $bStatus;
    } 
    
    /**
     * ImageButton::getButton()
     *
     * Public: return the HTMl of the button
     *
     * @return string: the HTML of the button
     */
    function getButton() {
    	
    	// set the javascript disable dubble submit option if wanted
        if($this->_bDisableOnSubmit) {
            if(isset( $this->_sExtra ) && preg_match("/onclick([ ]*)=([ ]*)('|\")(.*)$/i", $this->_sExtra)) {
                // put the function into a onchange tag if set
                $this->_sExtra = preg_replace("/onclick([ ]*)=([ ]*)('|\")(.*)$/i", "onclick=\\3this.form.submit();this.disabled=true;\\4", $this->_sExtra);
            } else {
                $this->_sExtra = "onclick=\"this.form.submit();this.disabled=true;\" ".$this->_sExtra;
            }
            
        }
        
        return 
        '<input '.
        'type="image" '.
        'src="'.$this->_sImage.'" '.
        'name="'.$this->_sName.'" '.
        'id="'.$this->_sName.'" '.
        (isset($this->_sExtra) ? $this->_sExtra.' ':'').
        (isset($this->_iTabIndex) ? ' tabindex="'.$this->_iTabIndex.'" ' : '').
        '/>';        
    }     
}

?>