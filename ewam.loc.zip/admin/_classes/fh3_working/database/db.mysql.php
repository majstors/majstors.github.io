<?php

/**
* class fh_mysql
*
* MySQL class
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/22 17:36:56 $
*/
class fh_mysql extends fh_db {
    var $_conn;     // connection handler
    var $_sql;      // SQL resource
    
    /**
     * fh_mysql::fh_mysql()
     *
     * Public constructor: check if we have a connection
     *
     * @return 
     */
    function fh_mysql( $db, $table, $keys = null ) {
        $this->fh_db( $db, $table, $keys );
        
        $this->_quoteNumbers = true;
    }
     
    /**
     * fh_mysql::connect()
     *
     * Public: Make a connection with the database and
     * select the database.
     *
     * @param string host: the host to connect to
     * @param string username: the username which should be used to login
     * @param string password: the password which should be used to login
     * @return void
     */
    function connect( $host = 'localhost', $username = '', $password = '' ) {    	
    	$this->_conn = mysql_connect( $host, $username, $password )
    	  or die('Error, could not connect with mysql: '.$this->getError() );
    	  
    	if( $this->_conn ) {  
    	   if(mysql_select_db( $this->_db, $this->_conn )) {
    	       $this->_isConnected = true;
    	       return true;
    	   }
    	} 
    	
    	return false;    	
    }    
    
    /**
     * fh_mysql::getDate()
     *
     * Public: returns the right date format for this database type
     *
     * @param string $date:  the date in dd-mm-yyyy format
     * @return string
     */
    function getDbDate($date) {
        list($d, $m, $y) = split('-', $date);
        
        return "'$y-$m-$d'";
    }    
        
    /**
     * fh_mysql::query()
     *
     * Public: Execute the query
     *
     * @param string $query: the query
     * @return resource 
     */
    function query( $query ) {
        
        // execute the query
        $this->_sql = mysql_query( $query );
        
        if(!$this->_sql) {
            trigger_error('Error in query! Error: '.mysql_error().' Query: '.$query );            
        } 
                 
        return $this->_sql;  
    }    
    
    /**
     * fh_mysql::getInsertId()
     *
     * Public: get the id of the last inserted record
     *
     * @return int
     */
    function getInsertId() {
        return mysql_insert_id();
    }
    
    /**
     * fh_mysql::getError()
     *
     * Public: return the last error
     *
     * @return string
     */
    function getError() {
        return mysql_error();
    }
    
    /**
     * fh_mysql::recordCount()
     *
     * Public: return the number of records found by the query
     *
     * @return int
     */
    function recordCount( $sql = null) {
        $sql = is_null($sql) ? $this->_sql : $sql;
        return mysql_num_rows( $sql );
    }     
    
    /**
     * fh_mysql::getRecord()
     *
     * Public: fetch a record in assoc mode and return it
     *
     * @return: assoc array or false when there are no records left
     */
    function getRecord( $sql = null) {
        $sql = is_null($sql) ? $this->_sql : $sql;
        return mysql_fetch_assoc( $sql );
    }
    
    /**
     * fh_mysql::getFieldNames()
     *
     * Public: return the field names of the table
     *
     * @param string $table: if a table is given, this one is used. otherwise the default is used
     * @return array
     */
    function getFieldNames( $table = null ) {
        $table = is_null($table) ? $this->_table : $table;
        
        $tmp = $this->_sql;
        
        $result = array();
        
        // check if we have a connection handler..
        // if so, fetch the column names
        if( $this->_conn ) {
            
            $fields  = mysql_list_fields( $this->_db, $table, $this->_conn );
            $columns = mysql_num_fields($fields);
            
            for ($i = 0; $i < $columns; $i++) {
                $result[] = mysql_field_name($fields, $i);
            }        
        
        // no connection handler available
        } else {            
            // try to get a record and fetch the field names..
            $sql = $this->query( 'SELECT * FROM `'.$table.'` LIMIT 1' );
            if( $this->recordCount($sql) == 1 ) {
                $result = array_keys( $this->getRecord() );
            
            // no record found.. analyse the CREATE TABLE text             
            } else {            
                $sql = $this->query( 'SHOW CREATE TABLE `'.$table.'`' );
                
                $row = $this->getRecord();
                
                // find all field names in the create statement
                $matches = array();
                preg_match_all( "/^ *`([^`]+)`(.*),\n/im", $row['Create Table'], $matches );
                    
                $result = $matches[1];                
            }
        }
        
        $this->_sql = $tmp;
        
        return $result;
    }
        
    
    /**
     * fh_mysql::escapeString()
     *
     * Public: escape the string we are going to save from dangerous characters
     *
     * @param string $string
     * @return string
     */
    function escapeString( $string ) {
        return mysql_escape_string( $string );
    }
    
    /**
     * fh_mysql::fetchKeys()
     *
     * Public: fetch the keys from the table 
     *
     * @return array of the keys which are found
     */
    function fetchKeys( $table = null) {
        $table = is_null($table) ? $this->_table : $table;
        
        $tmp = $this->_sql;
        
        $sql = $this->query("SHOW KEYS FROM `".$table."`");
        $keys = array();
        while( $r = $this->getRecord() ) {
            if ( $r['Key_name'] == 'PRIMARY' ) {
                $keys['PR'][] = $r['Column_name'];
            } else {
            	$keys[$r['Key_name']][] = $r['Column_name'];
            }
        }         
        
        mysql_free_result($sql);
        $this->_sql = $tmp;
        
        // if no keys are found...
        if(sizeof($keys) == 0) {
            trigger_error(
              "Error, could not fetch the indexes from table '".$table."'! ".
              "If you didn't define a primary key or another index type, ".
              "please set the name of the field (which should be used for indexing) ".
              "manually in the dbinfo() function!",
              E_USER_WARNING
            );
            return null;
        }
        
        if(isset($keys['PR'])) {
        	return $keys['PR'];
        } else {
        	$d = each( $keys );
        	return $d[1];
        }
    }
    
    /**
     * fh_mysql::fetchUniqueFields()
     *
     * Public: fetch the unique fields from the table
     *
     * @param string $table
     * @return array
     */
    function fetchUniqueFields( $table = null ) {
        $table = is_null($table) ? $this->_table : $table;
        
        $tmp = $this->_sql;
        
        $sql = $this->query("SHOW KEYS FROM `".$table."`");
        $unique = array();
        while( $r = $this->getRecord() ) {
            if ( $r['Non_unique'] == 0) {
                $unique[] = $r['Column_name'];
            } 
        }         
        
        mysql_free_result($sql);
        $this->_sql = $tmp;
        
        if(sizeof($unique) > 0) {
        	return $unique;
        } else {
        	return array();
        }        
    }
}

?>