<?php

/**
 * Document::catchErrors()
 *
 * Saves all PHP errors occoured in the form
 * Revision: $Date: 2005/04/30 09:51:02 $
 */
function &catchErrors() {
    static $errors = array();
    // Error event has been passed
    if (func_num_args()==5) { 
        $errors[] = array(
          'no'   => func_get_arg(0),
          'text' => func_get_arg(1),
          'file' => func_get_arg(2),
          'line' => func_get_arg(3),
          'vars' => func_get_arg(4)
        );
        
        // is it a ERROR? then display and quit
	    if(func_get_arg(0) == E_USER_ERROR) {
	    	echo 
	    	"<b>ERROR</b> [".func_get_arg(0)."] ".func_get_arg(1).
	    	" in <i>".basename(func_get_arg(2))."</i> on line <i>".func_get_arg(3)."</i> <br />\n";
	    	exit;
	    }
    }    	
    
    // call for the errors. Return the reference
    if (func_num_args()==0) { 
        return $errors;
    }

	$null_value = null;
    return $null_value;
}

?>