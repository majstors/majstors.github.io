<?php

/**
* class ImageConverter
*
* Convert images: resize or merge an image
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/22 17:36:56 $
*/
class ImageConverter
{
	// private vars!
    var $_sImage;
    var $_sError;
    var $_aSize;
    var $_aNewSize;
    var $_iQuality;

    /**
     * ImageConverter::ImageConverter()
     *
     * Public constructor: Create a new ImageConverter object
     *
     * @param string $sImage: The image to work with 
     * @return void
     */
    function ImageConverter( $sImage ) {    	
        $this->_sError   = '';
        $this->_sImage   = $sImage;
        $this->_iQuality = 80;

        // does the file exists ?
        if( file_exists($sImage) ) {
            $this->_aSize     = getimagesize( $sImage );
            $this->_aNewSize  = $this->_aSize;

            // is the type of the image right to convert it ?
            if(!in_array( 
              $this->_getExtension( $sImage ) , 
              array('jpg', 'png', 'jpeg'))) 
            {
                $this->_sError = 'Only jpg, jpeg and png files can be converted!';
                return;
            }
        } else {
            $this->_sError = 'File not found: '.$sImage;    
            return;
        }
    }
    
    /**
     * ImageConverter::setQuality()
     *
     * Public: Set the quality of the new resized image
     *
     * @param int $iQuality: the quality
     * @return void
     */
    function setQuality( $iQuality ) {
    	if( is_numeric( $iQuality ) ) {
        	$this->_iQuality = (int) $iQuality;
    	}     		
    }
    
    /**
     * ImageConverter::getError()
     *
     * Public: return the last error occoured
     *
     * @return string: the last occoured error
     */
    function getError() {
    	return $this->_sError;
    }
    
    /**
     * ImageConverter::doResize()
     *
     * Public: resize the image
     *
     * @param string $sDestination: The file how we have to save it
     * @param int $iNewWidth: The new width of the image
     * @param int $iNewHeight: The new height of the image
     * @return void
     */
    function doResize( $sDestination , $iNewWidth, $iNewHeight ) {
        
        // if no errors occourd
        if($this->_sError == '') {
        	// set the new size
        	$this->_setSize( $iNewWidth, $iNewHeight );
        	
        	// check if the destination dir exists
        	if(!is_dir( dirname( $sDestination ) )) {
        		$this->_sError = 'Destination dir does not exists: '.dirname( $sDestination );
        	}
        		
        	// does the destination has an extension attached ?
        	if( !in_array( $this->_getExtension( $sDestination ), array('jpg', 'jpeg', 'png'))) {
        		// if not, put the extension of the original file behind it
        		$sDestination .= '.'.$this->_getExtension($this->_sImage);
        	}
        	
        	// get the resource of the original file
            $rOrg = $this->_imageCreate( $this->_sImage );
              
            // get the old and new sizes of the image
            list($iOrgWidth, $iOrgHeight) = $this->_aSize;
            list($iNewWidth, $iNewHeight) = $this->_aNewSize;
            
            // generate the new image
            if($this->_GDVersion() >= 2) {
                $rImgResized = ImageCreateTrueColor( $iNewWidth, $iNewHeight );
                ImageCopyResampled( $rImgResized, $rOrg, 0, 0, 0, 0, $iNewWidth, $iNewHeight, $iOrgWidth, $iOrgHeight );
            } else {
                $rImgResized = ImageCreate( $iNewWidth, $iNewHeight );
                ImageCopyResized( $rImgResized, $rOrg, 0, 0, 0, 0, $iNewWidth, $iNewHeight, $iOrgWidth, $iOrgHeight );
            }
            
            // save the image to file
            $this->_saveImage( $rImgResized, $sDestination, $this->_iQuality );

            // clean up
            ImageDestroy( $rOrg );
            ImageDestroy( $rImgResized );
        } 
    }


    /**
     * ImageConverter::doMerge()
     *
     * Public: merge the image with a stamp
     *
     * @param [type] {parameters}
     * @return
     */
    function doMerge( $sStamp, $sAlign, $sValign, $aTransparant = null ) {
        if( file_exists($sStamp)) {
        	if(!function_exists('imagecopyresampled')) {
        		trigger_error(
        		  'Error, the required function imagecopyresampled does not exists! '.
        		  'Could not generate new image.', 
        		  E_USER_WARNING
        		);
        		return;
        	}
            // Open the current file (get the resource )
            $rImgSrc = $this->_imageCreate( $this->_sImage );
            
            // create the "new" file recourse
            $rImgDest = ImageCreateTrueColor( $this->_aSize[0], $this->_aSize[1] );

            // Open the stamp image
            $rImgStamp = $this->_imageCreate( $sStamp );

            // Transparant color...
            if(is_array($aTransparant)) {            	
            	$color = ImageColorAllocate( $rImgStamp, $aTransparant[0], $aTransparant[1], $aTransparant[2] );
            	ImageColorTransparent($rImgStamp, $color);
            }
            
            // Copy the current file to the new one
            ImageCopy( $rImgDest, $rImgSrc, 0,0,0,0, $this->_aSize[0], $this->_aSize[1] );
            ImageDestroy( $rImgSrc );
            
            // get the new position for the stamp
            $x = ImageSX( $rImgStamp );
            $y = ImageSY( $rImgStamp );
            $posX = $this->_getPos( $this->_aSize[0], $x, $sAlign );
            $posY = $this->_getPos( $this->_aSize[1], $y, $sValign );
            
            // copy the stamp to the new image
            ImageCopyMerge( $rImgDest, $rImgStamp, $posX, $posY, 0, 0, $x, $y, 100 );
            //ImageCopyResampled( $imgDest, $imgStamp, 0, 0, $x, $y, $x, $y );
            ImageDestroy( $rImgStamp );
            
            // Save the new image
            $this->_saveImage( $rImgDest, $this->_sImage, 100 );
            ImageDestroy( $rImgDest );
		} else {
			trigger_error('Error, stamp file does not exists: '. $sStamp, E_USER_WARNING );
		}
    }

    
    /******************************
     *      Private methods       *
     ******************************/
     
     
     /**
     * ImageConverter::_setSize()
     *
     * Private: set the new size of the image and calculate the new size directly
     *
     * @param int $x: the new width
     * @param int $y: the new height
     * @return void
     */
    function _setSize( $x, $y ) {
        // if no errors occourd
        if($this->_sError == '') {
            list( $iWidth, $iHeight ) = $this->_aSize;
            
            // get the new size
            if( $iWidth > $x )
              $this->_getNewSize( $iWidth, $iHeight, $x );
                
            if( $iHeight > $y )
              $this->_getNewSize( $iHeight, $iWidth, $y );
              
            $this->_aNewSize = array( $iWidth, $iHeight );
        }
    }
    
	/**
	 * ImageConverter::_GDVersion()
	 *
	 * Private: return the installed GD version
	 *
	 * @return int: the installed gd version or 0 on failure
	 */
	function _GDVersion() {
		static $iGDVersion = null;

		if ($iGDVersion === null) {
		   // Use output buffering to get results from phpinfo()
		   // without disturbing the page we're in.  
	   		ob_start();
   			@phpinfo(8);
   			$sModuleInfo = ob_get_contents();
   			ob_end_clean();
   			$aMatches = array();
   			if( preg_match("/\bgd\s+version\b[^\d\n\r]+?([\d\.]+)/i", $sModuleInfo, $aMatches ) ) {
   				$iGDVersion = $aMatches[1];
   			} else {
   				$iGDVersion = 1;
   			}
		}
		return $iGDVersion;
	}


	/**
	 * ImageConverter::_getPos()
	 *
	 * Private: get the position of the new stamp
	 *
	 * @param int $size: the size of the image (width of height)
	 * @param int $stampSize: the size of the stamp (width of height)	 
	 * @param string $where: position where to put the stamp on the image
	 * @return
	 */
    function _getPos( $size, $stampSize, $where )
    {
    	// percent ?
    	if(strpos($where, '%') !== false) {
    		echo "isPercent!";
    		$percent = str_replace( '%', '', $where );
    		$part    = $size / 100;
    		$x = ceil($percent * $part);
    	} else {
	        // get the pos for the copyright stamp
	        switch (StrToLower($where)) {
	            case 'top':
	            case 'left':
	              $x = 0;
	              break;
	            case 'middle':
	            case 'center':
	              $x = ceil($size / 2) - ceil($stampSize / 2);
	              break;
	            case 'bottom':
	            case 'right':
	              $x = $size - $stampSize;
	              break;
	            default:
	              $x = 0;
	        }
    	}
        
        return $x;
    }
    
    /**
     * ImageConverter::_getNewSize()
     *
     * Private: calculate the new size
     *
     * @param int $x: The old width
     * @param int $y: The old height
     * @param int $max: The max width/height allowed
     * @return void
     */
    function _getNewSize( &$x, &$y, $max ) {
        $procent = $x / 100;
        $scale   = $max / $procent;
        $x       = $scale * $procent;
        $y       = $scale * ($y / 100);
    }
   
    /**
     * ImageConverter::_getExtension()
     *
     * Private: return the extension of the given file
     *
     * @param string $sFile: the file where we have to retrieve the extension from
     * @return
     */
    function _getExtension( $sFile )
    {
        $fp = explode( '.', $sFile );
        return StrToLower( $fp[ count($fp) -1 ] );
    }
    
    /**
     * ImageConverter::_imageCreate()
     *
     * Private: create a new image resource based on the extension of the given file
     *
     * @param string $sFile: The file
     * @return resource or false on failure
     */
    function _imageCreate( $sFile ) {
        $sExt = $this->_getExtension( $sFile );

        if($sExt == 'jpg' || $sExt == 'jpeg') {
            return ImageCreateFromJPEG( $sFile );
        } elseif($sExt == 'png') {
            return ImageCreateFromPNG( $sFile);
        //} elseif($sExt == 'gif') {
        //    return ImageCreateFromGIF( $sFile );
        } else {
            return false;
        }
    }

    /**
     * ImageConverter::_saveImage()
     *
     * Private: function to save the new image
     *
     * @param resource $rImg: the image to save
     * @param string $sDestination: how to save the new image
     * @param int $iQuality: the quality of the new image 
     * @return bool: true of succes and false on failure
     */
    function _saveImage( &$rImage, $sDestination, $iQuality = null ) {
        $sExt = $this->_getExtension( $sDestination );

        if($sExt == 'jpg' || $sExt == 'jpeg') {
            return ImageJPEG($rImage, $sDestination, $iQuality);
        } elseif($sExt == 'png') {
            return ImagePNG($rImage, $sDestination);
        } else {
            trigger_error('Wrong destination given!', E_USER_WARNING );
            return false;
        }
    }
}
?>