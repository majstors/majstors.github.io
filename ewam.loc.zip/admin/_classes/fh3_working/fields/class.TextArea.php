<?php

/**
* class TextArea
*
* Create a textarea
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/04 13:08:55 $
*/
class TextArea extends Field {
    
    var $_iCols;   // int: number of colums which the textarea should get
    var $_iRows;   // int: number of rows which the textarea should get
    
    /**
     * TextArea::TextArea()
     *
     * Public constructor: create a new textarea
     *
     * @param object &$oForm: The form where this field is located on
     * @param string $sName: The name of the field
     * @return void
     */
    function TextArea( &$oform, $sName ) {
        // call the constructor of the Field class
        $this->Field( $oform, $sName );
        
        $this->setCols( 40 );
        $this->setRows( 7 );        
    }
    
    /**
     * TextArea::setCols()
     *
     * Public: set the number of cols of the textarea
     *
     * @param integer $iCols: the number of cols
     * @return void
     */
    function setCols( $iCols ) {
        $this->_iCols = $iCols;     
    }
    
    /**
     * TextArea::setRows()
     *
     * Public: set the number of rows of the textarea
     *
     * @param integer $iRows: the number of rows
     * @return void
     */  
    function setRows( $iRows ) {
        $this->_iRows = $iRows;
    }
    
    /**
     * TextArea::getField()
     *
     * Public: return the HTML of the field
     *
     * @return string: the html of the field
     */
    function getField() {
        return 
        '<textarea '.
        'name="'.$this->_sName.'" '.
        'id="'.$this->_sName.'" '.
        'cols="'.$this->_iCols.'" '.
        'rows="'.$this->_iRows.'"'.
        (isset($this->_iTabIndex) ? ' tabindex="'.$this->_iTabIndex.'" ' : '').
        (isset($this->_sExtra) ? ' '.$this->_sExtra :'').'>'.        
        (isset($this->_mValue) ? htmlspecialchars($this->_mValue) : '').
        '</textarea>';
    }
}

?>