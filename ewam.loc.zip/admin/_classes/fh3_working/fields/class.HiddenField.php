<?php

/**
* class HiddenField
*
* Create a hiddenfield on the given form
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/02 16:26:25 $
*/
class HiddenField extends Field {
    
    /**
     * HiddenField::getField()
     *
     * Public: Return the HTMl of the field
     *
     * @return string: The html of the field
     */
    function getField() {
        return 
        '<input type="hidden" '.
        'name="'.$this->_sName.'" '.
        'id="'.$this->_sName.'" '.
        'value="'.(isset( $this->_mValue ) ? htmlspecialchars($this->_mValue) : '').'" '.
        (isset($this->_sExtra) ? $this->_sExtra.' ' :'')."/>";
    }
    
}

?>