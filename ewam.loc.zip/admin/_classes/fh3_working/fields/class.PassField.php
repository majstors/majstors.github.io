<?php

/**
* class PassField
*
* Create a PassField
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/04 13:08:55 $
*/
class PassField extends TextField {
    var $_sPre;
    
    /**
     * PassField::PassField()
     *
     * Public constructor: Create a new passfield object
     *
     * @param object $oForm: The form where the field is located on
     * @param string $sName: The name of the form
     * @return void
     */
    function PassField(&$oForm, $sName) {
        // call the constructor of the Field class
        $this->Field($oForm, $sName);
        
        $this->_sPre = '';
        $this->setSize( 20 );
        $this->setMaxlength( 0 );
    }
       
    /**
     * PassField::getField()
     *
     * Public: return the HTML of the field
     *
     * @return string: the html
     */
    function getField() {
        return 
        $this->_sPre .
        '<input type="password" '.
        'name="'.$this->_sName.'" '.
        'id="'.$this->_sName.'" '.
        'size="'.$this->_iSize.'" '.
        (!empty($this->_iMaxlength) ? 'maxlength="'.$this->_iMaxlength.'" ':'').
        (isset($this->_iTabIndex) ? ' tabindex="'.$this->_iTabIndex.'" ' : '').
        (isset($this->_sExtra) ? $this->_sExtra.' ' :'')."/>";
    }
    
    /**
     * PassField::setPre()
     *
     * Set the message above the passfield
     *
     * @param string $sMsg: the message
     * @return void
     */
    function setPre( $sMsg) {
        $this->_sPre = $sMsg;
    }
    
    
    /**
     * PassField::checkPassword()
     *
     * Public: check the value of this field with another passfield
     *
     * @param object $oObj
     * @return boolean: true if the values are correct, false if not
     */
    function checkPassword( &$oObj ) {        
        // if the fields doesn't match
        if($this->getValue() != $oObj->getValue()) {
            $this->_sError = $this->_oForm->_text( 15 );
            return false; 
        } else {
            // if edit and no value.. keep the original
            if($this->getValue() == '') {
                if($this->_oForm->edit) {
                    
                    $this->_oForm->_dontSave[] = $this->_sName;
                    $this->_oForm->_dontSave[] = $oObj->_sName;
                    
                    
                    // make sure that no validator is overwriting the messages...
                    $this->setValidator( null );
                    $oObj->setValidator( null );
                } else {
                    $this->_sError = $this->_oForm->_text( 16 );
                    return false;
                }
            } else {
                # is the password not to short ?                
                if(strLen($this->getValue()) < FH_MIN_PASSWORD_LENGTH ) {
                    $this->_sError = sprintf( $this->_oForm->_text( 17 ), FH_MIN_PASSWORD_LENGTH );
                    return false;
                } else if( ! Validator::IsPassword($this->getValue()) ) {
                    $this->_sError = $this->_oForm->_text( 18 );
                    return false;
                }                
            }
        }
        return true;
    }    
}

?>