<?php

/**
* class dbSelectField
*
* Create a select field from records retrieved from the db
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/18 10:16:46 $
*/
class dbSelectField extends SelectField {
    var $_oDb;
	
	function dbSelectField( &$oForm, $sName, &$oDb, $sTable, $mFields ) {
	    // call the constructor of the selectfield
		$this->SelectField( $oForm, $sName );
		
		// make sure that the fields are set in an array
		$aFields = !is_array($mFields) ? array( $mFields ) : $mFields;
		
		if(sizeof( $aFields) == 2) {
		    $this->useArrayKeyAsValue( true );
		}
		
		// generate the query to retrieve the records
		$sQuery = 
		  'SELECT '. implode(', ', $aFields).
		  ' FROM '.$sTable.
		  ' ORDER BY '.(isset($aFields[1]) ? $aFields[1] : $aFields[0]);
		  
		  
		// get the records and load the options
		$this->_aOptions = array( '' => '' );  
		$oDb->query( $sQuery );  
		while( $row = $oDb->getRecord() ) {
		    if(sizeof($row) == 2) {
		        $this->_aOptions[$row[$aFields[0]]] = $row[$aFields[1]];
		    } else {
		        $this->_aOptions[] = $row[$aFields[0]];
		    }
		}
 	}	
}

?>