<?php

/**
* class TextField
*
* Create a textfield
*
* Created by: T. Heimans
* Revision: $Date: 2005/05/04 13:08:55 $
*/
class TextField extends Field {
    var $_iSize;         // int: the size of the field
    var $_iMaxlength;    // int: the maxlength of the field 

    /**
     * TextField::TextField()
     *
     * Public constructor: Create a new textfield object
     *
     * @param object &$oForm: The form where this field is located on
     * @param string $sName: The name of the field
     * @return void
     */
    function TextField( &$oForm, $sName ) {
        // call the constructor of the Field class
        $this->Field($oForm, $sName);
        
        $this->setSize( 20 );
        $this->setMaxlength( 0 );
    }
    
    /**
     * TextField::setSize()
     *
     * Public: set the new size of the field
     *
     * @param integer $iSize: the new size
     * @return void
     */
    function setSize( $iSize ) {
        $this->_iSize = $iSize;
    }
    
    
    /**
     * TextField::setMaxlength()
     *
     * Public: set the new maxlength of the field
     *
     * @param integer $iMaxlength: the new maxlength
     * @return void
     */
    function setMaxlength( $iMaxlength ) {
        $this->_iMaxlength = $iMaxlength;
    }
    
    /**
     * TextField::getField()
     *
     * Public: return the HTML of the field
     *
     * @return string: the html
     */
    function getField() {
        return 
        '<input type="text" '.
        'name="'.$this->_sName.'" '.
        'id="'.$this->_sName.'" '.
        'value="'.(isset($this->_mValue) ? htmlspecialchars($this->_mValue):'').'" '.
        'size="'.$this->_iSize.'" '.
        (!empty($this->_iMaxlength) ? 'maxlength="'.$this->_iMaxlength.'" ':'').
        (isset($this->_iTabIndex) ? ' tabindex="'.$this->_iTabIndex.'" ' : '').
        (isset($this->_sExtra) ? $this->_sExtra.' ' :'')."/>";
    }
}

?>