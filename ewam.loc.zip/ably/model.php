<?php

class Model {

    var $aMenu = array();
    var $sLang = 'sr';
    var $iStartID = false;
    var $oT = false;
    var $aPath = false;
    var $aPage = false;
    var $aStart = false;
    var $aLangs = false;
    var $aIntroPage = false;
    var $aArchivePageID = false;
    var $aAnalisysPageID = false;
    var $aFirstArchivePage = false;

    function __construct($aPath) {

        if ($aPath === false)
            return;

        global $DBCON, $sLang;
        $this->sLang = $sLang;
        $this->aPath = $aPath;
        
        
        $this->oT = new HtmlDbTree($DBCON, '_structure', $fields = null, $autoload = TRUE, $Q_STR = null);


        $aStart = $DBCON->select_single_to_array('_structure', '*', "WHERE layout='lang' AND title='{$this->sLang}'");
        $this->iStartID = $aStart['id'];
        $this->aLangs = $DBCON->select_to_array('_structure', '*', "WHERE layout='lang' AND public='1'");

        $aMenu = $this->oT->get_tree($startnode = $this->iStartID, $depth = 3, $inc_startnode = FALSE);

        $aMenu = $this->sortNews($aMenu);

        $this->aMenu = $this->setTree($aMenu);

        //$this->aFirstArchivePage = $this->getFirstArchive($this->aMenu[$this->aArchivePageID]['subpages']);
        $this->aHomeNews = $this->getHomeNews($this->aMenu[$this->aArchivePageID]['subpages']);

        $this->aPage = $this->getCurrentPage($aPath);

        //$this->dd($aMenu);
        //$this->dd($this->aMenu);
    }

    function sl($L) {
        die('<pre>' . print_r($L, true) . '<pre>');
    }

    static function usort_helper($a, $b) {
        if ($a['pubdate'] == $b['pubdate'])
            return 0;
        return ($a['pubdate'] > $b['pubdate']) ? -1 : 1;
    }

    function sortNews($aMenu) {

        $aNews = array();

        foreach ($aMenu as $K => $V) {
            if (strpos($V['tags'], 'news') !== false) {
                $aNews[$K] = $V;
            }
        }

        usort($aNews, "Model::usort_helper");
        
        $aNewsWK = array();
        
        foreach ($aNews as $K => $V) {
            $aNewsWK[$V['id']]=$V;
        }
        
        $aNews = $aNewsWK;

        $aNewsKeys = array_keys($aNews);
        $aNewMenu = array();
        $iK = 0;

        //$this->sl($aNewsKeys);
        
        foreach ($aMenu as $K => $V) {
            if (strpos($V['tags'], 'news') !== false) {
                $sKey = $aNewsKeys[$iK];
                $iK++;
                $aNewMenu[$sKey] = $aNews[$sKey];
            } else {
                $aNewMenu[$K] = $V;
            }
        }

        return $aNewMenu;
    }

    function getHomeNews($aPages) {

        $i = 3;
        $aHomeNews = array();

        foreach ($aPages as $K => $V) {
            if ($V['tags'] == 'news') {
                $aHomeNews[] = $this->fixForHomeContent($V);
                $i--;
            }
            if ($i == 0)
                break;
        }

        return $aHomeNews;
    }

    function fixForHomeContent($V) {
        $V['first_image'] = $this->getFirstImage($V['content']);

        return $V;
    }

    function getFirstImage($sContent) {
        $output = preg_match_all("/<img[^']*?src=\"([^']*?)\"[^']*?>/i", $sContent, $matches);
        return $matches[1][0];
    }

    function getFirstArchive($aPages) {
        foreach ($aPages as $K => $V) {
            if ($V['tags'] != 'intro')
                return $V;
        }
        return $V;
    }

    function getCurrentPage($aPath) {

        global $DBCON;

        $sURL = $aPath[1];


        if (isset($aPath[2])) {
            if (in_array($this->aPath[1], array('sr', 'en', 'hu')))
                $sURL = $aPath[2];
        } else {
            $aPages = $this->oT->get_tree($startnode = $this->iStartID, $depth = 1, $inc_startnode = FALSE);
            $aFirstPage = array_shift($aPages);
            $sURL = $aFirstPage['page_url'];
        }

        $sURL = mysql_real_escape_string($sURL);
        
        $sURL = urldecode($sURL);

        //$this->dd($sURL);

        return $DBCON->select_single_to_array('_structure', '*', "WHERE page_url='{$sURL}'");
    }

    function getTextBox($sTextBoxName) {
        global $DBCON;
        $sTextBoxName = mysql_real_escape_string($sTextBoxName);

        $aText = $DBCON->select_single_to_array('text_boxes', '*', "WHERE `position`='$sTextBoxName' and `lang`='{$this->sLang}'");

        if ($aText) {
            return $aText['text'];
        } else {
            return '';
        }
    }

    function dd($A) {
        print '<pre>';
        die(print_r($A, true));
    }

    function setTree($T) {


        foreach ($T as $K => $V) {
            
            //unset($V['content']);

            $V['shorten_title'] = $V['title'];
            if (strlen($V['title']) > 20) {
                //$V['shorten_title'] = substr($V['title'], 0, 40) . '…';
                $V['shorten_title'] = mb_strimwidth($V['title'], 0, 60, '…', 'utf-8');
            }

            if ($V['layout'] == 'home' || $V['public'] == '0') {
                unset($T[$K]);
            } else {
                if ($V['relative_level'] == 2) {

                    $T[$V['parent']]['subpages'][$K] = $V;

                    if ($V['parent'] == '')
                        die();

                    unset($T[$K]);
                    
                    $iLastParent = $V['parent'];
                }
                
                if ($V['relative_level'] == 3) {

                    $T[$iLastParent]['subpages'][$V['parent']]['subpages'][$K] = $V;

                    if ($V['parent'] == '')
                        die();

                    unset($T[$K]);
                }
                
            }

            if ($V['tags'] == 'intro')
                $this->aIntroPage = $V;

            if ($V['tags'] == 'archive')
                $this->aArchivePageID = $V['id'];
            if ($V['tags'] == 'analisys')
                $this->aAnalisysPageID = $V['id'];
        }

        //$this->dd($T);

        return $T;
    }

    function truncateHTML($str, $len, $end = '&hellip;') {
        //find all tags
        $tagPattern = '/(<\/?)([\w]*)(\s*[^>]*)>?|&[\w#]+;/i';  //match html tags and entities
        preg_match_all($tagPattern, $str, $matches, PREG_OFFSET_CAPTURE | PREG_SET_ORDER);
        //WSDDebug::dump($matches); exit; 
        $i = 0;
        //loop through each found tag that is within the $len, add those characters to the len,
        //also track open and closed tags
        // $matches[$i][0] = the whole tag string  --the only applicable field for html enitities  
        // IF its not matching an &htmlentity; the following apply
        // $matches[$i][1] = the start of the tag either '<' or '</'  
        // $matches[$i][2] = the tag name
        // $matches[$i][3] = the end of the tag
        //$matces[$i][$j][0] = the string
        //$matces[$i][$j][1] = the str offest

        while ($matches[$i][0][1] < $len && !empty($matches[$i])) {

            $len = $len + strlen($matches[$i][0][0]);
            if (substr($matches[$i][0][0], 0, 1) == '&')
                $len = $len - 1;


            //if $matches[$i][2] is undefined then its an html entity, want to ignore those for tag counting
            //ignore empty/singleton tags for tag counting
            if (!empty($matches[$i][2][0]) && !in_array($matches[$i][2][0], array('br', 'img', 'hr', 'input', 'param', 'link'))) {
                //double check 
                if (substr($matches[$i][3][0], -1) != '/' && substr($matches[$i][1][0], -1) != '/')
                    $openTags[] = $matches[$i][2][0];
                elseif (end($openTags) == $matches[$i][2][0]) {
                    array_pop($openTags);
                } else {
                    $warnings[] = "html has some tags mismatched in it:  $str";
                }
            }


            $i++;
        }

        $closeTags = '';

        if (!empty($openTags)) {
            $openTags = array_reverse($openTags);
            foreach ($openTags as $t) {
                $closeTagString .="</" . $t . ">";
            }
        }

        if (strlen($str) > $len) {
            //truncate with new len
            $truncated_html = substr($str, 0, $len);
            //add the end text
            $truncated_html .= $end;
            //restore any open tags
            $truncated_html .= $closeTagString;
        } else
            $truncated_html = $str;


        return $truncated_html;
    }

    function getMapLocations() {
        global $DBCON, $iDBFaza;
        return $DBCON->select_to_array('locations', '*', 'WHERE faza=' . $iDBFaza);
    }

    function getVodaMesto() {
        global $DBCON, $iDBFaza;
        return $DBCON->select_to_array('voda', 'DISTINCT mesto', 'WHERE faza=' . $iDBFaza . ' ORDER BY mesto');
    }

    function getSedimentMesto() {
        global $DBCON, $iDBFaza;
        return $DBCON->select_to_array('sedimenti', 'DISTINCT mesto', 'WHERE faza=' . $iDBFaza . ' ORDER BY mesto');
    }

    function getVodaTable($id) {
        global $DBCON, $iDBFaza;
        return $DBCON->select_to_array('voda', '*', 'WHERE mesto=\'' . $id . '\' AND faza=' . $iDBFaza . ' ORDER BY id');
    }

    function getSedimentTable($id) {
        global $DBCON, $iDBFaza;
        return $DBCON->select_to_array('sedimenti', '*', "WHERE mesto='$id' AND faza=$iDBFaza" . ' ORDER BY id');
    }

    function getSedimentPars() {
        global $DBCON, $iDBFaza;
        
        $aPF = $DBCON->select_to_array('sedimenti', 'DISTINCT parametar_id', "WHERE faza=$iDBFaza");
        
        
        
        $aIN = array();
        
        foreach($aPF as $K=>$V) {
            $aIN[] = (int) $V['parametar_id'];
        }
		
		
        
        //die(print_r($aIN, true));
        
        $aPars = $DBCON->select_to_array('parametri_sedimenti', '*', 'WHERE id in (' . implode(',', $aIN) . ')');


        $aRet = array();

        foreach ($aPars as $K => $V) {
            $aRet[$V['id']] = $V['parametar'];
        }

        return $aRet;
		
		//die(print_r($aPars, true));
    }

    function getSedimentData($id) {
        global $DBCON, $iDBFaza;
        $aPars = $DBCON->select_to_array('sedimenti', '*', "WHERE parametar_id=$id AND faza='$iDBFaza' ORDER by mesto");



        $title = "{$aPars[0]['parametar']} ({$aPars[0]['jedinica_mere']})";



        $data = array();

        $data[] = array('Mesto', 'Izmerena vrednost');



        foreach ($aPars as $K => $V) {
            $data[] = array($V['mesto'], $this->fixInt($V['izmerena_vrednost']));
        }


        return array('data' => $data, 'title' => $title);
    }

    function fixInt($I) {
        return (float) str_replace(',', '.', $I);
    }

}

?>
