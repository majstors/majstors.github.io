<?php include_once(TEMPLATES_DIR . '/components/header.php'); ?>
<div id="content_container">
    <?php include_once(CONTENT_DIR . "/$sLang/home.php"); ?>
</div>
<div id="side_bar">
    <h2>Partneri</h2>
    <p>
        <a href="#" class="partner_links" id="vode_vojvodine">Javno vodoprivredno preduze?e "Vode Vojvodine", Novi Sad</a>
        <a href="#" class="partner_links" id="fond_ep">Fond "Evropski Poslovi" Autonomne Pokrajine Vojvodine</a>
        <a href="#" class="partner_links" id="ati_vizig">Alsó-Tisza-vidéki Vízügyi Igazgatóság</a>
    </p>

</div>
<br clear="all"/>
<?php include_once(TEMPLATES_DIR . '/components/footer.php'); ?>            