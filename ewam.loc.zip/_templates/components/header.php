<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN" "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>eWAM - <?php echo $M->aPage['title']; ?></title>
        <meta name="title" content="eWAM" />        
        <meta name="description" content="eWAM" />
        <link rel="stylesheet" href="/css/reset.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="/css/style.css?ac=<?php echo md5(time()); ?>" type="text/css" media="screen" />
        <!-- link rel="stylesheet" href="/css/menu7.css" type="text/css" media="screen" / -->
        <link rel="stylesheet" href="/css/bjqs.css" type="text/css" media="screen" />
        <link rel="stylesheet" type="text/css" href="/css/flatmenu.css" media="all"/>
    </head>
    <body class="">
        <div id="topbar">
            <div class="pw">
                <div id="topbar_title">
                    <?php echo $M->getTextBox('HEADLINE'); ?>
                </div>
                <div id="functions_nav">
                    <ul>
                        <?php foreach ($M->aLangs as $K => $V): ?>
                            <li><a href="/<?php echo $V['page_url']; ?>"><?php echo strtoupper($V['title']); ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
        <div id="logobar">
            <div class="pw">
                <div id="logo_left"><a href="http://www.hu-srb-ipa.com"><img src="/img/hun_srb_logo_<?php echo strtolower($M->sLang); ?>.png"/></a></div>
                <div id="logo_center">
                    <a href="#"><img src="/img/ewam_logo.png"/></a><br/>
                    Ref. br. HUSRB/1203/121/237                    
                </div>
                <div id="logo_right"><a href="http://europa.eu/"><img src="/img/eu_logo_<?php echo strtolower($M->sLang); ?>.png"/></a></div>
            </div>
        </div>
        <div id="menu_bar">
            <div class="pw">
                <div id="home_link" style="float: left"><a href="/<?php echo "{$M->sLang}"; ?>"><img src="/img/icons/home.png"/></a></div>
                <div class="nav green-black">
                    <ul class="dropdown clear">


                        <?php foreach ($M->aMenu as $K => $V): ?>
                            <li class="<?php echo (isset($V['subpages'])) ? 'sub' : '' ?>">
                                <?php
                                $sAttrURL = ($V['layout'] != 'folder') ?
                                        "href=\"/{$M->sLang}/{$V['page_url']}\"" :
                                        "href=\"#\" onclick=\"return false;\"";
                                ?>
                                <a <?php echo $sAttrURL; ?>><?php echo $V['title']; ?></a>

                                <?php if (isset($V['subpages'])): ?>
                                    <ul>
                                        <?php foreach ($V['subpages'] as $K1 => $V1): ?>
                                            <li class="<?php echo (isset($V1['subpages'])) ? 'sub' : '' ?>"><a href="/<?php echo "{$M->sLang}/{$V1['page_url']}"; ?>"><?php echo $V1['shorten_title']; ?></a>
                                                <?php if (isset($V1['subpages'])): ?>
                                                    <ul>
                                                        <?php foreach ($V1['subpages'] as $K2 => $V2): ?>
                                                            <li><a href="/<?php echo "{$M->sLang}/{$V2['page_url']}"; ?>"><?php echo $V2['shorten_title']; ?></a>    
                                                            </li>
                                                        <?php endforeach; ?>    
                                                    </ul>
                                                <?php endif; ?>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>

                            </li>
                            <li class="divider"></li>
                        <?php endforeach; ?>






                        <!-- li class="sub">
                            <a href="#">Home</a>
                            <ul>
                                <li><a href="#">Welcome</a></li>
                                <li><a href="#">Take Virtual Tour</a></li>
                            </ul>
                        </li>
                        <li class="divider"></li>
                        <li class="sub">
                            <a href="#">The Company</a>
                            <ul>
                                <li class="sub">
                                    <a href="#">Where We Operate</a>
                                    <ul>
                                        <li><a href="#">Canada</a></li>
                                        <li><a href="#">Australia</a></li>
                                        <li><a href="#">Germany</a></li>
                                        <li><a href="#">Russia</a></li>
                                        <li><a href="#">South Africa</a></li>
                                    </ul>
                                </li>
                                <li class="sub">
                                    <a href="#">Our Partners</a>
                                    <ul>
                                        <li><a href="#">Microsoft</a></li>
                                        <li><a href="#">Apple Inc</a></li>
                                        <li><a href="#">Mastercard </a></li>
                                        <li><a href="#">Some Partners usually have extremely long annoying names</a></li>
                                    </ul>
                                </li>
                                <li><a href="#">Our Vision</a></li>
                                <li><a href="#">Background</a></li>
                                <li><a href="#">History</a></li>
                                <li><a href="#">Much More</a></li>
                            </ul>
                        </li>
                        <li class="divider"></li>
                        <li class="sub">
                            <a href="#">Our Services</a>
                            <ul>
                                <li><a href="#">Website Design </a></li>
                                <li><a href="#">Application Development</a></li>
                                <li><a href="#">Search Engine Optimization</a></li>
                                <li><a href="#">3D Motion Graphics</a></li>
                                <li><a href="#">Corporate Branding</a></li>
                            </ul>
                        </li>
                        <li class="divider"></li>
                        <li><a href="#">Latest</a></li>
                        <li class="divider"></li>
                        <li><a href="#">Portfolio</a></li>
                        <li class="divider"></li>
                        <li class="sub rtl">
                            <a href="#">Multi Level</a>
                            <ul>
                                <li><a href="#">Use Email</a></li>
                                <li><a href="#">Newsletter</a></li>
                                <li class="sub rtl">
                                    <a href="#">Use the following steps to send us a letter through post office - Standard Mail may arrive some day in 2020</a>
                                    <ul>
                                        <li><a href="#">Step 1 - Conceptualize</a></li>
                                        <li><a href="#">Step 2 - Get A Paper</a></li>
                                        <li><a href="#">Step 3 - Get A Pen</a></li>
                                        <li><a href="#">Step 4 - Start Writing</a></li>
                                        <li class="sub">
                                            <a href="#">Step 5 - Visualize</a>
                                            <ul>
                                                <li><a href="#">Visualize Words</a></li>
                                                <li><a href="#">Visualize Letters</a></li>
                                                <li class="sub ltr">
                                                    <a href="#">Visualize Characters</a>
                                                    <ul>
                                                        <li><a href="#">Continue Trail 1</a></li>
                                                        <li><a href="#">Continue Trail 2</a></li>
                                                        <li class="sub">
                                                            <a href="#">Continue Trail 3</a>
                                                            <ul>
                                                                <li><a href="#">Finally We Land</a></li>
                                                                <li><a href="#">Well Be Back </a></li>
                                                                <li><a href="#">How was the Journey?</a></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#">Continue Trail 4</a></li>
                                                        <li><a href="#">Continue Trail 5</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">Finish Visualization</a></li>
                                                <li><a href="#">Set The Tone </a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="#">Walk to our offices</a></li>
                                <li><a href="#">Fill this form</a></li>
                            </ul>
                        </li>
                        <li class="divider"></li-->
                    </ul>
                </div> 

            </div>
        </div>
        <div id="slider_bar">
            <!--
            <div class="pw" id="slider_container">
                <img src="/img/slider/jegricka_1.jpg"/>
                <div id="slider_over"><img src="/img/dobri_susedi.png"/></div>
            </div>
            -->

            <div id="slider_container" class="pw">
                <ul class="bjqs">
                    <li><img src="/img/slider/jegricka_1.jpg"/></li>
                    <li><img src="/img/slider/jegricka_2.jpg"/></li>
                    <li><img src="/img/slider/jegricka_3.jpg"/></li>
                    <li><img src="/img/slider/jegricka_4.jpg"/></li>
                    <li><img src="/img/slider/kurcsa_1.jpg"/></li>                    
                    <li><img src="/img/slider/kurcsa_2.jpg"/></li>                    
                    <li><img src="/img/slider/kurcsa_3.jpg"/></li>
                </ul>
                <div id="slider_over"><img src="/img/dobri_susedi_<?php echo strtolower($M->sLang); ?>.png"/></div>
            </div>


        </div>
        <div id="content_bar">
            <div class="pw">