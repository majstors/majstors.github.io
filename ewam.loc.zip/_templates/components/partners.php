<?php if ($M->sLang=='sr'): ?>
<h2>Partneri</h2>
<p>
    <a href="/sr/381" class="partner_links" id="vode_vojvodine">Javno vodoprivredno preduzeće "Vode Vojvodine", Novi Sad</a>
    <a href="/sr/382" class="partner_links" id="fond_ep">Fond "Evropski Poslovi" Autonomne Pokrajine Vojvodine</a>
    <a href="/sr/383" class="partner_links" id="ati_vizig">Uprava za vodoprivredu za područje Donja Tisa</a>
</p>
<?php endif; ?>
<?php if ($M->sLang=='en'): ?>
<h2>Partners</h2>
<p>
    <a href="/en/406" class="partner_links" id="vode_vojvodine">Public Water Management Company "Vode Vojvodine" Novi Sad</a>
    <a href="/en/407" class="partner_links" id="fond_ep">European Affairs Fund of Autonomous Province of Vojvodina</a>
    <a href="/en/408" class="partner_links" id="ati_vizig">Lower Tisza District Water Directorate</a>
</p>
<?php endif; ?>
<?php if ($M->sLang=='hu'): ?>
<h2>Partnerek</h2>
<p>
    <a href="/hu/431" class="partner_links" id="vode_vojvodine">Vode Vojvodine (Vajdasági-Vizek Vízgazdálkodási Vállalat), Újvidék</a>
    <a href="/hu/432" class="partner_links" id="fond_ep">Vajdaság Autonóm Tartomány Európai Ügyek Alapja</a>
    <a href="/hu/433" class="partner_links" id="ati_vizig">Alsó-Tisza-vidéki Vízügyi Igazgatóság</a>
</p>
<?php endif; ?>
