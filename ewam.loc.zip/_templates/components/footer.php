﻿</div>
</div>
<div id="footer_bar">
    <div class="pw" id="disclaimer_text">
        <p>
            <?php echo $M->getTextBox('DISCLAIMER'); ?>
        </p>
    </div>
    <div class="pw" id="footer_links">|
        <?php foreach ($M->aMenu as $K => $V): ?>
            <a href="<?php echo "/{$M->sLang}/{$V['page_url']}"; ?>"><?php echo $V['title']; ?></a>|
        <?php endforeach; ?>
    </div>
</div>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script type="text/javascript" src="/js/jquery.min.js"></script>
<script type="text/javascript" src="/js/jquery.gmap.min.js"></script>
<script type="text/javascript" src="/js/bjqs-1.3.min.js"></script>
<script type="text/javascript" src="js/flatmenu-responsive.js"></script>
<!-- script type="text/javascript" src="/js/custom.js"></script -->
<script type="text/javascript">
            
    jQuery(document).ready(function($) {
        $('#slider_container').bjqs({
            'height' : 396,
            'width' : 960,
            'responsive' : true,

            // animation values
            animtype : 'fade', // accepts 'fade' or 'slide'
            animduration : 1000, // how fast the animation are
            animspeed : 5000, // the delay between each slide
            automatic : true, // automatic

            // control and marker configuration
            showcontrols : false, // show next and prev controls
            centercontrols : true, // center controls verically
            nexttext : 'Next', // Text for 'next' button (can use HTML)
            prevtext : 'Prev', // Text for 'previous' button (can use HTML)
            showmarkers : false, // Show individual slide markers
            //centermarkers : true, // Center markers horizontally

            // interaction values
            //keyboardnav : true, // enable keyboard navigation
            //hoverpause : true, // pause the slider on hover

            // presentational options
            //usecaptions : true, // show captions for images using the image title tag
            //randomstart : true, // start slider at random slide
            //responsive : true // enable responsive capabilities (beta)
            lastoption: false
  
        });
        
    });
    
    $(document).ready(function(){
        $('#tabs div').hide();
        $('#tabs div:first').show();
        $('#tabs ul li:first').addClass('active');
 
        $('#tabs ul li a').click(function(){
            $('#tabs ul li').removeClass('active');
            $(this).parent().addClass('active');
            var currentTab = $(this).attr('href');
            $('#tabs div').hide();
            $(currentTab).show();
            $('#chart_div').html('');
            return false;
        });
    });



            
</script>
</body>
</html>